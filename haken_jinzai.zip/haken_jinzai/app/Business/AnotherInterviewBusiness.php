<?php
namespace App\Business;

use App\Model\AnotherInterview;
use App\Model\AnotherInterviewTime;
use App\Model\Region;
use App\Model\Staff;

class AnotherInterviewBusiness {

    /**
     * Get interview of another region by id
     * @param $anotherInterviewId
     * @return mixed
     */
    public function getAnotherInterviewById($anotherInterviewId) {
        return AnotherInterview::find($anotherInterviewId);
    }

    /**
     * Get interview of another region
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAllAnotherInterview() {
        return AnotherInterview::all();
    }

    /**
     * Add new schedule for another place list
     * @param $staffData
     * @return string
     */
    public function addNewAnotherSchedule($staffData) {
        if($staffData['staffId']) {
            $anotherInterviewTimeId = $staffData['anotherInterviewTimeId'];
            $staffId = $staffData['staffId'];
            $anotherInterviewTime = AnotherInterviewTime::find($anotherInterviewTimeId);
            
            $interviewCount = count(AnotherInterview::where('AnotherInterviewTimeId', $anotherInterviewTimeId)->get());
            $interviewDuplicate = AnotherInterview::where('StaffId',$staffId)->get();
            if ($interviewCount + 1 > $anotherInterviewTime->InterviewPeople) {
                return  trans('title.pre-register.warning.max_people');
            }
            if (count($interviewDuplicate)>0) {
                return trans('title.pre-register.warning.duplicate');
            }
            $anotherInterview = new AnotherInterview();
            $anotherInterview->StaffId = $staffId;
            $anotherInterview->AnotherInterviewTimeId = $anotherInterviewTimeId;
            $anotherInterview->save();
            $staff = Staff::find($staffId);
            $staff->InterviewDate = $anotherInterviewTime->Date;
            $staff->save();
            return trans('title.pre-register.warning.success_add');
        }
    }

    public function getAnotherInterviewByStaffId($staffId) {
        return AnotherInterview::where('StaffId',$staffId)->get();
    }

    /**
     * Get anotherInterviewByAnotherInterviewTimeId method
     * @param $anotherInterviewtimeId
     * @return $array/null
     */
    public function getAnotherInterviewByAnotherInterviewTimeId($notherInterviewTimeId){
        return AnotherInterview::where('AnotherInterviewTimeId',$notherInterviewTimeId)->first();
    }
}