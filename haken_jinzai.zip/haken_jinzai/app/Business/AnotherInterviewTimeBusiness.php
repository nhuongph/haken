<?php

//====================================================================================
//
//	FILENAME: AnotherInterviewTimeBusiness.php
//	CREATE: 20150517
//	CREATOR: RikkeiSoft
//
//====================================================================================
//
//	MODIFY: 20150517
//	MODIFER: RikkeiSoft
//	CONTENT: 
//
//------------------------------------------------------------------------------------
//	MODIFY: YYYYMMDD
//	MODIFER: RikkeiSoft
//	CONTENT:
//
//====================================================================================

namespace App\Business;

use App\Model\AnotherInterviewTime;
use App\Model\InterviewTime;

class AnotherInterviewTimeBusiness
{
	/**
	 * Add new another interview time
	 * @param $anotherInterviewInfo
	 */
	public function addAnotherInterviewTime($anotherInterviewInfo) {
		$anotherInterview = new AnotherInterviewTime();
		$anotherInterview->RegionName = $anotherInterviewInfo['regionName'];
		$anotherInterview->Date = $anotherInterviewInfo['date'];
		$anotherInterview->ResponsibleName = $anotherInterviewInfo['responsibleName'];
		$anotherInterview->Phone = $anotherInterviewInfo['phone'];
		$anotherInterview->Email = $anotherInterviewInfo['email'];
		$anotherInterview->InterviewPeople = $anotherInterviewInfo['interviewPeople'];
		$anotherInterview->save();
	}

	/**
	 * Get another interview time list
	 * @return mixed
	 */
	public function getAnotherInterviewTimeList() {

		$anotherInterviewTime = AnotherInterviewTime::orderBy('Date','Asc');
		return $anotherInterviewTime;
	}

	/**
	 * Get another interview time list
	 * @return mixed
	 */
	public function getAnotherInterviewTimeSchedule() {

		$anotherInterviewTime = AnotherInterviewTime::orderBy('Date','Asc')->groupby('Date')->get();
		return $anotherInterviewTime;
	}
	/**
	 * Get another interview time list by date
	 * @return mixed
	 */
	public function getAnotherInterviewTimeByDate($interviewDate) {
		return AnotherInterviewTime::where('Date',$interviewDate)->orderBy('Date','ASC')->get();
	}
}