<?php
namespace App\Business;
use App\Model\Brand;
use Illuminate\Support\Facades\Hash;
use DB;

class BrandBusiness {

	public function brandData($brandData,$brandId){
        $brand = Brand::find($brandId);
        //Check if brand exist
        if(!$brand) {
             $brand = new Brand();
        }
        //test git
        $brand->ManagementName 	= $brandData['ManagementName'];
        $brand->DisplayName 	= $brandData['DisplayName'];
        $brand->Remarks 		= $brandData['Remarks'];
        $brand->save();
        return $brand;
    }


    public function brandSettingReport($settingReportData){
        $settingReportData = new SettingReport();
        $settingReportData->Type1  = '';
        $settingReportData->save();
        return $settingReportData;

    }

    public function brandListData(){
        $brandList = DB::table('t_brand')
            ->select('t_brand.created_at','t_brand.ManagementName', 't_brand.DisplayName','t_brand.Remarks','t_brand.id')
            ->get();

        return $brandList ;  
    }

    public function getDetailsBrand($id){
        $brandListDetails = DB::table('t_brand')
            ->select('t_brand.created_at','t_brand.ManagementName', 't_brand.DisplayName','t_brand.Remarks','t_brand.id')
            ->where('t_brand.id',$id)
            ->get();

        return $brandListDetails ;
    }


    

}