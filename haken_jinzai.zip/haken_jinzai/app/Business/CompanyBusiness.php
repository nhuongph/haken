<?php

//====================================================================================
//
//	FILENAME: CompanyBusiness.php
//	CREATE: 20150516
//	CREATOR: RikkeiSoft
//
//====================================================================================
//
//	MODIFY: 20150516
//	MODIFER: RikkeiSoft
//	CONTENT: 
//
//------------------------------------------------------------------------------------
//	MODIFY: YYYYMMDD
//	MODIFER: RikkeiSoft
//	CONTENT:
//
//====================================================================================

namespace App\Business;

use App\Model\Company;
use App\Model\SubCompany;
use App\Model\Orders;

class CompanyBusiness
{
    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: get company by Id
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company id
    * @return company
    *----------------------------
    */    
    public function getCompanyById($companyId){
      return Company::find($companyId);
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: get sub company by Id
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company id
    * @return sub company
    *----------------------------
    */  
    public function getSubCompanyById($companyId){
      return SubCompany::find($companyId);
    }

    public function saveCompany($company, $subcompany, $companyInfo) {

      $company->companyName = $companyInfo['companyName'];
      $company->furiganaName = $companyInfo['furiganaName'];
      $company->postalCode = $companyInfo['postalCode'];

      $company->prefecturalName = $companyInfo['prefecturalName'];
      $company->municipalName = $companyInfo['municipalName'];
      $company->detailAddress = $companyInfo['detailAddress'];
      $company->phoneNumber = $companyInfo['phoneNumber'];
      $company->faxNumber = $companyInfo['faxNumber'];

      $subcompany->headOffice = $companyInfo['headOffice']; //
      $subcompany->capitalStock = $companyInfo['capitalStock'];//
      $subcompany->employeeNumber = $companyInfo['employeeNumber'];//

      $company->pepresentativeName = $companyInfo['pepresentativeName'];

      $company->responsiblePersonNameHaken = $companyInfo['responsibleName'];
      $company->responsiblePersonPositionHaken = $companyInfo['responsiblePosition'];
      $company->responsiblePersonPhoneNumberHaken = $companyInfo['responsiblePhone'];

      $company->chainCommandName = $companyInfo['chainName'];
      $company->chainCommandPosition = $companyInfo['chainPosition'];
      $company->chainCommandPhoneNumber = $companyInfo['chainPhone'];

      $subcompany->establishmentDate = $companyInfo['establishmentDate'];//
      $subcompany->mainCustomerBank = $companyInfo['mainCustomerBank'];//
      $subcompany->lastYearSuppliers = $companyInfo['lastYearSuppliers'];//
      $subcompany->mainCustomer = $companyInfo['mainCustomer'];//

      $company->contractDate = $companyInfo['contractDate'];
      $subcompany->companyMemo = $companyInfo['companyMemo'];//
      $company->personCharge = $companyInfo['personCharge'];

      $company->departmentName = $companyInfo['departmentName'];

      $subcompany->officialName = $companyInfo['officialName'];//

      $company->save();

      $subcompany->save();

      return $company;
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: add company
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company info
    * @return company
    *----------------------------
    */  
    public function addCompany($companyInfo){

      $company = new Company();
      $subcompany = new SubCompany();

      $companyId = $this->GetCompanyId();

      $company->companyId = $companyId;
      $subcompany->companyId = $companyId;

      return $this->saveCompany($company, $subcompany, $companyInfo);
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: get company
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param 
    * @return Company Id
    *----------------------------
    */
    public function GetCompanyId(){
      $company = Company::select('CompanyId')->orderBy('CompanyId','DESC')->first();
      
      if(!$company){
       return "ｶ000000001";
     } else {
       $companyCode = $company->CompanyId;
       $code = mb_substr($companyCode,1);
       $code = intval($code)+1;
       $count = strlen((string)$code);
       switch($count){
        case '1': $code = '00000000'.$code; break;
        case '2': $code = '0000000'.$code; break;
        case '3': $code = '000000'.$code; break;
        case '4': $code = '00000'.$code; break;
        case '5': $code = '0000'.$code; break;
        case '6': $code = '000'.$code; break;
        case '7': $code = '00'.$code; break;
        case '8': $code = '0'.$code; break;
        case '9': break;
      }
      return 'ｶ'.$code;
    }		
  }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: list company
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company info
    * @return company
    *----------------------------
    */  
    public function listCompany($companyInfo){
    	$company = new Company();
    	$searchCompany = $companyInfo['searchCompany'];

     return Company::leftJoin('t_subcompany','t_company.CompanyId','=','t_subcompany.CompanyId')
     ->where('CompanyName', 'like', "%$searchCompany%")
     ->orWhere('furiganaName', 'like', "%$searchCompany%")
     ->orWhere('detailaddress', 'like', "%$searchCompany%")
     ->select(
      't_company.CompanyId as CompanyId',
      't_company.CompanyName as CompanyName',
      't_company.DetailAddress as DetailAddress',
      't_company.PepresentativeName As PepresentativeName',
      't_company.PostalCode AS PostalCode',
      't_company.PhoneNumber AS PhoneNumber',
      't_company.ContractDate AS ContractDate',
      't_company.PrefecturalName AS PrefecturalName',
      't_company.MunicipalName AS MunicipalName',
      't_subcompany.EstablishmentDate AS EstablishmentDate',
      't_subcompany.OfficialName AS OfficialName'
      );
     ;
   }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: delete company
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
   public function deleteCompany($companyId){
    $company = Company::find($companyId);
    $order = Orders::where('AgreementDestinationID',$companyId)
              ->orWhere('OrderAddressId', $companyId)
              ->orWhere('EmploymentDestinationId', $companyId)
              ->first();
    if($order)
    {
      return false;
    }
    $company->subCompany()->delete();
    $company->delete();
  }
  
  /**
    *----------------------------
    * CREATE: ThienNB
    * DATE: 20062016
    * CONTENT: get select list company
    *----------------------------
    * MODIFY:
    * DATE:
    * CONTENT
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
   public function getSelectCompany(){
     $list = Company::all()->pluck('CompanyName', 'CompanyId')->toArray();
     return $list;
  }
}