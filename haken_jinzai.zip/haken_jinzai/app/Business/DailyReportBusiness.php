<?php
namespace App\Business;

use App\Model\StaffMessage;
use App\Model\Orders;
use Carbon\Carbon ;
use App\Model\ShiftTable;
use App\Model\ProjectCheckPoint;
use Illuminate\Support\Facades\DB;
class DailyReportBusiness {

    public function getAllMessage() {
        return StaffMessage::all();
    }
    public function getMessageByDate($date){
//      $date = Carbon::createFromFormat('Y-m-d',$date) ;
      
      return StaffMessage::whereDate('created_at','=',$date)->get();
    }
    
    /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: get all message in staff message by shift table 
    *----------------------------
    * @param $shiftTableId
    * @return true or false
    *----------------------------
    */  
    public function getMessageInfo($shiftTableId){
      
      if($shiftTableId){
//        dd($shiftTableId);
          $message = StaffMessage::where('ShiftTableId',$shiftTableId)->get();
          
        return $message;
      }
     
     return false;
   }
   /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: get all address work
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
    public function replyStaff($datas){
      
      if(isset($datas['staffMessageId'])){
        
          $message = StaffMessage::find($datas['staffMessageId']);
          $message->Reply = $datas['message'] ;
          $message->save();
        return $message;
      }
     
     return false;
   }
   
   /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: set Corresponding
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
    public function Corresponding($staffMessageId = null){
      
      if($staffMessageId){
        
          $message = StaffMessage::find($staffMessageId);
          $message->Corresponding = 1 ;
          $message->save();
        return $message;
      }
     
     return false;
   }
   
   /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: get all address work
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
    public function getAddressCompany(){
     $list = Orders::all()->pluck('AddressCompany', 'AddressCompany')->toArray();
     return $list;
   }
    /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: get all shift-table 
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */  
    public function getShiftTableInfo($searchData= null){
     $query = ShiftTable::join('t_orders_time','t_shifttable.OrderTimeId','=','t_orders_time.OrderTimeid')
                        ->join('t_orders','t_orders.OrderId','=','t_orders_time.OrderId')
                        ->join('t_projectbasicinfo','t_projectbasicinfo.OrderId','=','t_orders.OrderId')
                        ->join('t_staff','t_shifttable.StaffId','=','t_staff.StaffRegisterId')
                        ->join('t_company','t_orders.EmploymentDestinationId','=','t_company.CompanyId')
                        ->whereDate('DateWork','=',$searchData['dateSelect'])
                        ->select(
                          't_shifttable.ShiftTableId as ShiftTableId',
                          't_staff.Name as StaffName',
                          't_staff.Phone as Phone',
                          't_orders_time.OrderTimeid as OrderTimeid',
                          't_orders_time.TimeStart as TimeStart',
                          't_orders_time.TimeEnd as TimeEnd',
                           DB::raw("CONCAT(t_orders_time.TimeStart , '-' , t_orders_time.TimeEnd) As WorkTime"),
                          't_orders.ProjectName AS ProjectName',
                          't_orders.AddressCompany AS AddressCompany',
                          't_company.CompanyId AS CompanyId' ,
                          't_company.CompanyName AS CompanyName' ,
                          't_shifttable.Absense AS Absense'
                          
                          )

                        ->get() ;
     
     foreach ($query as $item){
       //get plan of staff
       $item['Plan']  = $this->getPlanTimeAttribute($item->ShiftTableId);
       //get actual of staff
       $item['Actual']= $this->getActualTimeAttribute($item->ShiftTableId);
       // stop ! in actual
       foreach ($item['Actual'] as $key=>$value){
         if ($value == '!'){
           $item['Status'] = ShiftTable::NOCHECKED;
           break;
         }  else {
           $item['Status'] = ShiftTable::CHECKED;
         }
       }
     }
     //
     $resultSearch = [];
     foreach ($query as $itemCheck){
        $checkStatus = $checkCompany = $checkOpen = $checkClose = $checkAddress = true ;
        if($searchData['status']!=""){
           $checkStatus = $this->checkStatus($itemCheck,$searchData);
        }
        if($searchData['company']!=""){
           $checkCompany = $this->checkCompany($itemCheck,$searchData);
        }
        if($searchData['open_time']!=""){
           $checkOpen = $this->checkOpenTime ($itemCheck,$searchData);
        }
        if($searchData['close_time']!=""){
           $checkClose = $this->checkCloseTime($itemCheck,$searchData);
        }
        if($searchData['address_work']!=""){
           $checkAddress = $this->checkAdressWork($itemCheck,$searchData);
        }
       
        if($checkStatus == true && $checkCompany == true && $checkOpen == true && $checkClose == true && $checkAddress == true){
          $resultSearch[]= $itemCheck;
        }
       
     }
     
     
     return $resultSearch;
   }
   
    public  function getPlanTimeAttribute($shiftTableId) {
      $times= [];
      $wakeup = $startTime =$arrivalTime = $openTime = $closeTime = $emp_report = $visit_report = '-';
      $shiftTable = ShiftTable::find($shiftTableId);
//      $projectCheckpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId);
      $depacture = $shiftTable->Departure;
     
      if($depacture) {
        
        // find depacture require by gaia
        //wakeup
        if ($depacture->CbxWakeup == 1){
          $wakeup = $depacture->Wakeup;
        }
        //depacture
        if ($depacture->CbxDeparture == 1){
          $startTime = $depacture->Departure;
        }
         
      }else{
        //not require by gaia
        
        $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',1)->first();
        if($shiftTable->TimeStartWanted != '' && $checkpoint->Checked == 1 ){
          $startTime = $shiftTable->TimeStartWanted ;
        }
        
      }
        // come to work time
      $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',2)->first();
      if(!empty($checkpoint) && $checkpoint->Checked == 1 ){
        $arrivalTime = $checkpoint->Start ;
      }
      // open time
      $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',3)->first();
      if(!empty($checkpoint) && $checkpoint->Checked == 1 ){
        $openTime = $checkpoint->Start ;
      }
      // end time
      $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',4)->first();
      if(!empty($checkpoint) && $checkpoint->Checked == 1 ){
        $closeTime = $checkpoint->Start ;
      }
      // employ report
      $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',5)->first();
      if(!empty($checkpoint) && $checkpoint->Checked == 1 ){
        $emp_report = $checkpoint->Start ;
      }
      // day report
      $checkpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId)->where('Name',6)->first();
      if(!empty($checkpoint) && $checkpoint->Checked == 1 ){
        $visit_report = $checkpoint->Start ;
      }
      //result
      $times  = [
          'WakeUpTime'                => $wakeup ,
          'StartedTime'           => $startTime ,
          'ArrivalTime'           => $arrivalTime ,
          'OpenedTime'            => $openTime ,
          'ClosedTime'            => $closeTime ,
          'ReportedTime'          => $emp_report ,
          'VisitingReportedTime'  => $visit_report
      ];
      return $times;
    }
    /**
    *----------------------------
    * CREATE: ThienNb
    * DATE: 20160615
    * CONTENT: get all shift-table actual
    *----------------------------
    * @param company id
    * @return true or false
    *----------------------------
    */ 
    public  function getActualTimeAttribute($shiftTableId,$date = null ) {
      $times= [];
      $plan = $this->getPlanTimeAttribute($shiftTableId) ;
      $wakeup = $startTime = $arrivalTime = $openTime = $closeTime = $emp_report = $visit_report = '-';
      $shiftTable = ShiftTable::find($shiftTableId);
      if($date == null){
        $hourNow = Carbon::now()->format('H:i');
      }
      else{
        $hourNow = '23:59';
      };
//      $projectCheckpoint = ProjectCheckPoint::where('OrderTimeId',$shiftTable->OrderTimeId);
      //wakeup
      if($plan['WakeUpTime']!='-'){
        //check hour now
        if($hourNow > $plan['WakeUpTime'] && $shiftTable->WakeUpTime == '' ){
          $wakeup = '!';
        }else if($shiftTable->WakeUpTime != ''){
          $wakeup = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->WakeUpTime)->format('H:i') ;
        }else{
          $wakeup = ' ';
        }
        
      }
      // Depature
      if($plan['StartedTime']!='-'){
        //check hour now
        if($hourNow > $plan['StartedTime'] && $shiftTable->StartedTime == '' ){
          $startTime = '!';
        }else if($shiftTable->StartedTime != ''){
          $startTime = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->StartedTime)->format('H:i') ;
        }else{
          $startTime = ' ';
        }
        
      }
      //arive
      if($plan['ArrivalTime']!='-'){
        //check hour now
        if($hourNow > $plan['ArrivalTime'] && $shiftTable->ArrivalTime == '' ){
          $arrivalTime = '!';
        }else if($shiftTable->ArrivalTime != ''){
          $arrivalTime = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->ArrivalTime)->format('H:i') ;
        }else{
          $arrivalTime = ' ';
        }
        
      }
      // open time
      if($plan['OpenedTime']!='-'){
        //check hour now
        if($hourNow > $plan['OpenedTime'] && $shiftTable->OpenedTime == '' ){
          $openTime = '!';
        }else if($shiftTable->OpenedTime != ''){
          $openTime = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->OpenedTime)->format('H:i') ;
        }else{
          $openTime = ' ';
        }
        
      }
      // close time
      if($plan['ClosedTime']!='-'){
        //check hour now
        if($hourNow > $plan['ClosedTime'] && $shiftTable->ClosedTime == '' ){
          $closeTime = '!';
        }else if($shiftTable->ClosedTime != ''){
          $closeTime = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->ClosedTime)->format('H:i') ;
        }else{
          $closeTime = ' ';
        }
        
      }
      // employ report
      if($plan['ReportedTime']!='-'){
        //check hour now
        if($hourNow > $plan['ReportedTime'] && $shiftTable->ReportedTime == '' ){
          $emp_report = '!';
        }else if($shiftTable->ReportedTime != ''){
          $emp_report = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->ReportedTime)->format('H:i') ;
        }else{
          $emp_report = ' ';
        }
        
      }
      //day report
      if($plan['VisitingReportedTime']!='-'){
        //check hour now
        if($hourNow > $plan['VisitingReportedTime'] && $shiftTable->VisitingReportedTime == '' ){
          $visit_report = '!';
        }else if($shiftTable->VisitingReportedTime != ''){
          $visit_report = Carbon::createFromFormat('Y-m-d H:i:s',$shiftTable->VisitingReportedTime)->format('H:i') ;
        }else{
          $visit_report = ' ';
        }
        
      }
      //result
      $times  = [
          'WakeUpTime'                => $wakeup ,
          'StartedTime'           => $startTime ,
          'ArrivalTime'           => $arrivalTime ,
          'OpenedTime'            => $openTime ,
          'ClosedTime'            => $closeTime ,
          'ReportedTime'          => $emp_report ,
          'VisitingReportedTime'  => $visit_report
      ];
      $check = '';
      foreach ( $times as $key => $value){
         if($check == 'stop' ) $times[$key] = '' ;
         if($value == "!") $check='stop';
      }
      
      return $times;
    }
    
    public function checkStatus($itemCheck, $searchData){
      
      //ok
      if($searchData['status']==1){
        if(!in_array('!', $itemCheck->Actual, true)) return true; 
      }
      //wakeup
      if($searchData['status']==2){
        if($itemCheck->Actual['WakeUpTime']=='!') return true; 
      }
      //StartedTime
      if($searchData['status']==3){
        if($itemCheck->Actual['StartedTime']=='!') return true; 
      }
      //ArrivalTime
      if($searchData['status']==4){
        if($itemCheck->Actual['ArrivalTime']=='!') return true; 
      }
      //OpenedTime
      if($searchData['status']==5){
        if($itemCheck->Actual['OpenedTime']=='!') return true; 
      }
      //ClosedTime
      if($searchData['status']==6){
        if($itemCheck->Actual['ClosedTime']=='!') return true; 
      }
      //ReportedTime
      if($searchData['status']==7){
        if($itemCheck->Actual['ReportedTime']=='!') return true; 
      }
      //VisitingReportedTime
      if($searchData['status']==8){
        if($itemCheck->Actual['VisitingReportedTime']=='!') return true; 
      }
      //Absense
      if($searchData['status']==9){
        if($itemCheck->Absense!=0) return true; 
      }
      //Not ok
      if($searchData['status']==10){
        if(in_array('!', $itemCheck->Actual, true) || $itemCheck->Absense!=0) return true; 
      }
      
      return FALSE;
    }
    public function checkCompany($itemCheck, $searchData){
      if($itemCheck->CompanyId == $searchData['company'])  return true;
      return FALSE;
    }
    public function checkOpenTime($itemCheck, $searchData){
      if($itemCheck->TimeStart >= $searchData['open_time'])  return true;
      return FALSE;
    }
    public function checkCloseTime($itemCheck, $searchData){
      if($itemCheck->TimeEnd <= $searchData['close_time'])  return true;
      return FALSE;
    }
    public function checkAdressWork($itemCheck, $searchData){
      if($itemCheck->AddressCompany == $searchData['address_work'])  return true;
      return FALSE;
    }
    
    public function updateTime($datas) {
      if (isset($datas['ShiftTableId'])) {
        $shiftTableId = $datas['ShiftTableId'] ;
        unset($datas['ShiftTableId']);
        unset($datas['_token']);
        $model = ShiftTable::find($shiftTableId);
        if ($model) {
          foreach ($datas as $key => $value) {
            if( strpos($value, ':') !== false ) {
            $hour = explode(':', $value)[0];
            $minute = explode(':', $value)[1];

            if($model->$key != ''){
              $newValue = Carbon::createFromFormat('Y-m-d H:i:s',$model->$key)->hour($hour)->minute($minute)->toDateTimeString() ;
            }else{
              $newValue = Carbon::now()->hour($hour)->minute($minute)->toDateTimeString() ;
            }
            $model->$key = $newValue;
            }
          }
          return $model->save();
        }
        return false;
      }
      return false;
    }

  }