<?php

//====================================================================================
//
//	FILENAME: DepartureBusiness.php
//	CREATE: 20160607
//	CREATOR: RikkeiSoft
//
//====================================================================================

namespace App\Business;

use App\Model\Departure;

class DepartureBusiness
{
	/**
	 * save departure business
	 *
	 * @author ToiTl
	 * @date 2016/06/07
	 */
	public function saveDeparture( $data ){
		$departure = Departure::where('OrderTimeId', $data['OrderTimeId'])
					->where('StaffId', $data['StaffId'])->first();

		if ( !$departure ) {
			$departure = new Departure();
		}

		if ( isset($data['CbxWakeup']) ) {
			$departure->CbxWakeup = $data['CbxWakeup'] == "true" ? 1 : 0;
		}

		if ( isset($data['CbxDeparture']) ) {
			$departure->CbxDeparture = $data['CbxDeparture'] == "true" ? 1 : 0;
		}

		if ( isset($data['Departure'])) {
			$departure->Departure = $data['Departure'];
		}

		if ( isset($data['Wakeup'])) {
			$departure->Wakeup = $data['Wakeup'];
		}

		if ( isset($data['Note'])) {
			$departure->Note = $data['Note'];
		}

		if ( isset($data['OrderTimeId'])) {
			$departure->OrderTimeId = $data['OrderTimeId'];
		}

		if ( isset($data['StaffId'])) {
			$departure->StaffId = $data['StaffId'];
		}

		$departure->save();
	}

	/**
     * Get staff by OrderTimeId
     * @param
     * @return mixed
     */
    public function getDepartureByOrderTimeId( $orderTimeIds ){
        $data = Departure::select('*')
                ->whereIn('OrderTimeId', $orderTimeIds)
                ->get();
        return $data;
    }
}