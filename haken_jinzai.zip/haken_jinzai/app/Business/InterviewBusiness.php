<?php
namespace App\Business;

use App\Model\Interview;
use App\Model\InterviewTime;
use App\Model\Region;
use App\Model\Staff;
class InterviewBusiness {

    /**
     * Get interview data by interview Id
     * @param $interviewId
     * @return mixed
     */
    public function getInterviewByInterviewId($interviewId){
        return Interview::find($interviewId);
    }

    /**
     * Add new schedule into interview time
     * @param $staffData
     * @return bool
     */
    public function addNewSchedule($staffData) {

        if($staffData['staffId']) {
            $interviewTimeId = $staffData['interviewTimeId'];
            $staffId = $staffData['staffId'];
            $region = $staffData['region'];

            $regionId = Region::where('Name', $region)->first()->RegionId;
            $interviewTime = InterviewTime::find($interviewTimeId);
            $interviewCount = count(Interview::where('InterviewTimeId', $interviewTimeId)->get());
            $interviewDuplicate = Interview::where('StaffId',$staffId)->where('RegionId','<>',3)->get();
            
            if ($interviewCount + 1 > $interviewTime->InterviewPeople) {
                return  trans('title.pre-register.warning.max_people');
            }
            if (count($interviewDuplicate)>0) {
                return trans('title.pre-register.warning.duplicate');
            }
            $interview = new Interview();
            $interview->StaffId = $staffId;
            $interview->RegionId = $regionId;
            $interview->InterviewTimeId = $interviewTimeId;
            $interview->save();
            $staff = Staff::find($staffId);
            $staff->InterviewDate = $interviewTime->InterviewDate;
            $staff->save();
            
            return trans('title.pre-register.warning.success_add');
        }
    }

    /**
     * Get interview list with no possible time
     * @return mixed
     */
    public function getInterviewListWithNoTime(){
        return Interview::select('InterviewId','StaffId','InterviewComment')->where('InterviewTimeId',null)->get();
    }

    /**
     * Get interview list with no possible time
     * @return mixed
     */
    public function checkInterviewByInterviewTimeId( $interviewTimeId ){
        return Interview::select('InterviewId','StaffId','InterviewComment')->where('InterviewTimeId',$interviewTimeId)->first();
    }

    public function getInterviewByStaffId($staffId) {
        return Interview::where('StaffId',$staffId)->get();
    }
}