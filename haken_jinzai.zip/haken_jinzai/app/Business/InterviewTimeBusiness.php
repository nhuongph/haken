<?php
namespace App\Business;

use App\Model\AnotherInterviewTime;
use App\Model\Interview;
use App\Model\InterviewTime;
use App\Model\Region;

class InterviewTimeBusiness {

    /**
     * Get all interview time
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAllInterviewTime() {
        return InterviewTime::all();
    }

    /**
     * Get interview time by region
     * @param $regionId
     * @return array
     */
    public function getInterviewTimeByLocation($regionId) {

        $times = [];
        $region = Region::find($regionId);
        if($region->Type != 0) {
            $interviewTimes = InterviewTime::where('RegionId',$regionId)->get();
            foreach($interviewTimes as $time) {
                $times[$time->InterviewDate][] = $time->InterviewTime;
            }
        } else {
            $interviewTimes = InterviewTime::where('RegionId',$regionId)->get();
            foreach($interviewTimes as $time) {
                $times[$time->InterviewDate][] = '';
            }
        }
        return $times;
    }

    /**
     * Get numnber join interview from 1 -> 15
     * @param $interviewInfo
     * @return mixed
     */
    public function addInterviewTime($interviewInfo)
    {   
        $interviewTime = new InterviewTime();
        $interviewTime->RegionId        = $interviewInfo['region'];
        $interviewTime->InterviewDate   = $interviewInfo['interviewDate'];
        $interviewTime->InterviewTime   = $interviewInfo['interviewHour'];
        $interviewTime->InterviewPeople = $interviewInfo['interviewPeople'];

        $interviewTime->save();
    }

    /**
     * Get list of interview time for datatable
     * @param $region
     * @return mixed
     */
    public function getInterviewTimeList($region) {

        $interviewPlace = Region::where('name',$region)->first();
        $interviewTime = InterviewTime::where('RegionId',$interviewPlace->RegionId)->groupby('InterviewDate');
        return $interviewTime->get();
    }

    /**
     * Get interview time by date and region
     * @param $date
     * @param $region
     * @return mixed
     */
    public function getTimeByDateAndRegion($date,$region) {
        $times = InterviewTime::select('InterviewTimeId', 'InterviewTime','InterviewPeople')->where('RegionId',$region)->where('InterviewDate',$date)->get();
        return $times;
    }

    public function getListInterviewDate(){

        $interviewTime = InterviewTime::select('InterviewDate')->groupBy('InterviewDate')->get();
        $interviewTimes        = [];
        $anotherInterviewTimes = [];
        foreach($interviewTime as $time) {
            $interviewTimes[$time->InterviewDate] = $time->InterviewDate;
        }
        $anotherInterviewTime = AnotherInterviewTime::select('Date')->groupBy('Date')->get();
        foreach($anotherInterviewTime as $time) {
            $anotherInterviewTimes[$time->Date] = $time->Date;
        }
        $date = [];
        if(count($interviewTimes) > 0 || count($anotherInterviewTimes) >0 ){
            $date = array_merge($anotherInterviewTimes,$interviewTimes);
        }
        ksort($date);
        return $date;
    }

     /**
     * get Tokyo, Kanagawa Interview Time List method
     *
     * @author ToiTL
     * @date 2016/05/23
     * @return InterviewTime
     */
    public function getTokyoKanagawaInterviewTimeList( $region ){
        $tabs = [
            'tokyo' => 1,
            'kanagawa' => 2
        ];

        return  InterviewTime::leftJoin('t_region','t_interviewtime.RegionId','=','t_region.RegionID')
                ->where('t_region.Type', '=', 1)
                ->where('t_region.RegionId', '=',  $tabs[$region])
                ->select(
                    't_interviewtime.InterviewTimeID as InterviewTimeID',
                    't_region.Name as RegionName',
                    't_interviewtime.InterviewDate As InterviewDate',
                    't_interviewtime.InterviewTime AS InterviewTime',
                    't_interviewtime.InterviewPeople AS InterviewPeople'
                );
    }
}