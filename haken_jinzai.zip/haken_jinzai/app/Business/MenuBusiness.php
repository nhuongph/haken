<?php
namespace App\Business;
use Illuminate\Support\Facades\Hash;
use App\Model\User;
use DB;
use Mail;

class MenuBusiness {

	public function getStaff($id){

        $staffList = DB::table('t_staff')
            ->select('t_staff.Name','t_staff.NameFurigana','t_staff.Birthdate',
            	't_staff.Sex','t_staff.Fax','t_staff.Mobile','t_staff.PostalCode','t_staff.PrefecturalName'
            	,'t_staff.MunicipalName','t_staff.AddressDetail','users.email',
                'users.password','t_staff.StaffRegisterId','t_staff.PostalCode')
            ->join('users', 'users.id', '=', 't_staff.StaffRegisterId')
            ->where('t_staff.StaffRegisterId',$id)
            ->get();

        return $staffList ;  
    }

    public function userMenuData($userData,$userId){
        $user = User::find($userId);
        //Check if user exist
        if(!$user) {
            $user = new User();
        }
       
        $user->password = Hash::make($userData['password']);
        $user->save();
        $this->sendMailChangeStaff($userId,$userData);
        return $user;
    }
    
    public function sendMailChangeStaff($userId, $userData){
        try {
            $staff = User::where('id',$userId)->first();
            $subject = $staff->name.trans('title.pwd.reset_pwd.title_mail.change_staff');
            
            if (isset($staff) && !empty($staff)) {
                Mail::send(['html' => 'site.email.change_staff_info_mail']
                        , [
                            "staff_name" => $staff->name,
                            'title_change' => $userData['selectbox'],//follow name in /staff/requestchange/{userID}
                            'content_change' => $userData['password'],//follow name in /staff/requestchange/{userID}
                            'staff_mail' => $staff->email,
                        ]
                        , function ($message) use ($subject) {
                    $message->from('system@gaia-ad.co.jp');
                    $message->to('t-office@gaia-ad.co.jp')->subject($subject);
                });
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }

}

