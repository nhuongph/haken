<?php

//====================================================================================
//
//	FILENAME: NoticeBusiness.php
//	CREATE: YYYYMMDD
//	CREATOR: RikkeiSoft
//
//====================================================================================
//
//	MODIFY: YYYYMMDD
//	MODIFER: RikkeiSoft
//	CONTENT: 
//
//====================================================================================

namespace App\Business;

use Illuminate\Support\Facades\Hash;
use App\Model\Notice;

class NoticeBusiness {

    /**
     * ----------------------------
     * CREATE: RikkeiSoft
     * DATE: YYYYMMDD
     * CONTENT: Add notice to DB
     * ----------------------------
     * @param $noticeInfo
     * @return object notice added	
     * ----------------------------
     */
    public function addNotice($noticeInfo) {
    	$notice = new Notice();
    	$notice->fill($noticeInfo);
    	$notice->save();
    	return $notice;
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: update notice
    *----------------------------
    * @param notice info
    * @return return notice updated
    *----------------------------
    */
    public function updateNotice($noticeInfo){
    	$notice = Notice::find($noticeInfo['noticeid']);
    	$notice-> fill($noticeInfo);
    	$notice->save();
    	return $notice;
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: get notice
    *----------------------------
    * @param notice id
    * @return return object notice 
    *----------------------------
    */
    public function getNotice($noticeId){
    	return Notice::find($noticeId);
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: add notice
    *----------------------------
    * @param list notice
    * @return return paging
    *----------------------------
    */
    public function listNotice(){
    	return Notice::paginate(30);
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: delete notice
    *----------------------------
    * @param notice id
    * @return
    *----------------------------
    */
    public function deleteNotice($noticeId){
        $notice = Notice::find($noticeId);
        $notice->delete();
    }

    /**
    *----------------------------
    * CREATE: RikkeiSoft
    * DATE: YYYYMMDD
    * CONTENT: add notice
    *----------------------------
    * @param list notice
    * @return return paging
    *----------------------------
    */
    public function listOfNewNotice( $paginate = 30 ){
        return Notice::orderBy('PublicDate', 'DESC')
                ->where('PublicDate', '<=', date('Y/m/d'))
                ->paginate($paginate);
    }
  }
