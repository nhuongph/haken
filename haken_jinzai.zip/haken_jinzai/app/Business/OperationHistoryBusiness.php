<?php

//====================================================================================
//
//	FILENAME: OperationHistoryBusiness.php
//	CREATE: 20160608
//	CREATOR: RikkeiSoft
//
//====================================================================================
//
//	MODIFY: 20160608
//	MODIFER: RikkeiSoft
//	CONTENT: 
//
//------------------------------------------------------------------------------------
//	MODIFY: 20160608
//	MODIFER: RikkeiSoft
//	CONTENT:
//
//====================================================================================

namespace App\Business;

use App\Model\OperationHistory;
use DB;
use DateTime;
use App\Model\Company;
use App\Model\SubCompany;
use Illuminate\Http\Request;
use Validator;
use Session;
use App\Model\Staff;
use App\Model\Orders;
use App\Model\OrdersDate;
use App\Model\OrdersTime;
use App\Model\DemandRegard;

class OperationHistoryBusiness
{
    /**
     * Add new operation history
     * @param $OpnHisInfo
     * @return 
     */	
	public function addOpnHistory($OpnHisInfo) {
		$OpnHis = new OperationHistory();
		$OpnHis->OpnTime = $OpnHisInfo['OpnTime']; 				//操作時刻
		$OpnHis->Operator = $OpnHisInfo['Operator']; 			//実行者
		$OpnHis->Object = $OpnHisInfo['Object']; 				//対象
		$OpnHis->ObjectDetail = $OpnHisInfo['ObjectDetail'];	//対象詳細
		$OpnHis->OpnType = $OpnHisInfo['OpnType'];				//種別
		$OpnHis->ItemName = $OpnHisInfo['ItemName'];			//項目名

		$OpnHis->save();

		return $OpnHis;
	}

    /**
     * List the operation history base on condition
     * @param $OpnHisInfo
     * @return 
     */	

	public function getListOperationHistory($keyword){
    	  $getListConfirmation =DB::table('t_operation_history')
            ->select('t_operation_history.OpnTime','t_operation_history.Operator','t_operation_history.Object','t_operation_history.ObjectDetail','t_operation_history.OpnType','t_operation_history.ItemName');
            
        if(!empty($keyword) ) {
    		  $getListConfirmation	= $getListConfirmation->where('t_operation_history.OpnTime', 'LIKE', $keyword['OpnTime']);
    	  }    
        if(!empty($keyword) ) {
    		  $getListConfirmation	= $getListConfirmation->where('t_operation_history.Operator', 'LIKE', $keyword['Operator']);
    	  }

    	  if(!empty($keyword) ) {
    		  $getListConfirmation	= $getListConfirmation->where('t_operation_history.Object', 'LIKE', $keyword['Object']);
    	  }

    	  if(!empty($keyword) ) {
    		  $getListConfirmation	= $getListConfirmation->where('t_operation_history.OpnType', 'LIKE', $keyword['OpnType']);
    	  }



        return $getListConfirmation->get();;
  }
    
    /**
     * Create: NhuongPH
     * Add new operation history
     * @param $OpnHisInfo
     * @return 
     */	
    public function newOpnHistory($ObjectDetail, $OpnType, $Object, $ItemName) {
            $OpnHis = new OperationHistory();
            $OpnHis->OpnTime = new DateTime();
            $OpnHis->Operator = auth()->guard('admin')->user()->name; //Creater
            $OpnHis->ObjectDetail = $ObjectDetail;//Detail
            $OpnHis->OpnType = $OpnType;// Create-Update-Delete
            $OpnHis->Object = $Object;// Object change
            $OpnHis->ItemName = $ItemName;// Item name

            $OpnHis->save();

            return $OpnHis;
    }
    
    /**
     * Create: NhuongPH
     * Add new operation history company
     * @param companyId and companyInfo
     * @return 
     */
    public function updComOpnHistory($companyId,$companyInfo){
        $company = Company::where('CompanyId', $companyId)->first();
        $subcompany = SubCompany::where('CompanyId', $companyId)->first();
        if(isset($company) && !empty($company)
            &&isset($subcompany) && !empty($subcompany)){
//        Change Company name 会社名    ->  companyName
            if ($company->CompanyName != $companyInfo['companyName']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_1')
                    );
            }
        
//        Change info of 郵便番号、都道府県、市区町村、以降の住所    
//                          -> postalCode, prefecturalName, municipalName, detailAddress
            if ($company->PostalCode != $companyInfo['postalCode']
                    ||  $company->PrefecturalName != $companyInfo['prefecturalName']
                    ||  $company->MunicipalName != $companyInfo['municipalName']
                    ||  $company->DetailAddress != $companyInfo['detailAddress']
                    ){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_2')
                    );
            }
//        Change info of phone number or Fax   ->  phoneNumber, faxNumber
            if ($company->PhoneNumber != $companyInfo['phoneNumber']
                    ||  $company->FaxNumber != $companyInfo['faxNumber']
                    ){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_3')
                    );
            }
//        Change info of 本社所在地  ->  headOffice
            if ($subcompany->HeadOffice != $companyInfo['headOffice']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_4')
                    );
            }
//        Change info of 資本金  ->  capitalStock
            if ($subcompany->CapitalStock != $companyInfo['capitalStock']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_5')
                    );
            }
//        Change info of .従業員数   ->  employeeNumber
            if ($subcompany->EmployeeNumber != $companyInfo['employeeNumber']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_6')
                    );
            }
//        Change info of 代表取締役  ->  pepresentativeName
            if ($company->PepresentativeName != $companyInfo['pepresentativeName']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_7')
                    );
            }
//        Change info of 派遣先責任者名、派遣先責任者役職、派遣先責任者連絡先
//                                    ->    responsibleName, responsiblePosition, responsiblePhone
            if ($company->ResponsiblePersonNameHaken != $companyInfo['responsibleName']
                    ||  $company->ResponsiblePersonPositionHaken != $companyInfo['responsiblePosition']
                    ||  $company->ResponsiblePersonPhoneNumberHaken != $companyInfo['responsiblePhone']
                    ){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_8')
                    );
            }
//        Change info of 指揮命令者名、指揮命令者役職、指揮命令者連絡先
//                                    -> chainName, chainPosition, chainPhone
            if ($company->ChainCommandName != $companyInfo['chainName']
                    ||  $company->ChainCommandPosition != $companyInfo['chainPosition']
                    ||  $company->ChainCommandPhoneNumber != $companyInfo['chainPhone']
                    ){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_9')
                    );
            }
//        Change info of 設立年月日  -> establishmentDate
            $subcompany->EstablishmentDate = date('Y/m/d', strtotime($subcompany->EstablishmentDate));
            if ($subcompany->EstablishmentDate != $companyInfo['establishmentDate']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_10')
                    );
            }
//        Change info of 主要取引銀行    ->  mainCustomerBank
            if ($subcompany->MainCustomerBank != $companyInfo['mainCustomerBank']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_11')
                    );
            }
//        Change info of 昨年度年商  ->  lastYearSuppliers
            if ($subcompany->LastYearSuppliers != $companyInfo['lastYearSuppliers']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_12')
                    );
            }
//        Change info of 主要取引先  ->  mainCustomer
            if ($subcompany->MainCustomer != $companyInfo['mainCustomer']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_13')
                    );
            }
//        Change info of 基本契約日  ->  contractDate
            $company->ContractDate = date('Y/m/d', strtotime($company->ContractDate));
            if ($company->ContractDate != $companyInfo['contractDate']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_14')
                    );
            }
//        Change info of 会社メモ    ->  companyMemo
            if ($subcompany->CompanyMemo != $companyInfo['companyMemo']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_15')
                    );
            }
//        Change info of 担当者  ->  personCharge
            if ($company->PersonCharge != $companyInfo['personCharge']){
                $this->newOpnHistory(
                    trans('title.operation_history.company.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.company.Object'),
                    trans('title.operation_history.company.Item_upd_16')
                    );
            }
        
        }
    }
    
    /**
     * Create: NhuongPH
     * Operation History for change role of staff
     * @param staff ID, staff change data
     * @return 
     */	
    /*public function changeRoleStaffOpnHistory($staffId,$preRegisterData) {
        $staff = Staff::where('StaffRegisterId',$staffId)->first();
//        Change info of 面接担当者(người đảm nhiệm phỏng vấn)   ->  interviewer
        
//        Change info of 面接日(ngày phỏng vấn)  -> interviewDate
        
//        Change info of タグ(tag): Thêm hoặc bỏ bớt 
//              ->  IsBright, IsConfidence, IsPositive, IsIntellectual, IsSpeed
//              , IsLaid, IsCleanliness, IsSmile, IsRoughly, IsScrupulous, IsWantWork
        
//        Change info of 登録区分    ->  selectRank
        
          Change info of 身だしなみ、態度、表情、性格、事務・営業経験、販売経験、遅刻、意欲、組織対応力
        
//        Change info of 第一印象    ->  first_impression
        
//        Change info of 面接時コメント  ->  comment
        
        Change info of 姓 hoặc 名
        
        Change info of 生年月日
        
//        Change info of 電話番号、FAX番号、携帯電話番号   ->  phone, fax, mobile
        
        Change info of email
        
        Change info of パスワード
        
        Change info of 郵便番号、都道府県、市区町村、以降の住所  ->  postal_code, prefectural_name,?,? 
        
//        Change info of 最寄駅  ->  nearest_station
        
        Change info of ご登録経緯
        
//        Change info of 希望就業期間  ->  desire_period
        
//        Add thêm hoặc xóa ngày của mục 就業曜日-> monday,tuesday,wednesday,thursday,friday,saturday,sunday,public_holiday
        
//        Add thêm hoặc xóa 1 selection của mục 希望職種->mobile_sale,home_sale,cosmetic_sale,apparel_sale,goods_sale,food_sale
//                            tasting_sale,business,rounder,coffee_staff,department_store_cash,secretary,data_entry
//                            companion,director,light_work,other
        
//        Change info of 就業期限    ->  employment_deadline
        
//        Add thêm hoặc xóa 1 selection của mục 所有資格    ->  ordinary_license,sales_officer,home_appliance_advisor,other_language_test
        
//        Change info of 所有資格(英語)  ->  TOEIC,  TOEFL
        
//        Change info of 所有資格(その他)    ->  entitlement
        
//        Change info of 卒業学校名、区分、学部名  ->education,education_school,education_department,education_2,education_school_2, education_department_2
        
//        Change info of 勤務先、業務内容、契約形態、期間  -> CompanyName1-CompanyName5,WorkContent1-WorkContent5, WorkCode1-WorkCode5, StartWork1-StartWork5
        
//        Change info of 身長、服サイズ、靴サイズ、スーツ用意、白シャツ用意、黒パンプス用意、エプロン用意、黒髪修正、声出し、百貨店経験、レジ経験、CAT経験、ネイル修正
//                ->height,uniform_type,clothes_size,shoes_size,suit_preparation,white_shirt_preparation,black_pump_preparation,apron_sling,black_hair_modification,voice,department_store_experience,pos_cash_register_experience,cat_experience,nail_modification
        
    }*/
    
    /**
     * Create: NhuongPH
     * Add new operation history company
     * @param companyId and companyInfo
     * @return 
     */
    public function updOrderOpnHistory($orderId,Request $request){
        $order = Orders::where('OrderId', $orderId)->first();
        $orderDate = OrdersDate::where('OrderId',$orderId)->select("DateOrderId","Date","NumberPeople","Notices")->get();  
        
//        Select Orders Date
        $orderDateArray = [];
        $requestOrderDateArray = [];
        foreach($orderDate as $key => $value){
            $orderDateArray[$key] = $value['attributes'];
        }
        foreach($request->OrdersDate as $key => $value){
            $requestOrderDateArray = array_merge($requestOrderDateArray,$value);
        }
        
//        Select Orders Time
        $orderTime = OrdersTime::where('OrderId',$orderId)->select("OrderTimeid","TimeStart","TimeEnd","TimeBreak",
                                                                    "Payment","Claim","TimeWorkings","Note","Name")->get();
        $orderTimeArray = [];
        foreach($orderTime as $key => $value){
            $key_current = $key+1;
            $orderTimeArray[$key_current] = $value['attributes'];
        }
        $countTimeArray = count($orderTimeArray);
        $countTimeArrayRequest = count($request->OrdersTime);
        for($i = $countTimeArray+1;$i<= $countTimeArrayRequest;$i++){
            $orderTimeArray[$i] = ["OrderTimeid" => "","TimeStart" => "","TimeEnd" => "","TimeBreak" => "",
                                "Payment" => "","Claim" => "","TimeWorkings" => "8","Note" => "","Name" => $i];
        }
        
//        Select Demand Regard;
        $demandRegard = DemandRegard::where('OrderId',$orderId)->first();
        
        if(isset($order) && !empty($order)
           && isset($request) && !empty($request)){
//            Change info of 案件名称    ->  ProjectName
            if ($order->ProjectName != $request->ProjectName){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_1')
                    );
            }
//            Change info of 受注者  ->  Contractor
            if ($order->Contractor != $request->Contractor){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_2')
                    );
            }
//            Change info of 受注日  ->  OrderDate
            $order->OrderDate = date('Y/m/d', strtotime($order->OrderDate));
            if ($order->OrderDate != $request->OrderDate){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_3')
                    );
            }
//            Change info of 職種    ->  CategoryJob
            if ($order->CategoryJob != $request->CategoryJob){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_4')
                    );
            }
//            Change info of 受注区分    ->  OrderDivision
            if ($order->OrderDivision != $request->OrderDivision){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_5')
                    );
            }
//            Change info of ブランド    ->  Brand
            if ($order->Brand != $request->Brand){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_6')
                    );
            }
//            Change info of 期間区分    ->  PeriodDivision
            if ($order->PeriodDivision != $request->PeriodDivision){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_7')
                    );
            }
//            Change info of 契約開始    ->  BeginContract
            $order->BeginContract = date('Y/m/d', strtotime($order->BeginContract));
            if ($order->BeginContract != $request->BeginContract){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_8')
                    );
            }
//            Change info of 契約終了    ->  EndContract
            $order->EndContract = date('Y/m/d', strtotime($order->EndContract));
            if ($order->EndContract != $request->EndContract){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_9')
                    );
            }
//            Change info of 基本契約時間
            if ($order->BeginContract != $request->BeginContract
                || $order->EndContract != $request->EndContract){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_10')
                    );
            }
//            Change info of 現場名      ->  AddressCompany
            if ($order->AddressCompany != $request->AddressCompany){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_11')
                    );
            }
//            Change info of 業務概要    ->  TaskOverview
            if ($order->TaskOverview != $request->TaskOverview){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_12')
                    );
            }
//            Change info of 服装        ->  Clothes
            if ($order->Clothes != $request->Clothes){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_13')
                    );
            }
//            Change info of 持ち物      ->  Belongings
            if ($order->Belogings != $request->Belongings){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_14')
                    );
            }
//            Change info of 最寄駅      ->  NeasestStation1-NeasestStation5
            if ($order->NearestStation1 != $request->NeasestStation1
                || $order->NearestStation2 != $request->NeasestStation2
                || $order->NearestStation3 != $request->NeasestStation3
                || $order->NearestStation4 != $request->NeasestStation4
                || $order->NearestStation5 != $request->NeasestStation5){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_15')
                    );
            }
//            Change info of 集合時間    ->  MeetingTime
            if ($order->MeetingTime != $request->MeetingTime){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_16')
                    );
            }
//            Change info of 集合場所    ->  MeetingPlace
            if ($order->MeetingPlace != $request->MeetingPlace){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_17')
                    );
            }
//            Change info of 担当営業    ->  SalesRepresentative
            if ($order->SalesRepresentative != $request->SalesRepresentative){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_18')
                    );
            }
//            Change info of 個別契約有無    ->  ContractExistence
            if ($order->ContractExistence != $request->ContractExistence){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_19')
                    );
            }
//            Change info of その他注意事項  ->  OtherNotes
            if ($order->Othernotes != $request->OtherNotes){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_20')
                    );
            }
//            Change info of 就業先：派遣先名称  ->  EmploymentDestinationId
            if ($order->EmploymentDestinationId != $request->EmploymentDestinationId){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_21')
                    );
            }
//            Change info of 契約書送付先    ->  AgreementDestinationID
            if ($order->AgreementDestinationID != $request->AgreementDestinationID){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_22')
                    );
            }
//            Change info of 請求書送付先    ->  OrderAddressId
            if ($order->OrderAddressId != $request->OrderAddressId){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_23')
                    );
            }
//            Change info of 派遣先責任者名、派遣先責任者所属部署、派遣先責任者役職、派遣先責任者連絡先    ->
//                    DispatchResponsibleName,  DispatchResponsibleDepartment,DispatchResponsibleTitle, ResponsiblePersonContact
            if ($order->DispatchResponsibleName != $request->DispatchResponsibleName
                    || $order->	DispatchResponsibleDepartment != $request->DispatchResponsibleDepartment
                    || $order->DispatchResponsibleTitle != $request->DispatchResponsibleTitle
                    || $order->ResponsiblePersonContact != $request->ResponsiblePersonContact){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_24')
                    );
            }
//            Change info of 指揮命令者名、指揮命令者所属部署、指揮命令者役職、指揮命令者連絡先,   ->
//                    ChainCommandName, ChainCommandDepartment, ChainCommandTitle, ChainCommandContact
            if ($order->ChainCommandName != $request->ChainCommandName
                    || $order->	ChainCommandDepartment != $request->ChainCommandDepartment
                    || $order->ChainCommandTitle != $request->ChainCommandTitle
                    || $order->ChainCommandContact != $request->ChainCommandContact){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_25')
                    );
            }
//            Change info of 苦情処理担当者名、苦情処理担当者所属部署、苦情処理担当者役職、苦情処理担当者連絡先    ->
//                    ComplaintPersonCharge, ComplaintPersonnelDepartment, ComplaintPersonnelOfficers, ComplaintPersonnelContacts
            if ($order->ComplaintPersonCharge != $request->ComplaintPersonCharge
                    || $order->	ComplaintPersonnelDepartment != $request->ComplaintPersonnelDepartment
                    || $order->ComplaintPersonnelOfficers != $request->ComplaintPersonnelOfficers
                    || $order->ComplaintPersonnelContacts != $request->ComplaintPersonnelContacts){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_26')
                    );
            }
//            Change info of 請求単位    ->  OrdersUnits
            if ($order->OrdersUnits != $request->OrdersUnits){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_27')
                    );
            }
//            Change info of 事前研修    ->  OrderUnitsPreTraining
            if ($order->OrderUnitsPreTraining != $request->OrderUnitsPreTraining){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_28')
                    );
            }
//            Change info of 交通費支払、交通費支払備考    ->  TransportationExpensePayment, TransportationExpensesRemarks
            if ($order->TransportationExpensePayment != $request->TransportationExpensePayment
                    || $order->TransportationExpensesRemarks != $request->TransportationExpensesRemarks){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_29')
                    );
            }
//            Change info of 交通費請求、交通費請求備考    ->  ConstructionRemoval, ConstructionRemovalRemarks
            if ($order->ConstructionRemoval != $request->ConstructionRemoval
                    || $order->ConstructionRemovalRemarks != $request->ConstructionRemovalRemarks){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_30')
                    );
            }
//            Change info of 設営・撤去、設営・撤去備考    ->  Allowance,  AllowanceRemarks
            if ($order->Allowance != $request->Allowance
                    || $order->AllowanceRemarks != $request->AllowanceRemarks){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_31')
                    );
            }
//            Change info of 手当、手当備考                ->  ConstructionRemoval1, ConstructionRemovalRemarks1
            if ($order->ConstructionRemoval1 != $request->ConstructionRemoval1
                    || $order->ConstructionRemovalRemarks1 != $request->ConstructionRemovalRemarks1){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_32')
                    );
            }
//            Change info of 自動更新、自動更新タイミング
//            if ($order->? != $request->?
//                    || $order->? != $request->?){
//                $this->newOpnHistory(
//                    trans('title.operation_history.order.ObjectDetail'),
//                    trans('title.operation_history.type_update'),
//                    trans('title.operation_history.order.Object'),
//                    trans('title.operation_history.order.Item_upd_32')
//                    );
//            }
//            Change info of 始業、終業、休憩、支払、請求、備考    ->  
//                  OrdersTime[TimeStart], OrdersTime[TimeEnd],OrdersTime[TimeBreak], OrdersTime[Payment], 
//                  OrdersTime[Claim], OrdersTime[TimeWorkings], OrdersTime[Note]
            $result = [];
            for($i = 1;$i <= $countTimeArrayRequest; $i++){
                $result += array_diff_assoc($orderTimeArray[$i], $request->OrdersTime[$i]);
            }
            if (!empty($result)){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_34')
                    );
            }
//            Change info of 勤務要否、人数、特記事項  ->
//                  OrdersDate[WorkNecessity], OrdersDate[NumberPeople], OrdersDate[Notices]
            
            $sizeOrderDate1 = count($orderDateArray);
            $sizeOrderDate2 = count($requestOrderDateArray);
            if ($sizeOrderDate1 != $sizeOrderDate2){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_35')
                    );
            }else{
                $result = [];
                for($i = 0;$i < $sizeOrderDate1; $i++){
                    $result += array_diff_assoc($orderDateArray[$i], $requestOrderDateArray[$i]);
                }
                if (!empty($result)){
                    $this->newOpnHistory(
                        trans('title.operation_history.order.ObjectDetail'),
                        trans('title.operation_history.type_update'),
                        trans('title.operation_history.order.Object'),
                        trans('title.operation_history.order.Item_upd_35')
                        );
                }
            }
//            Change info of 特別広告費、粗利  ->  TotalServices, SumTotal
            if ($order->TotalServices != $request->TotalServices
                    || $order->SumTotal != $request->SumTotal){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_36')
                    );
            }
//            Change info of 受注者(営業)コメント、対象年齢、性別、条件    ->
//                ContractorComments, AgeStart AgeEnd, SexNam, SexNu, Required Priority, CashRegister
            if($demandRegard->AgeStart == 0){
                $demandRegard->AgeStart = '';
            }
            if($demandRegard->AgeEnd == 0){
                $demandRegard->AgeEnd = '';
            }
            if ($demandRegard->ContractorComments != $request->ContractorComments
                    || $demandRegard->AgeStart !== $request->AgeStart
                    || $demandRegard->AgeEnd !== $request->AgeEnd
                    || $demandRegard->SexNam != $request->SexNam
                    || $demandRegard->SexNu != $request->SexNu
                    || $demandRegard->Required != $request->Required
                    || $demandRegard->Priority != $request->Priority
                    || $demandRegard->CashRegister != $request->CashRegister){
                $this->newOpnHistory(
                    trans('title.operation_history.order.ObjectDetail'),
                    trans('title.operation_history.type_update'),
                    trans('title.operation_history.order.Object'),
                    trans('title.operation_history.order.Item_upd_37')
                    );
            }
        }
    }
    
    
    /**
     * Create: NhuongPH
     * Check search Operation History
     * @param data search
     * @return lists Operation History
     */	
    public function searchOpnHistory($data) {
            $where  =   [];
            if(isset($data['Operator']) && !empty($data['Operator'])){
                $where += ['Operator'=>$data['Operator']];
            }
            if(isset($data['Object']) && !empty($data['Object'])){
                $where += ['Object'=>$data['Object']];
            }
            if(isset($data['OpnType']) && !empty($data['OpnType'])){
                $where += ['OpnType'=>$data['OpnType']];
            }                
            if(isset($data['dateFrom']) && !empty($data['dateFrom'])
                && isset($data['dateTo']) && !empty($data['dateTo'])
              ){
                $confirmations = OperationHistory::whereDate('OpnTime','>=',date('Y-m-d',strtotime($data['dateFrom'])))
                                                    ->whereDate('OpnTime','<=',date('Y-m-d',strtotime($data['dateTo'])))
                                                    ->where($where)
                                                    ->orderBy('OpnTime','DESC')
                                                    ->paginate(10);
            }else if(isset($data['dateFrom']) && !empty($data['dateFrom'])){
                $confirmations = OperationHistory::whereDate('OpnTime','>=',date('Y-m-d',strtotime($data['dateFrom'])))
                                                    ->where($where)
                                                    ->orderBy('OpnTime','DESC')
                                                    ->paginate(10);
            }else if(isset($data['dateTo']) && !empty($data['dateTo'])){
                $confirmations = OperationHistory::whereDate('OpnTime','<=',date('Y-m-d',strtotime($data['dateTo'])))
                                                    ->where($where)
                                                    ->orderBy('OpnTime','DESC')
                                                    ->paginate(10);
            }else{
                $confirmations = OperationHistory::where($where)->orderBy('OpnTime','DESC')->paginate(10);
            }
            
            return $confirmations;
    }

}