<?php
namespace App\Business;
use Illuminate\Support\Facades\Hash;
use App\Model\Orders;
use App\Model\OrdersDate;
use App\Model\OrdersTime;
use App\Model\DemandRegard;
use App\Model\User;
use App\Model\GaiA;
use App\Model\Role;
use DB;

class OrderBusiness {

	public function userData($userData,$orderId){
	    $order = Orders::find($orderId);
	    $orderstime='';
	    $demandRegard = '';
        if(isset($order)){
          $orderid=$order->OrderId;
          $orderstime = OrdersTime::where('OrderId',$orderid)->first();
          $demandRegard = DemandRegard::where('OrderId',$orderid)->first();
        }

        //Check if orders exist
        if(!$order) {
            $order= new Orders();
        }
        
	    	if(!$demandRegard) {
            $demandRegard = new DemandRegard();
        }
        if(!$orderstime) {
            $$orderstime = new OrdersTime();
        }

	      $order->ProjectName 									= $userData['ProjectName'];
	      $order->OrderDate 										= $userData['OrderDate'] ;
	      $order->Contractor										= $userData['Contractor'] ;
	      $order->CategoryJob 									= $userData['CategoryJob'];
	      $order->OrderDivision 								= $userData['OrderDivision'];
	      $order->Brand 												= $userData['Brand'];
	      $order->PeriodDivision 								= $userData['PeriodDivision'];
	      $order->BeginContract 								= $userData['BeginContract'];
	      $order->EndContract 									= $userData['EndContract'];
	      $order->AddressCompany 								= $userData['AddressCompany'];
	      $order->TaskOverview 									= $userData['TaskOverview'];
	      $order->Clothes 											= $userData['Clothes'];
	      $order->Belogings               			= $userData['Belongings'];
	      $order->NearestStation1     					= $userData['NeasestStation1'];
	      $order->NeasestStation2     					= $userData['NeasestStation2'];
	      $order->NeasestStation3     					= $userData['NeasestStation3'];
	      $order->NeasestStation4     					= $userData['NeasestStation4'];
	      $order->NearestStation5       				= $userData['NeasestStation5'];
	      $order->MeetingTime          					= $userData['MeetingTime'];
	      $order->MeetingPlace         					= $userData['MeetingPlace'];
	      $order->SalesRepresentative 					= $userData['SalesRepresentative'];
	      $order->Othernotes                		= $userData['OtherNotes'];
	      $order->ContractExistence             = $userData['ContractExistence'];
	      $order->EmploymentDestinationId 			= $userData['EmploymentDestinationId'];
	      $order->AgreementDestinationID 				= $userData['AgreementDestinationID'];
	      $order->OrderAddressId 								= $userData['OrderAddressId'];
	      $order->DispatchResponsibleName       = $userData['DispatchResponsibleName'];
	      $order->DispatchResponsibleDepartment = $userData['DispatchResponsibleDepartment'];
	      $order->DispatchResponsibleTitle      = $userData['DispatchResponsibleTitle'];
	      $order->ResponsiblePersonContact      = $userData['ResponsiblePersonContact'];
	      $order->ChainCommandName              = $userData['ChainCommandName'];
	      $order->ChainCommandDepartment        = $userData['ChainCommandDepartment'];
	      $order->ChainCommandTitle             = $userData['ChainCommandTitle'];
	      $order->ChainCommandContact           = $userData['ChainCommandContact'];
	      $order->ComplaintPersonCharge         = $userData['ComplaintPersonCharge'];
	      $order->ComplaintPersonnelDepartment  = $userData['ComplaintPersonnelDepartment'];
	      $order->ComplaintPersonnelOfficers    = $userData['ComplaintPersonnelOfficers'];
	      $order->ComplaintPersonnelContacts    = $userData['ComplaintPersonnelContacts'];
	      $order->OrdersUnits 					        = $userData['OrdersUnits'];
	      $order->OrderUnitsPreTraining 				= $userData['OrderUnitsPreTraining'];
	      $order->TransportationExpensePayment 	= $userData['TransportationExpensePayment'];
	      $order->TransportationExpensesRemarks = $userData['TransportationExpensesRemarks'];
	      $order->ConstructionRemoval 					= $userData['ConstructionRemoval'];
	      $order->ConstructionRemovalRemarks 		= $userData['ConstructionRemovalRemarks'];
	      $order->Allowance 										= $userData['Allowance'];
	      $order->AllowanceRemarks 							= $userData['AllowanceRemarks'];
	      $order->ConstructionRemoval1 					= $userData['ConstructionRemoval1'];
	      $order->ConstructionRemovalRemarks1 	= $userData['ConstructionRemovalRemarks1'];
	      $order->LastUpdatePerson              = $userData['LastUpdatePerson'];
	      $order->LastUpdateTime                = $userData['LastUpdateTime'];
	      $order->ApprovalRequestTime           = $userData['ApprovalRequestTime'];
	      $order->ApprovalRequester             = $userData['ApprovalRequester'];
	      $order->ApprovalRequestComment        = $userData['ApprovalRequestComment'];
	      $order->Status                        = $userData['Status'];
	      $order->PersonCharge                  = $userData['PersonCharge'];
	      $order->ApprovalComment               = $userData['ApprovalComment'];
	      $order->TotalPay											= $userData['TotalPay'];
	      $order->TotalClaims										= $userData['TotalClaims'];
	      $order->TotalServices                 = $userData['TotalServices'];
	      $order->SumTotal											= $userData['SumTotal'];
	      /*$order->PeopleApproal									= $userData['PeppleApproal'];*/

	      if(isset($userData['UpdateStatus'])){
	      	$order->Status								= $userData['UpdateStatus'];
	      }

	      if(isset($userData['UpdateStatusReturn'])){
	      	$order->Status								= $userData['UpdateStatusReturn'];
	      }
	      

	      if(isset($userData['UpdateRequest'])){
	      	$order->Status								= $userData['UpdateRequest'];
	      }

	      if(isset($userData['ConfirmRequests'])){
	      	$order->Status								= $userData['ConfirmRequests'];
	      }
	      $order->save();

	      if( !empty($userData['OrdersTime']) ){
		      foreach ($userData['OrdersTime'] as $key => $item){
		      		$orderstime = null;
			      	if(!empty($item['TimeStart']) && !empty($item['TimeEnd'])){
			      	  if ( isset($item['OrderTimeid']) ) {
			      	  	$orderstime = OrdersTime::find($item['OrderTimeid']);

			      	  }
			      	  if ( !$orderstime ){
			      	  	$orderstime = new OrdersTime();
			      	  }
			      	  $orderstime->OrderId        = $order->OrderId; 
					      $orderstime->TimeStart	    = $item['TimeStart'];
					      $orderstime->TimeEnd		    = $item['TimeEnd'];
					      $orderstime->TimeBreak	    = $item['TimeBreak'];
					      $orderstime->Payment		    = str_replace(',','', $item['Payment']);
					      $orderstime->Claim		      = str_replace(',','', $item['Claim']); 
					      $orderstime->TimeWorkings   = $item['TimeWorkings'];
					      $orderstime->Note				    = $item['Note'];
					      $orderstime->Name				    = $item['Name'];  
					      $orderstime->save();
					      
					      if(!empty($userData['OrdersDate'][$item['Name']])){
					     		foreach ($userData['OrdersDate'][$item['Name']] as $kOfdate => $value){

						     			//$orderdate = new OrdersDate();
						     			$orderdate = null;
							      	/*if(!empty($value['NumberPeople']) || !empty($value['Notices'])){*/

							      		if ( isset($value['DateOrderId']) ) {
							      	  	$orderdate = OrdersDate::find($value['DateOrderId']);
							      	  }
							      	  if (!$orderdate ){
							      	  	$orderdate = new OrdersDate();
							      	  }
							      	 	$orderdate->OrderId            = $order->OrderId;
							      	 	$orderdate->OrderTimeId        = $orderstime->OrderTimeid;
								       	$orderdate->WorkNecessity	     = isset($value['WorkNecessity']) ? 1 : 0;    
								       	$orderdate->NumberPeople       = $value['NumberPeople'];
								       	$orderdate->Notices            = $value['Notices'];
								       	$orderdate->Date               = $value['Date'];
								       	$orderdate->TableName 		     = $item['Name'];
								       	$orderdate->save();
							     		/*}*/
					       	}
				    	 }
			  		}
			  	}
		  	}

	      

	   		
	      
			

		  	$demandRegard->AgeStart  		  = $userData['AgeStart'];
		  	$demandRegard->AgeEnd    		  = $userData['AgeEnd'];

		  	if(isset($userData['SexNam'])){
		  		$demandRegard->SexNam       = $userData['SexNam'];
		  	}
		  	if(isset($userData['SexNu'])){
		  		$demandRegard->SexNu       	= $userData['SexNu'];
		  	}
		  	$demandRegard->Required  			= $userData['Required'];
		  	$demandRegard->Priority  			= $userData['Priority'];
		  	$demandRegard->CashRegister 	= $userData['CashRegister'];
		  	$demandRegard->ContractorComments = $userData['ContractorComments'];
		  	$demandRegard->OrderId        = $order->OrderId;
		  	$demandRegard->save();

	      return $order;
  }

  /*public function getListOrder(){
    	$orderList=DB::table('t_orders')
            ->select('t_orders.ProjectName','t_orders.OrderAddressId','t_orders.EmploymentDestinationId')
            ->get();
    	return $orderList;
  }*/

  public function getListOrder($keyword){
  		$keyword['OrderDate']     	  = isset($keyword['OrderDate']) && $keyword['OrderDate'] != -1 ? $keyword['OrderDate'].'%' : '%';
        $keyword['OrderDivision']   = isset($keyword['OrderDivision']) && $keyword['OrderDivision'] != -1 ? $keyword['OrderDivision'] : '%';
        $keyword['CategoryJob']     = isset($keyword['CategoryJob']) && $keyword['CategoryJob'] != -1 ? $keyword['CategoryJob'] : '%';
        $keyword['PeriodDivision']  = isset($keyword['PeriodDivision']) && $keyword['PeriodDivision'] != -1 ? $keyword['PeriodDivision'] : '%'; 
        $keyword['Status']          = isset($keyword['Status']) && $keyword['Status'] != 0 ? $keyword['Status'] : '%'; 
        $keyword['Contractor']      = isset($keyword['Contractor']) && $keyword['Contractor'] != 0 ? $keyword['Contractor'] : '%';
    	  $orderList=DB::table('t_orders')
            ->select('t_orders.OrderId','t_orders.ProjectName','t_orders.OrderAddressId','t_orders.EmploymentDestinationId','t_orders.OrderDivision','t_orders.PeriodDivision','t_orders.SumTotal','t_orders.CategoryJob','t_orders.OrderDate','t_orders.Status','t_orders.Contractor')
    		->where('t_orders.OrderDate', 'LIKE', $keyword['OrderDate'])
    		->where('t_orders.OrderDivision', 'LIKE', $keyword['OrderDivision'])
    		->where('t_orders.CategoryJob', 'LIKE', $keyword['CategoryJob'])
	    	->where('t_orders.PeriodDivision', 'LIKE', $keyword['PeriodDivision'])
	    	->where('t_orders.Status', 'LIKE', $keyword['Status'])
	    	->where('t_orders.Contractor', 'LIKE', $keyword['Contractor']);
    	return $orderList->get();
  }

  public function getListOrderByStatus($status){
  	$orderList=DB::table('t_orders')
            ->select('t_orders.ProjectName','t_orders.OrderAddressId','t_orders.EmploymentDestinationId')
            ->where('t_orders.Status',$status)
            ->get();
    return $orderList;
  }

  public function getCompanyName(){
  	$companyName=DB::table('t_company')
  					->join('t_subcompany', 't_subcompany.CompanyId', '=', 't_company.CompanyId')
            ->select('t_company.CompanyId','t_company.CompanyName')
            ->where('t_subcompany.OfficialName','1')
            ->get();
            // dd($companyName);
    return $companyName;
	}
	
	/**
     * Get list of brands
     *
     * @author ToiTL
     * @date 2016/05/25
     * @return brand list
     */ 
	public function getBrandList(){
		$rs = Orders::distinct()->select('Brand')->get();
		return $rs;
	}

	/**
     * Get list of 
     *
     * @author ToiTL
     * @date 2016/05/25
     * @return brand list
     */ 
	public function getTimeList(){
		$rs = Orders::distinct()->select('TimeWorkings')->get();
		return $rs;
	}

	/**
     * Get list of period
     *
     * @author ToiTL
     * @date 2016/05/25
     * @return brand list
     */ 
	public function getPeriodList(){
		$rs = Orders::distinct()->select('PeriodDivision')->get();
		return $rs;
	}

	public function getComanyNameListOrder(){
		$companyNameListOrder =DB::table('t_orders')
  					->join('t_company', 't_company.CompanyId', '=', 't_orders.EmploymentDestinationId')
            ->select('t_company.CompanyName','t_company.CompanyId')
            ->get();
            // dd($companyName);
    return $companyNameListOrder;
	}

	public function getBrandListOrder(){
		$companyNameListOrder =DB::table('t_orders')
  					->join('t_company', 't_company.CompanyId', '=', 't_orders.EmploymentDestinationId')
            ->select('t_company.CompanyName','t_company.CompanyId')
            ->get();
            // dd($companyName);
    return $companyNameListOrder;
	}

	/**
     * Get list of period
     *
     * @author ToiTL
     * @date 2016/05/25
     * @return brand list
     */ 
	public function getOrderByOrderId( $orderId ){
		return Orders::find( $orderId );
	}

	public function getFirstNameAndLastName(){
		$data = GaiA::leftJoin('users', 'users.email', '=', 't_gaia.email')
					->leftJoin('role_user', 'users.id', '=', 'role_user.user_id')
					->leftJoin('roles', 'roles.id', '=', 'role_user.role_id')
					->where('roles.name', 'gaia-Approver')
					->select('t_gaia.*')
					->get();
		return $data;
	}

	public function getOrderDate( $orderId ){
		$data = OrdersDate::where('OrderId', $orderId)
				->get();
		return $data;
	}

	
        
    /**
    * Send mail request approve order
    *
    * @author NhuongPH
    * @date 2016/06/20
    * @return Send mail
    * @param data user input and order id
    */ 
    public function sendMailRequestApproveOrder($userData,$orderId){
        try {            
            $staff = auth()->guard('admin')->user();
            $company = \App\Model\Company::where('CompanyId',$userData['EmploymentDestinationId'])->first();
            $subject = $userData['ProjectName'].'：'.$staff->name.trans('title.pwd.reset_pwd.title_mail.request_approve_order');
            
            if (isset($staff) && !empty($staff)) {
                \Mail::send(['html' => 'site.email.order_approve_mail']
                        , [
                            'order_name' => $userData['ProjectName'],
                            'company_name' => $company['CompanyName'],
                            'created_name' => $userData['Contractor'],
                            'overview_content' => $userData['TaskOverview'],
                        ]
                        , function ($message) use ($subject) {
                    $message->from('system@gaia-ad.co.jp');
                    $message->to('nhuongph@rikkeisoft.com')->subject($subject);
                });
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }
}