<?php
//====================================================================================
//                      
//  FILENAME: OrderTimeBusiness.php                  
//  CREATE: 20150530                   
//  CREATOR: RikkeiSoft                 
//                      
//====================================================================================
namespace App\Business;
use App\Model\OrdersTime;
class OrderTimeBusiness
{
	
	public $orderTime;
	public function __construct(){
	}

	/**
	 * Get time of order time method
	 *
	 * @author ToiTL
	 * @date 2016/05/20
	 * @param $orderID
	 */
	public function getOrderTimeByOrderID( $orderID ){
		$result = OrdersTime::select('TimeStart as start', 'TimeEnd as end', 'OrderTimeId')
				->where('OrderId', $orderID)->get();

		return $result;
	}
}