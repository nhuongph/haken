<?php
namespace App\Business;
use Illuminate\Support\Facades\Hash;
use App\Model\OrdersComment;
use DB;

class OrdersCommentBusiness {
	public function addComments( $orderId, $comments ){
		$cmt = new OrdersComment();
		$cmt->OrderId = $orderId;
		$cmt->CommentContent = $comments;
		$cmt->save();
	}
}