<?php
namespace App\Business;
use App\Model\Brand;
use Illuminate\Support\Facades\Hash;
use DB;

class PaymentBusiness {

	public function getListPayment($keyword){
		$paymentList =DB::table('t_orders')
            ->select('t_orders.ProjectName','t_orders.AddressCompany','t_orders.BeginContract','t_orders.EndContract','t_orders.OrderAddressId','t_orders.PeriodDivision','t_orders.Brand','t_orders.EmploymentDestinationId','t_orders.CategoryJob');

    if (!empty($keyword) ) {
    	$paymentList	= $paymentList->where('t_orders.ProjectName', 'LIKE', $keyword['projectName']);
    }

    if (!empty($keyword) ) {
    	$paymentList	= $paymentList->where('t_orders.PeriodDivision', 'LIKE', $keyword['PeriodDivision']);
    }

    if (!empty($keyword) ) {
    	$paymentList	= $paymentList->where('t_orders.Brand', 'LIKE', $keyword['Brand']);
    }

    return $paymentList->get();
	}
}