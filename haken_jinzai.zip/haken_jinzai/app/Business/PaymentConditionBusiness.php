<?php

//====================================================================================
//
//	FILENAME: CompanyBusiness.php
//	CREATE: 20150517
//	CREATOR: RikkeiSoft
//
//====================================================================================
//
//	MODIFY: 20150517
//	MODIFER: RikkeiSoft
//	CONTENT: 
//
//------------------------------------------------------------------------------------
//	MODIFY: YYYYMMDD
//	MODIFER: RikkeiSoft
//	CONTENT:
//
//====================================================================================

namespace App\Business;

use App\Business\CompanyBusiness;
use App\Model\PaymentCondition;

class PaymentConditionBusiness
{
    /**
     * Add new payment condition
     * @param $paymentInfo
     * @return 
     */	
	public function addPaymentCondition($paymentInfo) {
		
		$payment = new PaymentCondition();
		$payment->CompanyID = $paymentInfo['companyId'];
		$payment->BillSendDepartment = $paymentInfo['billSendDepartment'];
		$payment->ResponsibleName = $paymentInfo['responsibleName'];
		$payment->JobTitle = $paymentInfo['jobTitle'];
		$payment->paymentCondition = $paymentInfo['paymentCondition'];
		$payment->PaymentDate = $paymentInfo['paymentDate'];
		$payment->PostNumber = $paymentInfo['postNumber'];
		$payment->BillAddress = $paymentInfo['billAddress'];
		$payment->Tel = $paymentInfo['tel_payment'];
		$payment->Fax = $paymentInfo['fax_payment'];
		$payment->Note = $paymentInfo['note'];

		$payment->save();
	}

	public function getPaymentConditionById($id){
		return PaymentCondition::Where('JobID', $id)->first();
	}

	public function editPaymentCondition($payment, $paymentInfo){
		$payment->BillSendDepartment = $paymentInfo['billSendDepartment'];
		$payment->ResponsibleName = $paymentInfo['responsibleName'];
		$payment->JobTitle = $paymentInfo['jobTitle'];
		$payment->paymentCondition = $paymentInfo['paymentCondition'];
		$payment->PaymentDate = $paymentInfo['paymentDate'];
		$payment->PostNumber = $paymentInfo['postNumber'];
		$payment->BillAddress = $paymentInfo['billAddress'];
		$payment->Tel = $paymentInfo['tel_payment'];
		$payment->Fax = $paymentInfo['fax_payment'];
		$payment->Note = $paymentInfo['note'];

		$payment->save();		
	}
}