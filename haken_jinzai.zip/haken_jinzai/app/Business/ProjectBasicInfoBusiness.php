<?php
//====================================================================================
//                      
//  FILENAME: ProjectBasicInfoBusiness.php                  
//  CREATE: 20150524                   
//  CREATOR: RikkeiSoft                 
//                      
//====================================================================================
namespace App\Business;

use App\Model\User;
use App\Model\Role;
use App\Model\ProjectBasicInfo;
use Illuminate\Support\Facades\Hash;
use App\Model\OrdersTime;

class ProjectBasicInfoBusiness{
	
    /**
     * update ProjectBasicInfo method
     *
     * @author ToiTL
     * @date 2016/05/24
     * @param $data array
     */
    public function saveProjectBasicInfo( $data ){
        if ( isset($data['BasicInfoID']) ) {
            // Get object with data in database
            $basicRegister = $this->getProjectByBasicInfoID( $data['BasicInfoID'] );
        } else {
            // Create new object
            $basicRegister = new ProjectBasicInfo();
        }
        
        // Call convert data method
        //$basicRegister->fill($data);
        foreach ($data as $key => $value) {
         $basicRegister->{$key} = $value;
        }
        // Save data
        $basicRegister->save();

        return $basicRegister->BasicInfoID;
    }

    /**
     * Select list of project
     *
     * @author ToiTL
     * @date 2016/05/25
     * @return 
     */ 
    public function getProjectList(){
        $project = new ProjectBasicInfo();
        return $project;
    }

    /**
     * Select project by BasicInfoID condition
     *
     * @author ToiTL
     * @date 2016/05/25
     * @param $id
     * @return 
     */ 
    public function getProjectByBasicInfoID( $id = 0 ){
        $basicRegister = ProjectBasicInfo::find($id);
        return $basicRegister;
    }

    /**
     * Select list of project with order and resource info
     *
     * @author ToiTL
     * @date 2016/05/25
     * @param $search
     * @return 
     */ 
    public function getProjectListWithOrderAndResource( $search = null ){

        $table = ProjectBasicInfo::leftJoin('t_orders','t_orders.OrderId','=','t_projectbasicinfo.OrderId')
        ->leftJoin('t_company', 't_company.CompanyId', '=', 't_orders.EmploymentDestinationId')
        ->leftJoin('t_resource','t_resource.ResourceId','=','t_projectbasicinfo.Thumbnail')
        ->leftJoin('t_brand','t_brand.id','=','t_orders.Brand')
        ->orderBy('t_projectbasicinfo.created_at');

        // Check if isset paramters and set value seach
        if ( isset($search['displayStatus']) && $search['displayStatus'] != ProjectBasicInfo::ALL) {
            //$search['displayStatus'] = $search['displayStatus'] == -1 ? '%' : $search['displayStatus'];
            $table->where('t_projectbasicinfo.DisplayStatus','LIKE', $search['displayStatus']);
        }

        if ( isset($search['status']) && $search['status'] != ProjectBasicInfo::ALL) {
            //$search['status'] = $search['status'] == -1 ? '%' : $search['status'];
            $table->where('t_projectbasicinfo.Status','LIKE', $search['status']);
        }

        // if ( isset($search['tab']) && $search['tab'] != ProjectBasicInfo::ALL) {
        //     //$search['tab'] = $search['tab'] == -1 ? '%' : $search['tab'];
        //     $table->where('t_orders.Type','LIKE', $search['tab']);
        // }

        if ( isset($search['brand']) && $search['brand'] != ProjectBasicInfo::ALL) {
            //$search['brand'] = $search['brand'] == -1 ? '%' : $search['brand'];
            $table->where('t_orders.Brand','LIKE', $search['brand']);
        }

        if ( isset($search['time']) && $search['time'] != ProjectBasicInfo::ALL) {
            //$table->where('status','LIKE', $search['status']);
            $currentDate = date("Y-m-d 00:00:00");
            switch ($search['time']) {
                case ProjectBasicInfo::BEFORE_RECRUITMENT:
                    $table->where('t_projectbasicinfo.StartDate','>', $currentDate);
                    break;
                case ProjectBasicInfo::RECRUITING:
                    $table->where('t_projectbasicinfo.StartDate','<=', $currentDate);
                    $table->where('t_projectbasicinfo.EndDate','>=', $currentDate);
                    break;
                case ProjectBasicInfo::AFTER_RECRUITMENT:
                    $table->where('t_projectbasicinfo.EndDate','<', $currentDate);
                    break;
                default:
                    break;
            }
        }

        if ( isset($search['period']) && $search['period'] != ProjectBasicInfo::ALL) {
            //$search['period'] = $search['period'] == -1 ? '%' : $search['period'];
            $table->where('t_orders.PeriodDivision','LIKE', $search['period']);
        }

        return $table->select(
            't_orders.ProjectName AS ProjectName',
            't_resource.Path AS ThumbnailLink',
            't_projectbasicinfo.*',
            't_company.CompanyName AS CompanyName',
            't_orders.PeriodDivision AS PeriodDivision',
            't_orders.CategoryJob AS CategoryJob',
            't_brand.ManagementName', 't_brand.DisplayName'
            );
    }

    /**
     * Select orderid,
     *        project,
     *        company, 
     *        category job, 
     *        nearest station,
     *        companyname
     * @author HieuBV
     * @date 2016/06/02
     * @param
     * @return 
     */ 
    public function getIntroduceJobProject(){

        $table = ProjectBasicInfo::join('t_orders','t_orders.OrderId','=','t_projectbasicinfo.OrderId');

        return $table->select(
            't_orders.OrderId AS OrderId',
            't_orders.ProjectName AS ProjectName',
            't_orders.EmploymentDestinationId AS CompanyName',
            't_orders.CategoryJob AS CategoryJob',
            't_orders.NearestStation1 AS NearestStation'
            )->get();
    }

    /**
     * Save introduce job to DB
     *
     * @author HieuBV
     * @date 2016/06/02
     * @param
     * @return 
     */ 
    public function saveIntroduceJobProject($staffId, $orderId){
        $wantedJob = new WantedJob();
        $wantedJob->OrderTimeId = $orderId;
        $wantedJob->StaffId = $staffId;
        $wantedJob->Type = 2;
    }  
     
    public function getProjectByOrderId( $orderId ){
        $table = ProjectBasicInfo::where('OrderId', $orderId)->first();
        return $table;
    }
}