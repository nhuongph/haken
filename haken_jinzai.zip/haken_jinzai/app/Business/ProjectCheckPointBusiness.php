<?php
//====================================================================================
//                      
//  FILENAME: ProjectCheckPointBusiness.php                  
//  CREATE: 20150517                   
//  CREATOR: RikkeiSoft                 
//                      
//====================================================================================
namespace App\Business;
use App\Model\ProjectCheckPoint;

class ProjectCheckPointBusiness {
	/**
     * getCheckPointByBasicInfoID method
     *
     * @author ToiTL
     * @date 2016/05/30
     * @param $prID
     * @return Model
     */
	public function getCheckPointByBasicInfoID( $prID ){
		$result = ProjectCheckPoint::where('BasicInfoID', $prID)
					->orderBy('Name')
					->get();
		return $result;
	}

	/**
	 *----------------------------
	 * CREATE: RikkeiSoft
	 * DATE: YYYYMMDD
	 * CONTENT: get check point 
	 *----------------------------
	 * MODIFY:
	 * DATE:
	 * CONTENT
	 *----------------------------
	 * @param $noticeInfo
	 * @return bool
	 *----------------------------
	 */
	public function getCheckPointByChecked( $prID ){
		$result = ProjectCheckPoint::where('BasicInfoID', $prID)
					->orderBy('Name')
					->get();
		return $result;
	}


	/**
     * update Checkpoint method
     *
     * @author ToiTL
     * @date 2016/05/30
     * @param $data
     */
	public function saveProjectCheckPoint( $data ,$BasicInfoID = false){
		// Update all
		foreach ($data as $key => $value) {
			$checkPoint = null;
			if ( isset($value['CheckPointID']) ) {
				$checkPoint = ProjectCheckPoint::find( $value['CheckPointID'] );
			}

			if( $checkPoint == null ){
				$checkPoint = new ProjectCheckPoint();

				if ( $BasicInfoID !== false ) {
					$checkPoint->BasicInfoID = $BasicInfoID;
				}
			}

			if (isset($value['Start'])){
				$checkPoint->Start = $value['Start'];
			}

			if (isset($value['End'])){
				$checkPoint->End = $value['End'];
			}

			if (isset($value['Name'])){
				$checkPoint->Name = $value['Name'];
			}

			if (isset($value['Rule'])){
				$checkPoint->Rule = $value['Rule'];
			}

			if (isset($value['BasicInfoID'])){
				$checkPoint->BasicInfoID = $value['BasicInfoID'];
			}

			if (isset($value['OrderTimeId'])){
				$checkPoint->OrderTimeId = $value['OrderTimeId'];
			}

			if (isset($value['Checked'])){
				$checkPoint->Checked = 1;
			}
			$checkPoint->save();
		}
	}
}