<?php
namespace App\Business;
use App\Model\ProjectSettingDate;

class ProjectSettingDateBusiness {

	/**
	 * Insert new data
	 *
	 * @author ToiTL
	 * @date 2016/06/08
	 * @param $data
	 * @return $id
	 */
	public function saveProjectSettingDate( $data ){
		if ( isset($data['ProjectSettingDateID']) ) {
			$info = ProjectSettingDate::find($data['ProjectSettingDateID']);
		}

		if ( empty($info) ) {
			$info = new ProjectSettingDate();
		}

		if ( isset($data['Start']) ) {
			$info->Start = $data['Start'];
		}

		if ( isset($data['End']) ) {
			$info->End = $data['End'];
		}

		if ( isset($data['RestTime']) ) {
			$info->RestTime = $data['RestTime'];
		}

		if ( isset($data['WorkLocation']) ) {
			$info->WorkLocation = $data['WorkLocation'];
		}

		if ( isset($data['Allowance']) ) {
			$info->Allowance = $data['Allowance'];
		}

		if ( isset($data['Note']) ) {
			$info->Note = $data['Note'];
		}

		if ( isset($data['OrderId']) ) {
			$info->OrderId = $data['OrderId'];
		}

		$info->save();

		return $info->ProjectSettingDateID;
	}

	/** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: get project setting date by order id
    *----------------------------   
    * @return array  
    *----------------------------   
    */
    public function getRegisterDateByOrderId( $orderId ){
    	$result = ProjectSettingDate::where('t_projectsettingdate.OrderId', $orderId)
    			->first();

    	return $result;
    }
}