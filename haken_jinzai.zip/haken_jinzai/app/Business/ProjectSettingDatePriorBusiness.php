<?php
//====================================================================================		
//		
//	FILENAME: ProjectSettingDatePriorBusiness.php	
//	CREATE: YYYYMMDD	
//	CREATOR: RikkeiSoft	
//		
//====================================================================================		
namespace App\Business;
use App\Model\ProjectSettingDatePrior;

class ProjectSettingDatePriorBusiness {
	/**
	*----------------------------
	* CREATE: RikkeiSoft
	* DATE: YYYYMMDD
	* CONTENT: Add notice to DB
	*----------------------------
	* MODIFY:
	* DATE:
	* CONTENT
	*----------------------------
	* @param $data
	* @return int
	*----------------------------
	*/
	public function saveProjectSettingDatePrior( $data ){
		if ( isset($data['ProjectSettingDatePriorID']) ) {
			$info = ProjectSettingDatePrior::find($data['ProjectSettingDatePriorID']);
		}

		if ( empty($info) ) {
			$info = new ProjectSettingDatePrior();
		}

		if ( isset($data['ProjectSettingDateID']) ) {
			$info->ProjectSettingDateID = $data['ProjectSettingDateID'];
		}

		if ( isset($data['Position']) ) {
			$info->Position = $data['Position'];
		}

		if ( isset($data['Joiner']) ) {
			$info->Joiner = $data['Joiner'];
		}

		if ( isset($data['Date']) ) {
			$info->Date = $data['Date'];
		}

		if ( isset($data['Checked']) ) {
			$info->Checked = $data['Checked'];
		}

		$info->save();

		return $info->ProjectSettingDatePriorID;
	}
}