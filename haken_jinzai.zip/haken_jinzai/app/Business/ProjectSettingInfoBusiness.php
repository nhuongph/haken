<?php
namespace App\Business;
use App\Model\ProjectSettingInfo;

class ProjectSettingInfoBusiness {

	/**
	 * Insert new data
	 *
	 * @author ToiTL
	 * @date 2016/06/08
	 * @param $data
	 * @return $id
	 */
	public function saveProjectSettingInfo( $data ){
		if ( isset($data['ProjectSettingInfoID']) ) {
			$info = ProjectSettingInfo::find($data['ProjectSettingInfoID']);
		}

		if ( empty($info) ) {
			$info = new ProjectSettingInfo();
		}

		if ( isset($data['Clothes']) ) {
			$info->Clothes = $data['Clothes'];
		}

		if ( isset($data['Belonging']) ) {
			$info->Belonging = $data['Belonging'];
		}

		if ( isset($data['FocusTime']) ) {
			$info->FocusTime = $data['FocusTime'];
		}

		if ( isset($data['Responsible']) ) {
			$info->Responsible = $data['Responsible'];
		}

		if ( isset($data['Note']) ) {
			$info->Note = $data['Note'];
		}

		if ( isset($data['OrderId']) ) {
			$info->OrderId = $data['OrderId'];
		}

		$info->save();

		return $info->ProjectSettingInfoID;
	}

	/**
	 * get project setting info by order id
	 *
	 * @author ToiTL
	 * @date 2016/06/08
	 * @param $data
	 * @return $id
	 */
	public function getProjectSettingInfoByOrderId( $orderId ){
		$info = ProjectSettingInfo::where('OrderId', $orderId)->first();
		return $info;
	}
}