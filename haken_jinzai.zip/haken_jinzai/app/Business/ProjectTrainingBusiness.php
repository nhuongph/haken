<?php
namespace App\Business;
use App\Model\ProjectTraining;

class ProjectTrainingBusiness {

	/**
     * create BasicRegister method
     *
     * @author ToiTL
     * @date 2016/05/23
     * @param $projectid
     */
	public function getTrainingByBasicInfoID( $prID ){
		$result = ProjectTraining::where('BasicInfoID', $prID)
                         ->orderBy('Name')
                         ->get();
          return $result;
	}

     /**
     * update Checkpoint method
     *
     * @author ToiTL
     * @date 2016/05/30
     * @param $data
     */
     public function saveProjectTraining( $data , $BasicInfoID = false){
          // Update all
          foreach ($data as $key => $value) {
               $training = null;
               if ( isset($value['ProjectTrainingID']) ) {
                    $training = ProjectTraining::find( $value['ProjectTrainingID'] );
               }

               if( $training == null ){
                    $training = new ProjectTraining();
                    if ( $BasicInfoID !== false ) {
                         $training->BasicInfoID = $BasicInfoID;
                    }
               }

               if (isset($value['Name'])){
                    $training->Name = $value['Name'];
               }

               if (isset($value['Topic'])){
                    $training->Topic = $value['Topic'];
               }

               if (isset($value['BasicInfoID'])){
                    $training->BasicInfoID = $value['BasicInfoID'];
               }

               if (isset($value['Cate'])){
                    $training->Cate = $value['Cate'];
               }

               if (isset($value['Allowance'])){
                    $training->Allowance = $value['Allowance'];
               }

               $training->save();
          }
     }

     public function getProject(){
          return Project::all();
     }
}