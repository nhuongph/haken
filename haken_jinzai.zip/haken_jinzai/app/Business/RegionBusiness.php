<?php
namespace App\Business;
use App\Model\Region;

class RegionBusiness {

    /**
     * Get all region in database
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAllRegion(){
        return Region::all();
    }

    /**
     * Get region by regionId
     * @param $regionId
     * @return mixed
     */
    public function getRegionByName($regionId) {
        return Region::where('RegionId',$regionId)->first();
    }
}