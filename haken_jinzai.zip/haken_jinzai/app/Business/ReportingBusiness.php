<?php
namespace App\Business;
use App\Model\Report;
use App\Model\Distribution;
use App\Model\Comment;
use App\Model\SettingReport;
use Illuminate\Support\Facades\Hash;
use DB;

class ReportingBusiness {

	public function ReportData($reportData,$reportId){
	  foreach ($reportData as $key => $item){
	    $report = new Report();
      if(!empty($item['Category'])){
				$report->Category    = $item['Category'];
				$report->ProductName = $item['ProductName'];
				$report->Price       = $item['Price'];
        $report->reportId    = $reportId;
				$report->save();
		  }
	  }
    
  }

  public function DistributionData($distributionData,$reportId){
		  foreach ($distributionData as $key => $item){
		    $distribution = new Distribution();
        if(!empty($item['Category'])){
  				$distribution->Category     = $item['Category'];
  				$distribution->SampleName   = $item['SampleName'];
          $distribution->reportId     = $reportId;
  				$distribution->save();
        }
			}
	
  }

  public function CommentData($commentData,$reportId){
  	$comment = new Comment();
  	$comment->CommentContent = $commentData['CommentContent'];
    $comment->reportId = $reportId;
  	$comment->save();
  	return $comment;
  }

  public function getListSales(){
  	$salesList = DB::table('t_sales')
            ->select('t_sales.Category','t_sales.ProductName')
            ->get();

    return $salesList ; 
  }

  public function saveSettingReport($settingReport,$brandId){
        //Check if saveSetting exist
        $settingReport = new SettingReport();
        $settingReport->BrandId=$brandId;
        $settingReport->Type1='';
        $settingReport->Type2='';
        $settingReport->Type3='';
        $settingReport->Type4='';
        $settingReport->Type5='';
        $settingReport->Type6='';
        $settingReport->Type7='';
        $settingReport->Type8='';
        $settingReport->Type9='';
        $settingReport->Comment1='';
        $settingReport->Comment2='';
        $settingReport->Comment3='';
        $settingReport->Comment4='';
        $settingReport->save();
        return $settingReport;
  }



}