<?php
namespace App\Business;
use App\Model\Resource;

class ResourceBusiness {
	public function addResource( $link ){
		$resr = new Resource();
		$resr->Path = $link;
		$resr->save();
		return $resr->ResourceId;
	}
}