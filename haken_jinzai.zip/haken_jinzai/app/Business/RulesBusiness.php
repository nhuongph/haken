<?php
namespace App\Business;

use App\Model\Rules;
use Illuminate\Support\Facades\Hash;

class RulesBusiness{

    /**
     * Get all user
     * @return mixed
     */
    /*public function getAllUser() {

        $users = User::select('id','name','email')->get();
        $users = $users->reject(function ($user) {
            return $user->hasRole('admin') === true;
        });

        return $users;
    }
*/
    /**
     * Get user by id
     * @param $userId
     * @return mixed
     */
  /*  public function getUserById($userId) {
        return User::find($userId);
    }
*/
    //Add New User
    
    public function userRules($userRules){
        $usersLoginStaff= auth()->guard('admin')->user()->Staff->StaffRegisterId;
        //dd($usersLoginStaff);
        $rules = Rules::where('StaffRegisterId',$usersLoginStaff)->first();

        //dd($rules);
        if(!$rules) {
            $rules = new Rules();
        }
        $rules->BankCode          =  $userRules['NameBank'].$userRules['NumberBankBranch'];
        $rules->RecipientNameKana =  $userRules['AccountName'];
        $rules->TransferMethod    =  $userRules['TransferMethod'];
        $rules->AccountNumber     =  $userRules['TransferNumber']; 
        $rules->save();
        return $rules;
    }

}