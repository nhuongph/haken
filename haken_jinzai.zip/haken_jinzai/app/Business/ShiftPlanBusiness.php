<?php

//====================================================================================
//
//	FILENAME: ShiftPlanBusiness.php
//	CREATE: 20160607
//	CREATOR: ThienNB
//
//====================================================================================

  namespace App\Business;

  use App\Model\WantedJob;
  use App\Model\Orders;
  use App\Model\ProjectBasicInfo;
  use App\Model\OrdersTime;
  use App\Model\ShiftTable;
  use App\Model\ProjectCheckPoint;
  use App\Business\ShiftTableBusiness;
  
  use Illuminate\Support\Facades\Auth;

  class ShiftPlanBusiness {

    /**
     * get all wantedjob from orderid and have status = 2
     * @param $companyInfo
     * @return 
     */
    public function getAllWantedJobByOrderId($orderId) {

      $result = Orders::find($orderId)->WantedJob()->where('Status', WantedJob::STATUS_APPROVE)->get();
      return $result;
    }

    /**
     * save new wanted job 
     * @param $wantedJob
     * @return  $wantedJob
     */
    public function saveWanted($wantedJob) {
      $data = new WantedJob();
      foreach ($wantedJob as $key => $value) {
        if (\Illuminate\Support\Facades\Schema::hasColumn($data->getTable(), $key)) {
          $data->$key = $value;
        }
      }
      $data->TimeStartWanted = $this->getTimeStartDefause($data->OrderTimeId);
      $data->save();
      return $data;
    }
    /**
     * render cell in table shift plan
     * @param $wantedJob
     * @return  $wantedJob
     */
    public static function renderWantedJob($dateWanted, $orderTimeId, $status = 1) {
      $wantedJob = WantedJob::where('DateWanted', $dateWanted)
        ->where('OrderTimeId', $orderTimeId)
        ->where('Status', $status)
        ->get();
      $cell = "";
      if ($wantedJob) {

        foreach ($wantedJob as $job) {
          if ($job->Status == WantedJob::STATUS_SUBMITED) {
            if ($job->Type == WantedJob::TYPE_RECOMMEND) {
              $cell.= '<div class="cell-item" data-wanted="' . $job->WantedJobId . '" data-staffid="' . $job->StaffId . '" data-orderstime="' . $job->OrderTimeId . '"><button type="button" class="btn btn-success btn-sm btn-clone"> 回 </button> <br>' . $job->Staff->Name . '</div>';
            } else {
              $cell.= '<div class="cell-item" data-wanted="' . $job->WantedJobId . '" data-staffid="' . $job->StaffId . '" data-orderstime="' . $job->OrderTimeId . '"><button type="button" class="btn btn-warning btn-sm btn-clone"> 応 </button> <br> ' . $job->Staff->Name . '</div>';
            }
          } else if ($job->Status == WantedJob::STATUS_APPROVE) {
            $cell.= '<div class="cell-item" data-wanted="' . $job->WantedJobId . '" data-staffid="' . $job->StaffId . '" data-orderstime="' . $job->OrderTimeId . '"><button type="button" class="btn btn-default btn-sm active"> 確 </button> <br> ' . $job->Staff->Name . '</div>';
          }
        }
      } else {
        
      }

      return $cell;
    }
    
    /**
   * accept wanted job 
   * @param $wantedJob
   * @return  bool
   */
  public function approveWanted($wantedJob) {
    
    foreach ($wantedJob as $key ) {
      //check if data is id wantedjob or new wantedjob register have format staffId@DataWanted@OrderTimeId
      $save = null;
      if( strpos($key, '@') == false){
        //is wanted job apporove
          $job  = WantedJob::find($key);
          
          if(!empty($job) && $job->Status != WantedJob::STATUS_APPROVE){
            $job->Status = WantedJob::STATUS_APPROVE;
            $job->save();
            $save = $job;
            $success = true;
            
          }else{
            $success = false;
          }
        
      }else{
        // is new wanted from office, create new for staff
        $arrValue     = explode('@', $key);
        
        $staffId      = $arrValue[0];
        $dataWanted   = $arrValue[1];
        $orderTimeid  = $arrValue[2];
        
        $data = [
              'OrderTimeId' => $orderTimeid ,
              'StaffId'     => $staffId ,
              'DateWanted'  => $dataWanted ,
              'Type'        => WantedJob::TYPE_ASSIGN ,
              'Status'      => WantedJob::STATUS_APPROVE ,
        ];
        $save = $this->saveWanted($data);
        if(!empty($save) ){
           
          $success = true;
        }else{
          $success = false;
        }
      }
      
      if($save){
        
        $this->approveToShiftTable($save);
      }
    }
    
    
    return $success;
  }
  /**
   * accept wanted job to shift-table
   * @param $wantedJob
   * @return  bool
   */
  public function approveToShiftTable($wantedJob) {
    
    $shiftTable = ShiftTable::where('StaffId',$wantedJob->StaffId)
                            ->where('DateWork',$wantedJob->DateWanted)
                            ->where('OrderTimeId',$wantedJob->OrderTimeId)
                            ->first()  ;
    if(empty($shiftTable)){
        $shiftTableNew = new ShiftTableBusiness();
        return  $shiftTableNew->addShiftTable($wantedJob);
        
    }  else {
        return  $shiftTable;
    }                     
    
  }
  
  public function getTimeStartWanted($orderTimeId,$timeWanted =null){
//    if($timeWanted!=null)      return $timeWanted;
    $order = OrdersTime::find($orderTimeId);
    $timeStart = $order->TimeStart;
    $date = \Carbon\Carbon::createFromFormat('H:i', $timeStart)->subHour(1);
    return $date ;
    
  }
  public static  function getTimeStartDefause($orderTimeId,$timeWanted =null ){
    if($timeWanted != ''){
      return $timeWanted;
    }
    $setting =  ProjectCheckPoint::where('OrderTimeId',$orderTimeId)
                                  ->where('Name',1)
                                  ->where('Checked',1)
                                  ->first();
    if($setting){
      return $setting->Start;
    }
    return '';
  }
   /**
   * get max people in cell 
   * @param $ordertimeid
   * @return  int
   */
  
  public static  function getMaxPeople($orderTimeId ,$dateTime = null){
     $dateTime = \App\Model\OrdersDate::where('OrderTimeId',$orderTimeId)
                                       ->where('Date',$dateTime)
                                       ->first();
     if($dateTime) return $dateTime->NumberPeople ;
     
     return 0;
  }
  }
  