<?php
//====================================================================================						
//						
//	FILENAME: check-in.js					
//	CREATE: 20150613					
//	CREATOR: ToiTL					
//						
//====================================================================================
//						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//------------------------------------------------------------------------------------						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//====================================================================================
namespace App\Business;

use App\Model\Rules;
use App\Model\Resource;
use Illuminate\Support\Facades\Hash;
use App\Model\ShiftTable;
use App\Model\ScheduleReport;
use App\Model\Departure;
use App\Model\WantedJob;
use App\Model\ProjectCheckPoint;
use App\Business\ShiftPlanBusiness;
class ShiftTableBusiness{
	 /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: add CheckPoint
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */ 
    public function addCheckPoint( $data ){
        $shiftTable = new ShiftTable();
        $staffId = auth()->guard('admin')->user()->Staff->StaffRegisterId;

        // Set data to insert to db
    }
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: get current button
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public function getCurrentActionShiftTable($shiftTableId, $staffId){
        $shiftTable = ShiftTable::where('StaffId', $staffId)
                    ->where('ShiftTableId', $shiftTableId)
                    ->first();
        return $shiftTable;
    }

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: add new Shift table
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public  function addShiftTable($wantedJob,$saveNew =true){
        //        $date = date('Y-m-d');
        $orderTimeId  = $wantedJob->OrderTimeId ;
        $staffId      = $wantedJob->StaffId ;
        $shiftTable = ShiftTable::where('StaffId', $staffId)
                    ->where('DateWorK', $wantedJob->DateWanted)
                    ->where('OrderTimeId', $orderTimeId)
                    ->first();
        

        if ( !isset($shiftTable->ShiftTableId) ) {

            $shiftTable = new ShiftTable();
            $shiftTable->StaffId          = $staffId;
            $shiftTable->DateWork         = $wantedJob->DateWanted;
            $shiftTable->OrderTimeId      = $orderTimeId;
            $shiftTable->TimeStartWanted  = ShiftPlanBusiness::getTimeStartDefause($orderTimeId, $wantedJob->TimeStartWanted);

            // proect setting
            $projectSetting = ProjectCheckPoint::where('OrderTimeId', $orderTimeId)
                            ->orderBy('Name')
                            ->get();
            $projectSetting = $this->groupRowsToAnArray($projectSetting, "Name");

            $shiftTable->WakeUp = ShiftTable::UNCHECKED;

            if ( isset($projectSetting["1"][0]) && $projectSetting["1"][0]->Checked ) {
                $shiftTable->Started = ShiftTable::UNCHECKED;//$projectSetting["1"][0]->Rule;
            } else {
                $shiftTable->Started = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["2"][0]) && $projectSetting["2"][0]->Checked ) {
                $shiftTable->Arrival = ShiftTable::UNCHECKED;//$projectSetting["2"]->Rule;
            } else {
                $shiftTable->Arrival = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["3"][0]) && $projectSetting["3"][0]->Checked ) {
                $shiftTable->Opened = ShiftTable::UNCHECKED;//$projectSetting["3"][0]->Rule;
            } else {
                $shiftTable->Opened = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["4"][0]) && $projectSetting["4"][0]->Checked ) {
                $shiftTable->Closed = ShiftTable::UNCHECKED;//$projectSetting["4"][0]->Rule;
            } else {
                $shiftTable->Closed = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["5"][0]) && $projectSetting["5"][0]->Checked ) {
                $shiftTable->Reported = ShiftTable::UNCHECKED;//$projectSetting["5"][0]->Rule;
            } else {
                $shiftTable->Reported = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["6"]) && $projectSetting["6"][0]->Checked ) {
                $shiftTable->VisitingReported = ShiftTable::UNCHECKED;//$projectSetting["6"]->Rule;
            } else {
                $shiftTable->VisitingReported = ShiftTable::NOCHECKED;
            }

            // Get setting of user
            $userSetting = Departure::where('StaffId', $staffId)
                        ->where('OrderTimeId', $orderTimeId)
                        ->first();

            // Check if setting of this user
            if ( $userSetting ) {
                if ( $shiftTable->WakeUp != ShiftTable::NOCHECKED ) {
                    $shiftTable->WakeUp = $userSetting->CbxWakeup == ShiftTable::UNCHECKED ? ShiftTable::NOCHECKED : ShiftTable::UNCHECKED ;
                }

                if ( $shiftTable->Started != ShiftTable::NOCHECKED ) {
                    $shiftTable->Started = $userSetting->CbxDeparture == ShiftTable::UNCHECKED ? ShiftTable::NOCHECKED : ShiftTable::UNCHECKED ;
                }
            }
            
            if($saveNew==true){
            $shiftTable->save();
            }
        }

        return $shiftTable;
    }
    
     /** 
    *----------------------------   
    * CREATE: ThienNB    
    * DATE: 20161806
    * CONTENT: update shift-table from date table
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public  function confirmUpdateShiftTable($tableData){
//        $date = date('Y-m-d');
              
        foreach ($tableData as $shiftRow){
          $shiftRow   = (object) $shiftRow;
          
          if($shiftRow->ShiftTableId == 0 ){
            //new staff add to shift table
            
            $staffId      = $shiftRow->StaffId;
            $orderTimeId  = $shiftRow->OrderTimeId;
            $dateWork     = $shiftRow->DateWork ;
            
            //
            $shiftTable = new ShiftTable();
            $shiftTable->StaffId          = $staffId;
            $shiftTable->DateWork         = $dateWork;
            $shiftTable->OrderTimeId      = $orderTimeId;
            $shiftTable->TimeStartWanted  = ShiftPlanBusiness::getTimeStartDefause($orderTimeId);
            //add some absense
            $shiftTable->Absense          = $shiftRow->Absense;
            $shiftTable->ProjectTrainingID= $shiftRow->ProjectTrainingID;
            

            // proect setting
            $projectSetting = ProjectCheckPoint::where('OrderTimeId', $orderTimeId)
                            ->orderBy('Name')
                            ->get();
            $projectSetting = $this->groupRowsToAnArray($projectSetting, "Name");

            $shiftTable->WakeUp = ShiftTable::UNCHECKED;

            if ( isset($projectSetting["1"][0]) && $projectSetting["1"][0]->Checked ) {
                $shiftTable->Started = ShiftTable::UNCHECKED;//$projectSetting["1"][0]->Rule;
            } else {
                $shiftTable->Started = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["2"][0]) && $projectSetting["2"][0]->Checked ) {
                $shiftTable->Arrival = ShiftTable::UNCHECKED;//$projectSetting["2"]->Rule;
            } else {
                $shiftTable->Arrival = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["3"][0]) && $projectSetting["3"][0]->Checked ) {
                $shiftTable->Opened = ShiftTable::UNCHECKED;//$projectSetting["3"][0]->Rule;
            } else {
                $shiftTable->Opened = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["4"][0]) && $projectSetting["4"][0]->Checked ) {
                $shiftTable->Closed = ShiftTable::UNCHECKED;//$projectSetting["4"][0]->Rule;
            } else {
                $shiftTable->Closed = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["5"][0]) && $projectSetting["5"][0]->Checked ) {
                $shiftTable->Reported = ShiftTable::UNCHECKED;//$projectSetting["5"][0]->Rule;
            } else {
                $shiftTable->Reported = ShiftTable::NOCHECKED;
            }

            if ( isset($projectSetting["6"]) && $projectSetting["6"][0]->Checked ) {
                $shiftTable->VisitingReported = ShiftTable::UNCHECKED;//$projectSetting["6"]->Rule;
            } else {
                $shiftTable->VisitingReported = ShiftTable::NOCHECKED;
            }

            // Get setting of user
            $userSetting = Departure::where('StaffId', $staffId)
                        ->where('OrderTimeId', $orderTimeId)
                        ->first();

            // Check if setting of this user
            if ( $userSetting ) {
                if ( $shiftTable->WakeUp != ShiftTable::NOCHECKED ) {
                    $shiftTable->WakeUp = $userSetting->CbxWakeup == ShiftTable::UNCHECKED ? ShiftTable::NOCHECKED : ShiftTable::UNCHECKED ;
                }

                if ( $shiftTable->Started != ShiftTable::NOCHECKED ) {
                    $shiftTable->Started = $userSetting->CbxDeparture == ShiftTable::UNCHECKED ? ShiftTable::NOCHECKED : ShiftTable::UNCHECKED ;
                }
            }
            $result = $shiftTable->save();
            
          }else{
            //is old row, just update 
            $shiftTable= ShiftTable::find($shiftRow->ShiftTableId);
            if($shiftTable){
              $shiftTable->DateWork           = $shiftRow->DateWork ;
              $shiftTable->OrderTimeId        = $shiftRow->OrderTimeId ;
              $shiftTable->ProjectTrainingID  = $shiftRow->ProjectTrainingID ;
              $shiftTable->Absense            = $shiftRow->Absense ;
              $result = $shiftTable->save();
            }
          }
          
           
        }

        return $result;
    }

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: update CheckPoint
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public function updateCheckPoint($shiftTableId, $step = 1, $staffId){
        $shiftTable = $this->getCurrentActionShiftTable($shiftTableId, $staffId);
        $time = date('Y-m-d H:i:s');
        switch ($step) {
            case ShiftTable::WAKEUP:
                $shiftTable->WakeUp = ShiftTable::CHECKED;
                $shiftTable->WakeUpTime = $time;
                break;
            case ShiftTable::STARTED:
                $shiftTable->Started = ShiftTable::CHECKED;
                $shiftTable->StartedTime = $time;
                break;
            case ShiftTable::ARRIVAL:
                $shiftTable->Arrival = ShiftTable::CHECKED;
                $shiftTable->ArrivalTime = $time;
                break;
            case ShiftTable::OPENED:
                $shiftTable->Opened = ShiftTable::CHECKED;
                $shiftTable->OpenedTime = $time;
                break;
            case ShiftTable::CLOSED:
                $shiftTable->Closed = ShiftTable::CHECKED;
                $shiftTable->ClosedTime = $time;
                break;
            // case ShiftTable::REPORTED:
            //     $shiftTable->Reported = ShiftTable::CHECKED;
            //     $shiftTable->ReportedTime = $time;
            //     break;
            // case ShiftTable::VISITING_REPORTED:
            //     $shiftTable->VisitingReported = ShiftTable::CHECKED;
            //     $shiftTable->VisitingReportedTime = $time;
            //     break;
            default:
                # code...
                break;
        }

        $shiftTable->save();

        return $shiftTable;
    }
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: Updated report status
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public function updateReportStatus($type, $staffId, $shiftTableId, $date, $requestData){
        $shiftTable = ShiftTable::where('StaffId', $staffId)
                    ->where('ShiftTableId', $shiftTableId)
                    ->where('DateWork', $date)
                    ->first();

        if ($shiftTable) {
            $table = ScheduleReport::where('ShiftTableId', $shiftTableId);

            if ( $type == ScheduleReport::REPORT ) {
                $table->where('Type', ScheduleReport::REPORT);
            } else {
                $table->where('Type', ScheduleReport::VISITING_REPORT);
            }

            $table = $table->first();

            if ( !$table ) {
                $table = new ScheduleReport();
            }

            $table->ShiftTableId = $shiftTableId;

            if ( isset($requestData['LinkImage']) ) {
                $resource = new Resource();

                $resource->Path = $requestData['LinkImage'];

                $resource->save();

                $table->ExpenseImage = $resource->ResourceId;
            }

            if ( isset($requestData['ExpenseTotal']) ) {
                $table->ExpenseTotal = $requestData['ExpenseTotal'];
            }

            if ( isset($requestData['IsUsedBreakTime']) && $requestData['IsUsedBreakTime'] == true) {
                $table->IsUsedBreakTime = ScheduleReport::CHECKED;
            } else {
                $table->IsUsedBreakTime = ScheduleReport::UNCHECKED;
            }

            if ( isset($requestData['IsOverTime']) && $requestData['IsOverTime'] == true) {
                $table->IsOverTime = ScheduleReport::CHECKED;
            } else {
                $table->IsOverTime = ScheduleReport::UNCHECKED;
            }

            if ( isset($requestData['Remark']) ) {
                $table->Remark = $requestData['Remark'];
            }

            if ( $type == ScheduleReport::REPORT ) {
                $table->Type = ScheduleReport::REPORT;
            } else {
                $table->Type = ScheduleReport::VISITING_REPORT;
            }
            $table->save();
            // Set status report
            if ( $type == ScheduleReport::REPORT ) {
                $shiftTable->Reported = ShiftTable::CHECKED;
                $shiftTable->ReportedTime = date('Y-m-d H:i:s');
            } else {
                $shiftTable->VisitingReported = ShiftTable::CHECKED;
                $shiftTable->VisitingReportedTime = date('Y-m-d H:i:s');
            }
            
            $shiftTable->save();
        }
    }
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: get schedule report by shift table id
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public function getScheduleReportByShiftTableId($type, $shiftTableId){
        $table = ScheduleReport::where('ShiftTableId', $shiftTableId);

        if ( $type == ScheduleReport::REPORT ) {
            $table->where('Type', ScheduleReport::REPORT);
        } else {
            $table->where('Type', ScheduleReport::VISITING_REPORT);
        }
        return $table->first();
    }
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: group array
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    private function  groupRowsToAnArray($data , $key){
        $sorted = array();
        foreach ($data as $member) {
            $groupid = $member->{$key};
            if (isset($sorted[$groupid])) {
                $sorted[$groupid][] = $member;
            } else {
                $sorted[$groupid] = array($member);
            }
        }
        return $sorted;
    }
    
     /** 
    *----------------------------   
    * CREATE: ThienNb    
    * DATE: 20160615
    * CONTENT: render cell in table work schedule
    *----------------------------   
    * @param $data    
    * @return html view  
    *----------------------------   
    */
    public static function renderShiftTable($dateWanted, $orderTimeId) {
      $shiftTable = ShiftTable::where('DateWork', $dateWanted)
                              ->where('OrderTimeId', $orderTimeId)
                              ->get();
      $cell = "";
      if ($shiftTable) {
        $cell= view('site.shiftplan.work-schedule._cell-item',['shiftTable'=>$shiftTable])->render();
       
      } else {
        
      }

      return $cell;
    }
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: get list of task in a week
    *----------------------------   
    * @param $data    
    * @return staff  
    *----------------------------   
    */
    public function getWeekScheduleList($startDate , $endDate, $staffId){
        $shiftTable = ShiftTable::leftJoin('t_orders_time', 't_orders_time.OrderTimeId', '=', 't_shifttable.OrderTimeId')
                    ->leftJoin('t_orders', 't_orders.OrderId', '=', 't_orders_time.OrderId')
                    ->where('DateWorK', '>=', $startDate)
                    ->where('DateWorK', '<=', $endDate)
                    ->where('StaffId', $staffId)
                    // ->select('t_orders.Brand', 't_orders.AddressCompany',
                    // 't_orders_time.TimeStart', 't_orders_time.TimeEnd',
                    // 't_shifttable.DateWorK')
                    ->get();
        return $shiftTable;
    }

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: Get shedule
    *----------------------------   
    * @return staff  
    *----------------------------   
    */ 
    public function getCheckPointShedule(){
        // Get current staff id
        $staffId = auth()->guard('admin')->user()->Staff->StaffRegisterId;
        $result = ShiftTable::leftJoin('t_orders_time','t_orders_time.OrderTimeid', '=', 't_shifttable.OrderTimeId')
                ->leftJoin('t_orders', 't_orders_time.OrderId', '=', 't_orders.OrderId')
                ->leftJoin('t_company', 't_company.CompanyId', '=', 't_orders.EmploymentDestinationId')
                ->leftJoin('t_orders_date', 't_orders_date.OrderId', '=', 't_orders.OrderId')
                ->leftJoin('t_projectbasicinfo', 't_projectbasicinfo.OrderId', '=', 't_orders.OrderId')
                ->leftJoin('t_brand', 't_brand.id', '=', 't_orders.Brand')
                //->leftJoin('t_departure', 't_departure.OrderTimeId', '=', 't_orders_time.OrderTimeId')
                //->where('t_departure.StaffId', $staffId)
                ->where('t_shifttable.StaffId', $staffId)
                ->where('t_shifttable.DateWork', date('Y-m-d'))
                ->select(
                    't_orders.AddressCompany', 't_orders.ProjectName', 't_orders.OrderId',
                    't_orders_time.TimeStart', 't_orders_time.TimeEnd', 't_orders_time.TimeBreak', 't_orders_time.OrderTimeid',
                    't_company.CompanyName',
                    't_orders_date.Notices',
                    't_projectbasicinfo.MainChargeName', 't_projectbasicinfo.IsReceiptMail',
                    't_shifttable.ShiftTableId',
                    't_brand.ManagementName'
                )->get();
        return $result;
    }

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: Get staff list in shiftTable
    *----------------------------   
    * @param $orderId    
    * @return staff  
    *----------------------------   
    */ 
    public function getShiftTableWithOrderId( $orderId ){
        $table = ShiftTable::leftJoin('t_orders_time', 't_orders_time.OrderTimeid', '=', 't_shifttable.OrderTimeId')
                ->leftJoin('t_orders', 't_orders.OrderId', '=', 't_orders_time.OrderId')
                ->where('t_orders.OrderId',  $orderId)
                ->select('t_shifttable.*')
                ->groupBy('t_shifttable.StaffId')
                ->get();
        return $table;
    }
}