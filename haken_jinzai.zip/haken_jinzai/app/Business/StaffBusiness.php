<?php
namespace App\Business;
use App\Common\UploadHelper;
use App\Model\AnotherInterview;
use App\Model\AnotherInterviewTime;
use App\Model\Interview;
use App\Model\InterviewTime;
use App\Model\PartTimeJob;
use App\Model\Region;
use App\Model\Resource;
use App\Model\Role;
use App\Model\Staff;
use App\Model\SubStaff;
use App\Model\User;
use App\Model\WantedJob;
use App\Model\ShiftTable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Session\Session;
use Mail;
class StaffBusiness {

    /**
     * Get all staff info in database
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function getAllStaff(){
        return Staff::all();
    }

    /**
     * Get staff info by staff Id
     * @param $staffId
     * @return mixed
     */
    public function getStaffById($staffId){
        return Staff::find($staffId);
    }

    /**
     * Get staff info by staff email
     * @param $email
     * @return mixed
     */
    public function getStaffByEmail($email) {
        return Staff::where('Email',$email)->first();
    }

    /**
     * Add basic staff info for pre-register
     * @param $staffData
     * @return Staff
     */
    public function basicStaffData($staffId,$staffData){
        $staff    = Staff::find($staffId);
        $subStaff = SubStaff::where('StaffId',$staffId)->first();
        if(!$subStaff){
            $subStaff = new SubStaff();
        }
        if(!$staff){
            $staff = new Staff();
            $subStaff->StaffId = $staff->StaffRegisterId;
            $staffCode = Staff::select('StaffCode')->orderBy('StaffRegisterId','DESC')->first();
            if(!$staffCode){
                $staff->StaffCode = "G000001";
            } else {
                $code = mb_substr($staffCode->StaffCode,1);
                $code = intval($code)+1;
                $count = strlen((string) $code);
                switch($count){
                    case '1': $code = '00000'.$code; break;
                    case '2': $code = '0000'.$code; break;
                    case '3': $code = '000'.$code; break;
                    case '4': $code = '00'.$code; break;
                    case '5': $code = '0'.$code; break;
                    case '6': break;
                }
                $staff->StaffCode = 'G'.$code;
            }
        }
        if(isset($staffData['first_name'])){
            $staff->Name            = $staffData['first_name'].' '.$staffData['last_name'];
        }
        if(isset($staffData['first_name_furigana'])){
            $staff->NameFurigana    = $staffData['first_name_furigana'].' '.$staffData['last_name_furigana'];
        }
        if(isset($staffData['sex'])){
            $staff->Sex             = $staffData['sex'];
        }
        if(isset($staffData['birthdate'])){
            $staff->Birthdate       = date('Y-m-d', strtotime($staffData['birthdate']));
        }
        if(isset($staffData['postal_code'])){
            $staff->PostalCode      = str_replace('-', '', $staffData['postal_code']);
        }
        if(isset($staffData['prefectural_name'])){
            $staff->PrefecturalName = $staffData['prefectural_name'];
        }
        if(isset($staffData['commune'])){
        $staff->MunicipalName   = $staffData['commune'];
        }
        if(isset($staffData['address_detail'])){
        $staff->AddressDetail   = $staffData['address_detail'];
        }
        if(isset($staffData['phone'])){
        $staff->Phone           = $staffData['phone'];
        }
        if(isset($staffData['fax'])){
        $staff->Fax             = $staffData['fax'];
        }
        if(isset($staffData['mobile'])){
        $staff->Mobile          = $staffData['mobile'];
        }
        if(isset($staffData['email'])){
            $staff->Email           = $staffData['email'];
        }
        if(isset($staffData['password'])){
            $subStaff->Password     = Hash::make($staffData['password']);
        }
                $session = new Session();

        if($session->has('resourceId') && $session->get('resourceId') != null){
            $subStaff->Image = $session->get('resourceId');
        } else{
            if(array_key_exists('image',$staffData)) {
                $uploadHelper = new UploadHelper();
                list($extension,$filename) = $uploadHelper->UploadFile($staffData['image']);
                $resource = new Resource();
                $resource->Path     = 'img/uploads/'.$filename;
                $resource->Name     = $filename;
                $resource->MimeType = $extension;
                $resource->save();
                $subStaff->Image = $resource->ResourceId;
                $session->set('resourceId', $resource->ResourceId);
//                session(['resourceId'=> $resource->ResourceId]);
            }
        }

        if(array_key_exists('transfer_method',$staffData)){
            $staff->TransferMethod = $staffData['transfer_method'];
        }
        $staff->CurrentEmploymentStatus = $staffData['current_employment_status'];
        $staff->DesiredPeriod           = $staffData['desire_period'];
        if(array_key_exists('nearest_station',$staffData)){
            $subStaff->NearestStation  = $staffData['nearest_station'];
        }  else {
            $subStaff->NearestStation  = 0;
        }
        if(array_key_exists('registration_history',$staffData)){
            $subStaff->RegistrationHistory  = $staffData['registration_history'];
        } else {
            $subStaff->RegistrationHistory  = 0;
        }
        if(array_key_exists('monday',$staffData)){
            $subStaff->Monday    = $staffData['monday'];
        }else {
            $subStaff->Monday  = 0;
        }
        if(array_key_exists('tuesday',$staffData)){
            $subStaff->Tuesday   = $staffData['tuesday'];
        }else {
            $subStaff->Tuesday  = 0;
        }
        if(array_key_exists('wednesday',$staffData)){
            $subStaff->Wednesday = $staffData['wednesday'];
        }else {
            $subStaff->Wednesday  = 0;
        }
        if(array_key_exists('thursday',$staffData)){
            $subStaff->Thursday = $staffData['thursday'];
        }else {
            $subStaff->Thursday  = 0;
        }
        if(array_key_exists('friday',$staffData)){
            $subStaff->Friday   = $staffData['friday'];
        }else {
            $subStaff->Friday  = 0;
        }
        if(array_key_exists('saturday',$staffData)){
            $subStaff->Saturday = $staffData['saturday'];
        }else {
            $subStaff->Saturday  = 0;
        }
        if(array_key_exists('sunday',$staffData)){
            $subStaff->Sunday   = $staffData['sunday'];
        }else {
            $subStaff->Sunday  = 0;
        }
        if(array_key_exists('public_holiday',$staffData)){
            $subStaff->PublicHoliday = $staffData['public_holiday'];
        }else {
            $subStaff->PublicHoliday  = 0;
        }
        if(array_key_exists('mobile_sale',$staffData)){
            $subStaff->MobileSale    = $staffData['mobile_sale'];
        }else {
            $subStaff->MobileSale  = 0;
        }
        if(array_key_exists('home_sale',$staffData)){
            $subStaff->HomeSale      = $staffData['home_sale'];
        }else {
            $subStaff->HomeSale  = 0;
        }
        if(array_key_exists('cosmetic_sale',$staffData)){
            $subStaff->CosmeticSale  = $staffData['cosmetic_sale'];
        }else {
            $subStaff->CosmeticSale  = 0;
        }
        if(array_key_exists('apparel_sale',$staffData)){
            $subStaff->ApparelSale   = $staffData['apparel_sale'];
        }else {
            $subStaff->ApparelSale  = 0;
        }
        if(array_key_exists('goods_sale',$staffData)){
            $subStaff->GoodsSale     = $staffData['goods_sale'];
        }else {
            $subStaff->GoodsSale  = 0;
        }
        if(array_key_exists('food_sale',$staffData)){
            $subStaff->FoodSale      = $staffData['food_sale'];
        }else {
            $subStaff->FoodSale  = 0;
        }
        if(array_key_exists('tasting_sale',$staffData)){
            $subStaff->TastingSale   = $staffData['tasting_sale'];
        }else {
            $subStaff->TastingSale  = 0;
        }
        if(array_key_exists('business',$staffData)){
            $subStaff->Business   = $staffData['business'];
        }else {
            $subStaff->Business  = 0;
        }
        if(array_key_exists('rounder',$staffData)){
            $subStaff->Rounder   = $staffData['rounder'];
        }else {
            $subStaff->Rounder  = 0;
        }
        if(array_key_exists('coffee_staff',$staffData)){
            $subStaff->CoffeeStaff   = $staffData['coffee_staff'];
        }else {
            $subStaff->CoffeeStaff  = 0;
        }
        if(array_key_exists('department_store_cash',$staffData)){
            $subStaff->DepartmentStoreCashRegister   = $staffData['department_store_cash'];
        }else {
            $subStaff->DepartmentStoreCashRegister  = 0;
        }
        if(array_key_exists('secretary',$staffData)){
            $subStaff->Secretary     = $staffData['secretary'];
        }else {
            $subStaff->Secretary  = 0;
        }
        if(array_key_exists('data_entry',$staffData)){
            $subStaff->DataEntry     = $staffData['data_entry'];
        }else {
            $subStaff->DataEntry  = 0;
        }
        if(array_key_exists('companion',$staffData)){
            $subStaff->Companion     = $staffData['companion'];
        }else {
            $subStaff->Companion  = 0;
        }
        if(array_key_exists('director',$staffData)){
            $subStaff->Director      = $staffData['director'];
        }else {
            $subStaff->Director  = 0;
        }
        if(array_key_exists('light_work',$staffData)){
            $subStaff->Lightwork     = $staffData['light_work'];
        }else {
            $subStaff->Lightwork  = 0;
        }
        if(array_key_exists('other',$staffData)){
            $subStaff->Other         = $staffData['other'];
        }else {
            $subStaff->Other  = 0;
        }
        if($staffData['employment_deadline']!=''){
            $subStaff->EmploymentDeadline = date('Y-m', strtotime($staffData['employment_deadline'].'/01')) ;
        }
        if(array_key_exists('ordinary_license',$staffData)){
            $subStaff->OrdinaryLicense = $staffData['ordinary_license'];
        }else {
            $subStaff->OrdinaryLicense  = 0;
        }
        if(array_key_exists('sales_officer',$staffData)){
            $subStaff->SalesOfficer    = $staffData['sales_officer'];
        }else {
            $subStaff->SalesOfficer  = 0;
        }
        if(array_key_exists('home_appliance_advisor',$staffData)){
            $subStaff->HomeApplianceAdvisor = $staffData['home_appliance_advisor'];
        }else {
            $subStaff->HomeApplianceAdvisor  = 0;
        }
        if(array_key_exists('other_language_test',$staffData)){
            $subStaff->OtherLanguageTest    = $staffData['other_language_test'];
        }else {
            $subStaff->OtherLanguageTest  = 0;
        }
        $subStaff->TOEFL       = $staffData['TOEFL'];
        $subStaff->TOEIC       = $staffData['TOEIC'];
        $subStaff->Entitlement = $staffData['entitlement'];
        $staff->EducationDivision             = $staffData['education'];
        $staff->EducationDivisionSchool       = $staffData['education_school'];
        $staff->EducationDivisionDepartment   = $staffData['education_department'];
        $staff->EducationDivision_2           = $staffData['education_2'];
        $staff->EducationDivisionSchool_2     = $staffData['education_school_2'];
        $staff->EducationDivisionDepartment_2 = $staffData['education_department_2'];
        for($i = 1; $i <= 5; $i++){
            $companyName = "CompanyName$i";
            $workContent = "WorkContent$i";
            $workCode    = "WorkCode$i";
            $startDate   = "StartWork$i";
            $endDate     = "EndWork$i";
            $staff->$companyName = $staffData["$companyName"];
            $staff->$workContent = $staffData["$workContent"];
            $staff->$workCode    = $staffData["$workCode"];
            if($staffData["$startDate"]!=''){
            $staff->$startDate   = date('Y-m-d', strtotime($staffData["$startDate"]));
            }
            if($staffData["$endDate"]!=''){
            $staff->$endDate     = date('Y-m-d', strtotime($staffData["$endDate"]));
            }
        }
        
        if(array_key_exists('uniform_type',$staffData)){
            $staff->UniformType     = $staffData['uniform_type'];
        }
        $staff->ShoesSize             = $staffData['shoes_size'];
        $staff->Height                = $staffData['height'];
        $subStaff->ClothesSize        = $staffData['clothes_size'];
        if(array_key_exists('suit_preparation',$staffData)){
            $staff->SuitPreparation           = $staffData['suit_preparation'];
        }
        if(array_key_exists('suit_preparation',$staffData)){
            $staff->WhiteShirtPreparation     = $staffData['white_shirt_preparation'];
        }
        if(array_key_exists('black_pump_preparation',$staffData)){
            $staff->BlackPumpPreparation      = $staffData['black_pump_preparation'];
        }
        if(array_key_exists('apron_sling',$staffData)){
            $staff->ApronSling                = $staffData['apron_sling'];
        }
        if(array_key_exists('black_hair_modification',$staffData)){
            $staff->BlackHairModification     = $staffData['black_hair_modification'];
        }
        if(array_key_exists('voice',$staffData)){
            $staff->Voice                     = $staffData['voice'];
        }
        if(array_key_exists('department_store_experience',$staffData)){
            $staff->DepartmentStoreExperience = $staffData['department_store_experience'];
        }
        if(array_key_exists('pos_cash_register_experience',$staffData)){
            $staff->POSCashRegisterExperience = $staffData['pos_cash_register_experience'];
        }
        if(array_key_exists('cat_experience',$staffData)){
            $staff->CATExperience             = $staffData['cat_experience'];
        }
        if(array_key_exists('nail_modification',$staffData)){
            $staff->NailModification          = $staffData['nail_modification'];
        }
        
        return array($staff,$subStaff);
    }

    /**
     * Add new pre-register staff
     * @param $staff
     * @param $staffData
     * @return bool
     */
    public function addStaffRegister($staff, $subStaff, $staffData) {
        
        //Add new pre-register staff
        $regionId = $staffData['region'];
        $staff->Name            = $staffData['first_name'].' '.$staffData['last_name'];
        $staff->NameFurigana    = $staffData['first_name_furigana'].' '.$staffData['last_name_furigana'];
        $staff->RegisterDate    = Carbon::now();
        $staff->save();
        $subStaff->StaffId = $staff->StaffRegisterId;
        $subStaff->save();
        $staffId = $staff->StaffRegisterId;
        $region  = Region::find($regionId);
        if(array_key_exists('region',$staffData)) {
            //Check Possible Time
            if(array_key_exists('noPossibleTime', $staffData) && $staffData['noPossibleTime'] == 'check') {
                if($region->Type == 0) {
                    $interview = new Interview();
                    $interview->StaffId = $staffId;
                    $interview->RegionId = $regionId;
                    $interview->save();
                }
            } else {
                if($region->Type == 1) {
                    //Check if staff check any interview date & time
                    if(array_key_exists('interviewDate',$staffData) && array_key_exists('interviewTime',$staffData) ) {
                        $interviewDate = $staffData['interviewDate'];
                        $interviewTime = $staffData['interviewTime'];
                        $staffId = $staff->StaffRegisterId;

                        //Add interview for nearest date
                        foreach ($interviewDate as $index => $date) {
                            if (array_key_exists($index, $interviewTime)) {
                                $interviewTime = $interviewTime[$index];
                                foreach ($interviewTime as $time) {
                                    $interview = new Interview();

                                    $interviewTime = InterviewTime::where('RegionId', $regionId)->where('InterviewDate', $date)->where('InterviewTime', $time)->first();
                                    $interview->StaffId = $staffId;
                                    $interview->RegionId = $regionId;
                                    $interview->InterviewTimeId = $interviewTime->InterviewTimeId;
                                    $interview->save();
                                }
                                break;
                            }
                        }
                    }
                } else {
                    $anotherInterview = new AnotherInterview();
                    $anotherInterview->StaffId = $staffId;
                    $anotherInterview->AnotherInterviewTimeId = $staffData['anotherInterviewTime'];
                   
                    if(array_key_exists('appointment_time_from',$staffData)){
                        $anotherInterview->Hour    = $staffData['appointment_time_from']. '~' .$staffData['appointment_time_to'];
                    }
                    $anotherInterview->save();

                }
            }
        }
        
        //Add new user base on pre-register staff
        $user = new User();
        $user->name     = $staff->Name;
        $user->email    = $staff->Email;
        $user->password = Hash::make($staffData['password']);
        $user->save();

        //Add role

        $preRegisterRole = Role::where('name','pre-register')->first();
        $user->attachRole($preRegisterRole);
        session()->forget('staffData');
        return true;
    }

    /**
     * Update Pre-register staff information before interview
     * @param $staffData
     */
    public function updateStaffRegister($staffData) {

        $staff = Staff::where('Email',$staffData['email'])->first();
        if($staff) {
            list($staff,$subStaff) =  $this->basicStaffData($staff->StaffRegisterId,$staffData);
            //Update staff information
            $staff->save();
            $subStaff->save();
        }
    }

    /**
     * Search staff information by name
     * @param $staffName
     * @return mixed
     */
    public function searchStaffInfoByName($staffName){
        
        $staff = Staff::select('StaffRegisterId','Name','NameFurigana')
        ->where('Name','like',"%$staffName%")
        ->orWhere('NameFurigana','like',"%$staffName%")
        ->get();
        return $staff;
    }
    /** ThienNB
     * Search pre staff information by name
     * @param $staffName
     * @return mixed
     */
    public function searchPreRegisterInfoByName($staffName) {

      //get all user has rule pre-register
      $preRegisterUser = User::whereHas('roles', function($query) {
          $query->where('name', 'pre-register');
        })->get();

      $staffIdPre = [];
      foreach ($preRegisterUser as $pre) {
        if ($pre->Staff) {
          $staffIdPre[] = $pre->Staff->StaffRegisterId;
        }
      }

      $staff = Staff::select('StaffRegisterId', 'Name', 'NameFurigana')
        ->whereIn('StaffRegisterId', $staffIdPre)
        ->where(function($staff) use ($staffName) {
          $staff->where('Name', 'like', "%$staffName%")
          ->orWhere('NameFurigana', 'like', "%$staffName%");
        })
        ->get();
      return $staff;
    }

    /**
     * Search staff innerjoin with user information by name
     * @param $staffName
     * @return mixed
     */
    public function searchStaffJoinInfoByName($staffName){
        //get all user has rule staff
          $staffUser = User::whereHas('roles', function($query) {
              $query->where('name', 'staff');
            })->get();

          $staffIdPre = [];
          foreach ($staffUser as $pre) {
            if ($pre->Staff) {
              $staffIdPre[] = $pre->Staff->StaffRegisterId;
            }
          }

        $staff = Staff::select('StaffRegisterId','t_staff.Name','t_staff.NameFurigana')
        ->join('users','t_staff.Email','=','users.email')
         ->whereIn('StaffRegisterId', $staffIdPre)
        ->where(function($staff) use ($staffName) {
          $staff->where('t_staff.Name', 'like', "%$staffName%")
          ->orWhere('t_staff.NameFurigana', 'like', "%$staffName%");
        })
        
        ->get();
        return $staff;
    }

    /**
     * Update pre register staff detail by officer
     * @param $staffId
     * @param $preRegisterDetail
     * @return mixed
     */
    public function updateStaffPreRegisterDetail($staffId,$preRegisterDetail) {
//        dd($preRegisterDetail);
        $staff = Staff::find($staffId);
        $preRegisterDetail['email'] = $staff->Email;
        //save tag staff by office
        $substaff = $staff->SubStaff;
        //Update staff thumbnail if need
        if (array_key_exists('pdf_resume', $preRegisterDetail)) {
          
            $uploadHelper = new UploadHelper();
            list($extension, $filename) = $uploadHelper->UploadFile($preRegisterDetail['pdf_resume']);
            $resource = new Resource();
            $resource->Path = "img/uploads/" . $filename;
            $resource->Name = $filename;
            $resource->MimeType = $extension;
            $resource->save();
            $substaff->PDFResume = $resource->ResourceId;
        }
        
        
        $staff->ContactName   = $preRegisterDetail['contact_name'];
        $staff->ContactPhoneNumber   = $preRegisterDetail['contact_phone'];
        $staff->WorkStartDate   = $preRegisterDetail['work_start'];
        $staff->TaxClassification   = $preRegisterDetail['tax_classification'];
        $staff->Interviewer   = $preRegisterDetail['interviewer'];
        $staff->InterviewDate = $preRegisterDetail['interviewDate'];

//        if(array_key_exists('tag',$preRegisterDetail)){
//            $staff->Tag = serialize($preRegisterDetail['tag']);
//        }

        
        
        if(isset($preRegisterDetail['nationality_code']) ){
          $staff->NationalCode= $preRegisterDetail['nationality_code'];
        }
        $staff->save();
        
        foreach ($staff->SubStaff->TagArray as $key => $value ){
          if(isset($preRegisterDetail[$key])){
            $substaff->$key = 1;
        }else {
            $substaff->$key = 0;
        }
        //save rank 
        
        if($preRegisterDetail['selectRank'] == 1) {
            $substaff->Rank            = $preRegisterDetail['rank'];
            $substaff->RankType        = $preRegisterDetail['selectRank'];
            $substaff->Appearance      = $preRegisterDetail['appearance'];
            $substaff->Attitude        = $preRegisterDetail['attitude'];
            $substaff->Expression      = $preRegisterDetail['expression'];
            $substaff->Personality     = $preRegisterDetail['personality'];
            $substaff->AdminExperience = $preRegisterDetail['admin_sale_experience'];
            $substaff->SaleExperience  = $preRegisterDetail['sale_experience'];
            $substaff->BeingLate       = $preRegisterDetail['being_late'];
            $substaff->Willing         = $preRegisterDetail['appearance'];
            $substaff->Corresponding   = $preRegisterDetail['corresponding'];
        } else {
            if($preRegisterDetail['selectRank'] != null){
                $substaff->RankType        = $preRegisterDetail['selectRank'];
            }
        }
        $substaff->FirstImpression = $preRegisterDetail['first_impression'];
        $substaff->Comment         = $preRegisterDetail['comment'];
        //update by who
        $currentEditor = auth()->guard('admin')->user();
        if($currentEditor->GaiA){
          $name = $currentEditor->GaiA->Firstname.' '.$currentEditor->GaiA->Lastname;
        }  else {
          $name = $currentEditor->name;
        }
        //save verify
        
        $substaff->update_by   = $name;
        if(isset($preRegisterDetail['verify']) && $preRegisterDetail['verify']==1){
          $substaff->Verify= 1;
        }  else {
          $substaff->Verify= 0;
        }
        

    }

    $result = $staff->SubStaff()->save($substaff);
    
        //save detail staff 
    $saveDetail = $this->updateStaffRegister($preRegisterDetail);

    return $staff;
    }

    /**
     * Change role of a pre-register staff to staff by officer
     * @param $user
     * @return bool
     */
    public function changeRole($user){
        $preRegisterRole = Role::where('name','pre-register')->first();
        $staffRole       = Role::where('name','staff')->first();
        if($user->hasRole('pre-register')) {
            DB::table('role_user')->where('user_id',$user->id)->where('role_id',$preRegisterRole->id)->delete();
            $user->attachRole($staffRole);
        }
        return true;
    }

    /**
     * Get data list of Pre Register & filter with data
     * @param $filterData
     * @return mixed
     */
    public function getPreRegisterListWithFilter($filterData) {

        $preRegisterStaffList = Staff::select('StaffRegisterId','Email','Name','Birthdate','Sex','InterviewDate');
        /*dd($preRegisterStaffList);*/
        
        //get all user has rule pre-register
        $preRegisterUser = User::whereHas('roles', function($query)
        {
          $query->where('name', 'pre-register');
        })->get();

        $staffIdPre = [];
        foreach ($preRegisterUser as $pre){
            if($pre->Staff){
            $staffIdPre[] = $pre->Staff->StaffRegisterId;
            }
        }
        if($filterData['nameKey'] != null) {
            $key = $filterData['nameKey'];
            $preRegisterStaffList->where('Name','like',"%$key%")
            ->orWhere('Name','like',"%$key%");
        }

        if($filterData['interviewDate'] != null){
            $preRegisterStaffList->where('InterviewDate',$filterData['interviewDate']);
        }

        if($filterData['status'] != null){
            $currentDate = date_create('today');
            
            //User co role la pre-register, ngay phong van lon hon ngay hien tai hasRole('pre-register') && 面接待
            if($filterData['status'] == 0){
                $preRegisterStaffList->whereIn('StaffRegisterId', $staffIdPre);  
                $preRegisterStaffList->where(function($preRegisterStaffList) use ($currentDate)
                  {
                      $preRegisterStaffList->where('InterviewDate','>=',$currentDate)
                            ->orWhereNull('InterviewDate');
                  });
//                $preRegisterStaffList->where('InterviewDate','>=',$currentDate);
//                $preRegisterStaffList->orWhereNull('InterviewDate');
            }
            //User co role la pre-register, ngay phong van be hon ngay hien tai hasRole('pre-register') && 登録待
            if($filterData['status'] == 1){
                $preRegisterStaffList->whereIn('StaffRegisterId', $staffIdPre);  
                $preRegisterStaffList->where('InterviewDate','<',$currentDate);
            }
        }  else {
            $preRegisterStaffList->whereIn('StaffRegisterId', $staffIdPre);  

        }
        return $preRegisterStaffList->get();
    }

    /**
     * Get staff by some condition in search
     * @param $search
     * @return mixed
     */
    public function getStaffBySearching( $search ){
        $table = Staff::leftJoin('t_substaff', 't_substaff.StaffId', '=', 't_staff.StaffRegisterId')
        ->leftJoin('t_station', 't_station.StationId', '=', 't_substaff.NearestStation')
        ->leftJoin('t_resource', 't_resource.ResourceId', '=', 't_substaff.Image');

        if ( isset($search['male']) && isset($search['female']) ) {
            $table->where('t_staff.Sex', 'LIKE', '%');
        } else if ( isset($search['female']) ) {
            $table->where('t_staff.Sex', 'LIKE', '0');
        } else if ( isset($search['male']) ){
            $table->where('t_staff.Sex', 'LIKE', '1');
        }

        if ( !empty($search['startAge']) && is_numeric($search['startAge']) ) {
            $date = new \Carbon\Carbon($search['startAge'].' years ago');
            $date = $date->format('Y-m-d');
            $table->where('t_staff.Birthdate', '<=', $date);
        }

        if ( !empty($search['endAge']) && is_numeric($search['endAge']) ) {
            $date = new \Carbon\Carbon($search['endAge'].' years ago');
            $date = $date->format('Y-m-d');
            $table->where('t_staff.Birthdate', '>=', $date);
        }

        if ( !empty($search['nearestStation']) ) {
            $table->where('t_station.StationName', 'LIKE', $search['nearestStation']);
        }

        if ( isset($search['tags']) ) {
            foreach ($search['tags'] as $key => $value) {
                $table->where("t_substaff.{$key}", 1);
            }
        }

        if ( isset($search['registrationHistory']) ) {
            $search['registrationHistory'] = $search['registrationHistory'] == -1 ? '%' : $search['registrationHistory'];
            $table->where('t_substaff.RegistrationHistory', 'LIKE', $search['registrationHistory']);
        }

        return $table->select(
            't_staff.*',
            't_station.StationName',
            't_resource.Path',
            't_substaff.RegistrationHistory'
            );
    }

    /**
     * Get comments in staff
     * @param
     * @return mixed
     */
    public function getStaffComments( $num = 10 ){
        $data = SubStaff::join('t_staff', 't_staff.StaffRegisterId', '=', 't_substaff.StaffId')->select('Comment', 'Name', 'InterviewDate')
                ->orderBy('t_staff.InterviewDate')
                ->take($num)
                ->get();
        return $data;
    }

    /** 
    *----------------------------   
    * CREATE: HieuBV    
    * DATE: 20160602
    * CONTENT: Get staff base condition 
    *----------------------------   
    * @param $staffInfo    
    * @return staff  
    *----------------------------   
    */  
    public function introduceJob($staffInfo){

        $staff = new Staff();
        $staff = $staff->join('t_substaff', 't_substaff.StaffId', '=', 't_staff.StaffRegisterId');

        if(!empty($staffInfo['sex'])) {
            $staff = $staff->whereIn('Sex', $staffInfo['sex']);
        }

        if(!empty($staffInfo['rank'])){
            $staff = $staff->whereIn('t_substaff.Rank', $staffInfo['rank']);
        }

        if(!empty($staffInfo['oldstart'])){
            $birthdate = Carbon::parse(new Carbon($staffInfo['oldstart'].' years ago'))->format('Y-m-d');
            $staff = $staff->where('Birthdate', '<', $birthdate);
        }

        if(!empty($staffInfo['oldend'])){
            $birthdate = Carbon::parse(new Carbon($staffInfo['oldend'].' years ago'))->format('Y-m-d');
            $staff = $staff->where('Birthdate', '>', $birthdate);
        }

        if(!empty($staffInfo['name'])){
            $staff = $staff->where('Birthdate', '>', $birthdate);
        }

        return $staff->get();
    }

    /**
     * Get staff by OrderTimeId
     * @param
     * @return mixed
     */
    public function getStaffByOrderTimeId( $orderTimeIds ){
        $data = Staff::select('t_staff.StaffRegisterId', 't_staff.Name', 't_wantedjob.OrderTimeId', 't_wantedjob.TimeStartWanted')
                ->leftJoin('t_wantedjob','t_wantedjob.StaffId', '=', 't_staff.StaffRegisterId')
                ->where('t_wantedjob.Status', WantedJob::STATUS_APPROVE)
                ->whereIn('t_wantedjob.OrderTimeId', $orderTimeIds)
                ->get();
        return $data;
    }
    
    /**
     * ----------------------------   
     * CREATE: NhuongPH    
     * DATE: YYYYMMDD
     * CONTENT: Send mail for pre register step 2
     * @param: data of staff pre registered
     * @return sendmail into staff
     * ----------------------------   
     */
    public function sendMail($staffData) {
        try {
            $subject = trans('title.pwd.reset_pwd.title_mail.no_region');
            //no check region
            $aprove_mail = \Config::get('app.aprove_mail');
            if($aprove_mail == 1){
                if (isset($staffData['noPossibleTime']) && $staffData['noPossibleTime'] == "check") {
                    Mail::send(['html' => 'site.email.pre_re_no_regi_mail']
                            , [
                        "first_name" => $staffData['first_name'],
                        'last_name' => $staffData['last_name'],
                        'password' => $staffData['password'],
                        'service_name' => $subject,
                            ]
                            , function ($message) use ($staffData, $subject) {
                        $message->from('system@gaia-ad.co.jp');
                        $message->to($staffData['email'])->subject($subject . 'へ登録ありがとうございました');
                    });
                    //check region
                } else if (isset($staffData['region'])) {
                    if ($staffData['region'] == 1) {//Tokio
                        $subject = trans('title.pwd.reset_pwd.title_mail.tokio');
                        $date = array();
                        foreach ($staffData['interviewTime'] as $key => $time_list) {
                            $d = date('Y 年 m 月 d 日', strtotime($staffData['interviewDate'][$key]));
                            foreach ($time_list as $key => $var) {
                                array_push($date, $d . $var);
                            }
                        }
                        Mail::send(['html' => 'site.email.pre_re_tok_mail']
                                , [
                            "first_name" => $staffData['first_name'],
                            'last_name' => $staffData['last_name'],
                            'password' => $staffData['password'],
                            'interviewTime' => $date,
                                ]
                                , function ($message) use ($staffData, $subject) {
                            $message->from('system@gaia-ad.co.jp');
                            $message->to($staffData['email'])->subject($subject);
                        });
                    } else if ($staffData['region'] == 2) {//Kanagawa  
                        $subject = trans('title.pwd.reset_pwd.title_mail.kanagawa');
                        $date = array();
                        foreach ($staffData['interviewTime'] as $key => $time_list) {
                            $d = date('Y 年 m 月 d 日', strtotime($staffData['interviewDate'][$key]));
                            foreach ($time_list as $key => $var) {
                                array_push($date, $d . $var);
                            }
                        }
                        Mail::send(['html' => 'site.email.pre_re_ka_mail']
                                , [
                            "first_name" => $staffData['first_name'],
                            'last_name' => $staffData['last_name'],
                            'password' => $staffData['password'],
                            'interviewTime' => $date,
                                ]
                                , function ($message) use ($staffData, $subject) {
                            $message->from('system@gaia-ad.co.jp');
                            $message->to($staffData['email'])->subject($subject);
                        });
                    } else if ($staffData['region'] == 3) {//other
                        $subject = trans('title.pwd.reset_pwd.title_mail.other');
                        $anotherInterviewTime = AnotherInterviewTime::where('AnotherInterviewTimeID', $staffData['anotherInterviewTime'])->first();
                        if (isset($anotherInterviewTime) && !empty($anotherInterviewTime)) {
                            Mail::send(['html' => 'site.email.pre_re_oth_mail']
                                    , [
                                "first_name" => $staffData['first_name'],
                                'last_name' => $staffData['last_name'],
                                'password' => $staffData['password'],
                                'region_name' => $anotherInterviewTime['RegionName'],
                                'date' => date('Y 年 m 月 d 日', strtotime($anotherInterviewTime['Date'])),
                                'time_from' => $staffData['appointment_time_from'],
                                'time_to' => $staffData['appointment_time_to'],
                                    ]
                                    , function ($message) use ($staffData, $subject) {
                                $message->from('system@gaia-ad.co.jp');
                                $message->to($staffData['email'])->subject($subject);
                            });
                        }
                    }
                }
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }
    
    /**
     * ----------------------------   
     * CREATE: NhuongPH    
     * DATE: YYYYMMDD
     * CONTENT: Send mail set pre register to staff
     * @param: Staff Id
     * @return sendmail to staff
     * ----------------------------   
     */
    public function sendMailStaff($email) {
        try {
            $staff = Staff::where('Email',$email)->first();
            $service_name = trans('title.pwd.reset_pwd.title_mail.service_name');
            $subject = trans('title.pwd.reset_pwd.title_mail.set_staff');
            
            $aprove_mail = \Config::get('app.aprove_mail');
            if (($aprove_mail == 1) && isset($staff) && !empty($staff)) {
                Mail::send(['html' => 'site.email.set_staff_mail']
                        , [
                            "name" => $staff->Name,
                            'staffAddress' => $staff->Email,
                            'staffCode' => $staff->StaffCode,
                            'service_name' => $service_name
                        ]
                        , function ($message) use ($staff, $subject) {
                    $message->from('system@gaia-ad.co.jp');
                    $message->to($staff->Email)->subject($subject);
                });
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }
}