<?php
//====================================================================================						
//						
//	FILENAME: StaffMessageBusiness.php					
//	CREATE: YYYYMMDD					
//	CREATOR: ToiTL					
//						
//====================================================================================						
//						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//------------------------------------------------------------------------------------						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//====================================================================================
namespace App\Business;
use App\Model\StaffMessage;
use App\Model\Staff;
use App\Model\OrdersTime;
use App\Model\Orders;
use App\Model\ShiftTable;
use Mail;
use Swift_Mailer;
use Swift_SmtpTransport as SmtpTransport;

class StaffMessageBusiness {
	/** 
    *----------------------------   
  	* CREATE: ToiTL    
  	* DATE: YYYYMMDD
  	* CONTENT: add staff message method
  	*----------------------------
  	* @param $request   
  	* @return view  
  	*----------------------------   
  	*/
    public function addStaffMessage($message, $shiftTableId, $staffId) {
        $mess = new StaffMessage();

        $mess->Content = $message;
        $mess->ShiftTableId = $shiftTableId;
        $mess->StaffId = $staffId;
        $mess->SentDateTime = date('Y-m-d H:i:s');

        $mess->save();
        $this->sendMailAddStaffMessage($mess, $shiftTableId, $staffId);

        return $mess;
    }
    
    /*----------------------------   
  	* CREATE: NhuongPH    
  	* DATE: YYYYMMDD
  	* CONTENT: Send staff mail
  	*----------------------------
  	* @param $request   
  	* @return send  mail  
  	*----------------------------   
  	*/
    private function sendMailAddStaffMessage($mess, $shiftTableId, $staffId) {
        try {
            $staff = Staff::where('StaffRegisterId',$staffId)->first();
            $orderId = ShiftTable::select('OrderId')
                                ->leftJoin('t_orders_time','t_orders_time.OrderTimeid', '=', 't_shifttable.OrderTimeId')
                                ->where('t_shifttable.StaffId', $staffId)
                                ->where('t_shifttable.ShiftTableId', $shiftTableId)
                                ->first();
            $orders = Orders::select('t_orders.ProjectName'
                                    , 't_projectbasicinfo.BasicInfoID'
                                    ,'t_projectbasicinfo.MainChargeMail'
//                                    ,'t_projectbasicinfo.SubChargeMailOne'
                                    )
                ->leftJoin('t_projectbasicinfo','t_projectbasicinfo.OrderId', '=', 't_orders.OrderId')
                ->where('t_orders.OrderId', $orderId->OrderId)
                ->get();
            $subject = trans('title.pwd.reset_pwd.title_mail.set_staff');
            
            if (isset($orders) && !empty($orders)) {
                foreach ($orders as $order){
//                    $transport = SmtpTransport::newInstance('smtp.gmail.com', 587);
//                    $transport->setEncryption('tls');
//                    $transport->setUsername('nhuongph@rikkeisoft.com');
//                    $transport->setPassword('phn!9911');
//                    $swift = new Swift_Mailer($transport);
//
//                    Mail::setSwiftMailer($swift);
                    Mail::send(['html' => 'site.email.add_staff_message_mail']
                            , [
                                "project_name" => $order->ProjectName,
                                'staff_name' => $staff->Name,
                                'message_detail' => $mess->Content,
                                'message_id' => $mess->StaffMessageId,
                                'project_id'  =>  $order->BasicInfoID
                            ]
                            , function ($message) use ($order, $subject) {
                        $message->from('system@gaia-ad.co.jp');
                        $message->to($order->MainChargeMail)->subject($subject);
//                        if(isset($order->SubChargeMailOne) && !empty($order->SubChargeMailOne)){
//                            $message->cc($order->SubChargeMailOne)->subject($subject);
//                        }
                    });
                }
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }
}