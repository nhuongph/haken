<?php
namespace App\Business;

use App\Model\Tag;

class TagBusiness {

    public function getAllTag() {
        return Tag::all();
    }
}