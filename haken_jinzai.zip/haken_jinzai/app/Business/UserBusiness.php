<?php
namespace App\Business;

use App\Model\User;
use App\Model\Role;
use App\Model\GaiA;
use Illuminate\Support\Facades\Hash;
use DB;
class UserBusiness {

    /**
     * Get all user
     * @return mixed
     */
    public function getAllUser() {

        $users = User::select('id','name','email','firstname','lastname','part')->get();
        $users = $users->reject(function ($user) {
            return $user->hasRole('admin') === true;
        });

        return $users;
    }


    /**
     * Get user info by id
     * @param $userId
     * @return mixed
     */
    public function getUserById($userId) {
        return User::find($userId);
    }

    /**
     * Get user info by email
     * @param $email
     * @return mixed
     */
    public function getUserByEmail($email) {
        return User::where('email',$email)->first();
    }
    //Add New User
    public function userData($userData,$userId){
        $user = User::find($userId);
        //Check if user exist
        if(!$user) {
            $user = new User();
        }
        $user->name     = $userData['name'];
        $user->email    = $userData['email'];
        $user->password = Hash::make($userData['password']);
        $user->save();
        return $user;
    }

    

    public function getInterviewer(){
//        $interviewer = User::select('id','lastname','firstname')->get();
//        $interviewer = $interviewer->reject(function ($user) {
//            return $user->hasRole('admin') === true;
//        });
//        $interviewers = [];
//        foreach($interviewer as $value){
//            $interviewers[$value->id] = $value->firstname.' '.$value->lastname;
//        }
//        return $interviewers;
        $user = User::with('GaiA')->has('GaiA')->get();
        $interviewers = [];
    
        foreach($user as $value){
            $interviewers[$value->id] = $value->GaiA->Firstname.' '.$value->GaiA->Lastname;
        }
        return $interviewers;
      
    }

    /*public function userResgisterPersonal($userData,$userId){
        $user = User::find($userId);
        //Check if user exist
        if(!$user) {
            $user = new User();
        }
        //$user = new User();
        $user->email             = $userData['email'];
        $user->password          = Hash::make($userData['password']);
        $user->firstname         = $userData['firstname'];
        $user->lastname          = $userData['lastname'];
        $user->firstname_kana    = $userData['firstname_kana'];
        $user->lastname_kana     = $userData['lastname_kana'];
        $user->part              = $userData['part'];
        $user->save();

        if(array_key_exists('roleid',$userData)) {
         foreach ($userData['roleid'] as $item) {
            $role = Role::find($item);
            $user->attachRole($role);
        }
    }
    return $user;
    }*/

    public function userResgisterPersonal($userData,$userId){
        $user = User::find($userId);
        $gaia = GaiA::where('email',$userId)->first();
        //Check if user exist
        if(!$user) {
            $user = new User();
        }

        if(!$gaia){
            $gaia = new GaiA();
        }
        //$user = new User();
        $user->email             = $userData['email'];
        $user->password          = Hash::make($userData['password']);
        $user->name              = $userData['firstname'] .' ' .$userData['lastname'] ;
        $gaia->Firstname         = $userData['firstname'];
        $gaia->Lastname          = $userData['lastname'];
        $gaia->Firstname_Kana    = $userData['firstname_kana'];
        $gaia->Lastname_Kana     = $userData['lastname_kana'];
        $gaia->Part              = $userData['part'];
        $gaia->email             = $user->email;
        $gaia->phone             = $userData['phone'];        
        $gaia->BasicAuthority    = $userData['basicAuthority'];
        $user->save();
        $gaia->save();

            if(array_key_exists('roleid',$userData)) {
             foreach ($userData['roleid'] as $item) {
                $role = Role::find($item);
                $user->attachRole($role);
            }
        }
        return $user;
    }

     /**
     * Get Role name base on user Id
     * @return mixed
     */
     public function getRoleNameByUserId($userId)
     {           
        $roles = [];            
        $role_users = DB::table('role_user')->select('role_id')->where('user_id',$userId)->get(); 
        $roleName = [];  

        if(count($role_users) > 0){     
            foreach ($role_users as $key => $role) {                
                $roles = Role::select('display_name')->where('id',$role->role_id)->first();
                if($roles){
                    $roleName[] = $roles->display_name;                
                }                
            }                
        }  
        return $roleName;
    }

     /**
     * Get user with condition
     * @return mixed
     */
     public function getUserByCondition($UserInfo) {
        $username = $UserInfo['userName'];
        $roleInfoArr = $UserInfo['roleInfoArr'];
        $partInfoArr = $UserInfo['partInfoArr'];
        
        //join table t_gaia and role user, users
        $users = DB::table('t_gaia')
        ->leftjoin('users', 't_gaia.email', '=', 'users.email')
        ->leftjoin('role_user', 'users.id', '=', 'role_user.user_id')
        ->select('users.id','t_gaia.Firstname','t_gaia.Lastname','t_gaia.Part','role_id','t_gaia.email')
        
        //check first name and last name
        ->where(function ($query) use ($username){
            $query->where('t_gaia.Firstname', 'like', "%$username%")
            ->orWhere('t_gaia.Lastname', 'like', "%$username%");
        })

        //check role conditon, if null not check
        ->where(function ($query) use ($roleInfoArr){
            if ($roleInfoArr != "") {
                $query->where('role_id',$roleInfoArr);
            }
        })

        //check part conditon, if null not check
        ->where(function ($query) use ($partInfoArr){
            if ($partInfoArr != "") {
                $query->where('t_gaia.Part',$partInfoArr);
            }
        })
   
        ->groupBy('t_gaia.email');

        return $users;
    }
    
    /**
     * Get user mail by name method
     *
     * @author ToiTL
     * @date 2016/05/23
     * @param String $name
     * @return User
     */
    public function getUserMailByName( $name = '' ){
        if ( $name == '' ) {
            return '';
        }

        $user = User::where('name', 'LIKE', $name)->select('email')->first();

        return $user;
    }

    /**
     * Get gaia info by user id
     *
     * @author PhongND
     * @date 2016/06/10
     * @param String $userId
     * @return user
     */
    public function getGaiAInfoByUserId($userId){
        $user = DB::table('users')
        ->join('t_gaia', 'users.email', '=', 't_gaia.email')
        ->join('roles', 'roles.id', '=', 't_gaia.basicAuthority')
        ->select('users.id','t_gaia.Firstname','t_gaia.Lastname','t_gaia.Firstname_Kana', 't_gaia.Lastname_Kana', 't_gaia.Part','t_gaia.email','t_gaia.phone',"roles.display_name")
        ->where('users.id', '=', $userId)
        ->first();

        return $user;
    }
    /**
     * Get All user GaiA
     *
     * @author ThienNb
     * @date 2016/06/13
     * @param 
     * @return user
     */
    public function getAllGaiA(){
        $user = User::with('GaiA')->has('GaiA')->get();
        $interviewers = [];
    
        foreach($user as $value){
            $interviewers[$value->id] = $value->GaiA->Firstname.' '.$value->GaiA->Lastname;
        }
        return $interviewers;
    }

    public function getAllGaiAWithInfo() {

        $users = GaiA::select('*')->get();

        return $users;
    }
}