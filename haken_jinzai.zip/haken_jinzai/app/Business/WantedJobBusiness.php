<?php

//====================================================================================
//
//  FILENAME: WantedJobBusiness.php
//  CREATE: 20160523
//  CREATOR: ThienNB
//
//====================================================================================

namespace App\Business;

use App\Model\WantedJob;
use App\Model\Orders;
use App\Model\ProjectBasicInfo;
use App\Model\OrdersTime;
use App\Model\ProjectCheckPoint;
use Illuminate\Support\Facades\Auth;

class WantedJobBusiness {

  /**
   * get all orderTime from order
   * @param $companyInfo
   * @return 
   */
  public function getOrderTimeByOrder($orderId) {
    $order = Orders::find($orderId)->OrdersTime;
    return $order;
  }

  public function getOrderByOrderTime($orderId) {
    $order = OrdersTime::find($orderId)->order;
    return $order->get();
  }

  public function getOrderById($orderId) {
    $order = Orders::find($orderId);
    return $order;
  }

  public function getOrderTimeNameById($orderId) {
    $order = OrdersTime::find($orderId);
    return $order->TimeStart . '-' . $order->TimeEnd;
  }
  /**
   * get selected wanted job submit by staff and orderId
   * @param $orderId , $staffId
   * @return 
   */
  public function getSelectedWanted($orderId, $staffId) {
    $dataArr = array();
    $orderTimes = WantedJob::where('StaffId', $staffId)->get();
    foreach ($orderTimes as $orderTime) {
      $dataArr[] = date('Y-m-d', strtotime($orderTime->DateWanted)) . '@' . $orderTime->OrderTimeId;
    }
    return $dataArr;
  }
  /**
   * delete all wantedjob from order by staff
   * @param $orderId , $staffId
   * @return 
   */
  public function resetWantedJobUser($orderId, $staffId) {
    $orderTimes = Orders::find($orderId)->OrdersTime;

    foreach ($orderTimes as $orderTime) {
      $wanted = WantedJob::where('OrderTimeId', $orderTime->OrderTimeid)
      ->where('StaffId', $staffId);

      $wanted->delete();
    }
    return $wanted;
  }
  /**
   * get all wantedjob
   * @param $companyInfo
   * @return 
   */
  public function getAllWantedJob() {

    $result = WantedJob::all();
    return $result;
  }
  /**
   * get all project for staff . depend on type in wanted-job model
   * @param $type
   * @return paginate 
   */
  public function getAllProject($type = 1) {

    if ($type == WantedJob::TYPE_SEFT_ELECTED) {
      //Get all project registed
      $projectRegisted = ProjectBasicInfo::with('Orders')
      ->whereHas('Orders.OrdersTime.WantedJob', function ($query) {
        $staffId = auth()->guard('admin')->user()->staff->StaffRegisterId;
        $query->where('StaffId', '=', $staffId);
        $query->where('Status', '=', WantedJob::STATUS_SUBMITED);
      })->get()->getDictionary();
      //Get project not registed from registed
      $result = ProjectBasicInfo::with('Orders')
      ->whereNotIn('BasicInfoID', array_keys($projectRegisted))
      ->paginate(5);
    } else if ($type == WantedJob::TYPE_RECOMMEND) {
      $result = ProjectBasicInfo::with('Orders')
      ->whereHas('Orders.OrdersTime.WantedJob', function ($query) {
        $staffId = auth()->guard('admin')->user()->staff->StaffRegisterId;
        $query->where('StaffId', '=', $staffId);
        $query->where('Status', '=', WantedJob::STATUS_NOT_SUBMIT);
        $query->where('Type', '=', WantedJob::TYPE_RECOMMEND);
      })
      ->paginate(5);
    } else {
      //Type staff registed
      $result = ProjectBasicInfo::with('Orders')
      ->whereHas('Orders.OrdersTime.WantedJob', function ($query) {
        $staffId = auth()->guard('admin')->user()->staff->StaffRegisterId;
        $query->where('StaffId', '=', $staffId);
        $query->where('Status', '=', WantedJob::STATUS_SUBMITED);
      })
      ->paginate(5);
    }
    return $result;
  }
  /**
   * save new wanted job 
   * @param $wantedJob
   * @return  $wantedJob
   */
  public function saveWanted($wantedJob) {
    $data = new WantedJob();
    foreach ($wantedJob as $key => $value) {
      if (\Illuminate\Support\Facades\Schema::hasColumn($data->getTable(), $key)) {
        $data->$key = $value;
      }
    }
    $success = $data->save();
    return $success;
  }

  /**
   * get wanted job 
   * @param $wantedJob
   * @return $wantedJob
   */
  public function getWantedByStaffId($staffId){
    $wantedJobs = WantedJob::join('t_orders_time', 't_orders_time.OrderTimeid', '=', 't_wantedjob.OrderTimeId')
    ->leftJoin('t_orders', 't_orders.OrderId', '=', 't_orders_time.OrderId')
    ->leftJoin('t_projectbasicinfo', 't_projectbasicinfo.OrderId', '=', 't_orders.OrderId');

    $wantedJobs->where('t_wantedjob.StaffId', $staffId);

    return $wantedJobs->select(
      't_wantedjob.*',
      't_projectbasicinfo.StartDate AS StartDate',
      't_projectbasicinfo.EndDate AS EndDate',
      't_orders.ProjectName AS ProjectName',
      't_orders.OrderId AS OrderId'
      )->get();
  }

    /** 
    *----------------------------   
    * CREATE: HieuBV    
    * DATE: 20160602
    * CONTENT: Get staff base condition 
    *----------------------------   
    * @param $staffInfo    
    * @return staff  
    *----------------------------   
    */  
  public function saveIntroduceJobProject($staffId, $orderTimeId){
    $wantedJob = new WantedJob();
    $wantedJob->OrderTimeId = $orderTimeId;
    $wantedJob->StaffId = $staffId;
    $wantedJob->Type = 2;        
    $wantedJob->save();
  }  
  
  /** 
  *----------------------------   
  * CREATE: HieuBV    
  * DATE: 20160602
  * CONTENT: Get staff base condition 
  *----------------------------   
  * @param $staffInfo    
  * @return staff  
  *----------------------------   
  */ 
  public function getProjectWithSomeCondition( $search ){
    $table = ProjectBasicInfo::join('t_orders','t_orders.OrderId','=','t_projectbasicinfo.OrderId')
    ->leftJoin('t_resource','t_resource.ResourceId','=','t_projectbasicinfo.Thumbnail');
    
    
    if ( isset($search['Brand']) ) {
        $search['Brand'] = $search['Brand'] == -1 ? '%' : $search['Brand'];
        $table->where('t_orders.Brand','LIKE', $search['Brand']);
    }

    if ( isset($search['CategoryJob']) ) {
        $table->whereIn('t_orders.CategoryJob', $search['CategoryJob']);
    }

    if ( isset($search['IsNoExperience']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsNoExperience', 1);
    }

    if ( isset($search['IsTransportation']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsTransportation', 1);
    }

    if ( isset($search['IsLongTime']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsLongTime', 1);
    }

    if ( isset($search['IsInAMonth']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsInAMonth', 1);
    }

    if ( isset($search['IsTenDays']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsTenDays', 1);
    }

    if ( isset($search['IsOnlyOneDay']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.IsOnlyOneDay', 1);
    }

    //if ( isset($search['IsOnlyOneDay']) ) {
        //$search['IsNoExperience'] = $search['IsNoExperience'] == -1 ? '%' : $search['IsNoExperience'];
        $table->where('t_projectbasicinfo.DisplayStatus', ProjectBasicInfo::PUBLICLY);
        $table->where('t_projectbasicinfo.DisplayStatus', ProjectBasicInfo::CREATED);

        $currentDate = date("Y-m-d H:i:s");
        //$table->where('t_projectbasicinfo.StartDate + \'10:00:00\'','<=', $currentDate);
        //$table->where('t_projectbasicinfo.EndDate + \'23:59:59\'','>=', $currentDate);

        $table->where('t_projectbasicinfo.StartDate','<=', $currentDate);
        $table->where('t_projectbasicinfo.EndDate','>=', $currentDate);
    //}

    return $table->select(
        't_resource.Path AS ThumbnailLink',
        't_projectbasicinfo.*',
        't_orders.*'
        )->paginate(5);
  }
  
    /**
     * ----------------------------   
     * CREATE: NhuongPH    
     * DATE: YYYYMMDD
     * CONTENT: Send mail response apply project
     * @param: Order ID and Staff Register ID
     * @return sendmail
     * ----------------------------   
     */
    public function sendMailApplyProject($orderId, $staffRegisterId) {
        try {
            $staff = \App\Model\Staff::where('StaffRegisterId',$staffRegisterId)->first();
            $order = Orders::where('OrderId',$orderId)->first();
            $service_name   =   trans('title.pwd.reset_pwd.title_mail.service_name');
            $sys_intro_staff    =   trans('title.pwd.reset_pwd.title_mail.sys_intro_staff');
            $subject = $order->ProjectName.'への応募を受け付けました';
            
            if (isset($staff) && !empty($staff)) {
                \Mail::send(['html' => 'site.email.resp_app_proj']
                        , [
                            "name" => $staff->Name,
                            'service_name' => $service_name,
                            'sys_intro_staff' => $sys_intro_staff,
                            'project_name'  =>  $order->ProjectName,
                            'project_id' => $orderId,
                            'task_over_view'=> $order->TaskOverview
                        ]
                        , function ($message) use ($staff, $subject) {
                    $message->from('system@gaia-ad.co.jp');
                    $message->to($staff->Email)->subject($subject);
                });
            }
        } catch (Exception $e) {
            $response = trans('validation.pwd_reset.err_send_mail');
            Session::flash('errors',['0'=>$response]);
            return redirect()->back();
        }
    }
    /**
     * ----------------------------   
     * CREATE: ThienNB    
     * DATE: 20161906
     * CONTENT: get check point wake up for view wanted job
     * @param: Order Id
     * @return array
     * ----------------------------   
     */
    public function  getProjectCheckpoind($orderId){
      $order = Orders::find($orderId);
      $checkpoind = [];
      if($order){
        $projectCheckPoint = ProjectCheckPoint::with('OrdersTime')->whereHas('OrdersTime.Orders', function ($query) use($orderId) {
        $query->where('OrderId', '=', $orderId);
        $query->where('t_projectcheckpoint.Name', '=', 1);
        $query->where('t_projectcheckpoint.Checked', '=', 1);
      })->get();
        if($projectCheckPoint){
          
          foreach ($projectCheckPoint as $item){
            $orderTime = OrdersTime::find($item->OrderTimeId);
            $name = $orderTime->TimeStart.'-'. $orderTime->TimeEnd;
            $staffId = auth()->guard('admin')->user()->staff->StaffRegisterId;
            $wanted = WantedJob::where('OrderTimeId' , $orderTime->OrderTimeid)
                              ->where('StaffId',$staffId)
                              ->first();
//            dd($wanted);
            $checkpoind[] = [
                'orderTimeId' => $orderTime->OrderTimeid ,
                'name' => $name ,
                'time' => $wanted->TimeStartWanted != null ? $wanted->TimeStartWanted : $item->Start
            ];
                    
          }
        }
//        dd($checkpoind);
      }
      return $checkpoind;
    }
    /**
     * ----------------------------   
     * CREATE: ThienNB    
     * DATE: 20161906
     * CONTENT: set time wake up for view wanted job
     * @param: array
     * @return bool
     * ----------------------------   
     */
    public function  setTimeWakeUp($data){
      
      
      foreach($data as $key => $value){
        if( strpos($key, '_') == true){
          $arr= explode('_', $key);
          $orderTimeId= $arr[1];
          $staffId = auth()->guard('admin')->user()->staff->StaffRegisterId;
          $wanted = WantedJob::where('OrderTimeId' , $orderTimeId)
                              ->where('StaffId',$staffId)
                              ->get();
          if($wanted){
            foreach ($wanted as $row){
              $row->TimeStartWanted = $value;
              $result = $row->save();
            }
          }
          
        }
      }
      return $result;
    }
}