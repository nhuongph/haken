<?php
namespace App\Common;

class Constants
{
    public $ORDER_DIVISION = [
        '001'   => '派遣',
        '002'   => '請負',
        '003'   => '紹介予定派遣'
    ];

    public $EMPLOYMENT_STATUS = [
        '学生'   => '学生',
        '在職中'  => '在職中',
        '求職中'  => '求職中',
        '主婦(夫)' => '主婦(夫)',
        'その他'  => 'その他'
    ];

    public $NEAREST_STATION = [
        "東京" => "東京",
        "神奈川" => "神奈川",
        "千葉" => "千葉",
        "埼玉" => "埼玉",
        "その他" => "その他"
    ];

    public $DESIRE_PERIOD = [
        '単発' => '単発',
        '短期' => '短期',
        '長期' => '長期'
    ];

    public $WORK_DAY = [
        "1" => "月",
        "2" => "火",
        "3" => "水",
        "4" => "木",
        "5" => "金",
        "6" => "土",
        "0" => "日",
        // "1" => "祝日",
    ];

    public $LANGUAGE_CERTIFICATION = [
        "1" => "TOEIC",
        "2" => "TOEFL",
        "3" => "Another"
    ];

    public $UNIFORM_SIZE = [
        "S" => 'S',
        "M" => 'M',
        "L" => 'L'
    ];

    public $CLOTHES_SIZE = [
        '7'  => '7',
        '9'  => '9',
        '11' => '11',
        '13' => '13'
    ];

    public $WORK_PLACE = [
        "" => "-- Select Place --",
        "0" => "Tokyo",
        "1" => "Osaka",
        "2" => "Kagasawa"
    ];

    public $JOB_POSITION = [
        "" => "-- Select Job --",
        "0" => "Marketing",
        "1" => "Developer",
        "2" => "Accounting"
    ];

    public $CONTRACT_TYPE = [
        "" => "-- Select Contract --",
        "0" => "Parttime",
        "1" => "Contract 3 months",
        "2" => "Contract 6 months",
        "3" => "Long term contract"
    ];

    public $STATUS = [
        '0' => '面接待',
        '1' => '登録待',
//        '2' => '本登録完了'
    ];

    public function getShoesSize()
    {

        $SHOES_SIZE = [];
        $size = 20;

        while ($size <= 30) {
            $index = (string) $size;
            $SHOES_SIZE[$index] = $size;

            $size = $size + floatval(0.5);
        }

        return $SHOES_SIZE;
    }

    /**
     * Get hour from 8 -> 20 (Every hour add 30 minute)
     * @return mixed
     */
    public function getInterviewHour()
    {
        $arrTime = array();
        for ($i = 8; $i <= 20; $i++) {
            $arrTime[$i . ":00"] = $i . ":00";
        }

        return $arrTime;
    }

    /**
     * Get numnber join interview from 1 -> 15
     * @return mixed
     */
    public function getInterviewPeople()
    {
        $arrPeople = array();
        for ($i = 1; $i <= 15; $i++) {
            $arrPeople[$i] = $i;
        }

        return $arrPeople;
    }

    public $REGISTRATION_HISTORY = [
        'マイナビバイト'    => 'マイナビバイト',
        'マイナビ派遣'      => 'マイナビ派遣',
        'はたらこネット'    => 'はたらこネット',
        'バイトルドットコム' => 'バイトルドットコム',
        'enチャレンジはたらく' => 'enチャレンジはたらく',
        'en派遣' => 'en派遣',
        'その他' => 'その他',
        'ご紹介' => 'ご紹介'

    ];
    /**
     * Prefectures list
     */
    public $SELECT_PREFECTURE = [
        '秋田県'   => '秋田県',
        '青森県'   => '青森県',
        '千葉県'   => '千葉県',
        '愛媛県'   => '愛媛県',
        '福井県'   => '福井県',
        '福岡県'   => '福岡県',
        '福島県'   => '福島県',
        '岐阜県'   => '岐阜県',
        '群馬県'   => '群馬県',
        '広島県'   => '広島県',
        '北海道'   => '北海道',
        '兵庫県'   => '兵庫県',
        '茨城県'   => '茨城県',
        '石川県'   => '石川県',
        '岩手県'   => '岩手県',
        '香川県'   => '香川県',
        '鹿児島県' => '鹿児島県',
        '神奈川県' => '神奈川県',
        '高知県'   => '高知県',
        '熊本県'   => '熊本県',
        '京都府'   => '京都府',
        '三重県'   => '三重県',
        '宮城県'   => '宮城県',
        '宮崎県'   => '宮崎県',
        '長野県'   => '長野県',
        '長崎県'   => '長崎県',
        '奈良県'   => '奈良県',
        '新潟県'   => '新潟県',
        '大分県'   => '大分県',
        '岡山県'   => '岡山県',
        '沖縄県'   => '沖縄県',
        '大阪府'   => '大阪府',
        '佐賀県'   => '佐賀県',
        '埼玉県'   => '埼玉県',
        '滋賀県'   => '滋賀県',
        '島根県'   => '島根県',
        '静岡県'   => '静岡県',
        '栃木県'   => '栃木県',
        '徳島県'   => '徳島県',
        '東京都'   => '東京都',
        '鳥取県'   => '鳥取県',
        '富山県'   => '富山県',
        '和歌山県' => '和歌山県',
        '山形県'   => '山形県',
        '山口県'   => '山口県',
        '山梨県'   => '山梨県'
    ];

    public $EDUCATION_DIVISION = [
        '4大卒業'    => '4大卒業',
        '4大中退'    => '4大中退',
        '大学院卒業'  => '大学院卒業',
        '大学院中退'  => '大学院中退',
        '短大卒業'   => '短大卒業',
        '短大中退'   => '短大中退',
        '専門卒業'   => '専門卒業',
        '専門中退'   => '専門中退',
        '高校卒業'   => '高校卒業',
        '高校中退'   => '高校中退',
        '在学中'     => '在学中',
        'その他'     => 'その他'
    ];

    public $WORK_CODE = [
        '00' => '正社員',
        '01' => '派遣社員',
        '02' => '契約社員',
        '03' => 'パート',
        '04' => 'アルバイト',
        '05' => 'その他'
    ];

    public $RANK = [
        1 => '一般　(ランクA〜D)',
        2 => 'ランクS',
        3 => 'ランクG',
        4 => 'ランクH'
    ];

    /**
     * Project Scope
     */
    public $PROJECT_SCOPE = [
        0 => '非公開',     //PRIVATE
        1 => '一般公開'     //PUBLIC
    ];

    /**
     * Project status
     */
    public $PROJECT_STATUS = [
        0 => '作成中',     // CREATING
        1 => '作成完了'    // CREATED
    ];

    /**
     * Project recruitment time
     */
    public $PROJECT_RECRUITMENT_TIME = [
        0 => '募集開始前',
        1 => '募集中',
        2 => '募集期間終了'
    ];
    /**
     * 職種で選ぶ
     */
    public $JOB_CATEGORY = [
        '軽作業'       => '軽作業',
        'その他'       => 'その他',
        'アパレル販売'  => 'アパレル販売',
        'コンパニオン'  => 'コンパニオン',
        'ディレクター'  => 'ディレクター',
        '携帯販売'      => '携帯販売',
        '家電販売'      => '家電販売',
        '雑貨販売'      => '雑貨販売',
        '食品販売'      => '食品販売',
        '試飲・試食販売' => '試飲・試食販売',
        'ラウンダ'      => 'ラウンダ',
        'カフェスタッフ' => 'カフェスタッフ',
        '営業'         => '営業',
        '化粧品販売'    => '化粧品販売',
        '百貨店レジ'    => '百貨店レジ',
        '事務'         => '事務',
        'データ入力'    => 'データ入力'
    ];

    public $AGE_START = [
        '15' => '15',
        '16' => '16',
        '17' => '17',
        '18' => '18',
        '19' => '19',
        '20' => '20', 
        '21' => '21',
        '22' => '22',
        '23' => '23',
        '24' => '24',
        '25' => '25',
        '26' => '26',
        '27' => '27', 
        '28' => '28',
        '29' => '29',
        '30' => '30',
        '31' => '31',
        '32' => '32',
        '33' => '33',
        '34' => '34', 
        '35' => '35',
        '36' => '36',
        '37' => '37',
        '38' => '38',
        '39' => '39',
        '40' => '40', 
        '41' => '41',
        '42' => '42',
        '43' => '43', 
        '44' => '44',
        '45' => '45',
        '46' => '46',
        '47' => '47', 
        '48' => '48',
        '49' => '49',
        '50' => '50',
        '51' => '51',
        '52' => '52',
        '53' => '53', 
        '54' => '54',
        '55' => '55',
        '56' => '56',
        '57' => '57', 
        '58' => '58',
        '59' => '59',
        '60' => '60',
        '61' => '61',
        '62' => '62',
        '63' => '63', 
        '64' => '64',
        '65' => '65',
        '66' => '66',
        '67' => '67', 
        '68' => '68',
        '69' => '69',
        '70' => '70',
        '71' => '71',
        '72' => '72',
        '73' => '73', 
        '74' => '74',
        '75' => '75',
        '76' => '76',
        '77' => '77', 
        '78' => '78',
        '79' => '79',
        '80' => '80',

    ];

    

    /**
     * Sidebar menu
     */
    public $SIDEBAR_MENUS = [
        ["title.sidebar_menu.daily_management",             "#",                                ["admin"], 'fa fa-tasks'],
        ["title.sidebar_menu.pre-register",                 "/pre-register/manage",             ["admin"], 'fa fa-pencil-square-o'],
        ["title.sidebar_menu.partner_service_management",   "gaia/company/list",                ["admin"], 'fa fa-user-secret'],
        ["title.sidebar_menu.brand_management",             "gaia/brand/list",                  ["admin"], 'fa fa-registered'],
        ["title.sidebar_menu.order_content",                "/order/list",                      ["admin"], 'fa fa-table'],
        ["title.sidebar_menu.project_management",           "/user/project/list",               ["admin"], 'fa fa-briefcase'],
        ["title.sidebar_menu.payment_and_payment_finish",   "#",                                ["admin"], 'fa fa-credit-card'],
        ["title.sidebar_menu.message_management",           "#",                                ["admin"], 'fa fa-envelope-o'],
        ["title.sidebar_menu.staff_management",             "/staff/list",                      ["admin"], 'fa fa-user'],
        ["title.sidebar_menu.import_data",                  "#",                                ["admin"], 'glyphicon glyphicon-export'],
        ["title.sidebar_menu.role_management",              "/gaia/management/member/menu",     ["admin"], 'fa fa-unlock-alt']
    ];

    /**
     * Top menu
     */
    public $TOP_MENUS = [
        ["登録情報確認"     , "/staff/info/", ["staff"]]
        // ["日報",      "LINK/1", ["staff"]],
        // ["メッセージ", "LINK/2", ["staff"]]
    ];

    public $NATIONALITY_CODE = [

        '001' => '日本' ,
        '002' => '中華人民共和国' ,
        '003' => '大韓民国' ,
        '004' => '台湾(中華民国)' ,
        '005' => 'タイ' ,
        '006' => 'フィリピン' ,
        '007' => 'マレーシア' ,
        '008' => 'シンガポール' ,
        '009' => 'ミャンマー' ,
        '010' => 'インドネシア' ,
        '011' => '朝鮮民主主義人民共和国' ,
        '012' => 'ロシア' ,
        '013' => 'モンゴル' ,
        '014' => 'ベトナム' ,
        '015' => 'インド' ,
        '016' => 'アメリカ合衆国' ,
        '017' => 'カナダ' ,
        '018' => 'オーストラリア' ,
       
    ];

    public $ROLE_GAIA = [
        '1'  => '受入',
        '2'  => '営業' ,
        '3'  => '営業事務' ,
        '4'  => '手配' ,
        '5'  => '経理'
    ];
     public $STATUS_DAILY_REPORT = [

        '1' => 'OK' ,
        '2' => '未起床' ,
        '3' => '未出発' ,
        '4' => '未到着' ,
        '5' => '未始業' ,
        '6' => '未終業' ,
        '7' => '終業報告未提出' ,
        '8' => '入店報告未提出' ,
        '9' => '当日欠勤' ,
        '10' => 'OK以外' 
    ];
   
}

