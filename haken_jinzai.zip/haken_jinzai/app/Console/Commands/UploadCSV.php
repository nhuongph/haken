<?php

namespace App\Console\Commands;

use App\Model\Bank;
use App\Model\BankBranch;
use Illuminate\Console\Command;
use Maatwebsite\Excel\Facades\Excel;

class UploadCSV extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'csv:upload';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        Excel::load('public/bank_master.csv', function($reader) {

            // Getting all results
            $results = $reader->get();
            foreach($results as $value){

                $type     = intval($value['type']);

                if($type == 1){
                    $bankCode = intval($value['bank_code']);
                    $length   = strlen($bankCode);
                    switch($length){
                        case '1':
                            $bankCode = '000'.$bankCode; break;
                        case '2':
                            $bankCode = '00'.$bankCode; break;
                        case '3':
                            $bankCode = '0'.$bankCode; break;
                        default :
                            break;
                    };
                    $bank = new Bank();
                    $bank->BankCode  = (string) $bankCode;
                    $bank->ShortName = trim($value['short_name']);
                    $bank->FullName  = trim($value['full_name']);
                    $bank->save();
                }

                if($type == 2){
                    $bankCode   = intval($value['bank_code']);
                    $branchCode = intval($value['branch_code']);
                    $bankLength   = strlen($bankCode);
                    $branchLength = strlen($branchCode);
                    switch($bankLength){
                        case '1':
                            $bankCode = '000'.$bankCode; break;
                        case '2':
                            $bankCode = '00'.$bankCode; break;
                        case '3':
                            $bankCode = '0'.$bankCode; break;
                        default :
                            break;
                    };
                    switch($branchLength){
                        case '1':
                            $branchCode = '00'.$branchCode; break;
                        case '2':
                            $branchCode = '0'.$branchCode; break;
                        default :
                            break;
                    };
                    $bank = Bank::where('BankCode',$bankCode)->first();
                    $branch = new BankBranch();
                    $branch->BranchCode     = $branchCode;
                    $branch->MasterBankId   = $bank->BankId;
                    $branch->MasterBankCode = $bankCode;
                    $branch->ShortName      = trim($value['short_name']);
                    $branch->FullName       = trim($value['full_name']);
                    $branch->save();
                }

            }

        }, 'Shift-JIS');
    }
}
