<?php

//====================================================================================							
//							
//	FILENAME: Helper.php						
//	CREATE: 20150529						
//	CREATOR: ThienNB						
//							
//====================================================================================							

namespace App\Helpers;

use App\Common\Constants;

class Helper {

  public static function shout($string) {
    //
    return strtoupper($string);
  }

  /** 	
   * ----------------------------	
   * CREATE: ThienNB	
   * DATE: 20160529	
   * CONTENT: cover date obj  to date string like 05/23(祝日) 	
   * ----------------------------	
   * @param $date obj datetime	
   * @return string	
   * ----------------------------	
   */
  public static function dateFormatString($date) {
    $common = new Constants();
    $string = date('m/d', strtotime($date->format('Y-m-d H:i:s'))) . "(" . $common->WORK_DAY[date('w', strtotime($date->format('Y-m-d H:i:s')))] . ")";
    return $string;
  }

  /** 	
   * ----------------------------	
   * CREATE: ThienNB	
   * DATE: 20160529	
   * CONTENT: cover string date  to date string like 2016年05月23日 	
   * ----------------------------	
   * @param $date string	
   * @return string	
   * ----------------------------	
   */
  public static function fullDateFormatString($date) {

    $date_japan = date('Y年m月d日', strtotime($date));
    return $date_japan;
  }

}
