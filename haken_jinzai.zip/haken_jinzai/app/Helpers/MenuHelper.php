<?php

//====================================================================================							
//							
//	FILENAME: Helper.php						
//	CREATE: 20150610						
//	CREATOR: ToiTL						
//							
//====================================================================================							

namespace App\Helpers;

use App\Common\Constants;
use Illuminate\Support\Facades\Auth;
use App\Model\User;
use Illuminate\Support\Facades\Route;

class MenuHelper {
	/**
	 * Get list of menus method
	 *
	 * @author ToiTL
	 * @date 2016
	 */
	public static function getSidebarMenus(){
		$auth = auth()->guard('admin')->user();

		$constants = new Constants();
		$menus = $constants->SIDEBAR_MENUS;
		$mnList = [];
		if ( !$auth ) {
			$roleName = "*";
			foreach ($menus as $key => $value) {
				if ( in_array($roleName, $value[2]) ) {
					$mnList[] = (object) ["link" => $value[1], "text" => $value[0]];
				}
			}
		} else {
			$rolesName = User::find($auth->id)->roles;
			foreach ($rolesName as $role) {
				foreach ($menus as $key => $value) {
					if ( in_array($role->name, $value[2]) ) {
						$mnList[] = (object) ["link" => $value[1], "text" => $value[0]];
					}
				}
			}
		}
		
		return $mnList;
	}
	/**
	 * Get list of menus method
	 *
	 * @author ToiTL
	 * @date 2016
	 */
	public static function getTopMenus(){
		$auth = auth()->guard('admin')->user();

		$constants = new Constants();
		$menus = $constants->TOP_MENUS;
		$mnList = [];

		if ( !$auth ) {
			$roleName = "*";
			foreach ($menus as $key => $value) {
				if ( in_array($roleName, $value[2]) ) {
					$mnList[] = (object) ["link" => $value[1], "text" => $value[0]];
				}
			}
		} else {
			$rolesName = User::find($auth->id)->roles;
			foreach ($rolesName as $role) {
				foreach ($menus as $key => $value) {
					if ( in_array($role->name, $value[2]) ) {
						$mnList[] = (object) ["link" => $value[1], "text" => $value[0]];
					}
				}
			}
		}
		
		return ["links" => $mnList, "id" => isset($auth->id) ? $auth->id : null];
	}
  
      /*
    |--------------------------------------------------------------------------
    | ThienNB : Detect Active Route
    |--------------------------------------------------------------------------
    |
    | Compare given route with current route and return output if they match.
    | Very useful for navigation, marking if the link is active.
    |
    */
    public static function  isActiveRoute($route, $output = "active")
    {
        if (Route::currentRouteName() == $route) return $output;
    }

    /*
    |--------------------------------------------------------------------------
    | ThienNB : Detect Active Routes
    |--------------------------------------------------------------------------
    |
    | Compare given routes with current route and return output if they match.
    | Very useful for navigation, marking if the link is active.
    |
    */
    public static function  areActiveRoutes(Array $routes, $output = "active")
    {
        foreach ($routes as $route)
        {
            if (Route::currentRouteName() == $route) return $output;
        }

    }
}