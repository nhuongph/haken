<?php

//wanted job
Route::get('menu/list', ['as' => 'menu/list', 'uses' => 'MenuController@getMenu']);
Route::get('staff/info/{id}', ['as' => 'menu', 'uses' => 'MenuController@getUserLogin']);

Route::get('staff/requestchange/{userId}', ['as' => 'staff/requestchange', 'uses' => 'MenuController@getUpdateUser']);
Route::post('staff/requestchange/{userId}', ['as' => 'staff/requestchange', 'uses' => 'MenuController@getUpdateUser']);

Route::get('wanted-job', ['as' => 'wanted-job/index', 'uses' => 'WantedJobController@index']);
Route::get('wanted-job/register', ['as' => 'wanted-job/listOrder', 'uses' => 'WantedJobController@listOrder']);
Route::get('wanted-job/register/{orderId}', ['as' => 'wanted-job/register', 'uses' => 'WantedJobController@register']);
Route::post('wanted-job/register/{orderId}', ['as' => 'wanted-job/register', 'uses' => 'WantedJobController@register']);
Route::get('wanted-job/view/{orderId}', ['as' => 'wanted-job/view', 'uses' => 'WantedJobController@view']);
Route::post('wanted-job/view/{orderId}', ['as' => 'wanted-job/view-post', 'uses' => 'WantedJobController@view']);

Route::get('/wanted-job/search', ['as' => 'project_search','uses' => 'WantedJobController@searchProjectBasicInfo']);

Route::get('/wanted-job/search-result', ['as' => 'project_search_result','uses' => 'WantedJobController@searchResultProjectBasicInfo']);
Route::post('/staff/manage/check-point/week-schedule', ['as' => 'staff_checkpoint_schedule','uses' => 'StaffController@getWeekSchedule']);

Route::get('/staff/manage/check-point', ['as' => 'staff_checkpoint_manage','uses' => 'StaffController@getCheckPoint']);

Route::post('/staff/manage/check-point/update', ['as' => 'staff_checkpoint_update','uses' => 'StaffController@updateCheckPoint']);

Route::post('/staff/manage/check-point/loadfirst', ['as' => 'staff_loadfirst','uses' => 'StaffController@loadFirstShiftTableButton']);

Route::post('/staff/manage/check-point/send-message', ['as' => 'staff_sendmessage','uses' => 'StaffController@sendMessage']);

Route::get('/staff/manage/report/{shiftTableId}', ['as' => 'staff_report','uses' => 'StaffController@addReport']);
Route::post('/staff/manage/report/{shiftTableId}', ['as' => 'staff_report','uses' => 'StaffController@addReport']);


