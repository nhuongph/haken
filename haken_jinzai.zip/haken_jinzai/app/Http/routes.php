<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

//Admin
Route::group(['namespace'=> 'Site'],function(){

    Route::get('set-comment-cookie',['as' => 'comment-cookie','uses' => 'OrderController@setCommentOnCookie']);

    Route::get('home',function () { return "Welcome"; });    
    # Authenticate Section
    Route::get('gaia/brand/add',['as' => 'gaia/brand/add','uses' => 'BrandController@getNew']);
    Route::post('gaia/brand/add',['as' => 'gaia/brand/add','uses' => 'BrandController@getNew']);
    Route::get('gaia/brand/update/{brandId}',['as' => 'gaia/brand/update','uses' => 'BrandController@getUpdate']);
    Route::post('gaia/brand/update/{brandId}',['as' => 'gaia/brand/update','uses' => 'BrandController@getUpdate']);
    Route::get('gaia/brand/list',['as' => 'gaia/brand/list','uses' => 'BrandController@getList']);
    Route::get('gaia/brand/details/{id}',['as' => 'gaia/brand/details','uses' => 'BrandController@getDetails']);
    Route::get('gaia/brand/delete/{id}',['as' => 'gaia/brand/delete','uses' => 'BrandController@getDelete']);


    Route::get('report/index/{brandId}',['as' => 'report/index','uses' => 'ReportingController@getIndex']);
    Route::get('report/new/{reportId}',['as' => 'report/new','uses' => 'ReportingController@getNew']);
    Route::post('report/new/{reportId}',['as' => 'report/new','uses' => 'ReportingController@getNew']);

    Route::get('payment/list',['as' => 'payment/list','uses' => 'PaymentController@getListPayment']);
    Route::get('gaia/management/history/list',['as' => 'gaia/management/history/list','uses' => 'OperationHistoryController@getListOperationHistory']);

   
    
    Route::post('distribution/new/{reportId}',['as' => 'distribution/new','uses' => 'ReportingController@getNewDistribution']);
    Route::get('distribution/new/{reportId}',['as' => 'distribution/new','uses' => 'ReportingController@getNewDistribution']);

    Route::post('comment/new',['as' => 'comment/new','uses' => 'ReportingController@getComment']);
    Route::get('comment/new',['as' => 'comment/new','uses' => 'ReportingController@getComment']);
    Route::get('report/sales',['as' => 'report/sales','uses' => 'ReportingController@getSales']);

    
    Route::get('/login',['as' => 'login','uses' => 'AuthController@getLogin']);
    Route::post('/login',['as' => 'login','uses' => 'AuthController@getLogin']);
    Route::get('/logout',['as' => 'logout','uses' => 'AuthController@getLogout']);
    
    /** 
    *----------------------------   
    * CREATE: NhuongPH    
    * DATE: YYYYMMDD
    * CONTENT: URL reset password
    *----------------------------   
    */
    Route::controllers(
            [
                'password' => 'PasswordController'
            ]
    );

    # Login Staff 
    Route::get('pre-register/reg-staff/login',['as' => 'pre-register/login','uses' => 'StaffLoginController@getLogin']);
    Route::post('pre-register/reg-staff/login',['as' => 'pre-register/login','uses' => 'StaffLoginController@getLogin']);
    Route::get('staff/pre-register/logout',['as' => 'pre-register/logout','uses' => 'StaffLoginController@getLogout']);

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: URL of staff list
    *----------------------------   
    */
    Route::get('staff/list', ['as' => 'staff_list', 'uses' => 'StaffController@getMemberList']);
    Route::post('staff/list', ['as' => 'staff_list', 'uses' => 'StaffController@getMemberList']);
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: URL of staff detail
    *----------------------------   
    */

    Route::get('staff/detail/{id}', ['as' => 'staff_edit', 'uses' => 'StaffController@detailMemberList']);
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: URL of download skill sheet
    *----------------------------   
    */
    Route::post('staff/download/skill-sheet', ['as' => 'staff_edit', 'uses' => 'StaffController@downloadSkillSheet']);

    Route::get('pre-register/search',['as' => 'pre-register/search','uses' => 'RegisterPersonnelController@getSearch']);

    Route::group(['middleware' => ['admin']],function(){

        Route::get('/',['as'=>'home','uses'=>'AdminController@getIndex']);
        Route::group(['middleware'=>['role:pre-register']],function(){
            //Pre-register staff rules section
            Route::get('pre-register/reg-staff/oath',['as' => 'staff', 'uses' => 'StaffLoginController@getRules']);
            Route::get('pre-register/reg-staff/bankaccount',['as' => 'pre-register/reg-staff/bankaccount', 'uses' => 'StaffLoginController@newsRules']);
            Route::post('pre-register/reg-staff/bankaccount',['as' => 'pre-register/reg-staff/bankaccount', 'uses' => 'StaffLoginController@newsRules']);
            Route::post('staff/bankbranch',['uses' => 'StaffLoginController@bankbranch']);

            Route::post('staff/numberbankbranch',['uses' => 'StaffLoginController@getNumberBankBranch']);
            //Update pre-register staff information section
            Route::get('staff/pre-register/update',['as' => 'staff/pre-register/update', 'uses' => 'StaffController@updateStaff']);
            Route::post('staff/pre-register/update',['as' => 'staff/pre-register/update', 'uses' => 'StaffController@updateStaff']);
        });

        #check role admin

        Route::group(['middleware' => ['role:admin']],function(){
               

            //Officer Management Section
            Route::get('/user',['as' => 'user', 'uses' => 'UserController@getIndex']);
            Route::post('/user',['as' => 'user', 'uses' => 'UserController@getIndex']);
            Route::get('/user/new',['as' => 'user/new', 'uses' => 'UserController@newUser']);
            Route::post('/user/new',['as' => 'user/new', 'uses' => 'UserController@newUser']);
            Route::get('/user/update/{userId}',['as' => 'user/update', 'uses' => 'UserController@updateUser']);
            Route::post('/user/update/{userId}',['as' => 'user/update', 'uses' => 'UserController@updateUser']);
            Route::get('/user/manage',['as' => 'user/manage', 'uses' => 'UserController@userRole']);

            Route::get('gaia/order/new',['as' => 'gaia/order/new','uses' => 'OrderController@getNew']);
            Route::post('gaia/order/new',['as' => 'gaia/order/new','uses' => 'OrderController@getNew']);
            Route::get('order/update/{orderId}',['as' => 'order/update','uses' => 'OrderController@getUpdate']);
            Route::post('order/update/{orderId}',['as' => 'order/update','uses' => 'OrderController@getUpdate']);

            Route::get('order/list',['as' => 'order/list','uses' => 'OrderController@getList']);
            Route::get('order/list/{name}',['as' => 'order/list/name','uses' => 'OrderController@getListByStatus']);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of new order
            *----------------------------   s
            */
            Route::get('order/add',['as' => 'order/add','uses' => 'OrderController@addOrder']);
            Route::post('order/add',['as' => 'order/add','uses' => 'OrderController@addOrder']);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of order detail
            *----------------------------   
            */
            Route::get('order/detail/{orderId}',[
                'as' => 'order/detail',
                'uses' => 'OrderController@getDetail'
            ]);

            Route::get('order/delete/{orderId}',[
                'as' => 'order/delete',
                'uses' => 'OrderController@getDelete'
            ]);

              #gaiamanagement
            Route::get('gaia/management/member/menu',['as' => 'gaia/management/member/menu','uses' => 'GaiAController@getMenuGaiA']);

            Route::get('gaia/management/member/add',['as' => 'registerpersonnel/getnewregisterpersonal','uses' => 'GaiAController@getNewRegisterPersonal']);
            Route::post('gaia/management/member/add',['as' => 'registerpersonnel/getnewregisterpersonal','uses' => 'GaiAController@getNewRegisterPersonal']);
            Route::get('gaia/update/{userId}',['as' => 'registerpersonnel/getupdateregisterpersonal','uses' => 'GaiAController@getUpdateRegisterPersonal']);
            Route::post('gaia/update/{userId}',['as' => 'registerpersonnel/getupdateregisterpersonal','uses' => 'GaiAController@getUpdateRegisterPersonal']);

            Route::get('gaia/management/member/list',['as' => 'listGaiAMember', 'uses' => 'GaiAController@getGaiaMember']);
            Route::post('gaia/management/member/list',['as' => 'listGaiAMember', 'uses' => 'GaiAController@getGaiaMember']);
            Route::get('gaia/detail/{userId}',['as' => 'employee/detail','uses' => 'GaiAController@getGaiAMemberDetail']);
            Route::post('gaia/delete/{userId}',['as' => 'employee/delete','uses' => 'GaiAController@deleteGaiA']);


            //Staff Management Section
            Route::get('staff',['as' => 'admin/staff', 'uses' => 'StaffController@getIndex']);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of ajax get mail
            *----------------------------   
            */
            Route::post('/user/get_mail', [
                'as'    => 'get_mail',
                'uses'  => 'UserController@getUserMail'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of project list
            *----------------------------   
            */
            Route::get('/user/project/list', [
                'as'    => 'basic_registration_list',
                'uses'  => 'UserController@getProjectBasicInfoList'
            ]);

            Route::post('/user/project/list', [
                'as'    => 'basic_registration_list',
                'uses'  => 'UserController@getProjectBasicInfoList'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of update project
            *----------------------------   
            */
            Route::get('/user/project/update/{projectId}', [
                'as'    => 'basic_registration_update',
                'uses'  => 'UserController@updateProjectBasicInfo'
            ]);

            Route::post('/user/project/update/{projectId}', [
                'as'    => 'basic_registration_update',
                'uses'  => 'UserController@updateProjectBasicInfo'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of project detail
            *----------------------------   
            */
            Route::get('/user/project/detail/{projectId}', [
                'as'    => 'basic_registration_detail',
                'uses'  => 'UserController@detailProjectBasicInfo'
            ]);


            //Pre-register section (manage, interview schedule, detail)
            Route::get('pre-register/manage',['as'=>'pre-register/manage', 'uses' => 'PreRegisterController@getIndex']);
            //Interview Schedule
            Route::get('pre-register/manage/interview/schedule',['as'=>'pre-register/manage/interview/schedule', 'uses' => 'PreRegisterController@interviewSchedule']);
            Route::post('pre-register/interview_schedule/list',['uses' => 'PreRegisterController@getScheduleList']);
            Route::post('pre-register/interview_schedule/list/another_place',['uses' => 'PreRegisterController@getScheduleListAnotherPlace']);
            Route::post('pre-register/interview_schedule/list/no_time',['uses' => 'PreRegisterController@getScheduleListNoTime']);
            Route::post('pre-register/interview_schedule/list/no_time/comment',['uses' => 'PreRegisterController@updateScheduleNoTimeComment']);
            Route::post('pre-register/interview_schedule/search',['uses' => 'PreRegisterController@getInterviewStaff']);
            Route::post('pre-register/interview_schedule/add_schedule',['uses' => 'PreRegisterController@addNewSchedule']);
            Route::post('pre-register/interview_schedule/add_another_schedule',['uses' => 'PreRegisterController@addNewAnotherSchedule']);
            Route::post('pre-register/interview_schedule/remove_schedule',['uses' => 'PreRegisterController@removeSchedule']);
            Route::post('pre-register/interview_schedule/remove_another_schedule',['uses' => 'PreRegisterController@removeAnotherSchedule']);
            //Add Interview Time & another interview time
            Route::get('pre-register/manage/interview/tokyokanagawa/register', ['as' => 'interview_time','uses' => 'PreRegisterController@SettingInterview']);
            Route::post('pre-register/manage/interview/tokyokanagawa/register', ['as' => 'interview_time','uses' => 'PreRegisterController@SettingInterview']);
            Route::get('pre-register/another_interview',['as' => 'anotherinterview', 'uses' => 'AnotherInterviewTimeController@newAnotherInterviewTime']);
            Route::post('pre-register/another_interview',['as' => 'anotherinterview', 'uses' => 'AnotherInterviewTimeController@newAnotherInteriewTime']);
            //Pre-register List
            Route::get('pre-register/manage/list',['as'=>'pre-register/manage/list','uses'=>'PreRegisterController@getPreRegisterList']);
            Route::post('pre-register/manage/list/filter',['as'=>'pre-register/manage/list/filter','uses'=>'PreRegisterController@getPreRegisterListFilter']);
            //Pre-register detail
            Route::get('pre-register/manage/detail/change_role/{email}',['as'=> 'pre-register/manage/change_role','uses' => 'PreRegisterController@changeStaffRole']);
            Route::get('pre-register/manage/detail/{staffId}',['as'=> 'pre-register/manage/detail','uses' => 'PreRegisterController@getPreRegisterDetail']);
            Route::post('pre-register/manage/detail/{staffId}',['as'=> 'pre-register/manage/detail','uses' => 'PreRegisterController@getPreRegisterDetail']);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of another interview list
            *----------------------------   
            */
            Route::get('pre-register/manage/interview/another/list', [
                'as'    => 'another_list',
                'uses'  => 'AnotherInterviewTimeController@getAnotherInterviewTimeList'
            ]);

            Route::post('pre-register/manage/interview/another/list', [
                'as'    => 'another_list_post',
                'uses'  => 'AnotherInterviewTimeController@getAnotherInterviewTimeList'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of delete another interview
            *----------------------------   
            */
            Route::post('pre-register/manage/interview/another/delete', [
                'as'    => 'another_delete',
                'uses'  => 'AnotherInterviewTimeController@deleteAnotherInterviewTime'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of update another interview
            *----------------------------   
            */
            Route::get('pre-register/manage/interview/another/update/{id}', [
                'as'    => 'edit_another_interview_time',
                'uses'  => 'AnotherInterviewTimeController@updateAnotherInterviewTime'
            ]);

            Route::post('pre-register/manage/interview/another/update/{id}', [
                'as'    => 'edit_another_interview_time',
                'uses'  => 'AnotherInterviewTimeController@updateAnotherInterviewTime'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of tokyo kanagawa list
            *----------------------------   
            */
            Route::get('pre-register/manage/interview/tokyokanagawa/list', [
                'as'    => 'tokyokanagawa_list',
                'uses'  => 'PreRegisterController@getTokyoKanagawaInterviewTimeList'
            ]);
            
            Route::post('pre-register/manage/interview/tokyokanagawa/list', [
                'as'    => 'tokyokanagawa_list_post',
                'uses'  => 'PreRegisterController@getTokyoKanagawaInterviewTimeList'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of delete tokyo kanagawa
            *----------------------------   
            */
            Route::post('pre-register/manage/interview/tokyokanagawa/delete', [
                'as'    => 'delete_tokyo_kanagawa_interview_time', 
                'uses'  => 'PreRegisterController@deleteTokyoKanagawaInterviewTime'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of update tokyo kanagawa
            *----------------------------   
            */
            Route::get('pre-register/manage/interview/tokyokanagawa/update/{id}', [
                'as'    => 'edit_tokyo_kanagawa_interview_time', 
                'uses'  => 'PreRegisterController@updateTokyoKanagawaInterviewTime'
            ]);

            Route::post('pre-register/manage/interview/tokyokanagawa/update/{id}', [
                'as'    => 'edit_tokyo_kanagawa_interview_time', 
                'uses'  => 'PreRegisterController@updateTokyoKanagawaInterviewTime'
            ]);

            //Company Management Section
            Route::get('gaia/company/add',['as' => 'addcompany', 'uses' => 'CompanyController@addCompany']);
            Route::post('gaia/company/add',['as' => 'addcompany', 'uses' => 'CompanyController@addCompany']);
            Route::get('gaia/company/edit/{companyid}',['as' => 'editcompany', 'uses' => 'CompanyController@editCompany']);
            Route::post('gaia/company/edit/{companyid}',['as' => 'editcompany', 'uses' => 'CompanyController@editCompany']);
            Route::get('gaia/company/get/{companyId}',['as' => 'getcompany', 'uses' => 'CompanyController@getCompany']);
            Route::get('gaia/company/list',['as' => 'listcompany', 'uses' => 'CompanyController@listCompany']);
            Route::post('gaia/company/list',['as' => 'listcompany', 'uses' => 'CompanyController@listCompany']);
            Route::get('ajax/listcompany',['as' => 'ajax/listcompany', 'uses' => 'CompanyController@getAjaxCompany']);
            Route::get('company/delete/{companyId}', ['as'=>'getdeletecompany', 'uses'=>'CompanyController@deleteCompany']);
            Route::post('company/delete', ['as'=>'deletecompany', 'uses'=>'CompanyController@deleteCompany']);

            //Setting Another Interview
            Route::get('pre-register/manage/interview/another/register',['as' => 'anotherinterview', 'uses' => 'AnotherInterviewTimeController@newAnotherInterviewTime']);
            Route::post('pre-register/manage/interview/another/register',['as' => 'anotherinterview', 'uses' => 'AnotherInterviewTimeController@newAnotherInterviewTime']);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of update departure project
            *----------------------------   
            */ 
            Route::get('user/project/departure/add/{orderId}',[
                'as'    => 'departure/add',
                'uses'  => 'UserController@addDeparture'
            ]);

            Route::post('user/project/departure/update',[
                'as'    => 'departure/update',
                'uses'  => 'UserController@addDeparture'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of add new register date with get method (display view)
            *----------------------------   
            */ 
            Route::get('user/register-date/add/{orderId}', [
                'as'    => 'register-date/add',
                'uses'  => 'UserController@addRegisterDate'
            ]);

            Route::post('user/register-date/add/{orderId}', [
                'as'    => 'register-date/add',
                'uses'  => 'UserController@addRegisterDate'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of add new register date with get method (display view)
            *----------------------------   
            */ 
            Route::get('user/register-date/update/{orderId}', [
                'as'    => 'register-date-update',
                'uses'  => 'UserController@updateRegisterDate'
            ]);

            Route::post('user/register-date/update/{orderId}', [
                'as'    => 'register-date-update',
                'uses'  => 'UserController@updateRegisterDate'
            ]);

            //Shift plan , shedule wanted job
           
            Route::get('shift-plan/view/{orderId}',['as' => 'shift-plan/view', 'uses' => 'ShiftPlanController@view']);
            Route::get('shift-plan/update/{orderId}',['as' => 'shift-plan/update', 'uses' => 'ShiftPlanController@update']);
            Route::post('shift-plan/update/{orderId}',['as' => 'shift-plan/update', 'uses' => 'ShiftPlanController@update']);
            Route::post('shift-plan/work-schedule/add',['as' => 'work-schedule/add', 'uses' => 'ShiftPlanController@addWorkSchedule']);
            Route::get('shift-plan/work-schedule/{orderId}',['as' => 'shift-plan/work-schedule', 'uses' => 'ShiftPlanController@workSchedule']);
            Route::post('shift-plan/work-schedule/{orderId}',['as' => 'shift-plan/work-schedule-post', 'uses' => 'ShiftPlanController@workSchedule']);
            
            Route::post('shift-plan/search',['uses' => 'ShiftPlanController@getStaff']);

            //Notice
            Route::get('notice/listnotice', ['as' => 'notice/listnotice', 'uses' => 'NoticeController@listNotice']);
            Route::get('notice/ajax/listnotice',['as' => 'listnotice', 'uses' => 'NoticeController@listAjaxNotice']);

            Route::get('notice/addnotice', ['as' => 'addnotice', 'uses' => 'NoticeController@addNotice']);
            Route::post('notice/addnotice', ['as' => 'addnotice', 'uses' => 'NoticeController@addNotice']);

            Route::post('notice/editnotice', ['as' => 'editnotice', 'uses' => 'NoticeController@editPostNotice']);
            Route::get('notice/editnotice/{noticeId}', ['as' => 'editnotice', 'uses' => 'NoticeController@editNotice']);

            Route::get('notice/getnotice/{noticeId}', ['as' => 'getnotice', 'uses' => 'NoticeController@getNotice']);
            Route::get('notice/delete/{noticeId}', ['as' => 'deletenotice', 'uses' => 'NoticeController@deleteNotice']);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of message list
            *----------------------------   
            */
            Route::post('/user/message/setting/preview', ['as'    => 'preview_message_setting', 'uses'  => 'UserController@previewMessageMailContent']);
            Route::get('/user/message/setting/{orderId}', ['as'    => 'message_setting', 'uses'  => 'UserController@settingMessageMailContent']);
            Route::post('/user/message/setting/{orderId}', ['as'    => 'post_message_setting', 'uses'  => 'UserController@settingMessageMailContent']);

            //Daily Report manager 2B
            Route::get('dailyreport', ['as' => 'dailyreport', 'uses' => 'DailyReportController@index']);
            Route::post('dailyreport/getmessage', ['as' => 'dailyreport/getmessage', 'uses' => 'DailyReportController@GetMessage']);
            Route::post('dailyreport/search', ['as' => 'dailyreport/search', 'uses' => 'DailyReportController@Search']);
            Route::post('dailyreport/update-time', ['as' => 'dailyreport/update-time', 'uses' => 'DailyReportController@UpdateTime']);
            Route::post('dailyreport/get-message-detail', ['as' => 'dailyreport/get-message-detail', 'uses' => 'DailyReportController@GetMessageDetail']);
            
        });
        
        Route::group(['middleware' => ['role:staff']],function(){
            //wanted job
            Route::get('menu/list',['as' => 'menu/list','uses' => 'MenuController@getMenu']);
            Route::get('staff/info/{id}',['as' => 'menu','uses' => 'MenuController@getUserLogin']);

            Route::get('staff/requestchange/{userId}',['as' => 'staff/requestchange','uses' => 'MenuController@getUpdateUser']);
            Route::post('staff/requestchange/{userId}',['as' => 'staff/requestchange','uses' => 'MenuController@getUpdateUser']);

            Route::get('wanted-job',['as' => 'wanted-job/index', 'uses' => 'WantedJobController@index']);
            Route::get('wanted-job/register',['as' => 'wanted-job/listOrder', 'uses' => 'WantedJobController@listOrder']);
            Route::get('wanted-job/register/{orderId}',['as' => 'wanted-job/register', 'uses' => 'WantedJobController@register']);
            Route::post('wanted-job/register/{orderId}',['as' => 'wanted-job/register', 'uses' => 'WantedJobController@register']);    
            Route::get('wanted-job/view/{orderId}',['as' => 'wanted-job/view', 'uses' => 'WantedJobController@view']);
            Route::post('wanted-job/view/{orderId}',['as' => 'wanted-job/view-post', 'uses' => 'WantedJobController@view']);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of Serch basic info
            *----------------------------   
            */ 
            Route::get('/wanted-job/search', [
                'as'    => 'project_search',
                'uses'  => 'WantedJobController@searchProjectBasicInfo'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of searching result
            *----------------------------   
            */ 
            Route::get('/wanted-job/search-result', [
                'as'    => 'project_search_result',
                'uses'  => 'WantedJobController@searchResultProjectBasicInfo'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of check in list in a week
            *----------------------------   
            */ 
            Route::post('/staff/manage/check-point/week-schedule',[
                'as'    => 'staff_checkpoint_schedule',
                'uses'  => 'StaffController@getWeekSchedule'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of check in
            *----------------------------   
            */ 
            Route::get('/staff/manage/check-point',[
                'as'    => 'staff_checkpoint_manage',
                'uses'  => 'StaffController@getCheckPoint'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of handle checkin with post method
            *----------------------------   
            */ 
            Route::post('/staff/manage/check-point/update',[
                'as'    => 'staff_checkpoint_update',
                'uses'  => 'StaffController@updateCheckPoint'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of get current button
            *----------------------------   
            */ 
            Route::post('/staff/manage/check-point/loadfirst',[
                'as'    => 'staff_loadfirst',
                'uses'  => 'StaffController@loadFirstShiftTableButton'
            ]);
            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of send message in check point
            *----------------------------   
            */ 
            Route::post('/staff/manage/check-point/send-message',[
                'as'    => 'staff_sendmessage',
                'uses'  => 'StaffController@sendMessage'
            ]);

            /** 
            *----------------------------   
            * CREATE: ToiTL    
            * DATE: YYYYMMDD
            * CONTENT: URL of report
            *----------------------------   
            */ 
            Route::get('/staff/manage/report/{shiftTableId}',[
                'as'    => 'staff_report',
                'uses'  => 'StaffController@addReport'
            ]);
            Route::post('/staff/manage/report/{shiftTableId}',[
                'as'    => 'staff_report',
                'uses'  => 'StaffController@addReport'
            ]);
        });
    });

    //Staff Management Section
    Route::get('staff',['as' => 'staff', 'uses' => 'StaffController@getIndex']);
    Route::get('pre-register/policy/',['as' => 'staff', 'uses' => 'StaffController@getIndex']);
    Route::post('staff/bank_branch/',['uses' => 'StaffController@getBankBranch']);
    Route::get('pre-register/{step}',['as' => 'staff/pre-register', 'uses' => 'StaffController@newStaff']);
    Route::post('pre-register/{step}',['as' => 'staff/pre-register', 'uses' => 'StaffController@newStaff']);
    Route::post('staff/interview_time',['uses' => 'StaffController@getInterviewTime']);


    Route::get('upload',['uses' => 'StaffController@Upload']);
    Route::post('upload',['uses' => 'StaffController@Upload']);

Route::get('staffmanager/introducejob', ['as' => 'introducejob', 'uses' => 'StaffController@introduceJob']);
Route::post('staffmanager/introducejobstaff', ['as' => 'introducejobstaff', 'uses' => 'StaffController@introduceJobStaff']);
Route::post('staffmanager/introducejobproject', ['as' => 'introducejobproject', 'uses' => 'StaffController@introduceJobProject']);
Route::post('staffmanager/introducejobfinish', ['as' => 'introducejobfinish', 'uses' => 'StaffController@introduceJobFinish']);

//Route::get('staffmanager/introducejobstaff', ['as' => 'introducejobstaff', 'uses' => 'StaffController@introduceJobStaff']);

});

