<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AnotherInterview extends Model
{
    protected $table = "t_anotherinterview";
    public $primaryKey = 'AnotherInterviewId';
    public $timestamps = false;

    /**
     * ORM relationship
     */

    public function Staff(){
        return $this->hasOne('App\Model\Staff','StaffRegisterId','StaffId');
    }

    public function AnotherInterviewTime() {
        return $this->belongsTo('App\Model\InterviewTime','InterviewTimeId','InterviewTimeId');
    }
}
