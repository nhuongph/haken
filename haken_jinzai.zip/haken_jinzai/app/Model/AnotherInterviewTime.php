<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

use DB;

class AnotherInterviewTime extends Model
{
	protected $table = "t_anotherinterviewtime";

	public $primaryKey = "AnotherInterviewTimeID";
	protected $rules = [
	'regionName' 			=> 'required|min:2',
	'date'						=> 'required|date_format:Y/m/d',
	'responsibleName'	=> 'required|min:2',
	'phone' 					=> 'required|min:13|max:13',
	'email' 					=> 'required|email',
	];

	// The list of rule to validate the update action
	protected $updateRules = [
		'responsibleName'	=> 'required|min:2',
		'phone' 					=> 'required|numeric',
		'email' 					=> 'required|min:5',
	];

	public function isValid($companyData){

		$validate = validator($companyData, $this->rules);

		return $validate;
	}

	/**
	 * ORM Relationship
	 */

	public function AnotherInterview(){
		return $this->hasMany('App\Model\AnotherInterview','AnotherInterviewTimeID','AnotherInterviewTimeID');
	}

	/**
	 * Check valid with update rules
	 *
	 * @author ToiTL
	 * @date 2016/05/19
	 * @param $requestData
	 * @return array/true $validate
	 */
	public function isUpdateValid( $requestData ){
		return validator($requestData, $this->updateRules);
	}
}
