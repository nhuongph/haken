<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    protected $table   = "t_brand";
    public $primaryKey = "id";

    protected $rules = [
    	  'ManagementName'                 =>'required',
    	  'DisplayName'                    =>'required',
    	  'Remarks'                        =>'required',
    ];

    public function isValid($brandRules, $rules){
        $validate = validator($brandRules,$this->rules);
        return $validate;
    }
}