<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Certification extends Model
{
    protected $table = "t_certification";
}
