<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    protected $table   = "t_comment";
    public $primaryKey = "id";

    protected $rules = [
    	  'CommentContent' =>'required',            
    ];

    public function isValid($brandRules, $rules){
        $validate = validator($brandRules,$this->rules);
        return $validate;
    }
}