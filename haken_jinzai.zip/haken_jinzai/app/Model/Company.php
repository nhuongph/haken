<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\SubCompany;
use Validator;

class Company extends Model
{
	protected $table = "t_company";

	protected $primaryKey = 'CompanyId';

	public $timestamps = false;

	public $incrementing = false;

	protected $rules = [
	'companyName' 			=> 'required',
	'furiganaName' 			=> ['required','regex:/^[ぁ-んァ-ン]+$/u'],
	'postalCode' 				=> ['required','regex:/^([0-9\s\-\+\(\)]*)$/'],
	'prefecturalName'		=> 'required',
	'municipalName'			=> 'required',
	'phoneNumber'				=> ['required','regex:/^([0-9\s\-\+\(\)]*)$/'],
	'pepresentativeName'=> 'required',
	'companyMemo'				=> 'required',
	'personCharge'			=> 'required',

	'faxNumber'					=> ['regex:/^([0-9\s\-\+\(\)]*)$/'],
	'capitalStock'			=> 'numeric|between:0,999999.999999',
	'employeeNumber'		=> 'numeric',
	'lastYearSuppliers' => 'numeric',
	];

	public function isValid($companyData){

		$validate = validator($companyData, $this->rules);

		return $validate;
	}	

	public function subCompany(){
		return $this->hasOne('App\Model\SubCompany', 'CompanyId', 'CompanyId');
	}
}
