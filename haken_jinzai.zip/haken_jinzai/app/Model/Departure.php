<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Departure extends Model{
	protected $table = "t_departure";
	protected $primaryKey = "DepartureId";
}