<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DesiredJob extends Model
{
    protected $table = "t_desiredjob";
}
