<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class GaiA extends Model
{
    protected $table   = "t_gaia";
    public $primaryKey = "id";
    
    public function User(){

       return $this->hasOne('App\Model\User','email','email');

    }
    
}