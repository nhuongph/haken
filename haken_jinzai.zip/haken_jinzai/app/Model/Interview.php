<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Interview extends Model
{
    protected $table = "t_interview";
    public $primaryKey = 'InterviewID';
    public $timestamps = false;

    /**
     * ORM relationship
     */

    public function Staff(){
        return $this->hasOne('App\Model\Staff','StaffRegisterId','StaffId');
    }

    public function InterviewTime() {
        return $this->belongsTo('App\Model\InterviewTime','InterviewTimeId','InterviewTimeId');
    }
}
