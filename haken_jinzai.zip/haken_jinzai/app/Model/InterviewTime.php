<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class InterviewTime extends Model
{
    protected $table = "t_interviewtime";
    public $primaryKey = 'InterviewTimeId';
    public $timestamps = false;
    protected $rules = [
        'interviewDate' => 'required|date_format:Y/m/d',
    ];


    public function isValid($settingInterviewData){

        #validation data
        $validate = validator($settingInterviewData,$this->rules);
        return $validate;
    }

    /**
     * ORM relationship
     */

    public function Interview(){
        return $this->hasMany('App\Model\Interview','InterviewTimeId','InterviewTimeId');
    }
}
