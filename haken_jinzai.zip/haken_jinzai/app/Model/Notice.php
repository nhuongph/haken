<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Notice extends Model {

	protected $table = "t_notice";
	public $primaryKey = 'NoticeId';
	public $timestamps = false;
	protected $fillable = ['title', 'content', 'publicdate', 'publichour', 'author', 'updatedby'];

	protected $rules = [
	'title'			=>'required',
	'content'   =>'required',
	'publicdate'=>'required|date_format:Y/m/d',
	'publichour'=>'required',
	];

	public function isValid($noteData){
		$validate = validator($noteData, $this->rules);
		return $validate;
	}
}