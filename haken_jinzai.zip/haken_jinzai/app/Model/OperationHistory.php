<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OperationHistory extends Model
{
    protected $table    = "t_operation_history";
    public $primaryKey  = "OpnHisId";
    public $timestamps  = false;
}
