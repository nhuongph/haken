<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    protected $table = "t_orders";
    public $primaryKey = 'OrderId';

	 protected $rules = [
        'ProjectName'                   =>'required',
        'Contractor'                    =>'required',
        'OrderDate'                     =>'required',
        'CategoryJob'                   =>'required',
        'OrderDivision'                 =>'required',
        'Brand'                         =>'required',
        'PeriodDivision'                =>'required',
        'BeginContract'                 =>'required',
        'EndContract'                   =>'required',
        'AddressCompany'                =>'required',
        'TaskOverview'                  =>'required',
        'Clothes'                       =>'required',
        'Belongings'                    =>'required',
        'PaymentUnits'                  =>'required',
        'NeasestStation1'               =>'required',
        'SalesRepresentative'           =>'required',
        'ContractExistence'             =>'required',
        'EmploymentDestinationId'       =>'required',
        'DispatchResponsibleName'       =>'required',
        'ResponsiblePersonContact'      =>'required',
        'ChainCommandName'              =>'required',
        'ChainCommandContact'           =>'required',
        'ComplaintPersonCharge'         =>'required',
        'ComplaintPersonnelContacts'    =>'required',
        'OrdersUnits'                   =>'required',
        'OrderUnitsPreTraining'         =>'required',
        'TransportationExpensePayment'  =>'required',
        'ConstructionRemoval'           =>'required',
        'Allowance'                     =>'required',
        'ConstructionRemoval1'          =>'required',
        
           
    ];

    public function isValid($userRules, $rules){
        $validate = validator($userRules,$this->rules);
        return $validate;
    }

    public function OrdersDate(){
        return $this->hasMany('App\Model\OrdersDate','OrderId','OrderId');
    }
    public function OrdersTime(){
        return $this->hasMany('App\Model\OrdersTime','OrderId','OrderId');
    }
    public function ProJectBasicInfo(){
        return $this->hasOne('App\Model\ProjectBasicInfo','OrderId','OrderId');
    }
    public function WantedJob() {
      return $this->hasManyThrough(
          'App\Model\WantedJob', 'App\Model\OrdersTime', 'OrderId', 'OrderTimeId', 'OrderId'
      );
    }

    public function EmploymentDestinationIdCompany(){
        return $this->hasOne('App\Model\Company', 'CompanyId', 'EmploymentDestinationId');
    }

    public function AgreementDestinationIDCompany(){
        return $this->hasOne('App\Model\Company', 'CompanyId', 'AgreementDestinationID');
    }

    public function OrderAddressIdCompany(){
        return $this->hasOne('App\Model\Company', 'CompanyId', 'OrderAddressId');
    }
  }
