<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrdersComment extends Model
{
    protected $table   = "t_orders_comment";
    public $primaryKey = "id";

   
}