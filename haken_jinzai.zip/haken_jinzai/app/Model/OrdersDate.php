<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrdersDate extends Model
{
	protected $table = "t_orders_date";
	public $primaryKey = 'DateOrderId';

    public function Orders() {
        return $this->belongsTo('App\Model\Order','OrderId','OrderId');
    }


}