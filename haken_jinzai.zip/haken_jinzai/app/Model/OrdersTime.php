<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrdersTime extends Model
{
	protected $table = "t_orders_time";
  public $primaryKey  = "OrderTimeid";

  protected $rules = [
        'TimeStart'                 =>'required',
        'TimeEnd'                   =>'required',
        'TimeBreak'                 =>'required',
        'Claim'                     =>'required',
    ];

  public function isValidArray($userData){
        $validate = [];
        $status = false;
        foreach ($userData as $key => $value) {
            if ( $value['TimeStart'] != '' || $value['TimeEnd'] != '' || $value['TimeBreak'] != '' ||$value['Claim']) {
                $validate = validator($value,$this->rules);
                if ($validate->fails()) {
                    return $validate;
                }
            }
        }
        if ( !$status ) {
            return ['The category name field is required.'];
        }
        return null;
  }

  public function Orders(){
      return $this->belongsTo('App\Model\Orders','OrderId','OrderId');
  }
  public function WantedJob(){
      return $this->hasMany('App\Model\WantedJob','OrderTimeId','OrderTimeid');
  }
  public function ProjectCheckPoint(){
      return $this->hasMany('App\Model\ProjectCheckPoint','OrderTimeId','OrderTimeid');
  }
  public function isRecommend(){
      return $this->belongsTo('App\Model\Orders','OrderId','OrderId');
  }

}