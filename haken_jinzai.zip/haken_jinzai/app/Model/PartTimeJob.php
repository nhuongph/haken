<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PartTimeJob extends Model {

    protected $table    = "t_parttime";
    public $primaryKey  = "PartTimeId";
    public $timestamps  = false;
}