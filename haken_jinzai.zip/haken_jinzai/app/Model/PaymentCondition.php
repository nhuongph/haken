<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PaymentCondition extends Model
{
	protected $table	= "t_paymentcondition";

	protected $primaryKey = 'JobID';

	// protected $rules = [
	// 'billSendDepartment'=> 'required|min:2',
	// 'responsibleName' 	=> 'required|min:2',
	// 'jobTitle' 					=> 'required|min:7',
	// 'paymentCondition' 	=> 'required',
	// 'paymentDate'				=> 'required|date_format:Y/m/d',
	// 'postNumber'				=> 'required|min:2',
	// 'billAddress' 			=> 'required|min8',
	// 'tel' 							=> 'required|min:10',
	// 'fax' 							=> 'required|min:10',	
	// ];

	// public function isValid($companyData){

	// 	$validate = validator($companyData, $this->rules);

	// 	return $validate;
	// }	    
}
