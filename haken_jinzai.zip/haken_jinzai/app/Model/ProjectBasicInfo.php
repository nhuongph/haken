<?php
//====================================================================================
//                      
//  FILENAME: ProjectBasicInfo.php                  
//  CREATE: 20150524                   
//  CREATOR: RikkeiSoft                 
//                      
//====================================================================================
namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\common\Constants;
use Illuminate\Support\Facades\Validator;

class ProjectBasicInfo extends Model
{
    //
    protected $table    = "t_projectbasicinfo";
    protected $primaryKey  = "BasicInfoID";

    /**
     * Const for status display
     */
    const PRIVACY       = 0;
    const PUBLICLY      = 1;

    /**
     * Const for status of project
     */
    const CREATING      = 0;
    const CREATED       = 1;

    /**
     * 時期 : time of project
     */
    // public $TIME_STATUS = [
    //     0   => '募集開始前',
    //     1   => '募集中',
    //     2   => '募集期間終了',
    // ];
    const BEFORE_RECRUITMENT    = 0;
    const RECRUITING            = 1;
    const AFTER_RECRUITMENT     = 2;

    /**
     *
     */
    const ALL   = -1;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['*'];

    public static $rules = [];
    
    public function Orders(){

      return $this->hasOne('App\Model\Orders','OrderId','OrderId');

    }
    public function Resource(){
        return $this->hasOne('App\Model\Resource','ResourceId','Thumbnail');
    }

    public static function isValid($data, $required = array() ){

        $validate = validator($data, self::$rules);
        //validate week day
        $validate->after(function($validate) use ($data, $required) {

            if( isset($data['StartDate']) && isset($data['EndDate']) ) {
                $orderTime = strtotime($required['BeginInterviewDate']);
                $start = strtotime($data['StartDate']);
                $end = strtotime($data['EndDate']);
                if ( $start > $orderTime || $end > $orderTime ){
                    $validate->errors()->add('date', trans('validation.date.less_than_begincontract'));
                } else if ( $start > $end ){
                    $validate->errors()->add('date', trans('validation.date.compare_date'));
                }
            }

        });
        return $validate;
    }

    /**
     *----------------------------
     * CREATE: RikkeiSoft
     * DATE: YYYYMMDD
     * CONTENT: get name of recruitment attribute
     *----------------------------
     * @return string
     *----------------------------
     */
    public function getRecruitmentTimeAttribute(){
        $contants = new Constants();
        $currentDate = strtotime(date("Y-m-d 00:00:00"));
        $start = strtotime($this->StartDate);
        $end = strtotime($this->EndDate);

        if ( $start <= $currentDate && $end >= $currentDate ) {
            return $contants->PROJECT_RECRUITMENT_TIME[self::RECRUITING];
        }

        if ( $start > $currentDate ) {
            return $contants->PROJECT_RECRUITMENT_TIME[self::BEFORE_RECRUITMENT];
        }

        if ( $end < $currentDate ) {
            return $contants->PROJECT_RECRUITMENT_TIME[self::AFTER_RECRUITMENT];
        }
    }
    /**
     *----------------------------
     * CREATE: RikkeiSoft
     * DATE: YYYYMMDD
     * CONTENT: get name of display Status attribute
     *----------------------------
     * @return string
     *----------------------------
     */
    public function getDisplayStatusNameAttribute(){
        $contants = new Constants();
        return $contants->PROJECT_SCOPE[$this->DisplayStatus];
    }
    /**
     *----------------------------
     * CREATE: RikkeiSoft
     * DATE: YYYYMMDD
     * CONTENT: get name of Status attribute
     *----------------------------
     * @return string
     *----------------------------
     */
    public function getStatusNameAttribute(){
        $contants = new Constants();
        return $contants->PROJECT_STATUS[$this->Status];
    }
    /**
     *----------------------------
     * CREATE: RikkeiSoft
     * DATE: YYYYMMDD
     * CONTENT: get name of PeriodDivision attribute
     *----------------------------
     * @return string
     *----------------------------
     */
    public function getPeriodDivisionNameAttribute(){
        $contants = new Constants;
        if ( isset($this->PeriodDivision) ) {
            return $contants->DESIRE_PERIOD[$this->PeriodDivision];
        }
    }
}
