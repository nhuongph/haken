<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProjectCheckPoint extends Model
{
    //
    protected $table = "t_projectcheckpoint";
    protected $primaryKey = 'CheckPointID';
    
    public function OrdersTime(){
      return $this->belongsTo('App\Model\OrdersTime','OrderTimeid','OrderTimeId');
  }
}
