<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProjectSettingDate extends Model{
    //
    protected $table = "t_projectsettingdate";
    protected $primaryKey = 'ProjectSettingDateID';
    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: project setting date prior
    *----------------------------   
    * @return view  
    *----------------------------   
    */
    public function ProjectSettingDatePrior(){
    	return $this->hasMany('App\Model\ProjectSettingDatePrior','ProjectSettingDateID','ProjectDateID');
    }
}
