<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProjectSettingDatePrior extends Model{
    //
    protected $table = "t_projectsettingdateprior";
    protected $primaryKey = 'ProjectSettingDatePriorID';

}
