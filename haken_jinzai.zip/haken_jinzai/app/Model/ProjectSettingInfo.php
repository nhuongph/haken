<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProjectSettingInfo extends Model{
    //
    protected $table = "t_projectsettinginfo";
    protected $primaryKey = 'ProjectSettingInfoID';

    protected static $rules = [
    ];

    /** 
    *----------------------------   
    * CREATE: ToiTL    
    * DATE: YYYYMMDD
    * CONTENT: validate method
    *----------------------------   
    * @return view  
    *----------------------------   
    */
    public static function isValid($data){
    	return validator($data, self::$rules);
    }
}
