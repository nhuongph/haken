<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProjectTraining extends Model
{
    //
    protected $table = "t_projecttraining";
    protected $primaryKey = 'ProjectTrainingID';

}
