<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $table   = "t_sales";
    public $primaryKey = "id";

    protected $rules = [
    	  'Category'                 =>'required',
    	  'ProductName'              =>'required',
    	  'Price'                    =>'required',
    ];

    public function isValid($brandRules, $rules){
        $validate = validator($brandRules,$this->rules);
        return $validate;
    }

    public function isValidArray($brandRules){
        $validate = [];
        $status = false;
        foreach ($brandRules as $key => $value) {
            if ( $value['Category'] != '' || $value['ProductName'] != '' || $value['Price'] != '') {
                $validate = validator($value,$this->rules);
                $status = true;
                if ($validate->fails()) {
                    return $validate;
                }
            }
        }
        if ( !$status ) {
            return ['The category name field is required.'];
        }
        return null;
    }
}