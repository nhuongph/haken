<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Resource extends Model {

    protected $table = "t_resource";
    public $primaryKey = "ResourceId";
    public $timestamps = false;
}