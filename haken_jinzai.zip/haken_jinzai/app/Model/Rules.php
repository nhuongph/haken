<?php

namespace App\Model;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Zizaco\Entrust\Traits\EntrustUserTrait;

class Rules extends Authenticatable
{
    use EntrustUserTrait;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = "t_staff";
    // protected $fillable = [
    //     'name', 'email', 'password','StaffRegisterId'
    // ];
    protected $primaryKey = "StaffRegisterId";
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    protected $rules = [
        'NameBank'           =>'required',
        'NameBranch'         =>'required',
        'AccountName'        =>'required',
        'TransferMethod'     =>'required',
        'TransferNumber'     =>'required|min:7|max:10',
    ];

    public function isValid($userRules, $rules){
        $validate = validator($userRules,$this->rules);
        return $validate;
    }
}
