<?php
//====================================================================================						
//						
//	FILENAME: ScheduleReport.php					
//	CREATE: YYYYMMDD					
//	CREATOR: ToiTL					
//						
//====================================================================================						
//						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//------------------------------------------------------------------------------------						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//====================================================================================
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ScheduleReport extends Model {
	protected $table = 't_schedulereport';
	protected $primaryKey = 'ScheduleReportId';

	// Report type
	const REPORT 			= 1;
	const VISITING_REPORT	= 2;

	// Status of check point
    const UNCHECKED			= 0;
    const CHECKED 			= 1;

    protected static $rules = [
        'ExpenseTotal'		=> 'required',
    ];

    protected static $specialRules = [
        'ExpenseTotal'		=> 'required',
        'Remark'			=> 'required'
    ];

    public static function isValid( $data , $isSpecial = false ){
    	if ( $isSpecial ) {
    		return validator($data,self::$specialRules);
    	}
    	return validator($data,self::$rules);
    }
}