<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SettingReport extends Model
{
    protected $table   = "t_setting_report";
    public $primaryKey = "Id";

    
}