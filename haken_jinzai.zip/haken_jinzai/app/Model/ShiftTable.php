<?php
//====================================================================================						
//						
//	FILENAME: ShiftTable.php					
//	CREATE: 20150613					
//	CREATOR: ToiTL					
//						
//====================================================================================						
//						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//------------------------------------------------------------------------------------						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//====================================================================================
namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\ProjectTraining;
class ShiftTable extends Model {

    protected $table   = 't_shifttable';
    public $primaryKey = 'ShiftTableId';

    // Step in check point
    const WAKEUP 			      = 1;
    const STARTED 			    = 2;
    const ARRIVAL 			    = 3;
    const OPENED 			      = 4;
    const CLOSED 			      = 5;
    const REPORTED 			    = 6;
    const VISITING_REPORTED = 7;

    // Status of check point
    const UNCHECKED 			  = 0;
    const CHECKED 			    = 1;
    const NOCHECKED 			  = 2;
    
    // Status of absense
    const NOT_ABSENSE 			= 0;
    const STAFF_CONVENIENCE = 1;
    const CLIENT_CONVENIENCE= 2;


    public function Staff() {
     return $this->hasOne('App\Model\Staff', 'StaffRegisterId', 'StaffId');
    }
    public function ProjectTraining() {
     return $this->hasOne('App\Model\ProjectTraining', 'ProjectTrainingID', 'ProjectTrainingID');
    }
    public function OrdersTime(){
      return $this->hasOne('App\Model\OrdersTime','OrderTimeid','OrderTimeId');
    }
     /** 
    *----------------------------   
    * CREATE: ThienNb    
    * DATE: 20160615
    * CONTENT: check if it is first day work of staff
    *----------------------------   
    * @param $data    
    * @return bool 
    *----------------------------   
    */
    public  function getIsFirstdayAttribute() {
      $shiftTable = ShiftTable::where('OrderTimeId', $this->OrderTimeId)
                              ->where('StaffId', $this->StaffId)
                              ->orderBy('DateWork','ASC')
                              ->first();
      if($shiftTable){
        if($this->DateWork == $shiftTable->DateWork){
          return true ;
        }else {
          return false;
        }
      }
      

      return true;
    }
     /** 
    *----------------------------   
    * CREATE: ThienNb    
    * DATE: 20160615
    * CONTENT: check if it is first day work of staff
    *----------------------------   
    * @param $data    
    * @return bool 
    *----------------------------   
    */
    public  function getBtnTraningAttribute() {
      //normal status
      if($this->ProjectTrainingID == 0) 
        return "<button class='btn btn-defause btn-sm btn-status' type='button' data-staffid='$this->StaffId' data-orderstimeid='$this->OrderTimeId'"
                . " data-projecttrainingid='$this->ProjectTrainingID' data-status='$this->StatusCircle' data-currentstatus='3,0' >". trans('title.work-schedule.label.normal').'</button>';
      $projectTraining = $this->ProjectTraining;
      if($projectTraining->Cate==0){ 
        $type = trans('title.work-schedule.label.tranning');
        $typeClass = 'btn-primary';
      } else {
        $type = trans('title.work-schedule.label.ojt');
        $typeClass = 'btn-warning';
      };
      if($projectTraining) 
        // status cirle is explore by '@'
        // earch status in string format Cate,ProjectTrainingID,Name for each project tranning
        // Cate is type for tranning(0) or OJT (1)
        return "<button class='btn $typeClass btn-sm btn-status' type='button' data-staffid='$this->StaffId' data-orderstimeid='$this->OrderTimeId'"
                . " data-projecttrainingid='$this->ProjectTrainingID' data-status='$this->StatusCircle' data-currentstatus='$projectTraining->Cate,$projectTraining->ProjectTrainingID,$projectTraining->Name'>". $type.$projectTraining->Name .'</button>';

      return false;
    }
    public  function getStatusCircleAttribute() {
      //normal status
      $status = '3,0,0';
      $projectTranning = ProjectTraining::where('BasicInfoID',  $this->OrdersTime->Orders->ProJectBasicInfo->BasicInfoID)
                                          ->where('Topic','<>' ,'')
                                          ->orderBy('Cate', 'ASC')
                                          ->orderBy('Name', 'ASC')
                                          ->get()   ;
      
      if($projectTranning){
        foreach ($projectTranning as $pro){
          $status.= '@'.$pro->Cate.','.$pro->ProjectTrainingID.','.$pro->Name;
        }
      }
      return $status;
    }
    
    public  function getClassAbsenseAttribute() {
      if($this->Absense == self::NOT_ABSENSE){
        return '';
      }  else if($this->Absense == self::STAFF_CONVENIENCE){
        return 'text-danger';
      }else{
        return 'text-primary';
      }
      return '';
    }

}