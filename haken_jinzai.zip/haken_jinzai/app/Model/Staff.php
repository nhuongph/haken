<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Zizaco\Entrust\Traits\EntrustUserTrait;
use Illuminate\Support\Facades\Validator;

class Staff extends Model
{
  /**
  * The attributes that are mass assignable.
  *
  * @var array
  */
  protected $table = "t_staff";
  public $primaryKey = "StaffRegisterId";
  public $timestamps = false;
  protected $fillable = [
   'name', 'email', 'password'
  ];

  /**
  * The attributes that should be hidden for arrays.
  *
  * @var array
  */
  protected $hidden = [
      'password'
  ];

  protected $rules = [
    'first_name'         => 'required',
    'last_name'          => 'required',
    'first_name_furigana'  => 'required',
    'last_name_furigana'   => 'required',
    'sex'                => 'required',
    'birthdate'          => 'required',
    'phone'              => ['required','regex:/^([0-9\s\-\+\(\)]*)$/'],  
    'fax'                => ['regex:/^([0-9\s\-\+\(\)]*)$/'],
    'mobile'             => ['regex:/^([0-9\s\-\+\(\)]*)$/'],
    'postal_code'        => 'required|numeric',
    'prefectural_name'   => 'required',
    'commune'            => 'required',
    'address_detail'     => 'required',
    'email'              => 'required|email|unique:t_staff',
    'password'           => 'required|min:6',
    'image'              => 'mimes  :jpeg,jpg,png,gif',
    'education'          => 'required',
    'education_school'   => 'required',
    'education_2'        => 'required',
    'education_school_2' => 'required',
    'transfer_method'    => 'required',
    'current_employment_status' => 'required',
    'desire_period'      => 'required',
    'uniform_type'       => 'required',
    'clothes_size'       => 'required',
    'TOEIC'              => 'numeric' ,
    'TOEFL'              => 'numeric' ,
    'height'             => 'numeric' ,
    'nearest_station'    => 'required',
//    'checkbox1' => 'required_without_all: checkbox2, checkbox3,checkbox4',
//    'suit_preparation'        => 'required',
//    'black_pump_preparation'  => 'required',
//    'apron_sling'        => 'required',
//    'black_hair_modification' => 'required',
//    'voice'              => 'required',
//    'department_store_experience'  => 'required',
//    'pos_cash_register_experience' => 'required',
//    'cat_experience'     => 'required',
//    'nail_modification'  => 'required'
  ];

  protected $rules_update = [
      'first_name'         => 'required',
      'last_name'          => 'required',
      'first_name_furigana'  => 'required',
      'last_name_furigana'   => 'required',
      'sex'                => 'required',
      'birthdate'          => 'required',
      'phone'              => ['required','regex:/^([0-9\s\-\+\(\)]*)$/'],  
      'fax'                => ['regex:/^([0-9\s\-\+\(\)]*)$/'],
      'mobile'             => ['regex:/^([0-9\s\-\+\(\)]*)$/'],
      'postal_code'        => 'required|numeric',
      'prefectural_name'   => 'required',
      'commune'            => 'required',
      'address_detail'     => 'required',
      'image'              => 'mimes:jpeg,jpg,png,gif',
      'education'          => 'required',
      'education_school'   => 'required',
      'education_2'        => 'required',
      'education_school_2' => 'required',
      'transfer_method'    => 'required',
      'current_employment_status' => 'required',
      'desire_period'      => 'required',
      'uniform_type'       => 'required',
      'clothes_size'       => 'required',
      'TOEIC'              => 'numeric' ,
      'TOEFL'              => 'numeric' ,
      'height'             => 'numeric' ,
      'nearest_station'    => 'required',
//      'suit_preparation'        => 'required',
//      'black_pump_preparation'  => 'required',
//      'apron_sling'        => 'required',
//      'black_hair_modification' => 'required',
//      'voice'              => 'required',
//      'department_store_experience'  => 'required',
//      'pos_cash_register_experience' => 'required',
//      'cat_experience'     => 'required',
//      'nail_modification'  => 'required'
  ];
  protected $rules_detail = [
      'pdf_resume'      => 'mimes:pdf'
  ];
  public function isValid($staffData){
    #validation data
    
    
    $validate = Validator::make($staffData, $this->rules);
    //validate week day
    $validate->after(function($validate) use ($staffData)
    {
      
      if(!isset($staffData['monday']) && !isset($staffData['tuesday']) && !isset($staffData['wednesday']) &&!isset($staffData['thursday']) &&
            !isset($staffData['friday']) && !isset($staffData['saturday']) && !isset($staffData['sunday'])  && !isset($staffData['public_holiday']) 
        ){
      $validate->errors()->add('monday', trans('validation.weekday'));
      }
    });
    return $validate;
  }

  public function updateValid($staffData) {
    $validate = validator($staffData,$this->rules_update);
    return $validate;
  }
  public function detailValid($staffData) {
    $validate = validator($staffData, $this->rules_detail);
    return $validate;
  }
  
  public function getFirstNameFuriganaAttribute()
  {
      $string = explode(' ', $this->NameFurigana); 
      $name   = isset($string[0])? $string[0] : '';
      return $name;    
  }
  public function getLastNameFuriganaAttribute()
  {
      $string = explode(' ', $this->NameFurigana); 
      $name   = isset($string[1])? $string[1] : '';
      return $name;    
  }
  public function getLastNameAttribute()
  {
      $string = explode(' ', $this->Name); 
      $name   = isset($string[1])? $string[1] : '';
      return $name;    
  }
  public function getFirstNameAttribute()
  {
      $string = explode(' ', $this->Name); 
      $name   = isset($string[0])? $string[0] : '';
      return $name;    
  }
  public function getAgeAttribute()
  {
      $string = \Carbon\Carbon::createFromFormat('Y-m-d',$this->Birthdate)->diff(\Carbon\Carbon::now())->format('%y');
      return $string;    
  }
  
  /**
   * ORM Relationships
   */

  //One to one
  public function StaffMetadata() {
    return $this->hasOne('App\Model\StaffMetadata','StaffID','StaffRegisterId');
  }


  public function SubStaff(){
    return $this->hasOne('App\Model\SubStaff','StaffId','StaffRegisterId');
  }
  public function User(){

    return $this->hasOne('App\Model\User','email','Email');

  }
}
