<?php
//====================================================================================						
//						
//	FILENAME: StaffMessage.php					
//	CREATE: YYYYMMDD					
//	CREATOR: ToiTL					
//						
//====================================================================================						
//						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//------------------------------------------------------------------------------------						
//	MODIFY: 					
//	MODIFER: RikkeiSoft					
//	CONTENT:					
//						
//====================================================================================
namespace App\Model;
use Illuminate\Database\Eloquent\Model;

class StaffMessage extends Model{
	protected $table = "t_staffmessage";
	protected $primaryKey = "StaffMessageId";
}