<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Station extends Model {

    protected $table   = 't_station';
    public $primaryKey = 'StationId';
    public $timestamps = false;
}