<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubCompany extends Model {

    protected $table   = 't_subcompany';
    public $primaryKey = 'CompanyId';
    public $timestamps = false;

    public function Company(){
        return $this->belongsTo('App\Model\Company', 'CompanyId', 'CompanyId');
    }
}

