<?php
namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SubStaff extends Model {

    protected $table   = 't_substaff';
    public $primaryKey = 'SubStaffId';
    public $timestamps = false;

    public function Resource(){
        return $this->hasOne('App\Model\Resource','ResourceId','Image');
    }
    public function ResourcePdf(){
        return $this->hasOne('App\Model\Resource','ResourceId','PDFResume');
    }
    
    public function getTagArrayAttribute() {
      $arrayTag = [
        'IsBright'        => '明るい',
        'IsConfidence'    => '自信○',
        'IsPositive'      => '積極的',
        'IsIntellectual'  => '知的',
        'IsSpeed'         => 'スピード感',
        'IsLaid'          => 'のんびり',
        'IsCleanliness'   => '清潔感',
        'IsSmile'         => '笑顔',
        'IsRoughly'       => '大雑把',
        'IsScrupulous'    => '几帳面',
        'IsWantWork'      => '採用したい'
      ];
      return $arrayTag;
    }

  }

