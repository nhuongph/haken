<?php

namespace App\Model;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Zizaco\Entrust\Traits\EntrustUserTrait;
use DB;
class User extends Authenticatable
{
    use EntrustUserTrait;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password'
    ];
    public $primaryKey = "id";
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $rules = [
        'name'                  => 'required|min:6',
        'email'                 => 'required|email|min:6|unique:users',
        'password'              => 'required|min:6|confirmed',
        'password_confirmation' => 'required|min:6',
    ];

    protected $rules_resgiter_personal=[
        'firstname'             => 'required',
        'lastname'              => 'required',
        'firstname_kana'        => 'required',
        'lastname_kana'         => 'required',
        'phone'                 => ['required','regex:/^([0-9\s\-\+\(\)]*)$/'],
        'email'                 => 'required|email|min:6|unique:users',
        'password'              => 'required|min:6',
        'part'                  => 'required'
    ];



    public function isValid($userData, $user){

        if($user->password != null && $userData['password'] == null ) {
            unset($this->rules['password']);
            unset($this->rules['password_confirmation']);
        }

        if($user->email != null && $userData['email'] == $user->email) {
            $this->rules['email'] = 'required|email|min:6';
        }

        $validate = validator($userData,$this->rules);

        return $validate;
    }
    public function isValidResgisterPersonal($userData, $user){
        $validate = validator($userData,$this->rules_resgiter_personal);
        return $validate;
    }
    public function Staff(){

       return $this->hasOne('App\Model\Staff','Email','email');

    }
    public function GaiA(){

       return $this->hasOne('App\Model\GaiA','email','email');

    }

}
