<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class WantedJob extends Model
{
    protected $table    = "t_wantedjob";
    public $primaryKey  = "WantedJobId";
    const TYPE_SEFT_ELECTED   = 1 ;
    const TYPE_RECOMMEND      = 2 ;
    const TYPE_REGISTERED     = 3 ;
    const TYPE_ASSIGN         = 3 ;
    const STATUS_NOT_SUBMIT   = 0 ;
    const STATUS_SUBMITED     = 1 ;
    const STATUS_APPROVE      = 2 ;
    
    public function Staff() {
      return $this->hasOne('App\Model\Staff', 'StaffRegisterId', 'StaffId');
    }

  }