<?php

namespace App\Providers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use App\Business\ProjectBasicInfoBusiness;
use App\Model\Orders;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Validator::extend('name_kana', function($attribute, $value, $parameters)
        {
            if (preg_match("/^[ァ-ヶｦ-ﾟー]+$/u", $value)) {
                return true;
            }
        });

        Validator::extend('japan_tel', function($attribute, $value, $parameters)
        {
            if (preg_match("/^[0-9]{2,4}-[0-9]{2,4}-[0-9]{3,4}$/", $value)) {
                return true;
            }
        });
        view()->composer('site.menu.pre-register', function($view){
            $currentRoute = Route::current();
            $params = $currentRoute->parameters();

            if ( isset($params['projectId']) ) {
                $projectBusiness = new ProjectBasicInfoBusiness();
                $orderId = $projectBusiness->getProjectByBasicInfoID($params['projectId'])->OrderId;
            } else if (isset($params['orderId'])) {
                $orderId = $params['orderId'];
            }

            $order = Orders::find($orderId);

            $view->with('order',$order);
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        
    }
}
