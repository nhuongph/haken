<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTAccountTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_account', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('AccountID');
			$table->integer('StaffID');
			$table->integer('BranchID');
			$table->string('NumberBankBranch', 11);
			$table->string('AccountName', 20);
			$table->string('TransferMethod', 20);
			$table->string('TransferNumber', 20);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_account');
	}

}
