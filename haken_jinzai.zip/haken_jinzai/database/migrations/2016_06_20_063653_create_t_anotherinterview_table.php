<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTAnotherinterviewTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_anotherinterview', function(Blueprint $table)
		{
			$table->increments('AnotherInterviewId');
			$table->integer('StaffId');
			$table->integer('AnotherInterviewTimeId');
			$table->string('Hour', 50);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_anotherinterview');
	}

}
