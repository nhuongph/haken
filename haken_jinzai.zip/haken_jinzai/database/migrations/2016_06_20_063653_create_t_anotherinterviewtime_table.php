<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTAnotherinterviewtimeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_anotherinterviewtime', function(Blueprint $table)
		{
			$table->increments('AnotherInterviewTimeID');
			$table->date('Date');
			$table->string('Phone', 15);
			$table->timestamps();
			$table->string('RegionName', 50);
			$table->string('ResponsibleName', 100)->nullable();
			$table->string('Email', 50);
			$table->integer('InterviewPeople')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_anotherinterviewtime');
	}

}
