<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTBankTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_bank', function(Blueprint $table)
		{
			$table->increments('BankId');
			$table->string('BankCode', 10);
			$table->string('ShortName', 100);
			$table->string('FullName', 100);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_bank');
	}

}
