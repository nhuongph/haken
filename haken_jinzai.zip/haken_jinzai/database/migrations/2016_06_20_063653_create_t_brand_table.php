<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTBrandTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_brand', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('ManagementName', 100);
			$table->string('DisplayName', 100);
			$table->text('Remarks', 65535);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_brand');
	}

}
