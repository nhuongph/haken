<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTCompany1Table extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_company1', function(Blueprint $table)
		{
			$table->increments('CompanyID');
			$table->string('CompanyName', 100);
			$table->string('FuriganaName', 200);
			$table->string('PostNumber', 20);
			$table->string('Address');
			$table->string('Tel', 20);
			$table->string('Fax', 20);
			$table->string('HeadOfficeAddress');
			$table->decimal('CapitalStock', 5);
			$table->integer('EmployeeNumber');
			$table->string('CEO', 100);
			$table->string('FuriganaCEOName', 200);
			$table->date('EstablishmentDate');
			$table->decimal('RevenueLastYear', 10);
			$table->string('MainClient', 150);
			$table->timestamps();
			$table->string('MainBank', 50);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_company1');
	}

}
