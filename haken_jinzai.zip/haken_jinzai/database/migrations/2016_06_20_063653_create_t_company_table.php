<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTCompanyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_company', function(Blueprint $table)
		{
			$table->string('CompanyId', 12)->primary();
			$table->string('CompanyName', 100);
			$table->string('DepartmentName', 50)->nullable();
			$table->string('FuriganaName', 200);
			$table->string('PersonCharge', 50);
			$table->string('PostalCode', 10);
			$table->string('PrefecturalName', 50);
			$table->string('MunicipalName', 50);
			$table->string('DetailAddress', 100)->nullable();
			$table->string('PhoneNumber', 13);
			$table->string('InnerLine', 12)->nullable();
			$table->string('FaxNumber', 12)->nullable();
			$table->date('ContractDate')->nullable();
			$table->string('PepresentativeName', 50);
			$table->string('PepresentativePosition', 50)->nullable();
			$table->string('PepresentativePhoneNumber', 13)->nullable();
			$table->string('ResponsiblePersonNameHaken', 50)->nullable();
			$table->string('ResponsiblePersonPositionHaken', 50)->nullable();
			$table->string('ResponsiblePersonPhoneNumberHaken', 13)->nullable();
			$table->string('ChainCommandName', 50)->nullable();
			$table->string('ChainCommandPosition', 50)->nullable();
			$table->string('ChainCommandPhoneNumber', 13)->nullable();
			$table->date('Collisionday')->nullable();
			$table->integer('Paymentcondition')->nullable();
			$table->date('BillMustArriveDate')->nullable();
			$table->string('BrandName', 50)->nullable();
			$table->decimal('TrafficFee', 10, 0)->nullable();
			$table->text('Memo6', 65535)->nullable();
			$table->text('Memo7', 65535)->nullable();
			$table->text('Memo8', 65535)->nullable();
			$table->text('Memo9', 65535)->nullable();
			$table->string('ResponsibleTeam', 50)->nullable();
			$table->string('BusinessTypeCode', 20)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_company');
	}

}
