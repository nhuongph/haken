<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTInterviewTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_interview', function(Blueprint $table)
		{
			$table->increments('InterviewID');
			$table->integer('StaffId');
			$table->integer('RegionId');
			$table->integer('InterviewTimeId')->nullable();
			$table->text('InterviewComment', 65535)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_interview');
	}

}
