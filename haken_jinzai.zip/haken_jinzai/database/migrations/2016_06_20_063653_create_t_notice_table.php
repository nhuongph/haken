<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTNoticeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_notice', function(Blueprint $table)
		{
			$table->integer('NoticeId', true);
			$table->string('Title');
			$table->text('Content', 65535);
			$table->string('Author');
			$table->string('UpdatedBy');
			$table->string('PublicDate', 10);
			$table->string('PublicHour', 10);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_notice');
	}

}
