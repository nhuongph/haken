<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTOperationHistoryTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_operation_history', function(Blueprint $table)
		{
			$table->increments('OpnHisId');
			$table->timestamp('OpnTime')->default(DB::raw('CURRENT_TIMESTAMP'));
			$table->string('Operator', 50);
			$table->string('Object', 50);
			$table->string('ObjectDetail');
			$table->string('OpnType', 50);
			$table->string('ItemName', 50);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_operation_history');
	}

}
