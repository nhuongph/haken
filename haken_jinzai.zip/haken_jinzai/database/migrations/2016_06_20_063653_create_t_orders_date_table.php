<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTOrdersDateTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_orders_date', function(Blueprint $table)
		{
			$table->integer('DateOrderId', true);
			$table->date('Date');
			$table->integer('OrderTimeId');
			$table->integer('OrderId');
			$table->integer('WorkNecessity');
			$table->string('NumberPeople', 50);
			$table->text('Notices', 65535);
			$table->integer('TableName');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_orders_date');
	}

}
