<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTOrdersDemandRegardTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_orders_demand_regard', function(Blueprint $table)
		{
			$table->integer('DemandRegardId', true);
			$table->integer('OrderId');
			$table->integer('AgeStart');
			$table->integer('AgeEnd');
			$table->text('Required', 65535);
			$table->text('Priority', 65535);
			$table->text('ContractorComments', 65535);
			$table->integer('CashRegister');
			$table->integer('CommentId');
			$table->integer('SexNam');
			$table->integer('SexNu');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_orders_demand_regard');
	}

}
