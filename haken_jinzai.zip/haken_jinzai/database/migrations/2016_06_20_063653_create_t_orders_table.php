<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTOrdersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_orders', function(Blueprint $table)
		{
			$table->increments('OrderId');
			$table->string('ProjectName', 50);
			$table->string('Contractor', 50);
			$table->date('OrderDate');
			$table->string('CategoryJob', 50);
			$table->string('Type', 50);
			$table->string('OrderDivision', 50);
			$table->string('Brand', 50);
			$table->string('PeriodDivision', 50);
			$table->dateTime('BeginContract')->default('0000-00-00 00:00:00');
			$table->dateTime('EndContract')->default('0000-00-00 00:00:00');
			$table->string('TimeWorkings', 50);
			$table->string('AddressCompany', 50);
			$table->string('TaskOverview', 50);
			$table->string('NearestStation1', 50);
			$table->string('NeasestStation2', 50);
			$table->string('NeasestStation3', 50);
			$table->string('NeasestStation4', 50);
			$table->string('NearestStation5', 100);
			$table->string('MeetingTime', 50);
			$table->string('MeetingPlace', 50);
			$table->string('SalesRepresentative', 50);
			$table->string('ContractExistence', 20);
			$table->string('Othernotes', 50);
			$table->string('Clothes', 50);
			$table->string('EmploymentDestinationId', 50);
			$table->string('AgreementDestinationID', 50);
			$table->string('OrderAddressId', 50);
			$table->string('DispatchResponsibleName', 50);
			$table->string('DispatchResponsibleDepartment', 50);
			$table->string('DispatchResponsibleTitle', 50);
			$table->string('ResponsiblePersonContact', 50);
			$table->string('ChainCommandName', 50);
			$table->string('ChainCommandDepartment', 50);
			$table->string('ChainCommandTitle', 50);
			$table->string('ChainCommandContact', 50);
			$table->string('ComplaintPersonCharge', 50);
			$table->string('ComplaintPersonnelDepartment', 50);
			$table->string('ComplaintPersonnelOfficers', 50);
			$table->string('ComplaintPersonnelContacts', 50);
			$table->string('OrdersUnits', 50);
			$table->string('TransportationExpensesRemarks', 50);
			$table->string('ConstructionRemoval', 50);
			$table->string('ConstructionRemovalRemarks', 50);
			$table->string('Allowance', 50);
			$table->string('AllowanceRemarks', 50);
			$table->string('ConstructionRemoval1', 50);
			$table->string('ConstructionRemovalRemarks1', 50);
			$table->string('OrderUnitsPreTraining', 50);
			$table->string('TransportationExpensePayment', 50);
			$table->timestamp('LastUpdateTime')->default(DB::raw('CURRENT_TIMESTAMP'));
			$table->string('LastUpdatePerson', 50);
			$table->timestamp('ApprovalRequestTime')->default(DB::raw('CURRENT_TIMESTAMP'));
			$table->string('ApprovalRequester', 50);
			$table->text('ApprovalRequestComment', 65535);
			$table->string('PersonCharge', 50);
			$table->text('ApprovalComment', 65535);
			$table->string('Status', 50);
			$table->string('PeopleApproal', 100);
			$table->timestamps();
			$table->integer('TotalPay');
			$table->integer('TotalClaims');
			$table->integer('TotalServices');
			$table->integer('SumTotal');
			$table->string('Belogings', 50);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_orders');
	}

}
