<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjectsettinginfoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projectsettinginfo', function(Blueprint $table)
		{
			$table->integer('ProjectSettingInfoID', true);
			$table->integer('OrderId')->nullable();
			$table->string('Note', 45)->nullable();
			$table->string('Clothes', 45)->nullable();
			$table->string('Belonging', 45)->nullable();
			$table->string('FocusTime', 45)->nullable();
			$table->string('Responsible', 45)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projectsettinginfo');
	}

}
