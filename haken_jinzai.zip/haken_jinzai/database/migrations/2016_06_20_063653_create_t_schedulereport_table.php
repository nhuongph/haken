<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTSchedulereportTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_schedulereport', function(Blueprint $table)
		{
			$table->integer('ScheduleReportId', true);
			$table->integer('ShiftTableId')->nullable();
			$table->string('ExpenseTotal', 45)->nullable();
			$table->integer('ExpenseImage')->nullable();
			$table->integer('IsUsedBreakTime')->nullable()->default(0);
			$table->integer('IsOverTime')->nullable()->default(0);
			$table->text('Remark', 65535)->nullable();
			$table->integer('Type')->nullable();
			$table->timestamps();
			$table->text('Reply', 65535)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_schedulereport');
	}

}
