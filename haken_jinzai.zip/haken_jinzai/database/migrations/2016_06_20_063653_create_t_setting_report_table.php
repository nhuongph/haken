<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTSettingReportTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_setting_report', function(Blueprint $table)
		{
			$table->integer('Id', true);
			$table->integer('BrandId');
			$table->string('Type1', 100);
			$table->string('Type2', 100);
			$table->string('Type3', 100);
			$table->string('Type4', 100);
			$table->string('Type5', 100);
			$table->string('Type6', 100);
			$table->string('Type7', 100);
			$table->string('Type8', 100);
			$table->string('Type9', 100);
			$table->string('Comment1', 100);
			$table->string('Comment2', 100);
			$table->string('Comment3', 100);
			$table->string('Comment4', 100);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_setting_report');
	}

}
