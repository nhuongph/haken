<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTShifttableTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_shifttable', function(Blueprint $table)
		{
			$table->integer('ShiftTableId', true);
			$table->integer('StaffId')->nullable();
			$table->date('DateWork')->nullable();
			$table->integer('OrderTimeId')->nullable();
			$table->string('TimeStartWanted', 10)->nullable();
			$table->integer('ProjectTrainingID')->nullable()->default(0);
			$table->integer('Absense');
			$table->timestamps();
			$table->integer('WakeUp')->nullable()->default(0);
			$table->dateTime('WakeUpTime')->nullable();
			$table->integer('Started')->nullable()->default(0);
			$table->dateTime('StartedTime')->nullable();
			$table->integer('Arrival')->nullable()->default(0);
			$table->dateTime('ArrivalTime')->nullable();
			$table->integer('Opened')->nullable()->default(0);
			$table->dateTime('OpenedTime')->nullable();
			$table->integer('Closed')->nullable()->default(0);
			$table->dateTime('ClosedTime')->nullable();
			$table->integer('Reported')->nullable()->default(0);
			$table->dateTime('ReportedTime')->nullable();
			$table->integer('VisitingReported')->nullable()->default(0);
			$table->dateTime('VisitingReportedTime')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_shifttable');
	}

}
