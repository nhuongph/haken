<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTStaffTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_staff', function(Blueprint $table)
		{
			$table->increments('StaffRegisterId');
			$table->string('StaffCode', 20);
			$table->string('Name');
			$table->string('NameFurigana');
			$table->string('MaidenName')->nullable();
			$table->string('NationalCode')->nullable();
			$table->boolean('Sex');
			$table->date('Birthdate');
			$table->integer('PostalCode');
			$table->string('PrefecturalName');
			$table->string('MunicipalName');
			$table->string('AddressDetail');
			$table->string('Mobile')->nullable();
			$table->string('Fax')->nullable();
			$table->string('Phone')->nullable();
			$table->string('Email', 100);
			$table->string('Email_2', 100)->nullable();
			$table->string('Email_3', 100)->nullable();
			$table->string('ContactName', 100)->nullable();
			$table->string('ContactPhoneNumber', 100)->nullable();
			$table->string('Interviewer', 100)->nullable();
			$table->date('InterviewDate')->nullable();
			$table->date('RegisterDate');
			$table->date('WorkStartDate')->nullable();
			$table->string('EducationDivision');
			$table->string('EducationDivisionSchool');
			$table->string('EducationDivisionDepartment')->nullable();
			$table->string('EducationDivision_2');
			$table->string('EducationDivisionSchool_2');
			$table->string('EducationDivisionDepartment_2')->nullable();
			$table->string('TransferMethod', 50);
			$table->string('CurrentEmploymentStatus', 50);
			$table->text('DesiredPeriod', 65535);
			$table->integer('Height')->nullable();
			$table->string('UniformType', 50)->nullable();
			$table->string('ShoesSize', 50);
			$table->boolean('SuitPreparation');
			$table->boolean('WhiteShirtPreparation');
			$table->boolean('BlackPumpPreparation');
			$table->boolean('ApronSling');
			$table->boolean('BlackHairModification');
			$table->boolean('Voice');
			$table->boolean('DepartmentStoreExperience');
			$table->boolean('POSCashRegisterExperience');
			$table->boolean('CATExperience');
			$table->boolean('NailModification');
			$table->boolean('PackingExperience')->nullable();
			$table->boolean('TouchUp')->nullable();
			$table->string('TrafficFee')->nullable();
			$table->string('Memo20')->nullable();
			$table->string('TaxClassification')->nullable();
			$table->string('BankCode')->nullable();
			$table->string('AccountNumber')->nullable();
			$table->string('PostalSavingNumber')->nullable();
			$table->string('RecipientName')->nullable();
			$table->string('RecipientNameKana')->nullable();
			$table->string('DepartmentCode')->nullable();
			$table->date('StartWork1')->nullable();
			$table->date('EndWork1')->nullable();
			$table->string('CompanyName1')->nullable();
			$table->string('WorkCode1')->nullable();
			$table->string('WorkContent1')->nullable();
			$table->string('WorkExperienceContentCode')->nullable();
			$table->string('WorkExperienceContentCode_2')->nullable();
			$table->string('WorkExperienceContentCode_3')->nullable();
			$table->string('JobDescriptionDetail')->nullable();
			$table->string('JobDescriptionDetail_2')->nullable();
			$table->string('WorkExperienceDetail')->nullable();
			$table->string('WorkExperienceDetail_2')->nullable();
			$table->string('MasterCodeJob')->nullable();
			$table->date('StartWork2')->nullable();
			$table->date('EndWork2')->nullable();
			$table->string('CompanyName2')->nullable();
			$table->string('WorkCode2')->nullable();
			$table->string('WorkContent2')->nullable();
			$table->string('WorkExperienceContentCode2')->nullable();
			$table->string('WorkExperienceContentCode2_2')->nullable();
			$table->string('WorkExperienceContentCode2_3')->nullable();
			$table->string('JobDescriptionDetail2')->nullable();
			$table->string('JobDescriptionDetail2_2')->nullable();
			$table->string('WorkExperienceDetail2')->nullable();
			$table->string('WorkExperienceDetail2_2')->nullable();
			$table->string('MasterCodeJob2')->nullable();
			$table->date('StartWork3')->nullable();
			$table->date('EndWork3')->nullable();
			$table->string('CompanyName3')->nullable();
			$table->string('WorkCode3')->nullable();
			$table->string('WorkContent3')->nullable();
			$table->string('WorkExperienceContentCode3')->nullable();
			$table->string('WorkExperienceContentCode3_2')->nullable();
			$table->string('WorkExperienceContentCode3_3')->nullable();
			$table->string('JobDescriptionDetail3')->nullable();
			$table->string('JobDescriptionDetail3_2')->nullable();
			$table->string('WorkExperienceDetail3')->nullable();
			$table->string('WorkExperienceDetail3_2')->nullable();
			$table->string('MasterCodeJob3')->nullable();
			$table->date('StartWork4')->nullable();
			$table->date('EndWork4')->nullable();
			$table->string('CompanyName4')->nullable();
			$table->string('WorkCode4')->nullable();
			$table->string('WorkContent4')->nullable();
			$table->string('WorkExperienceContentCode4')->nullable();
			$table->string('WorkExperienceContentCode4_2')->nullable();
			$table->string('WorkExperienceContentCode4_3')->nullable();
			$table->string('JobDescriptionDetail4')->nullable();
			$table->string('JobDescriptionDetail4_2')->nullable();
			$table->string('WorkExperienceDetail4')->nullable();
			$table->string('WorkExperienceDetail4_2')->nullable();
			$table->string('MasterCodeJob4')->nullable();
			$table->date('StartWork5')->nullable();
			$table->date('EndWork5')->nullable();
			$table->string('CompanyName5')->nullable();
			$table->string('WorkCode5')->nullable();
			$table->string('WorkContent5')->nullable();
			$table->string('WorkExperienceContentCode5')->nullable();
			$table->string('WorkExperienceContentCode5_2')->nullable();
			$table->string('WorkExperienceContentCode5_3')->nullable();
			$table->string('JobDescriptionDetail5')->nullable();
			$table->string('JobDescriptionDetail5_2')->nullable();
			$table->string('WorkExperienceDetail5')->nullable();
			$table->string('WorkExperienceDetail5_2')->nullable();
			$table->string('MasterCodeJob5')->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_staff');
	}

}
