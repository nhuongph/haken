<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTStaffmessageTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_staffmessage', function(Blueprint $table)
		{
			$table->integer('StaffMessageId', true);
			$table->string('Title')->nullable();
			$table->text('Content', 65535)->nullable();
			$table->integer('StaffId')->nullable();
			$table->integer('OrderTimeId')->nullable();
			$table->timestamps();
			$table->dateTime('SentDateTime')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_staffmessage');
	}

}
