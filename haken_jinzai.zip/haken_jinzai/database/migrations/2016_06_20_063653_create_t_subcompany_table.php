<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTSubcompanyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_subcompany', function(Blueprint $table)
		{
			$table->string('CompanyId', 12)->primary();
			$table->string('HeadOffice', 50)->nullable();
			$table->decimal('CapitalStock', 10, 0)->nullable();
			$table->integer('EmployeeNumber')->nullable();
			$table->date('EstablishmentDate')->nullable();
			$table->string('MainCustomerBank', 50)->nullable();
			$table->string('LastYearSuppliers', 50)->nullable();
			$table->string('MainCustomer', 50)->nullable();
			$table->text('CompanyMemo', 65535);
			$table->integer('OfficialName');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_subcompany');
	}

}
