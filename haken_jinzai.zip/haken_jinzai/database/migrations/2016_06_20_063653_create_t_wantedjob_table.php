<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTWantedjobTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_wantedjob', function(Blueprint $table)
		{
			$table->increments('WantedJobId');
			$table->integer('OrderTimeId');
			$table->integer('StaffId');
			$table->date('DateWanted');
			$table->integer('Type');
			$table->integer('Status');
			$table->timestamps();
			$table->string('TimeStartWanted', 8)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_wantedjob');
	}

}
