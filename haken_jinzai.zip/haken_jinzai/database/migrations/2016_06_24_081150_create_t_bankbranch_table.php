<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTBankbranchTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_bankbranch', function(Blueprint $table)
		{
			$table->increments('BranchId');
			$table->string('BranchCode', 10);
			$table->integer('MasterBankId');
			$table->string('MasterBankCode', 10);
			$table->string('ShortName', 100);
			$table->string('FullName', 100);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_bankbranch');
	}

}
