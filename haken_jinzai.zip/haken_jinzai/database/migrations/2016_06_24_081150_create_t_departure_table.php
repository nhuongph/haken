<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTDepartureTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_departure', function(Blueprint $table)
		{
			$table->integer('DepartureId', true);
			$table->integer('StaffId')->nullable();
			$table->integer('CbxWakeup')->nullable()->default(0);
			$table->string('Wakeup', 45)->nullable();
			$table->integer('CbxDeparture')->nullable();
			$table->string('Departure', 45)->nullable();
			$table->string('Note', 45)->nullable();
			$table->timestamps();
			$table->integer('OrderTimeId')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_departure');
	}

}
