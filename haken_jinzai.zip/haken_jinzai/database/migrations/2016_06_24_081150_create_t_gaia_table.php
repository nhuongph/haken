<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTGaiaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_gaia', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('Firstname', 100);
			$table->string('Lastname', 100);
			$table->string('Firstname_Kana', 100);
			$table->string('Lastname_Kana', 100);
			$table->string('Part', 100);
			$table->string('email', 100);
			$table->string('Phone', 15);
			$table->string('BasicAuthority', 50);
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_gaia');
	}

}
