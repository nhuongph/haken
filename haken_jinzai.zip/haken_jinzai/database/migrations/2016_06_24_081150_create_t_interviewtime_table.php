<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTInterviewtimeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_interviewtime', function(Blueprint $table)
		{
			$table->increments('InterviewTimeId');
			$table->integer('RegionId');
			$table->date('InterviewDate');
			$table->string('InterviewTime', 20);
			$table->integer('InterviewPeople');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_interviewtime');
	}

}
