<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTJobCategoryTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_job_category', function(Blueprint $table)
		{
			$table->string('job_code', 6)->unique('job_code_UNIQUE');
			$table->string('job_name', 40);
			$table->string('job_detail', 80)->nullable();
			$table->text('memo', 65535)->nullable();
			$table->integer('display_flag')->default(0);
			$table->string('job_name_for_staff', 40)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_job_category');
	}

}
