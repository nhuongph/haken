<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTMessageMailHistoryTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_message_mail_history', function(Blueprint $table)
		{
			$table->integer('MessageMailHistoryId')->primary();
			$table->integer('StaffId')->nullable();
			$table->string('Content', 45)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_message_mail_history');
	}

}
