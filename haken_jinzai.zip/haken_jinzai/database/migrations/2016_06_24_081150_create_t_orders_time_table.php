<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTOrdersTimeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_orders_time', function(Blueprint $table)
		{
			$table->integer('OrderTimeid', true);
			$table->integer('OrderId');
			$table->string('TimeStart', 50);
			$table->string('TimeEnd', 50);
			$table->string('TimeBreak', 50);
			$table->string('Payment', 50);
			$table->string('Claim', 50);
			$table->string('TimeWorkings', 50);
			$table->text('Note', 65535);
			$table->integer('Name');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_orders_time');
	}

}
