<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTParttimeTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_parttime', function(Blueprint $table)
		{
			$table->increments('PartTimeID');
			$table->integer('StaffID');
			$table->string('Workplace', 20);
			$table->string('ContentBusiness', 100);
			$table->string('ContactForm', 20);
			$table->date('StartDate');
			$table->date('EndDate');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_parttime');
	}

}
