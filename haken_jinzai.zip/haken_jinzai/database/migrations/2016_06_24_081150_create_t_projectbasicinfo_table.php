<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjectbasicinfoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projectbasicinfo', function(Blueprint $table)
		{
			$table->integer('BasicInfoID', true);
			$table->integer('OrderId')->unsigned()->nullable();
			$table->integer('Thumbnail')->unsigned()->nullable();
			$table->date('StartDate')->nullable();
			$table->date('EndDate')->nullable();
			$table->string('MainChargeName', 20)->nullable();
			$table->string('MainChargeMail')->nullable();
			$table->string('SubChargeNameOne', 20)->nullable();
			$table->string('SubChargeMailOne')->nullable();
			$table->string('SubChargeNameTwo', 20)->nullable();
			$table->string('SubChargeMailTwo')->nullable();
			$table->integer('IsReceiptMail')->nullable()->default(0);
			$table->timestamps();
			$table->integer('IsNoExperience')->nullable()->default(0);
			$table->integer('IsLongTime')->nullable()->default(0);
			$table->integer('IsTransportation')->nullable()->default(0);
			$table->integer('Status')->nullable()->default(0);
			$table->integer('IsInAMonth')->nullable()->default(0);
			$table->integer('IsTenDays')->nullable()->default(0);
			$table->integer('IsOnlyOneDay')->nullable()->default(0);
			$table->integer('DisplayStatus')->nullable()->default(0);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projectbasicinfo');
	}

}
