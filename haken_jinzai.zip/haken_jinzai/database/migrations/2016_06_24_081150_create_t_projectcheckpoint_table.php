<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjectcheckpointTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projectcheckpoint', function(Blueprint $table)
		{
			$table->integer('CheckPointID', true);
			$table->integer('BasicInfoID')->nullable();
			$table->string('Rule', 5)->nullable();
			$table->string('Start', 5)->nullable();
			$table->string('End', 5)->nullable();
			$table->integer('Checked')->nullable()->default(0);
			$table->integer('Name')->nullable();
			$table->timestamps();
			$table->integer('OrderTimeId')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projectcheckpoint');
	}

}
