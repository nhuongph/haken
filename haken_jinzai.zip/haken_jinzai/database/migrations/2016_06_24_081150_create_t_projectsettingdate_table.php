<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjectsettingdateTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projectsettingdate', function(Blueprint $table)
		{
			$table->integer('ProjectDateID', true);
			$table->string('Start', 45)->nullable();
			$table->string('End', 45)->nullable();
			$table->string('RestTime', 45)->nullable();
			$table->string('WorkLocation', 45)->nullable();
			$table->string('Allowance', 45)->nullable();
			$table->string('Note', 45)->nullable();
			$table->string('OrderId', 45)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projectsettingdate');
	}

}
