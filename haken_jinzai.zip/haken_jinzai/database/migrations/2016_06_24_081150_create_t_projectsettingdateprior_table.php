<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjectsettingdatepriorTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projectsettingdateprior', function(Blueprint $table)
		{
			$table->integer('ProjectSettingDatePriorID', true);
			$table->integer('ProjectSettingDateID')->nullable();
			$table->string('Date', 45)->nullable();
			$table->string('Position', 45)->nullable();
			$table->string('Joiner', 45)->nullable();
			$table->timestamps();
			$table->integer('Checked')->nullable()->default(0);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projectsettingdateprior');
	}

}
