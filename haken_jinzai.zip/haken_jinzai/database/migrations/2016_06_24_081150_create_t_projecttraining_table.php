<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTProjecttrainingTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_projecttraining', function(Blueprint $table)
		{
			$table->integer('ProjectTrainingID', true);
			$table->integer('Name')->nullable();
			$table->string('Time', 10)->nullable();
			$table->string('Payment', 45)->nullable();
			$table->string('Claim', 45)->nullable();
			$table->string('Type', 45)->nullable();
			$table->string('Cate', 45)->nullable();
			$table->integer('BasicInfoID')->nullable();
			$table->string('Topic')->nullable();
			$table->timestamps();
			$table->string('Allowance', 45)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_projecttraining');
	}

}
