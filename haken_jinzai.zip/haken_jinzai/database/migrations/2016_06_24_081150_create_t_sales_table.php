<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTSalesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_sales', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('reportId');
			$table->string('Category', 50);
			$table->string('ProductName', 50);
			$table->integer('Price');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_sales');
	}

}
