<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTStaffmessageTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_staffmessage', function(Blueprint $table)
		{
			$table->integer('StaffMessageId', true);
			$table->string('Title')->nullable();
			$table->text('Content', 65535)->nullable();
			$table->integer('StaffId')->nullable();
			$table->integer('ShiftTableId')->nullable();
			$table->timestamps();
			$table->dateTime('SentDateTime')->nullable();
			$table->text('Reply', 65535);
			$table->integer('ReplyGaiaId');
			$table->integer('Corresponding')->default(0);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_staffmessage');
	}

}
