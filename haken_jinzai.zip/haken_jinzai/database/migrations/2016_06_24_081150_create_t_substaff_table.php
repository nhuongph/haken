<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTSubstaffTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_substaff', function(Blueprint $table)
		{
			$table->increments('SubStaffId');
			$table->integer('StaffId')->unsigned();
			$table->string('Password', 100);
			$table->string('NearestStation')->nullable();
			$table->string('RegistrationHistory')->nullable();
			$table->boolean('Monday')->default(0);
			$table->boolean('Tuesday')->default(0);
			$table->boolean('Wednesday')->default(0);
			$table->boolean('Thursday')->default(0);
			$table->boolean('Friday')->default(0);
			$table->boolean('Saturday')->default(0);
			$table->boolean('Sunday')->default(0);
			$table->boolean('PublicHoliday')->default(0);
			$table->boolean('MobileSale')->default(0);
			$table->boolean('HomeSale')->default(0);
			$table->boolean('CosmeticSale')->default(0);
			$table->boolean('ApparelSale')->default(0);
			$table->boolean('GoodsSale')->default(0);
			$table->boolean('FoodSale')->default(0);
			$table->boolean('TastingSale')->default(0);
			$table->boolean('Business')->default(0);
			$table->boolean('Rounder')->default(0);
			$table->boolean('CoffeeStaff')->default(0);
			$table->boolean('DepartmentStoreCashRegister')->default(0);
			$table->boolean('Secretary')->default(0);
			$table->boolean('DataEntry')->default(0);
			$table->boolean('Companion')->default(0);
			$table->boolean('Director')->default(0);
			$table->boolean('Lightwork')->default(0);
			$table->boolean('Other')->default(0);
			$table->string('EmploymentDeadline');
			$table->boolean('OrdinaryLicense')->default(0);
			$table->boolean('SalesOfficer')->default(0);
			$table->boolean('HomeApplianceAdvisor')->default(0);
			$table->boolean('OtherLanguageTest')->default(0);
			$table->integer('TOEIC')->unsigned()->nullable();
			$table->integer('TOEFL')->unsigned()->nullable();
			$table->string('Entitlement')->nullable();
			$table->integer('ClothesSize')->nullable();
			$table->string('Image', 45)->nullable();
			$table->boolean('IsBright')->default(0);
			$table->boolean('IsConfidence')->default(0);
			$table->boolean('IsPositive')->default(0);
			$table->boolean('IsIntellectual')->default(0);
			$table->boolean('IsSpeed')->default(0);
			$table->boolean('IsLaid')->default(0);
			$table->boolean('IsCleanliness')->default(0);
			$table->boolean('IsSmile')->default(0);
			$table->boolean('IsRoughly')->default(0);
			$table->boolean('IsScrupulous')->default(0);
			$table->boolean('IsWantWork')->default(0);
			$table->integer('Appearance')->default(1);
			$table->integer('Attitude')->default(1);
			$table->integer('Expression')->default(1);
			$table->integer('Personality')->default(1);
			$table->integer('AdminExperience')->default(1);
			$table->integer('SaleExperience')->default(1);
			$table->integer('BeingLate')->default(1);
			$table->integer('Willing')->default(1);
			$table->integer('Corresponding')->default(1);
			$table->text('FirstImpression', 65535);
			$table->text('Comment', 65535);
			$table->string('Rank', 5);
			$table->integer('RankType');
			$table->integer('PDFResume');
			$table->string('update_by');
			$table->integer('Verify');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_substaff');
	}

}
