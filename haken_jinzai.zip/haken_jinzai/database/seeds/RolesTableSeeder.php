<?php

use Illuminate\Database\Seeder;

class RolesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      \DB::table('roles')->delete();

      \DB::table('roles')->insert(array(
        0 =>
        array(
          'id' => 1,
          'name' => 'admin',
          'display_name' => 'Administrator',
          'description' => 'Administrator of the whole site',
          'created_at' => NULL,
          'updated_at' => NULL,
        ),
        1 =>
        array(
          'id' => 2,
          'name' => 'officer',
          'display_name' => 'Officer',
          'description' => 'Officer Position',
          'created_at' => NULL,
          'updated_at' => NULL,
        ),
        2 =>
        array(
          'id' => 3,
          'name' => 'business',
          'display_name' => 'Business',
          'description' => 'Business Position',
          'created_at' => NULL,
          'updated_at' => NULL,
        ),
        3 =>
        array(
          'id' => 4,
          'name' => 'pre-register',
          'display_name' => 'Pre-register',
          'description' => 'Pre-register Staff',
          'created_at' => NULL,
          'updated_at' => NULL,
        ),
        4 =>
        array(
          'id' => 5,
          'name' => 'staff',
          'display_name' => 'Staff',
          'description' => 'Staff Position',
          'created_at' => NULL,
          'updated_at' => NULL,
        ),
      ));
    }
}
