<?php

use Illuminate\Database\Seeder;

class TRegionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        \DB::table('t_region')->delete();
        
        \DB::table('t_region')->insert(array (
            0 => 
            array (
                'Name' => '東京',
                'Type' => 1,
                'RegionId' => 1,
            ),
            1 => 
            array (
                'Name' => '神奈川',
                'Type' => 1,
                'RegionId' => 2,
            ),
            2 => 
            array (
                'Name' => 'その他',
                'Type' => 0,
                'RegionId' => 3,
            ),
        ));
    }
}
