<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('users')->delete();
        
        \DB::table('users')->insert(array (
            0 => 
            array (
                'id' => 1,
                'name' => 'Super Admin',
                'email' => 'admin@hakenjinjai.com',
                'password' => '$2y$10$ZeM3MjWmJXK35wEpezuqy.ZvHMBGe6wf8T4UW7oUz4PuomRsLbDYe',
                'remember_token' => '',
                'created_at' => NULL,
                'updated_at' => '2016-05-31 15:56:39',
                'firstname' => '',
                'lastname' => '',
                'firstname_kana' => '',
                'lastname_kana' => '',
                'part' => '',
            )
        ));
    }
}
