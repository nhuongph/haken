#! /bin/bash
rm -rf haken_jinzai
git clone marinaxinc@marinaxinc.git.backlog.jp:/GAIA_TEMP_STAFF/web.git haken_jinzai
cd haken_jinzai
cd deploy
ant -f build.xml
cd ..
chmod 777 -R storage
chmod 777 -R bootstrap/cache
chmod 777 -R public
composer install
php artisan key:generate
php artisan migrate
php artisan db:seed
cp deploy/EntrustRole.php vendor/zizaco/entrust/src/Entrust/Middleware/EntrustRole.php
