※ 要求ソフト: Ant, composer, git, create ssh key for git, lib php

	1. Ant: 
	    yum install ant

	2. Composer: 
	    php composer-setup.php --install-dir=bin --filename=composer
	    mv composer.phar /usr/local/bin/composer

	3. Git: 
	    yum install git

	4. Generate ssh key: 
	    参考リンク：　https://help.github.com/articles/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent/

	5. Lib Php: 
	    yum install php56w-mysql php56w-mbstring php56w-mcrypt 
	    (参考リンク: https://webtatic.com/packages/php56/)

※ デプロイする前にファイルdeploy/build.xmlのデータベースの情報をコンフィグしてください。
	CONFIG.DB_HOST
	CONFIG.DB_DATABASE
	CONFIG.DB_USERNAME
	CONFIG.DB_PASSWORD


※ デプロイ
   以下のコマンドを実施してください。
	sh build.sh



