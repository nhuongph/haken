var MESSAGE = {
	CONNECT_ERROR: "コネクションエラー。",
	DELETE_SUCCESS: "削除成功しました。",
	DELETE_CONFIRM: "削除してもよろしいでしょうか？",
	DELETE_ERROR_INTERVIEW: "面接希望の方が登録されています。面接希望者のキャンセル処理を行ってから、再度操作を行ってください。",
	SEND_MESSAGE_SUCCESS: 'Send message success',
	SEND_MESSAGE_ERROR: 'Send message error' ,
  SAVE_SUCCESS : 'save success' ,
  SAVE_ERROR : 'have error on saving' ,
  MAX_PEOPLE : '該当日の人数を達成しました。',
  DUPPLICATE : 'allready have in this day' ,
  
}