$(document).ready(function(){
        $('#submit_send_mail').on('click', function(){
            var $email = $("#email")
            , $confirm_email = $("#confirm_email");
        if ($email.val() != $confirm_email.val()) {
            $confirm_email.each(function() {
                this.setCustomValidity("Email Don't Match");
            });
        } else {
            $confirm_email.each(function() {
                this.setCustomValidity("");
            });
        }
    });
    
    $('#submit').on('click', function(){
            var $password = $("#password")
            , $confirm_password = $("#confirm_password");
        if ($password.val() != $confirm_password.val()) {
            $confirm_password.each(function() {
                this.setCustomValidity("Password Don't Match");
            });
        } else {
            $confirm_password.each(function() {
                this.setCustomValidity("");
            });
        }
    });
});