$(function(){
    $(function () {
        $('#birthdate').datetimepicker({
            //autoclose: true
            format: 'YYYY/MM/DD',
            locale: 'ja'
        });
        $('#employment_deadline').datetimepicker({
            //autoclose: true
            format: 'YYYY/MM' ,
            locale: 'ja'
        });
    });
    function startWorkInit( index){
        var startwork = '#start_work'+index;
        var endwork   = '#end_work'+ index;
        $(startwork).datetimepicker({
            format: 'YYYY/MM/DD',
            locale: 'ja'
        });
        $(endwork).datetimepicker({
            format: 'YYYY/MM/DD',
            locale: 'ja',
            useCurrent: false
        });
        
        $(startwork).on("dp.change", function (e) {
            $(endwork).data("DateTimePicker").minDate(e.date);
        });
        $(endwork).on("dp.change", function (e) {
            $(startwork).data("DateTimePicker").maxDate(e.date);
        });
    }
    startWorkInit(1);
    startWorkInit(2);
    startWorkInit(3);
    startWorkInit(4);
    startWorkInit(5);
//    for(var $i = 1; $i <= 5; $i++ ){
//        var startwork = '#start_work'+$i;
//        var endwork   = '#end_work'+$i;
//        $(startwork).datetimepicker({
//            format: 'YYYY/MM/DD',
//            locale: 'ja'
//        });
//        $(endwork).datetimepicker({
//            format: 'YYYY/MM/DD',
//            locale: 'ja',
//            useCurrent: false
//        });
//        
//        $(startwork).on("dp.change", function (e) {
//            $(endwork).data("DateTimePicker").minDate(e.date);
//        });
//        $(endwork).on("dp.change", function (e) {
//            $(startwork).data("DateTimePicker").maxDate(e.date);
//        });
//    }


    //Interview time table
    $('[name=noPossibleTime]').on('change',function(){
        $('#noPossibleTime_Hour').hide();
        $('.noPossibleTime_Hour').hide();
        $('.staffRegister').show();
        $('[name=appointment_time]').prop('disabled', 'disabled');
        if($(this).is(':checked')){
            $('.anotherInterview').each(function(){
                $(this).prop('checked', false);
            });
            $('.interview').each(function(){
                $(this).prop('checked', false);
            });
        }
    });

    $('.interview').on('change',function(){
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });
    $('.anotherInterview').on('change',function() {
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });

    if($('[name=bank_code]').val() != null) {
        var bankBranch = $('[name=branch]').val();
        getBranchList(bankBranch);
    }

    $('[name=bank_code]').on('change',function(){
        getBranchList(null);
    });
});

function getBranchList(bankBranch){

    branchCode = $('[name=branch_code]');
    if($('[name=bank_code]').val() != '') {
        branchCode.prop('disabled',false);
        $.ajax({
            type: "POST",
            url : SITE_ROOT + "/staff/bank_branch",
            data: {
                bankId : $('[name=bank_code]').val()
            },success: function(data) {
                branchCode.empty();
                $.each( data, function( key, branch ) {
                    var selected = '';
                    if(key == bankBranch){
                        selected = 'selected';
                    }
                    option = "<option "+selected+"value='"+key+"'>"+branch+"</option>"
                    branchCode.append(option);
                });
            }
        })
    } else {
        branchCode.prop('disabled', 'disabled');
        branchCode.empty();
    }
}
function staffRegister(){
    if($('[name=regionType]').val() == '1'){
        $('#interviewForm').submit();
    } else {
        if($('[name=noPossibleTime]').is(':checked')){
            $('#interviewForm').submit();
        } else {
            if ($('[name=anotherInterviewTime]').is(':checked')) {                
                $('.noPossibleTime_Hour').show();
                $('.staffRegister').hide();
                $('[name=appointment_time]').prop('disabled', false);
                $('[name=appointment_time]').focus();
            } else {
                $('[name=noPossibleTime]').prop('checked',true);
            }
        }
    }
}

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#profileImage').html("<img src="+e.target.result+" class='img-responsive img-circle'>");
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("input[name=image]").change(function () {
    readURL(this);
});


$('[name=region]').on('change',function(){
    if($(this).is(':checked')) {
        regionId = $(this).val()
        $.ajax({
            type: "POST",
            data: { regionId : regionId },
            url: SITE_ROOT + '/staff/interview_time',
            success: function(table){
                $('#interviewTime').html(table);
                $('#noPossibleTime').show().removeAttr('class','hidden');
                $('.noPossibleTime_Hour').hide();
                $('.staffRegister').show();
                $('[name=appointment_time]').prop('disabled','disabled');
            }
        });
    }
});
// select first region
$("input:radio[name=region]:first").click();
$("[name=region]").trigger('change');
$('#appointment_time_from').datetimepicker({

        format: 'HH:mm',
        locale: 'ja'
});
$('#appointment_time_to').datetimepicker({
    
        format: 'HH:mm',
        locale: 'ja'
});
 