<?php

return [

    //Staff Section
    'staff' => [
        'manage'  => 'Staff Management - JA',
        'new'     => 'Pre-Register New Staff - JA',
        'update'  => 'Update Pre-register Staff Profile - JA',
        'back'    => '戻る',
        'next'    => '次へ',
        'register'=> '登録',
        'pre-register' => [
            'policy' => 'は入力必須項目です。それ以外の項目は、必須ではありませんが、ご入力いただけますと、面接がスムーズです。
                            可能な限り、入力いただけますと幸いです',
            'finish' => '登録完了',
            'cancel' => 'キャンセル'
        ],

    ],

    'action' => [
        'accept'         => 'accept',
        'accept_content' => 'accept_content',
        'cancel'         => 'cancel',
        'return'         => 'return',
        'login'          => 'login',
        'upload'         => 'upload',
        'update'         => 'update',
        'registration'   => 'registration',
        'apply'          => 'Apply',
        'inquiry'        => 'Inquiry',
        'detail'         => 'Detail',
    ],

    'pre-register' => [
        'index'                 => '事前登録',
        'management'            => '事前登録-管理メニュー',
        'interview_schedule'    => '面接予定',
        'information_detail'    => '事前登録者情報-詳細',
        'pre-register_list'     => '事前登録者一覧',
        'interview_place'       => '東京・神奈川 面接枠管理',
        'interview_other_place' => 'その他」面接日登録',
        'edit'                  => '編集',
        'return'                => '戻る',
        'tokyo'                 => '東京',
        'kanagawa'              => '神奈川',
        'other'                 => 'その他',
        'time_out_hope'         => '時間外希望',
        //List
        'list'                  => '事前登録者一覧',
        'name'                  => '名前',
        'image'                 => '画像',
        'status'                => 'ステータス',
        //Detail
        'upload_resume'         => '履歴書pdf登録',
        'gender'                => '性別',
        'age'                   => '年齢',
        'update_by'             => '最終更新者',
        'male'                  => '男',
        'female'                => '女',
        'interviewer'           => '面接担当者',
        'interview_day'         => '面接日',
        'evaluation'            => '数値評価',
        'total_score'           => '総合点数',
        'rank'                  => 'ランク',
        'appearance'            => '身だしなみ',
        'attitude'              => '態度',
        'expression'            => '表情',
        'personality'           => '性格',
        'admin_sale_experience' => '事務・営業経験',
        'sale_experience'       => '販売経験',
        'being_late'            => '遅刻',
        'willing'               => '意欲',
        'corresponding'         => '組織対応力',
        'first_impression'      => '第一印象',
        'comment'               => '面接時コメント'
    ],
    'wanted-job'    => [
        'worklist'              => 'work list',
        'work_location'         => 'work location',
        'period'                => 'period',
        'over_view'             => 'over view',
        'help'                  => 'Date on which you want to apply, select the working time, please press the "apply" button.'
    ]

];