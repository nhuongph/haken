<?php

return [

    /*
    |--------------------------------------------------------------------------
    |--------------------------------------------------------------------------
    */
    'title' => [
        'add'=>'ブランド登録',
        'update'=>'ブランド編集',
        'list'=>'ブランド一覧'
        ],
    'header' => [
        'add'=>'ブランド登録',
        'update'=>'ブランド編集',
        'list'=>'ブランド一覧'
        ],
    'header-table' => [
        'note'=>'備考',//CM
        'manage-name'=>'管理名',
        'display-name'=>'表示名',
        'list-registration-date'=>'登録日',
        'list-management-name'=>'管理名',
        'list-display-name'=>'表示名',
        ],
    'button'=>[
        'list-setting-info-shop'=>'入店報告設定'
    ],
    ];
