<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'button' => [
        'register'=>'登録',
        'update'=>'更新',
        'cancel'=>'キャンセル',
        'next'=>'次へ',
        'back'=>'戻る',
        'save'=>'保存',
        'edit'=>'編集',
        'delete'=>'削除',
        'back-list-item'=>'一覧に戻る',
        'close'=>'閉じる',
        'search'=>'検索',
        'confirm' => '確定',
        'detail'=>'詳細',
        'add-new'=>'新規追加',
    ],

    'title' => [
        'first-name'=>'姓',
        'last-name'=>'名',
        'first-name-kana'=>'セイ',
        'last-name-kana'=>'メイ',
        'email'=>'email',
        'department-name'=>'部署名',
        'password'=>'パスワード',
        'phone' =>  'TEL'
    ],

    'days' => [
        'Mon'  => '月',
        "Tue"    => "火",
        "Wed"    => "水",
        "Thu"    => "木",
        "Fri"    => "金",
        "Sat"    => "土",
        "Sun"    => "日",
    ],

    'labels' => [
        'please_choose' => '選択してください。',
        'no_record'     => '検索結果が0件。'
    ]

];
