<?php

return [

    'header-detail'=>'取引先詳細',
    'header-update'=>'取引先更新',
    'header-add'=>'取引先登録',
    'header-list'=>'取引先一覧',

    'title'=>'取引先管理',

    //Title for add, edit, get
    'title-company'=>' 会社基本情報',

    //Common use add and edit
    'title-content'=>[
        'company-name'=>'会社名',
        'furigana-name'=>'フリガナ',
        'postal-code'=>'郵便番号',
        'prefectural-name'=>'都道府県',
        'municipal-name'=>'市区町村',
        'detail-address'=>'以降の住所',
        'tel'=>'TEL',
        'fax'=>'FAX',
        'head-office'=>'本社所在地',
        'capital-stock'=>'資本金',
        'employee-number'=>'従業員数',
        'ceo'=>'代表取締役',
        'responsible-person-name-haken'=>'派遣先責任者名',
        'responsible-person-position-haken'=>'派遣先責任者役職',
        'responsible-person-phone-number-haken'=>'派遣先責任者連絡先',
        'chain-command-name'=>'指揮命令者名',
        'chain-command-position'=>'指揮命令者役職',
        'chain-command-contact'=>'指揮命令者連絡先',
        'establishment-date'=>'設立年月日',
        'main-customer-bank'=>'主要取引先銀行',
        'lastyear-suppliers'=>'昨年度年商',
        'main-customer'=>'主要取引先',
        'basic-contract-date'=>'基本契約日',
        'company-memo'=>'会社メモ',
        'person-charge'=>'担当者',
        'department-name'=>'部署名',
        'offical-name'=>'正式名称/副部署',
    ],

    'content'=>[
        'main-bank'=>' 銀行',
        'money'=>' 万円'
    ],

    'radio'=>[
        'regular'=>'正',
        'deputy'=>'副',    
    ],

    'list'=>[
        'address'=>'住所',
        'pepresentativename'=>'代表者',
    ],
    ];
