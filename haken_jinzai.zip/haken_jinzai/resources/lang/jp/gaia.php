<?php

return [
    'common' => [
        'header' => [
            'proposal_detail'   => '案件詳細'
        ],

        'button' => [
            'wake-up_and_depature'      => '起床・出発',
            'basic_info'                => '基本情報',
            'provision'                 => '引き当て',
            'shift_confirmation'        => 'シフト確認',
            'prior_training'            => '事前研修',
            'message_transmission'      => 'メッセージ送信',
        ],

        'labels' => [
            'staff_service_events'      => 'A社　イベントスタッフ業務',
        ]
    ],
    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'register' => [
        'title-new'=>'新規管理スタッフ登録',
        'title-update'=>'ガイアメンバー情報更新',
        'title1'=>'ユーザーの基本情報を登録してください。',
        'title2'=>'付与する権限を選択してください。',
        'button'=>[
            'create'  => '新規作成',
        ],
    ],
    'list' => [
        'search'=>[
        'name'=>'名前から探す',
        'privilege'=>'権限で探す',        
        'department'  => '部署名で探す',
        ],
    ],

    'staffmessage'  => [
        'title' => [
            'message_transmission'  => 'メッセージ送信'
        ],

        'labels' => [
            'subject'               => '件名',
            'notify_of_staff'       => 'A社　イベントスタッフ業務　参加確定のお知らせ',
            'necessity_submiting'   => '送信要否',
            'block_name'            => 'ブロック名称',
            'transmission_tartget'  => '送信対象',
            'submit_content'        => '送信内容'
        ],

        'button' => [
            'transmission_history' => '送信履歴'
        ]
    ],

    'project' => [
        'labels' => [
            'start'             => '出発',
            'arrival'           => '到着',
            'open'              => '始業',
            'end_job'            => '終業',
            'job_report'        => '終業報告',
            'visiting_report'   => '入店報告'
        ]
    ]
];
