<?php

return [
    'Staff' => [
        'manage'    => 'Staff Management - JA',
        'new'       => 'Register New Staff - JA',
        'update'    => 'Update Staff - JA',
    ],

    // Message for error or notify
    'pre-register'	=> [
    	'delete_question'                   => "削除してよろしいでしょうか？",
    	'delete_another_interview_error' 	=> "面接希望の方が登録されています。面接希望者のキャンセル処理を行ってから、再度操作を行ってください。",
    	'delete_tokyo_kanagawa_error'		=> "面接希望の方が登録されています。面接希望者のキャンセル処理を行ってから、再度操作を行ってください。",
        'login_usertype_error'              => "事前登録者のみこの機能使用できます。",
        'login_info_wrong'                  => "メールまたはパスワードが間違っています。"
    ],

    // Message for error or notify in js
    'GaiA_Member'  => [
        'delete_success' => "削除成功しました。",
        'delete_fail'    => "削除失敗しました。",
        'no_data'        => "検索結果が0件。"
    ],
    'login'  => [
        'login_pre_regiter_error'           => "事前登録者は別のログインURLを使用お願い致します。",
        'login_info_wrong'                  => "メールまたはパスワードが間違っています。"
    ],
];