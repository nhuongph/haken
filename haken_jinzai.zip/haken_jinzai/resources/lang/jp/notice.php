<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */

    'title'=>'お知らせ管理',

    'label'=>[    
        'title'             => 'タイトル',
        'content'           => '本文',
        'publicdatetime'    => '公開日時',
        'author'=>'作成者',
        'updatedby'=>'最終更新',
    ],

    'list-notice' => [
        'title'=>'お知らせ一覧',
        'create'  => '新規作成',
    ],
    'add-notice' => [
        'title'=>'お知らせ　新規作成・編集時',
    ],
    'detail-notice' => [
        'title'=>'お知らせ詳細',
        'return-list'  => '一覧に戻る',
    ],
    ];
