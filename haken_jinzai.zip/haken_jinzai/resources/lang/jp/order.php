<?php
return [
	'title' => [
		'detail' 	=> '受注詳細',
		'new'	 	=> '新規登録'
	],

	'labels' => [
		'project_name'		=> '案件名称',
		'contractor'		=> '受注者',
		'order_date'		=> '受注日',
		'job_categrory'		=> '職種',
		'select_all'		=> '-- 選択してください --'
	],

	'button' => [
		'edit'				=> '編集',
		'list'				=> '受注一覧'
	],

	'header' => [
		'list'=>'受注一覧',	
		'order_detail' 	=> '受注詳細',
		'new_order'		=> '案件基本情報'
	]
];