<?php

return [

    /*
    |--------------------------------------------------------------------------
    | lbl: Label
    | tb: table
    |--------------------------------------------------------------------------
    */
    'new' => [
        'title'=>'事前登録',
        '1'=>"１ー",
        '2'=>"２ー",
        '3'=>"３ー",
        '4'=>"４ー",
        '5'=>"５ー",
        'interview-location'=>"希望面接会場",
        'interview-time'=>"希望面接時間"
        ],
    'manage' => [
        'title-menu'=>'事前登録',
        'interview'=>[
            'another-register-title'=>'その他　面接枠管理',
            'tokyo-register-title'=>'東京・神奈川　面接枠管理',
        ],
        ],
    'register-staff' => [
        'title'=>'誓約書',
        'oath'=>'内容に同意する',
        'not-oath'=>'内容に同意しない',
        ],
    'list'=>[
        'dll-select-interview-date'=>'-- インタビュー選択 --',
        'dll-select-status'=>'-- 状態選択 --',
        'lbl-title-search-interview-date'=>'面接日で絞り込む',
        'lbl-title-search-status'=>'ステータスで絞り込む',
        'lbl-title-search-name'=>'名前で検索',
        'lbl-tb-title-name'=>'スタッフ名',
        'lbl-tb-title-image'=> '本人画像登録',
        'lbl-tb-title-interview-day'=> '面接日',
        'lbl-tb-title-gender'=> '性別',
        'lbl-tb-title-age'=>'年齢',
        'lbl-tb-title-status'=>'ステータス',
    ]
    ];
