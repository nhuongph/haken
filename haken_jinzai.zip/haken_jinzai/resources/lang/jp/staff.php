<?php
return [
	//'staff' => [
	/**
     * Creator
     */
    'check-point' => [
    	'title'	 => [
            'schedule_check-point'      => '勤務管理画面',
            'reporting_for_schedule'    => '終業報告'
        ],

    	'header' => [
    		'notice_list'	            => 'お知らせ',
    		'task_list'		            => '担当業務',
            'reporting_for_schedule'    => '終業報告',
            'send_message'              => 'メッセージ送信'
    	],

        'labels' => [
            'all_notice'				=> 'お知らせ一覧へ',
            'basic_information'			=> '基本情報',
            'work_breaking_hours'   	=> '勤務時間休憩',
            'work_location'				=> '勤務地',
            'notices'					=> '特記事項',
            'emergency_contact'			=> '緊急連絡先',
            'contact_person'		 	=> '担当者',
            'have_no_task_today'		=> '本日、タスクがございません。',
            'schedule_of_week'			=> '週の予定',
            'expense_total'             => '経費合計',
            'expense_image'             => '経費画像',
            'is_used_break_time'        => '休憩時間は60分取得できましたか ?',
            'is_have_overtime'          => '残業・早出がありましたか ?',
            'yes'                       => 'はい　',
            'no'                        => 'いいえ',
            'note'                      => '備考',
            'circle'                    => '円',
            'task_note'					=> [
            	'line_1'	                        => '※電車遅延や体調不良等、問題が発生した場合は、電話かメッセージ送信ボタンでご連絡ください。',
            	'line_2'	                        => '※経費の申告漏れ等の修正は、「報告修正」ボタンより行ってください。-日の-時まで修正が可能です。',
                'only_one_image'                    => 'レシートが複数ある場合、まとめて撮影を行い、一枚の画像にしてください。',
                'if_no_please_input_in_comment_box' => 'いいえの場合、実際の休憩時間を備考欄に記入してください。',
                'if_have_please_input_in_comment_box' => 'はいの場合、発生したシフト外の勤務時間数と残業理由を備考欄に記入してください。'
            ]
        ],

        'button' => [
        	'report_notify'			=> '報告修正',
        	'message_transmission'	=> 'メッセージ送信',
        	'send'					=> '送信する',
        	'cancel'				=> '戻る',
            'transmission'          => '送信'
        ]
    ]
	//]
];