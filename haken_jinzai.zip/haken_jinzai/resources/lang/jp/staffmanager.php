<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    'introducejob' => [
        'title'=>'案件紹介メッセージ送信',
        'label'=>[    
            'title'             => 'タイトル',
            'content'           => '作成者',
            'publicdatetime'    => '公開日時'
        ],
        'button'=>[
        'create'  => '新規作成',
        ]
    ]
    ];
