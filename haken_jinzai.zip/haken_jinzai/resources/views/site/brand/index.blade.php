@extends('site/layouts/main')
@section('title')
{{ trans('brand.title.add') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/brand.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/brand_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{route('gaia/brand/list')}}">{{ trans('company.header-list') }}</a></li>
        <li class="active">{{ trans('brand.title.add') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting brand">
    <div class="col-lg-12 col-md-12">
        <div class="box box-info box-solid add">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('brand.header.add') }}</b></h4>
            </div>            
            <div class="box-body content">
                <div class="col-md-12 col-sm-12 col-sx-12">
                    @include('site/message/index')
                    <div class="layout-child-panel">
                        {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                        <table class="table table-responsive">
                            <tr>
                                <td>{{ trans('brand.header-table.manage-name') }}</td>
                                <td>{!! Form::text('ManagementName', $brand->ManagementName, ['class' => 'form-control']) !!}</td>
                            </tr>
                            <tr>
                                <td>{{ trans('brand.header-table.display-name') }}</td>
                                <td>{!! Form::text('DisplayName', $brand->DisplayName, ['class' => 'form-control']) !!}</td>
                            </tr>
                            <tr>
                                <td>{{ trans('brand.header-table.note') }}</td>
                                <td>{!! Form::text('Remarks', $brand->Remarks, ['class' => 'form-control']) !!}</td>
                            </tr>
                        </table>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                            <div class="button-group btn-button">
                                <button class="btn btn-primary button-submit">{{ trans('common.button.register') }}</button> 
                                <a href="{{route('gaia/brand/list')}}" class="btn btn-primary">{{ trans('common.button.cancel') }}</a>
                            </div>
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

