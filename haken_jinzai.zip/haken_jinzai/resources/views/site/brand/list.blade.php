@extends('site/layouts/main')
@section('title')
{{ trans('brand.title.list') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/brand.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/brand_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">{{ trans('brand.title.list') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting brand">
    <div class="col-lg-12 col-md-12">
        <div class="box box-info box-solid list">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('brand.header.list') }}</b></h4>
            </div>
            <div class="box-body content">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    @include('site/message/index')
                    <p class="text-right">
                        <a href="{{route('gaia/brand/add')}}" class="btn btn-primary">{{trans('common.button.add-new')}}</a>
                    </p>
                    <div class="layout-child-panel table-container">
                        {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                        <table class="table table-responsive table-bordered brand-list">
                            <thead>
                                <tr>
                                    <th>{{trans('brand.header-table.list-registration-date')}}</th>
                                    <th>{{trans('brand.header-table.list-management-name')}}</th>
                                    <th>{{trans('brand.header-table.list-display-name')}}</th>
                                    <th>{{trans('brand.header-table.note')}}</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <?php foreach($brandLists as $brandList){?>
                            <tr>
                               <td>
                                <?php 
                                $date=date_create($brandList->created_at);
                                echo date_format($date,"Y/m/d");
                                ?>   
                            </td>
                            <td><?php echo $brandList->ManagementName;?></td>
                            <td><?php echo $brandList->DisplayName;?></td>
                            <td><?php echo $brandList->Remarks;?></td>
                            <td class="action" style="width:300px;">
                                <div class="row text-center">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <a href="{{ route('gaia/brand/update', ['brandId'=>$brandList->id])}}" class="btn btn-primary btn-detail">{{trans('common.button.edit')}}</a>
                                        <a href="{{ route('gaia/brand/delete', ['brandId'=>$brandList->id])}}" class="btn btn-primary btn-delete">{{trans('common.button.delete')}}</a>                                    
                                    </div>
                                </div>
                                <div class="row text-center">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <a href="{{ route('report/index', ['brandId'=>$brandList->id])}}" class="btn btn-primary btn-setting-shop">{{trans('brand.button.list-setting-info-shop')}}</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php  } ?>

                    </table>


                    {!! Form::close() !!}

                </div>
            </div>
        </div>
    </div>
</div>

</div>

@endsection

