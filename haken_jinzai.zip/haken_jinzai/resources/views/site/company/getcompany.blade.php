@extends('site/layouts/main')
@section('title')
{{ trans('company.header-detail') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/company.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/company_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
	<h1><small></small></h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="{{route('listcompany')}}">{{ trans('company.header-list') }}</a></li>
		<li class="active">{{ trans('company.header-detail') }}</li>
	</ol>
</section>
@endsection
@section('content')
<form id="registercompany" method="POST"> 
	<div class="row text-setting company">
		<div class="col-lg-12 col-md-12">
			<div class="box box-info box-solid get">
				<div class="box-header with-border">
					<h4 class="text-title"><b>{{ trans('company.title') }}</b></h4>
				</div>
				<div class="box-body content">	
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-right">
							<a href="{{route('listcompany')}}" class="btn btn-primary">{{ trans('common.button.back-list-item') }}</a>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 text-title">
							{{$company->CompanyName}}{{trans('company.title-company')}}
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-right">
							<a href="{{route('editcompany', $company->CompanyId)}}" class="btn btn-primary">{{ trans('common.button.edit') }}</a>
							<a href="{{route('getdeletecompany', $company->CompanyId)}}" class="btn btn-primary">{{ trans('common.button.delete') }}</a>
						</div>
					</div>				
					@include('site.message.index')
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 layout-child-panel">
						<div class="row row-eq-height">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.company-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 col-sm-8 col-xs-8">{!! $company->CompanyName !!}</div>    
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.furigana-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->FuriganaName !!}</div>				
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.postal-code') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								{!! $company->PostalCode !!}
							</div>
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.prefectural-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->PrefecturalName !!}</div>			
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.municipal-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->MunicipalName !!}</div>			
						</div>				
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.detail-address') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->DetailAddress !!}</div>			
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.tel') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->PhoneNumber !!}</div>				
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.fax') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->FaxNumber !!}</div>				
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.head-office') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->HeadOffice !!}</div>				
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.capital-stock') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->CapitalStock !!}</div>				
						</div>			
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.employee-number') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->EmployeeNumber !!}</div>
						</div>						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.ceo') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->PepresentativeName !!}</div>
						</div>						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.responsible-person-name-haken') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ResponsiblePersonNameHaken !!}</div>			
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.responsible-person-position-haken') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ResponsiblePersonPositionHaken !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ">{{ trans('company.title-content.responsible-person-phone-number-haken') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ResponsiblePersonPhoneNumberHaken !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.chain-command-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ChainCommandName !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.chain-command-position') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ChainCommandPosition !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.chain-command-contact') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->ChainCommandPhoneNumber !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.establishment-date') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								{!! $subcompany->EstablishmentDate == "0000-00-00" ? " " : date('Y 年 m 月 d 日', strtotime($subcompany->EstablishmentDate)) !!}
							</div>
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.main-customer-bank') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->MainCustomerBank !!}{!! trans('company.content.main-bank') !!}</div>				
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.lastyear-suppliers') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->LastYearSuppliers !!}{{ trans('company.content.money') }}</div>
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.main-customer') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $subcompany->MainCustomer !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 ">{{ trans('company.title-content.basic-contract-date') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								{!! $company->ContractDate == "0000-00-00" ? " " : date('Y 年 m 月 d 日', strtotime($company->ContractDate)) !!}
							</div>
						</div>
						<div class="row">

							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.company-memo') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 white-space-setting">{{ $subcompany->CompanyMemo }}</div>	
						</div>				
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star">{{ trans('company.title-content.person-charge') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->PersonCharge !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.department-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{!! $company->DepartmentName !!}</div>	
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">{{ trans('company.title-content.offical-name') }}</div>
							<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
								{{ $subcompany->OfficialName == 1 ? trans('company.radio.regular'): trans('company.radio.deputy') }}
							</div>	
						</div>
					</div>		
				</div>
			</div>
		</div>
	</div>
	<input type="hidden" name="sections" id="sections" value="1">
	<input type="hidden" name="lstPaymentUpdate" id="lstPaymentUpdate" value="1,">
	<input type="hidden" name="_token" value="{{{ csrf_token() }}}" />
</form>
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/moment.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
<script type="text/javascript" src="{!! asset('js/site/gaia/company.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/ajax_zip3/ajax_zip3.min.js') !!}"></script>
@endsection