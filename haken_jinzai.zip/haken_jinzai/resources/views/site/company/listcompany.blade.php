@extends('site/layouts/main')
@section('title')
{{ trans('company.header-list') }}
@endsection
@section('page_css')
<link href="{!! asset('css/common/text.css') !!}" rel="stylesheet">
<link href="{!! asset('css/common/layout_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/company.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/company_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">{{ trans('company.header-list') }}</li>
</ol>
</section>
@endsection
@section('content')
{!! Form::open() !!}
<div class="row text-setting company">
    <div class="col-lg-12 col-md-12 list">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('company.title') }}</b></h4>
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12 pull-right">
                        <div class="input-group search pull-right">
                            {!! Form::text('searchCompany', null, ['class'=>'form-control', 'required' => 'required']) !!}
                            <span class="input-group-btn">
                                {!! Form::button('', ['id'=>'btSearch', 'class'=>'btn btn-default glyphicon glyphicon-search']) !!}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="row text-right">
                    <div class="col-md-12">
                        <a href="{!! route('addcompany') !!}" value="新規登録" class="btn btn-primary">
                            <span class="glyphicon glyphicon-pencil btn-add" aria-hidden="true"></span>新規登録</a>                
                        </div>
                    </div>
                    <div class="layout-child-panel">
                        <div class="content col-md-12 col-sm-12 col-xs-12 table-container">
                            @foreach($listcompany as $company)
                            <div class="col-md-12 col-sm-12 col-xs-12 info-box">
                                <div class="col-md-2 col-sm-2 col-xs-2 company-contact">
                                    <div class="text-truncate">{!! link_to_route('getcompany', $company->CompanyName, ['id'=>$company->CompanyId]) !!}</div>
                                    <div>{!! $company->PhoneNumber !!}</div>
                                </div>
                                <div class="col-md-10 col-sm-10 col-xs-10">
                                    <div class="col-md-3 col-sm-3 col-xs-3 official-name">
                                        {!! $company->OfficialName == 1 ? trans('company.radio.regular') :  trans('company.radio.deputy') !!}
                                    </div>
                                    <div class="col-md-5 col-sm-5 col-xs-5 company-detail">
                                        <div>{!! trans('company.list.address') !!}:{!! $company->PrefecturalName !!}{!! $company->MunicipalName !!}{!! $company->DetailAddress !!}</div>
                                        <div class="text-truncate">{!! trans('company.list.pepresentativename') !!}:{!! $company->PepresentativeName !!}</div>                            
                                    </div>
                                    <div class="col-md-3 col-sm-3 col-xs-3 contract-date margin-top-9">
                                        <div class="padding-top-8">{{ trans('company.title-content.basic-contract-date') }}</div>
                                        <div>{!! $company->ContractDate == "0000-00-00" ? " " : date('Y/m/d', strtotime($company->ContractDate)) !!}</div>
                                    </div>                        
                                    <div class="pull-right m-t-2">
                                        <button type="button" class="btn btn-primary btn-delete" value="{{$company->CompanyId}}" id="btn-delete">
                                            <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                                            {{ trans('common.button.delete') }}
                                        </button>
                                    </div>
                                </div>                    
                            </div>
                            @endforeach
                            <div class="pagination lst-company-paging"> {{ $listcompany->links() }} </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {!! Form::close() !!}
    @section('page_js')
    <script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
    <script type="text/javascript" src="{!! asset('js/site/gaia/company.js') !!}"></script>
    @endsection
    @endsection