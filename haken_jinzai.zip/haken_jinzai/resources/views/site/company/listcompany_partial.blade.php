@foreach($listcompany as $company)
<div class="col-md-12 col-sm-12 col-xs-12 info-box">
    <div class="col-md-2 col-sm-2 col-xs-2 company-contact">
        <div class="text-truncate">{!! link_to_route('editcompany', $company->CompanyName, ['id'=>$company->CompanyId]) !!}</div>
        <div>{!! $company->PhoneNumber !!}</div>
    </div>
    <div class="col-md-10 col-sm-10 col-xs-10">
        <div class="col-md-3 col-sm-3 col-xs-3 official-name">
            {!! $company->OfficialName == 1 ? trans('company.radio.regular') :  trans('company.radio.deputy') !!}
        </div>
        <div class="col-md-5 col-sm-5 col-xs-5 company-detail">
            <div>{!! trans('company.list.address') !!}:{!! $company->DetailAddress !!}</div>
            <div class="text-truncate">{!! trans('company.list.pepresentativename') !!}:{!! $company->PepresentativeName !!}</div>                            
        </div>
        <div class="col-md-3 col-sm-3 col-xs-3 contract-date margin-top-9">
            <div class="padding-top-8">{{ trans('company.title-content.basic-contract-date') }}</div>
            <div>{!! $company->ContractDate == "0000-00-00" ? " " : date('Y/m/d', strtotime($company->ContractDate)) !!}</div>
        </div>                        
        <div class="pull-right m-t-2">
            <button type="button" class="btn btn-primary btn-delete" value="{{$company->CompanyId}}" id="btn-delete">
                <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
                {{ trans('common.button.delete') }}
            </button>
        </div>
    </div>                    
</div>
@endforeach
<div class="pagination lst-company-paging"> {{ $listcompany->links() }} </div>
<script type="text/javascript" src="{!! asset('js/site/gaia/company.js') !!}"></script>