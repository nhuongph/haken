@extends('site/layouts/main')
@section('title')
{{ trans('title.confirmation.list') }}
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{route('gaia/management/member/menu')}}">{{ trans('gaiamanagement.title-menu') }}</a></li>
        <li class="active">{{ trans('title.confirmation.list') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting gaia">
    <div class="col-lg-12 col-md-12">
        <div class="box box-info box-solid add">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('title.confirmation.list') }}</b></h4>
            </div>          
            <div class="panel-body">
                <div class="col-md-12">
                    @include('site/message/index')
                    <div class="basic-form col-md-10 col-md-offset-1">

                        {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal  padding-top-10 padding-bottom-10', 'method' => 'GET']) !!}

                        <div class="form-group">
                            <div class="col-md-3">操作時刻で探す</div>
                            <div class="col-md-9 nonePaddingLeft">
                                <div class="col-md-5">
                                    <div class='input-group date' id='datetimepicker' >
                                        {!! Form::text('dateFrom', Session::get('dateFrom'), ['class' => 'form-control']) !!}
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-2 text-center float-left"> 〜 </div>
                                <div class="col-md-5">
                                    <div class='input-group date' id='datetimepicker1' >
                                        {!! Form::text('dateTo', Session::get('dateTo'), ['class' => 'form-control']) !!}
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-3">実行者で探す</div>
                            <div class="col-md-9 nonePaddingLeft">  
                                <div class="col-md-5">
                                    {!! Form::select('Operator', $operator, Session::get('operator'), ['class' => 'form-control']) !!}	
                                </div>
                            </div>
                        </div>                                    
                        <div class="form-group">
                            <div class="col-md-3">対象で探す</div>
                            <div class="col-md-9 nonePaddingLeft">
                                <div class="col-md-5">
                                    {!! Form::select('Object', $object, Session::get('object'), ['class' => 'form-control']) !!}	
                                </div>                                            
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-3">種別で探す</div>
                            <div class="col-md-9 nonePaddingLeft">
                                <div class="col-md-5">
                                    {!! Form::select('OpnType', $opnType, Session::get('opnType'), ['class' => 'form-control']) !!}
                                </div>
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <button class="btn btn-default btn-lg button-submit" >検索実行</button>
                        </div>
                        {!! Form::close() !!}                            
                    </div>
                    <div class="serach-lisst-confirmation-history">
                        <table class="table table-responsive table-bordered col-md-11">
                            <tr>
                                <td>操作時刻</td>
                                <td>実行者</td>
                                <td>対象</td>
                                <td>対象詳細</td>
                                <td>種別</td>
                                <td>項目名</td>
                            </tr>
                            <?php foreach ($confirmations as $confirmation) {
                                ?>
                                <tr>
                                    <td><?php echo $confirmation->OpnTime ;?></td>
                                    <td><?php echo $confirmation->Operator ;?></td>
                                    <td><?php echo $confirmation->Object ;?></td>
                                    <td><?php echo $confirmation->ObjectDetail ;?></td>
                                    <td><?php echo $confirmation->OpnType ;?></td>
                                    <td><?php echo $confirmation->ItemName ;?></td>
                                </tr>

                                <?php } ?>                                      
                            </table>
                            {!! $confirmations->appends(Request::only(['dateFrom','dateTo','Operator','Object','OpnType']))->render() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('page_js')
<script src="{{ asset('plugins/bootstrap/js/moment.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') }}"></script>
<script type="text/javascript">
 $(function () {
  $('#datetimepicker').datetimepicker({
   format: 'YYYY/MM/DD'
});
  $('#datetimepicker1').datetimepicker({
     format: 'YYYY/MM/DD'
 });
});
</script>
<!--<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
<script src="{{ asset('js/site/user/order.create.js') }}"></script>-->
@endsection