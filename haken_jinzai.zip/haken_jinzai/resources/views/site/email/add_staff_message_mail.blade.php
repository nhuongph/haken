{{ $project_name }}<br>
{{ $staff_name }}からメッセージが届きました。<br>
<br>
<pre>{{ $message_detail }}</pre>
<br>
<br>
メッセージに返信する<br>
{{ url('staff/manage/check-point/message/') }}/{{ $message_id }}<br>
<br>
案件詳細<br>
{{ url('user/project/detail/')}}/{{ $project_id }}<br>
<br>
-------------------<br>
このメールはシステムより自動配信されています。<br>
返信は受付できませんので、ご了承ください。<br>