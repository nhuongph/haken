@extends('site/layouts/main')
@section('title')
{{ trans('title.GaiA.GaiA_member_detail') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/gaiamanage.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/gaiamanage_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{route('gaia/management/member/menu')}}">{{ trans('gaiamanagement.title-menu') }}</a></li>
        <li class="active">{{ trans('gaiamanagement.title-view') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting gaia-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box box-info box-solid add">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('gaiamanagement.title-view') }}</b></h4>
            </div>
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="basic-form">
                        <div class="col-md-12 col-xs-12 text-right">
                            @if(!empty($user))
                            <a href="{{ route('registerpersonnel/getupdateregisterpersonal', ['userId'=>$user->id]) }}" class="btn btn-primary btn-lg">{{ trans('title.user.basic_register.action.edit') }}</a>
                            @endif
                            <a href="{{ route('listGaiAMember') }}" class="btn btn-primary btn-lg">{{ trans('title.action.return') }}</a>
                        </div>
                        <div class="col-md-12 col-xs-12">
                            &nbsp;
                        </div>
                        <div class="col-md-12 col-xs-12">
                            @include('site/message/index')
                        </div>
                        @if(!empty($user))
                        {!! Form::open(['id'=> 'registercompany', 'class' => 'form-horizontal']) !!}                        	  
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="col-md-1"></div>                            
                            <div class="col-md-11">
                                <h4>{{ Form::label('title',\Lang::get('gaia.register.title1'),['class'=>'reg-title']) }}</h4>
                            </div>
                        </div>
                        <div class="layout-child-panel reg-content col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('common.title.first-name') !!}</b></div>
                                <div class="col-md-3">{!! $user->Firstname!!}</div>
                                <div class="col-md-2"><b>{!! trans('common.title.last-name') !!}</b></div>
                                <div class="col-md-3">{!! $user->Lastname !!}</div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('common.title.first-name-kana') !!}</b></div>
                                <div class="col-md-3">{!! $user->Firstname_Kana !!}</div>
                                <div class="col-md-2"><b>{!! trans('common.title.last-name-kana') !!}</b></div>
                                <div class="col-md-3">{!! $user->Lastname_Kana !!}</div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('common.title.email') !!}</b></div>
                                <div class="col-md-8 email-validation" >{!! $user->email !!}</div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('common.title.phone') !!}</b></div>
                                <div class="col-md-8 email-validation" >{!! $user->phone !!}</div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('common.title.department-name') !!}</b></div>
                                <div class="col-md-8" >
                                    {!! $user->Part !!}		
                                </div>
                            </div>
                            <div class="form-group"> 
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b>{!! trans('gaia.register.title2') !!}</b></div>
                                <div class="col-md-8" >
                                    {!! $user->display_name !!}
                                </div>
                            </div>            
                            <div class="form-group text-center">
                                &nbsp;
                            </div>  
                        </div>
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="col-md-1"></div>
                            <div class="col-md-11">
                                <h4>{{ Form::label('title',\Lang::get('title.gaia_1.title'),['class'=>'reg-title']) }}</h4>
                            </div>
                        </div>
                        <div class="col-md-10 col-xs-10 col-md-offset-1 col-xs-offset-1">
                            <table class="table table-bordered">
                                @foreach($role as $key=>$value)
                                <tr>
                                    <td class="col-md-1 ">
                                        {!! Form::checkbox('roleid[]', $value->id,in_array($value->id, $role_user),['class'=>'roleid', 'disabled'=>'']) !!}
                                    </td>
                                    <td class="col-md-5 ">
                                        {{ $value->display_name }}							
                                    </td>
                                    <td class="col-md-5 ">
                                        <?php $tit = 'title.gaia_1.role_' . (string) $key ?>
                                        {!! trans($tit) !!}
                                    </td>
                                </tr>
                                @endforeach
                            </table>
                        </div>         
                        <div class="form-group text-center">
                            &nbsp;
                        </div> 
                        {!! Form::close() !!}
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
