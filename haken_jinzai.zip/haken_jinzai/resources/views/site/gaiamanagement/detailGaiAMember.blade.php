@extends('site/layouts/main')
@section('title')
{{ trans('title.GaiA.GaiA_member_detail') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/gaiamanage.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/gaiamanage_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
<div class="row text-setting gaia">
	<div class="col-lg-12 col-md-12 gaia-manage">
		<div class="panel panel-default register">
			<div class="panel-body layout-border">
				<div class="col-md-12 col-sm-12 col-sm-12 col-xs-12">
					<div class="basic-form">
						<div class="row">
							<!-- <div class="col-md-8"></div> -->
							<div class="col-md-9 pull-right">
								<a href="{{ route('registerpersonnel/getupdateregisterpersonal', ['userId'=>$user->id]) }}" class="btn btn-primary btn-lg">{{ trans('title.user.basic_register.action.edit') }}</a>

								<a href="{{ route('listGaiAMember') }}" class="btn btn-primary btn-lg">{{ trans('title.action.return') }}</a>
							</div>
						</div>   
						<br> 
						<div class="reg-title">{!! trans('title.GaiA.user_basic_info') !!}</div>        	  
						<div class="layout-child-panel reg-content">
							<div class="row">
								<div class="col-md-2">{{ trans('title.pre-register.first_name') }}</div>
								<div class="col-md-3">
									{!! Form::label($user->Firstname, null, ['class'=>'control-label']) !!}
								</div>
								<div class="col-md-2">{{ trans('title.pre-register.last_name') }}</div>
								<div class="col-md-3">
									{!! Form::label($user->Lastname, null, ['class'=>'control-label']) !!}
								</div>	          
							</div>
							<div class="row">
								<div class="col-md-2">{{ trans('title.pre-register.first_name_furigana') }}</div>
								<div class="col-md-3">
									{!! Form::label($user->Firstname_Kana, null, ['class'=>'control-label']) !!}
								</div>
								<div class="col-md-2">{{ trans('title.pre-register.last_name_furigana') }}</div>
								<div class="col-md-3">
									{!! Form::label($user->Lastname_Kana, null, ['class'=>'control-label']) !!}
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">{{ trans('title.GaiA.email') }}</div>
								<div class="col-md-8 col-sm-8 col-xs-8" >
								{!! $user->email !!}
									<!-- {!! Form::label($user->email, null, ['class'=>'control-label']) !!} -->
								
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">{{ trans('title.GaiA.department_name') }}</div>
								<div class="col-md-8" >
									{!! Form::label($user->Part, null, ['class'=>'control-label']) !!}
								</div>
							</div>	
						</div>
						<div class="reg-title">{!! trans('title.GaiA.user_authority') !!}</div>
						<div class="layout-child-panel reg-content">
							@foreach($role as $roles)
								<div class="row">
									<div class="col-md-2">
										@if(count($role_user) > 0)	                	
											@if(in_array($roles->id,$role_user)) 
												{{ Form::checkbox('roleid[]', $roles->id, true,array('disabled')) }}
											@else
												{{ Form::checkbox('roleid[]', $roles->id, false,array('disabled')) }}
											@endif
										@else
											{{ Form::checkbox('roleid[]', $roles->id, false,array('disabled')) }}		
										@endif

									</div>		        
									<div class="col-md-8">
										{{$roles->display_name}}
									</div>
								</div>
							@endforeach
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
