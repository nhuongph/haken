@extends('site/layouts/main')
@section('title')
{{ trans('gaiamanagement.title-list') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/gaiamanage.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/gaiamanage_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="{{route('gaia/management/member/menu')}}">{{ trans('gaiamanagement.title-menu') }}</a></li>
        <li class="active">{{ trans('gaiamanagement.title-list') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting gaia-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box box-info box-solid list">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('gaiamanagement.title-list') }}</b></h4>
            </div>        
            <div class="box-body">
                <div class="layout-child-panel">
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8" >
                            <a href="{{ route('gaia/management/member/menu') }}" class="btn btn-primary btn-lg pull-right">{{ trans('title.action.return') }}</a>
                        </div>   
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8 alert" style="margin-left:15px;margin-right:30px;"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">{!! trans('gaia.list.search.name') !!}</div>       
                        <div class="col-md-8">
                            <div class="input-group">
                                {!! Form::text('userName', null, ['class'=>'form-control']) !!}
                                <span class="input-group-btn">
                                    {!! Form::button('', ['id'=>'btSearchUser', 'class'=>'btn btn-default glyphicon glyphicon-search']) !!}
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">{!! trans('gaia.list.search.privilege') !!}</div>       
                        <div class="col-md-8">{!! Form::select('roleInfoArr',$roleInfoArr,null, ['class' => 'form-control','id'=>'roleId']) !!}</div>
                    </div>
                    <div class="row">
                        <div class="col-md-2">{!! trans('gaia.list.search.department') !!}</div>       
                        <div class="col-md-8">{!! Form::select('partInfoArr',$partInfoArr,null, ['class' => 'form-control','id'=>'partId']) !!}</div>
                    </div>                
                    <div class="row">
                        <div class="col-md-2"></div>       
                        <div class="col-md-8"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-2 col-md-2">
                        </div>
                        <div class="col-lg-8 col-md-8">
                            <div id="GaiAUserList_section">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@stop
@section('page_js')
<script src="{{ asset('js/site/GaiAUser/GaiAUser.js') }}"></script>
@stop