
<table id="GaiAUserList" class="table table-bordered table-responsive">
	<thead>
		<tr>
			<th width="20%" class="text-center">{{ trans('title.GaiA.name') }}</th>
			<th width="30%" class="text-center">{{trans('title.GaiA.authority')}}</th>
			<th width="15%" class="text-center">{{trans('title.GaiA.department')}}</th>
			<th class="text-center"></th>
		</tr>
	</thead>
	@if($message =="")                               
		@foreach($listGaiaMember as $gaiaMember)
		<tr>
			<td class="text-center">{{ $gaiaMember->Firstname .' '. $gaiaMember->Lastname }}</td>                                    
			<td class="text-center">
				<?php $roleName = $userBusiness->getRoleNameByUserId($gaiaMember->id); ?>     

				@if(count($roleName) > 0)
				@foreach($roleName as $name)
				{{ $name }} <br>
				@endforeach
				@endif                                        
			</td>
			<td class="text-center">{{ $gaiaMember->Part }}</td>
			<td class="text-center">
				<div class="button-group text-center">
					<a href="{{ route('employee/detail', ['userId'=>$gaiaMember->id]) }}" class="btn btn-primary btn-lg">{{ trans('title.action.detail') }}</a>
					<a href="javascript: void(0)" class="btn btn-primary btn-lg delete-btn" data-id="{!! $gaiaMember->id !!}">{{ trans('title.action.delete') }}</a>
				</div>
			</td>
		</tr>
		@endforeach
	@else
		<tr>
			<td colspan="4" class="text-center">{{$message}}</td>
		</tr>
	@endif
</table>
{{ $listGaiaMember->links() }}