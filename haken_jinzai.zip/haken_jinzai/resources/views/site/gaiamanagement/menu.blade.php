@extends('site/layouts/main')
@section('title')
{{ trans('gaiamanagement.title-menu') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/gaiamanage.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/gaiamanage_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">{{ trans('gaiamanagement.title-menu') }}</li>
    </ol>
</section>
@endsection
@section('content')
<div class="row text-setting gaia">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 menu">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('gaiamanagement.title-menu') }}</b></h4>
            </div>
            <div class="box-body menu-item">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    @include('site.message.index')
                    <div class="form-group">
                        <div class="button-group text-center">
                            <div>
                                <a href="{{ route('registerpersonnel/getnewregisterpersonal') }}" class="btn btn-lg btn-primary btn-management">{{ trans('title.gaia.new') }}</a>
                            </div>
                            <div>
                            <a href="{{ route('listGaiAMember') }}" class="btn btn-lg btn-primary btn-management">{{ trans('title.gaia.list') }}</a>
                            </div>
                            <div>
                                <a href="/gaia/management/history/list" class="btn btn-lg btn-primary btn-management">{{ trans('title.gaia.operationhistory') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection