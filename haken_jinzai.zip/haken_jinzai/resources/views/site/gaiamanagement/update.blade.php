@extends('site/layouts/main')

@section('title')
{{ trans('gaia.register.title-update') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/gaiamanage.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/gaiamanage_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
<br>
<div class="row text-setting gaia-manage">
	<div class="panel panel-default register">
		<div class="panel-heading layout-bg-title">
			<div class="row">
				<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
					<h4 class="text-title"><b></b></h4>
				</div>
			</div>
		</div> 
		<div class="panel-body layout-border">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				@include('site/message/index')
				<div class="basic-form">
					{!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}                        	  
					<span class="reg-title">{!! trans('gaia.register.title1') !!}</span>
					<div class="layout-child-panel reg-content">
						<div class="row">
							<div class="col-md-2">{!! trans('common.title.first-name') !!}</div>
							<div class="col-md-3">{!! Form::text('firstname',$gaia->Firstname, ['class'=>'form-control']) !!}</div>
							<div class="col-md-2">{!! trans('common.title.last-name') !!}</div>
							<div class="col-md-3">{!! Form::text('lastname', $gaia->Lastname, ['class'=>'form-control']) !!}</div>
						</div>
						<div class="row">
							<div class="col-md-2">{!! trans('common.title.first-name-kana') !!}</div>
							<div class="col-md-3">{!! Form::text('firstname_kana', $gaia->Firstname_Kana, ['class'=>'form-control']) !!}</div>
							<div class="col-md-2">{!! trans('common.title.last-name-kana') !!}</div>
							<div class="col-md-3">{!! Form::text('lastname_kana', $gaia->Lastname_Kana, ['class'=>'form-control']) !!}</div>
						</div>
						<div class="row">
							<div class="col-md-2">{!! trans('common.title.email') !!}</div>
							<div class="col-md-8" >{!! Form::text('email', $user->email, ['class'=>'form-control']) !!}</div>							
						</div>
						<div class="row">
							<div class="col-md-2">{!! trans('common.title.password') !!}</div>
							<div class="col-md-8" >
								{!! Form::password('password',['class'=>'form-control']) !!}		
							</div>						
						</div>
						<div class="row">
							<div class="col-md-2">{!! trans('common.title.department-name') !!}</div>
							<div class="col-md-8" >
								{!! Form::text('part', $gaia->Part, ['class'=>'form-control']) !!}		
							</div>
						</div>
					</div>
					<div class="reg-title">{!! trans('gaia.register.title2') !!}</div>
					<div class="layout-child-panel reg-chk">
						@foreach($role as $roles)
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-10">
										@if(count($role_user) > 0)	                	
										<input type="checkbox" name="roleid[]"  value="{{ $roles->id }}" @if(in_array($roles->id,$role_user)) 
										{{ 'checked' }}
										@endif/>
										@else
										{!! Form::checkbox('roleid[]', $roles->id) !!}		
										@endif
										{{$roles->display_name}}								
							</div>
						</div>
						@endforeach						
					</div>
					<div class="button-group btn-button text-center">
						<button class="btn btn-primary btn-lg">{!! trans('common.button.update') !!}</button> 
						<a href="{{ route('employee/detail', ['userId'=>$user->id]) }}" class="btn btn-primary btn-lg">{{ trans('common.button.cancel') }}</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
@section('page_js')
<!-- <script src="{{ asset('js/site/staff.js') }}"></script> -->
@endsection
