<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{!! csrf_token() !!}">

    <!-- Favicon-->
    <link rel="shortcut icon" href="{{ asset('img/icons/favicon.ico') }}" type="image/x-icon">

    <!-- Web Fonts-->
    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css"> -->

    <!-- Vendor CSS-->
    <link href="{{ asset('plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- <link href="{{ asset('plugins/sb-admin/css/sb-admin-2.css') }}" rel="stylesheet"> -->
    <link href="{{ asset('plugins/admin-lte/css/AdminLTE.css') }}" rel="stylesheet">
    <link href="{{ asset('plugins/admin-lte/css/skins/_all-skins.min.css') }}" rel="stylesheet">
    <link href="{{ asset('plugins/sb-admin/css/timeline.css') }}" rel="stylesheet">

    <!-- Custom Css -->
    <link href="{{ asset('css/site/style.css') }}" rel="stylesheet">
    <!-- Font-awesome -->
    <link href="{{ asset('plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('plugins/metisMenu/dist/metisMenu.min.css') }}" rel="stylesheet">
    <!-- <link href="{{ asset('css/site/menu/menu.css') }}" rel="stylesheet"> -->

    <!-- DataTable Css -->
    <link href="{{ asset('plugins/datatables/media/css/jquery.dataTables.min.css') }}" rel="stylesheet" type="text/css"/>
    <!-- Calendar Css -->
    <link href="{{ asset('css/site/bootstrap-datetimepicker.css') }}" rel="stylesheet" type="text/css"/>
    <!-- Common Css -->
    <link href="{!! asset('css/common/text.css') !!}" rel="stylesheet" type="text/css">
    <link href="{{ asset('css/common/layout.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('css/common/layout_responsive.css') }}" rel="stylesheet" type="text/css"/>    
    <!-- Include Css -->
    @yield('page_css')

    <script type="text/javascript" src="{{ asset('plugins/jquery/jQuery-2.2.0.min.js') }}"></script>    
    <script type="text/javascript" src="{{ asset('js/site/main.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/common/msg.jp.js') }}"></script>
    <!-- Inlcude common func js -->
    <script type="text/javascript" src="{{ asset('js/common/func/URLCommon.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/common/func/StringCommon.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/common/func/DateCommon.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/common/func/EventCommon.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/common/func/LoadingEventCommon.js') }}"></script>
    <script>
        var SITE_ROOT = "{{ route('home') }}"
    </script>
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!-- WARNING: Respond.js doesn't work if you view the page via file://-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')
    script(src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js')
    -->
</head>
<body class="skin-blue sidebar-mini wysihtml5-supported">
<div class="wrapper">
    <header class="main-header">
        @include('site/layouts/header')
    </header>
    <aside class="main-sidebar">
        @include('site/layouts/main-sidebar')
    </aside>
    
    <div class="content-wrapper">
        @yield('breadcrumb')
        <section class="content">
        @yield('content')
        </section>
    </div>

</div>

<!-- Vendor jQuery-->

<!-- Metis Menu Plugin JavaScript -->
<!-- <script src="{{ asset('plugins/metisMenu/dist/metisMenu.min.js') }}"></script> -->

<!-- Main JS -->
<!-- <script src="{{ asset('plugins/sb-admin/js/sb-admin-2.js') }}"></script> -->
<script src="{{ asset('plugins/datatables/media/js/jquery.dataTables.js') }}"></script>
<script src="{{ asset('plugins/bootbox/bootbox.min.js') }}"></script>


<script type="text/javascript" src="{{ asset('plugins/slimScroll/jquery.slimscroll.min.js') }}"></script>
<!-- Bootstrap WYSIHTML5 -->
<script type="text/javascript" src="{{ asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js') }}"></script>
<!-- AdminLTE App -->
<script type="text/javascript" src="{{ asset('plugins/admin-lte/js/app.min.js') }}"></script>

<!-- Custom Theme JavaScript -->
<script type="text/javascript" src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}"></script>
<!-- Include JS -->
<script type="text/javascript" src="{{ asset('js/common/func/moment-with-locales.js') }}"></script>
@yield('page_js')
</body>

