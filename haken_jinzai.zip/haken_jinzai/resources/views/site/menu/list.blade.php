@extends('site/layouts/main')

@section('title')
{{ trans('title.report.index') }}
@endsection



@section('content')
<div class="row">
</div>
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="panel panel-default" style="margin-top:20px;">
            <div class="panel-heading panel-heading-rules">
                ブランド登録   
            </div>
            <div class="panel-body">
                <div class="col-md-12 col-sm-12">
                    @include('site/message/index')
                    <div class="basic-form">

                        <div class="box-menu-list">
                          <div class="box-1-list">
                             <div class="btn-logo-default-box-1">
                                ロゴ
                            </div>
                            <div  class="col-md-2 btn-logo-default">
                                MENU
                            </div>
                        </div>

                        <div class="box-2-list">
                         <div class="btn-logo-default">
                            日報
                        </div>
                        <div  class="btn-logo-default">
                            メッセージ
                        </div>
                        <div  class="btn-logo-default">
                            仕事に応募 登録管理
                        </div>
                        <div class="btn-logo-default">
                            <?php  $id = auth()->guard('admin')->user()->id;?>
                            <a href="/staff/info/<?php echo $id ?>">登録情報 確認</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

@endsection

