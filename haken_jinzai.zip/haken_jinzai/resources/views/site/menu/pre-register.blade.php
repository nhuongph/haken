<div class="row">
    <div class="col-md-3"><h3>
        {{$order->EmploymentDestinationIdCompany->CompanyName }}
        {{' ' .$order->ProjectName }}
        </h3></div>
    <div class="col-md-9">
    </div>
</div>

<div class="btn-group" role="group">
    <a href="{!! URL::to('/user/project/detail',[$order->ProJectBasicInfo->BasicInfoID]) !!}" class="btn btn-default btn-lg {{Menu::areActiveRoutes(['basic_registration_detail'],'btn-info')}}">{!! trans('gaia.common.button.basic_info') !!}</a>
    <a href="{!! URL::to('/shift-plan/view',[$order->OrderId]) !!}" class="btn btn-default btn-lg {{Menu::areActiveRoutes(['shift-plan/view','shift-plan/update'],'btn-info')}}">{!! trans('gaia.common.button.provision') !!}</a>
    <a href="{!! URL::to('/shift-plan/work-schedule',[$order->OrderId]) !!}" class="btn btn-default btn-lg {{Menu::areActiveRoutes(['shift-plan/work-schedule'],'btn-info')}}">{!! trans('gaia.common.button.shift_confirmation') !!}</a>
    <a href="{!! URL::to('#') !!}" class="btn btn-default btn-lg">{!! trans('gaia.common.button.prior_training') !!}</a>
    <a href="{!! URL::to('/user/message/setting', [$order->OrderId]) !!}" class="btn btn-default btn-lg {{Menu::areActiveRoutes(['message_setting'],'btn-info')}}">{!! trans('gaia.common.button.message_transmission') !!}</a>
    <a href="{!! URL::to('/user/project/departure/add',[$order->OrderId]) !!}" class="btn btn-default btn-lg {{Menu::areActiveRoutes(['departure/add'],'btn-info')}}">{!! trans('gaia.common.button.wake-up_and_depature') !!}</a>
</div>
<hr/>
