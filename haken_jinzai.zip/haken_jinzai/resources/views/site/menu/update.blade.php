@extends('site/layouts/main')

@section('title')
{{ trans('title.report.index') }}
@endsection



@section('content')
    <div class="row">
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                    
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        @include('site/message/index')
                         <div class="basic-form">
                            {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                            	<div class="menu-update-user">
                                    <div class="update-pw-return col-md-2">
                                        <a href="/staff/info/<?php echo $user->id;?>">戻る</a></div>
                                    <div class="col-md-12 menu-update-user-bottom">
                                    	変更が必要な箇所を指定してください
                                    </div>
                                
                                    <div class="col-md-12 menu-update-user-bottom">
                                    	<select name="selectbox" class="form-control">
                                    		 <option class="form-control" value="郵便番号、住所、最寄駅">郵便番号、住所、最寄駅</option>
                                    		 <option class="form-control" value="姓">姓</option>
                                    		 <option class="form-control" value="電話番号、携帯電話番号、FAX番号">電話番号、携帯電話番号、FAX番号</option>
                                    		 <option class="form-control" value="email">email</option>
                                    		 <option class="form-control" value="パスワード">パスワード</option>
                                    	</select>
                                    </div>
                                    
                                   	<div class="col-md-12 menu-update-user-bottom">
                                   			変更する内容を記載してください。
                                   	</div>

                                   	<div class="col-md-12 menu-update-user-bottom">
                                   		<input type="text" name="password" class="form-control">
                                   	</div>
                                
                                
                                
		                            <div class="button-submit col-md-12">
		                            	<button class="btn btn-default btn-lg">変更申請</button>
		                            </div>
                                </div>
                           {!! Form::close() !!}

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

