@if(session()->has('errors'))
    <div class="alert alert-danger" role="alert" >
        @foreach($errors as $error)
            <p>{{ $error }}</p>
        @endforeach
    </div>
@endif

@if(session()->has('success'))
    <div class="alert alert-success" role="alert" >
        @foreach(session()->get('success') as $message)
            <p>{{ $message }}</p>
        @endforeach
    </div>
@endif