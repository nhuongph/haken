@extends('site/layouts/main')
@section('title')
{!! trans('notice.add-notice.title') !!}
@endsection
@section('page_css')
<link href="{!! asset('css/common/text.css') !!}" rel="stylesheet">
<link href="{!! asset('css/common/layout_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
<br>
{!! Form::open(['id'=>'addnotice', 'class'=>'form-horizontal']) !!}
<div class="row text-setting notice">
    <div class="panel panel-default add">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                    <h4 class="text-title"><b>{!! trans('notice.title') !!}</b></h4>
                </div>
            </div>
        </div>        
        <div class="panel-body layout-border">  
            @include('site.message.index')
            <div class="row">
                <button type="submit" id='btedit' class='btn btn-primary'>{!! trans('common.button.save') !!}</button>
                <a href="{!! route('notice/listnotice') !!}" class='btn btn-primary'>{!! trans('common.button.cancel') !!}</a>
            </div>            
            <div class="border-content">
                <div class="row">
                    <div class="col-md-4 text-header text-right">{!! trans('notice.label.title') !!}</div>
                    <div class="col-md-8">{!! Form::text('title', null, ['class'=>'form-control control-width']) !!}</div>
                </div>
                <div class="row">
                    <div class="col-md-4 text-header text-right">{!! trans('notice.label.content') !!}</div>
                    <div class="col-md-8">{!! Form::textarea('content', null, ['class' => 'form-control control-width']) !!}</div>
                </div>            
                <div class="row">
                    <div class="col-md-4 text-header text-right">{!! trans('notice.label.publicdatetime') !!}</div>
                    <div class="col-md-8">
                        <div class="form-group">
                            <div class='input-group date' id='datetimepicker_settinginterview'>
                                {!! Form::text('publicdate', null, ['class'=>'form-control border-control-timepicker']) !!}
                                <span class="input-group-addon border-control-timepicker">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>  
                        </div>                              
                        <div class="form-group">
                            <div class='input-group date' id='publicdatetimepicker'>
                                {!! Form::text('publichour', null, ['class'=>'form-control border-control-timepicker']) !!}
                                <span class="input-group-addon border-control-timepicker">
                                    <span class="glyphicon glyphicon-time"></span>
                                </span>
                            </div>
                        </div>                  
                    </div>
                </div>               
            </div>
        </div>
    </div>
</div>
{!! Form::close() !!}
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/moment.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script type="text/javascript" src="{!! asset('js/site/notice/notice.js')!!}"></script>
@endsection