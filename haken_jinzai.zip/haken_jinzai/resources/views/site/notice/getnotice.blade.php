@extends('site/layouts/main')
@section('title')
{!! trans('notice.detail-notice.title') !!}
@endsection
@section('page_css')
<link href="{!! asset('css/common/text.css') !!}" rel="stylesheet">
<link href="{!! asset('css/common/layout_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
{!! Form::open(['id'=>'addnotice', 'class'=>'form-horizontal']) !!}
<br>
<div class="row text-setting notice">
    <div class="panel panel-default get">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-8 col-md-8 col-sm-8 col-xs-8'>
                    <h4 class="text-title"><b>{!! trans('notice.title') !!}</b></h4>
                </div>
            </div>          
        </div>      
        <div class="panel-body layout-border">  
            @include('site.message.index')
            <div class="row">
                <a href="{!! route('notice/listnotice') !!}" class="btn btn-primary pull-right">{!! trans('notice.detail-notice.return-list') !!}</a>
            </div>
            <div class="row">
                <a href="{!! URL::route('editnotice', [$notice->NoticeId]) !!}" class="btn btn-primary">{!! trans('common.button.edit') !!}</a>
                <a href="{!! route('deletenotice', [$notice->NoticeId]) !!}" class="btn btn-primary">{!! trans('common.button.delete') !!}</a>
            </div>
            <div class="border-content">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-header text-right">{!! trans('notice.label.title') !!}</div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{{ $notice->Title }}</div>    
                </div>
                <div class="row">
                    <div class="col-lg 4 col-md-4 col-sm-4 col-xs-4 text-header text-right">{!! trans('notice.label.content') !!}</div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{{ $notice->Content }}</div>
                </div>
                <div class="row">
                    <div class="col-lg 4 col-md-4 col-sm-4 col-xs-4 text-header text-right">{!! trans('notice.label.author') !!}</div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{{ $notice->Author }}</div>
                </div>
                <div class="row">
                    <div class="col-lg 4 col-md-4 col-sm-4 col-xs-4 text-header text-right">{!! trans('notice.label.updatedby') !!}</div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">{{ $notice->UpdatedBy }}</div>
                </div>                
                <div class="row border-row-bottom">
                    <div class="col-lg 4 col-md-4 col-sm-4 col-xs-4 text-header text-right">公開日時</div>
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
                        {{ $notice->PublicDate }}
                        {{ $notice->PublicHour }}
                    </div>
                </div>               
            </div>
        </div>
    </div>
</div>
{!! Form::close() !!}
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/moment.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script type="text/javascript" src="{!! asset('js/site/notice/notice.js')!!}"></script>
@endsection