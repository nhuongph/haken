@extends('site/layouts/main')
@section('title')
{!! trans('notice.list-notice.title') !!}
@endsection
@section('page_css')
<link href="{!! asset('css/common/text.css') !!}" rel="stylesheet">
<link href="{!! asset('css/common/layout_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/gaia/notice_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
{!! Form::open(['url'=> 'editnotice', 'id'=>'editnotice', 'class'=>'form-horizontal']) !!}
<br>
<div class="row text-setting notice">
    <div class="panel panel-default list">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-8 col-md-8 col-sm-8 col-xs-8'>
                    <h4 class="text-title"><b>{!! trans('notice.title') !!}</b></h4>
                </div>
            </div>
        </div>
        <div class="panel-body layout-border">  
            <div class="row">
                <a href="{!! URL::route('addnotice') !!}" class="btn btn-primary text-button pull-right">{!! trans('notice.list-notice.create') !!}</a>
            </div>
            <div class="row">
            <div class="tablecontent">
                <div class="table-responsive">
                    <table class="table table-bordered table-responsive table-hover">
                        <thead class="bg-header text-header">
                            <tr>
                                <th class="text-header">{!! trans('notice.label.title') !!}</th>
                                <th class="text-header">{!! trans('notice.label.author') !!}</th>
                                <th class="text-header">{!! trans('notice.label.publicdatetime') !!}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($notices as $notice)
                            <tr class="content">
                                <td>
                                    <a href="{!! route('editnotice', ['noticeId' => $notice->NoticeId]) !!}">{!! $notice->Title !!}</a>
                                </td>
                                <td>{!! $notice->Author !!}</td>
                                <td>
                                    {!! $notice->PublicDate !!}
                                    {!! $notice->PublicHour !!}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    </div>
                    <div class=""> {!! $notices->links() !!} </div>
                </div>
            </div>
        </div>
    </div>
</div>
{!! Form::close() !!}
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/moment.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script type="text/javascript" src="{!! asset('js/site/notice/notice.js')!!}"></script>
@endsection