<div class="table-responsive">
<table class="table table-bordered table-responsive table-hover layout-table-curved">
    <thead class="bg-header text-header">
        <tr>
            <th class="text-header">{!! trans('notice.label.title') !!}</th>
            <th class="text-header">{!! trans('notice.label.author') !!}</th>
            <th class="text-header">{!! trans('notice.label.publicdatetime') !!}</th>
        </tr>
    </thead>
    <tbody>
        @foreach($notices as $notice)
        <tr class="content">
            <td><a href="{!! route('editnotice', ['noticeId' => $notice->NoticeId]) !!}">{!! $notice->Title !!}</a></td>
            <td>{!! $notice->Author !!}</td>
            <td>
                {!! $notice->PublicDate !!}
                {!! $notice->PublicHour !!}
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
</div>
<div class="pagination"> {!! $notices->links() !!} </div>
<script type="text/javascript" src="{!! asset('js/site/notice/notice.js') !!}"></script>