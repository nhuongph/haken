@extends('site/layouts/main')

@section('title')
	{{ trans('order.title.detail') }}
@endsection

@section('content')
<div class="row">
    <div class="col-lg-12 col-md-12  margin-top-10">
        <div class="panel panel-default">
            <div class="panel-heading panel-heading-rules">
               {{ trans('order.header.order_detail') }}
               <div class="pull-right">
               		<a href="{{ route('order/update', ['orderId' => $order->OrderId]) }}" class="btn btn-default"> <i class="glyphicon glyphicon-edit"></i> {{ trans('order.button.edit') }}</a>
               		<a href="{{ route('order/list') }}" class="btn btn-default"><i class="glyphicon glyphicon-list"></i> {{ trans('order.button.list') }}</a>
               </div>
            </div>
            <div class="panel-body">
                <div class="col-md-12 col-sm-12 order-form" >
                    @include('site/message/index')
                    <div class="basic-form">
                    	  {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}                        	  
                         <table class="table table-responsive table-bordered">
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">{{ trans('order.labels.project_name') }}</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ProjectName !!}</span>          	
				                </div>
				                
				            </td>		          
				        </tr>
				         <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">{{ trans('order.labels.contractor') }}</div>
				                 <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->Contractor !!}</span> 	
				                </div>  
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">{{ trans('order.labels.order_date') }}</div>
				                <div class="col-md-9 nonePaddingLeft">
					                <div class='input-group width-percent-100'>
					                	<span class="form-control">{!! date('Y/m/d', strtotime($order->OrderDate)) !!}</span>
					                    <span class="input-group-addon">
					                        <span class="glyphicon glyphicon-calendar"></span>
					                    </span>
						            </div>
				                </div>  
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">{{ trans('order.labels.job_categrory') }}</div>
				                <div class="col-md-9 nonePaddingLeft">
				        			<span class="form-control">{!! $order->CategoryJob !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">受注区分</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{{ $orderDivision[$order->OrderDivision] }}</span>
				                </div>
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">ブランド</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{{ $brands[$order->Brand] }}</span>
				                </div>
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">期間区分</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{{ $desirePeriod[$order->PeriodDivision] }}</span>
				                </div>
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">契約開始</div>
				                <div class="col-md-9 nonePaddingLeft">
					                <div class='input-group width-percent-100'>
					                	<span class="form-control">{!! date('Y/m/d', strtotime($order->BeginContract)) !!}</span>
					                    <span class="input-group-addon">
					                        <span class="glyphicon glyphicon-calendar"></span>
					                    </span>
					                </div>
				                 </div> 
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">契約終了</div>
				                <div class="col-md-9 nonePaddingLeft">
					                <div class='input-group width-percent-100'>
					                	<span class="form-control">{!! date('Y/m/d', strtotime($order->EndContract)) !!}</span>
					                    <span class="input-group-addon">
					                        <span class="glyphicon glyphicon-calendar"></span>
					                    </span>
					                </div>
				                </div> 
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">現場名</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->AddressCompany !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">業務概要></div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->TaskOverview !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">服装</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->Clothes !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				         <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">持ち物</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->Belogings !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">最寄駅</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->NearestStation1 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft"></div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->NeasestStation2 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft"></div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->NeasestStation3 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft"></div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->NeasestStation4 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft"></div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->NearestStation5 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">集合時間</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->MeetingTime !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">集合場所</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->MeetingPlace !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">担当営業</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->SalesRepresentative !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">個別契約有無</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	 <input type="radio" name="ContractExistence" value="有" checked="checked" disabled="true"> 有
				                	 <input type="radio" name="ContractExistence" value="無" disabled="true">無
				                </div> 
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">その他注意事項</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->OtherNotes !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">就業先：派遣先名</div>
				                <div class="col-md-9 nonePaddingLeft">
				                 	<span class="form-control">
				                 		{!! isset($order->EmploymentDestinationIdCompany->CompanyName) ? $order->EmploymentDestinationIdCompany->CompanyName : '' !!}
				                 	</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">契約書送付先</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">
				                		{!! isset($order->AgreementDestinationIDCompany->CompanyName) ? $order->AgreementDestinationIDCompany->CompanyName : '' !!}
				                	</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">請求書送付先</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! isset($order->OrderAddressIdCompany->CompanyName) ? $order->OrderAddressIdCompany->CompanyName : '' !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">派遣先責任者名</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->DispatchResponsibleName !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				   
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">派遣先責任者所属部署</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->DispatchResponsibleDepartment !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">派遣先責任者役職</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->DispatchResponsibleTitle !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">派遣先責任者連絡先</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ResponsiblePersonContact !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">指揮命令者名</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ChainCommandName !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">指揮命令者所属部署</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ChainCommandDepartment !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">指揮命令者役職</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ChainCommandTitle !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">指揮命令者連絡先</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ChainCommandContact !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">苦情処理担当者名</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ComplaintPersonCharge !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>


				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">指揮命令者所属部署</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ComplaintPersonnelDepartment !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">苦情処理担当者役職</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ComplaintPersonnelOfficers !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">苦情処理担当者連絡先</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ComplaintPersonnelContacts !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>

				       
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">請求単位</div>
				                <div class="col-md-9 nonePaddingLeft">		                	
				                	  <input type="radio" name="OrdersUnits" value="時間" 
				                	 <?php if($order->OrdersUnits=='時間'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?>  disabled="true"> 時間
				                	 <input type="radio" name="OrdersUnits" value="日別"
				                	  <?php if($order->OrdersUnits=='日別'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  日別
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">事前研修</div>
				                <div class="col-md-9 nonePaddingLeft">		                	
									<input type="radio" name="OrderUnitsPreTraining" value="有" 
				                	 <?php if($order->OrderUnitsPreTraining=='有'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true"> 有
				                	 <input type="radio" name="OrderUnitsPreTraining" value="無"
				                	  <?php if($order->OrderUnitsPreTraining=='無'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  無
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">交通費支払</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	 <input type="radio" name="TransportationExpensePayment" value="有" 
				                	 <?php if($order->TransportationExpensePayment=='有'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true"> 有
				                	 <input type="radio" name="TransportationExpensePayment" value="無"
				                	  <?php if($order->TransportationExpensePayment=='無'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  無
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">交通費支払備考</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->TransportationExpensesRemarks !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">交通費請求</div>
				                <div class="col-md-9 nonePaddingLeft">		                	 
				                	 <input type="radio" name="ConstructionRemoval" value="有" 
				                	 <?php if($order->ConstructionRemoval=='有'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true"> 有
				                	 <input type="radio" name="ConstructionRemoval" value="無"
				                	  <?php if($order->ConstructionRemoval=='無'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  無

				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">交通費請求備考</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ConstructionRemovalRemarks !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">設営・撤去</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	 <input type="radio" name="Allowance" value="有" 
				                	 <?php if($order->Allowance=='有'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true"> 有
				                	 <input type="radio" name="Allowance" value="無"
				                	  <?php if($order->Allowance=='無'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  無
				                </div>
				                
				            </td>		          
				        </tr>
						<tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">設営・撤去備考</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->AllowanceRemarks !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">手当</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	 <input type="radio" name="ConstructionRemoval1" value="有" 
				                	 <?php if($order->ConstructionRemoval1=='有'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true"> 有
				                	 <input type="radio" name="ConstructionRemoval1" value="無"
				                	  <?php if($order->ConstructionRemoval1=='無'){
				                	 	  echo 'checked="checked"' ;
				                	 }
				                	 ?> disabled="true">
				                	  無
				                </div>
				                
				            </td>		          
				        </tr>
				        <tr>
				            <td colspan="2">
				                <div class="col-md-3 nonePaddingLeft">手当備考</div>
				                <div class="col-md-9 nonePaddingLeft">
				                	<span class="form-control">{!! $order->ConstructionRemovalRemarks1 !!}</span>
				                </div>
				                
				            </td>		          
				        </tr>
				    </table>

	   	<div class="table-responsive">
	   		<table class="table table-bordered table-box-2" id="generate-data-table">
	    	<tr class="table-box-2-title">
	    		<td>NO</td>
	    		<td>始業</td>
	    		<td>終業</td>
	    		<td>休憩</td>
	    		<td>支払</td>
	    		<td>請求</td>
	    		<td>備考</td>
	    	</tr>
				
	    	@for($i=1;$i<=6;$i++)
	    	<tr class="table-box-money table-get-money" data-row="{!! $i !!}">
	    		<td>{{$i}}</td>
	    		<td>
	    			<span class="form-control TimeStart hour-minute"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeStart : ''; ?></span>
	    		</td>

	    		<td><span class="form-control TimeEnd hour-minute"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeEnd : ''; ?></span></td>

	    		<td><span class="form-control TimeBreak hour-minute"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeBreak : ''; ?></span></td>

	    		<td><span class="form-control Payment number-comma"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->Payment : ''; ?></span></td>

	    		<td><span class="form-control Claim number-comma"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->Claim : ''; ?></span></td>

	    		<td><span class="form-control Note"><?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->Note : ''; ?></span>
	    		</td>
	    		
	    	</tr>
	    	@endfor
	    	</table>
	   	</div>
	    
	    <div class="working-registration">
	    	<!-- <button type="button" class="btn btn-default btn-lg button-submit" id="generate-btn" style="float:right;margin-bottom:15px;">勤務日登録</button> -->
	    </div>
	   	
	    <div id="generate-content">
	    	@foreach( $orderDates as $key => $value )
				<table class="table table-responsive table-bordered table-box-2 date-table generate-table">
					<tr>
						<th class="width-percent-10">日付</th>
						<th class="width-percent-12">勤務要否</th>
						<th class="width-percent-39">人数</th>
						<th class="width-percent-39">特記事項</th>
					</tr>
					@foreach( $value as $dkey => $orderDate )
					<tr>
						<td>
							{{date('m/d', strtotime($orderDate->Date))}}
						</td>
          				<td><input type="checkbox"  name="OrdersDate[{{$key}}][{{$dkey}}][WorkNecessity]" value="{{$orderDate->WorkNecessity}}" {{$orderDate->WorkNecessity === 1 ? 'checked="true"' : ''}} disabled="true"/></td>
          				<td><span class="form-control NumberPeople number-people">{{$orderDate->NumberPeople}}</span></td>
          				<td><span class="form-control">{{$orderDate->Notices}}</span></td>
					</tr>
					@endforeach
				</table>
	    	@endforeach
	    </div>

	    <table class="table table-responsive table-bordered table-box-3" >
			<tr>
	    		<td class="width-percent-25">請求総額</td>
	    		<td class="width-percent-25">支払総額</td>
	    		<td class="width-percent-25">特別広告</td>
	    		<td class="width-percent-25">粗利</td>
	    	</tr>
	    	<tr>
	    		<td><span class="form-control sum-money-2"><?php echo $order->TotalClaims; ?></span></td>
	    		<td><span class="form-control sum-money-1"><?php echo $order->TotalPay; ?></span></td>
	    		<td><span class="form-control sum-money-3"><?php echo $order->TotalServices; ?></span></td>
	    		<td><span class="form-control sum-money-total"><?php echo $order->SumTotal; ?></td>
	    	</tr>
			
			<tr>
				<td>
					<!-- <?php if($order->Status=="下書き"){?>
						<button class="btn btn-default btn-lg update-status">更新</button>
						<?php }elseif($order->Status=="承認待"){?>
						<button class="btn btn-default btn-lg update-status" disabled>更新</button>
						<?php }else{?>
						<button class="btn btn-default btn-lg update-status" disabled>更新</button>
						<?php }?>
						-->
				</td>
				<td colspan="3">
					<div class="box-1-people-time margin-bottom-50">
						<div class="col-md-3">最終更新</div>
						<div class="col-md-9">
							<span class="form-control">
							{{ $order->LastUpdateTime }}
							</span>
						</div>
					</div>
					<div class="box-1-people-person margin-top-10">
					 	<div class="col-md-3">最終更新者</div>
						<div class="col-md-9"><span class="form-control">{{ $order->Contractor }}</span></div>
					</div>
				</td>
				<tr>
					<td>担当上長</td>
					<td colspan="3">
						<span name="PeppleApproal" class="form-control">{{$order->PeppleApproal}}</span>
					</td>
				</tr>
			</tr>

			<tr>
				<td>		
					<!--  <?php if($order->Status=="下書き"){?>
					<button type="button" class="btn btn-default btn-lg update-request" data-toggle="modal" data-target="#myModal">承認依頼</button>
					 <?php }else{ ?>
					 <button type="button" class="btn btn-default btn-lg update-request" data-toggle="modal" data-target="#myModal" disabled>承認依頼</button>
					 <?php } ?> -->
				</td>
				<td colspan="3">
					<div class="box-2-people-time margin-bottom-50">
						<div class="col-md-3">承認依頼</div>
						<div class="col-md-9">
							<span class="form-control">{{ $order->ApprovalRequestTime }}</span>
						</div>

					</div>
					<div class="box-2-people-person margin-bottom-15 overflow-hidden">
					 	<div class="col-md-3">承認依頼者</div>
						<div class="col-md-9">
							<span class="form-control">{{ $order->ApprovalRequester }}</span>
						</div>
					</div>
					<div class="box-2-people-commet">
					 	<div class="col-md-3">コメント</div>
						<div class="col-md-9">
							<span class="form-control">{{ $order->ApprovalRequestComment }}</span>
						 </div>
					</div>
				</td>
			</tr>

			<tr>
				<td>
					<!-- <div class="col-md-3 nonePaddingLeft">
						<?php if($order->Status=='承認待'){?>
						<button class="btn btn-default btn-lg change-status" data-toggle="modal" type="button" data-target="#myModalChangeStatus">承認</button>
						<?php } else {?>
						<button class="btn btn-default btn-lg change-status" disabled data-toggle="modal" type="button" data-target="#myModalChangeStatus" disabled >承認</button>
						<?php } ?>
					</div>
					
					<div class="col-md-3">
						<?php if($order->Status=='下書き'){?>
						<button class="btn btn-default btn-lg update-status-return" >否認</button>
						<?php } elseif ($order->Status=='承認待'){?>
						<button class="btn btn-default btn-lg  update-status-return">否認</button>
						<?php } ?>
					</div> -->
				</td>
				<td colspan="3">
					<div class="box-2-people-time margin-bottom-50">
						<div class="col-md-3">承認状態</div>
						<div class="col-md-9 approval-status-add">
							<span class="form-control">{{ $order->Status }}</span>
						</div>

					</div>
					<div class="box-2-people-person margin-bottom-15 overflow-hidden">
					 	<div class="col-md-3">担当者</div>
						<div class="col-md-9">
							<span class="form-control">{{ $order->PersonCharge }}</span>
						</div>
					</div>
					<div class="box-2-people-commet">
					 	<div class="col-md-3">コメント</div>
						<div class="col-md-9">
							<span class="form-control">{{ $order->ApprovalComment }}</span>
						</div>
					</div>
				</td>
			</tr>
	    	
	    </table>

    <table class="table table-responsive table-bordered" >
		<tr>
			<td>受注者(営業) コメント</td>
			<td colspan="3">ブランドのイメージの関係で、なるべく見た目の綺麗な女性を集めてください。現場での対応能力が高ければ、40代でも2〜3名であれば構いません。</td>
		</tr>
		<tr>
			<td>対象年齢</td>
			<td colspan="3">
				<div class="col-md-6 nonePaddingLeft marginBottom5">
					<span class="form-control">{{ isset($demandRegard->AgeStart) ? $demandRegard->AgeStart : '' }}</span>
				</div>
				<div class="col-md-6 nonePaddingLeft marginBottom5">
					<span class="form-control">{{ isset($demandRegard->AgeEnd) ? $demandRegard->AgeEnd : '' }}</span>
				</div>
				
			</td>
		</tr>
		<tr>
			<td>性別</td>
			<td colspan="3">
				<input type="checkbox" name="SexNam" @if( isset($demandRegard->SexNam) && $demandRegard->SexNam == 0) {{ 'checked="checked"' }} @endif disabled>男性
				<input type="checkbox" name="SexNu" @if( isset($demandRegard->SexNu) && $demandRegard->SexNu == 0) {{ 'checked="checked"' }} @endif disabled>女性
			</td>
		</tr>
		<tr>
			<td rowspan="3">条件</td>
			<td>必須</td>
			<td>
				<span class="form-control">{!! isset($demandRegard->Required) ? $demandRegard->Required : '' !!}</span>
			</td>
		</tr>
		<tr>
			<td>優先</td>
			<td>
				<span class="form-control">{!! isset($demandRegard->Priority) ? $demandRegard->Priority : '' !!}</span>
			</td>
		</tr>
		<tr>
			<td>レジ</td>
			<td>
				<input type="radio" name="CashRegister" value="0" @if( isset($demandRegard->CashRegister) && $demandRegard->CashRegister == 0) {{ 'checked="checked"' }} @endif disabled> 有
				<input type="radio" name="CashRegister" value="1" @if( isset($demandRegard->CashRegister) && $demandRegard->CashRegister == 1) {{ 'checked="checked"' }} @endif disabled> 無
			</td>
		</tr>
    </table>

    <div id="myModal" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content update-request-order">
			    <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h4 class="modal-title">承認依頼</h4>
			    </div>

			    <div class="modal-body">
			       	<td colspan="3">
						<div class="box-2-people-commet">
						 	<div class="col-md-3">コメント</div>
							<div class="col-md-9">
							   <input type="text" name="ApprovalRequestComment" class="form-control" value="{{ $order->ApprovalRequestComment }}">
							</div>
						</div>
					</td>
			    </div>

			    <div class="modal-footer">
			      	<button class="btn btn-default btn-lg update-request">承認依頼</button>
			        <button type="button" class="btn btn-default btn-lg" data-dismiss="modal">キャンセル</button>
			    </div>
			</div>
		</div>
	</div>

	<div id="myModalChangeStatus" class="modal fade" role="dialog">
		<div class="modal-dialog">
		    <div class="modal-content update-request-order">
		      	<div class="modal-header">
		        	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        	<h4 class="modal-title">否認</h4>
		      	</div>

		      	<div class="modal-body">
		       		<td colspan="3">
						<div class="box-2-people-commet">
						 	<div class="col-md-3">コメント</div>
							<div class="col-md-9">
							   <input type="text" name="ApprovalComment" class="form-control" value="{{ $order->ApprovalComment }}">
							 </div>
						</div>
					</td>
		      	</div>

		      	<div class="modal-footer">
		      		<button class="btn btn-default btn-lg change-status">否認</button>
		        	<button type="button" class="btn btn-default btn-lg" data-dismiss="modal">キャンセル</button>
		      	</div>
		    </div>
		</div>
	</div>
    {!! Form::close() !!}
    <div class="col-md-12 margin-top-10">
		<div class="col-md-12">コメント</div>
		<div class="col-md-12">
			<div class="thumbnail">
				@foreach($comments as $key => $value)
					<span class="form-control">{{ $value->CommentContent }}</span>
				@endforeach

				@if( count($comments) == 0 )
					<div class="text-center">
						コメントなし
					</div>
				@endif
			</div>
		</div>
    </div>       
</div>
@endsection
@section('page_js')
    <script src="{{ asset('plugins/bootstrap/js/moment.js') }}"></script>
	<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
@endsection