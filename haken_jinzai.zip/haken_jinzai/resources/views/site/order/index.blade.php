@extends('site/layouts/main')
@section('title')
{{ trans('order.title.new') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/order.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
	<h1><small></small></h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="{{route('order/list')}}">{{ trans('title.order.pageList') }}</a></li>
		<li class="active">{{ trans('order.title.new') }}</li>
	</ol>
</section>
@endsection
@section('content')
<div class="row text-setting order">
	<div class="col-lg-12 col-md-12">
		<div class="box box-info box-solid add">
			<div class="box-header with-border">
				<h4 class="text-title"><b>{{ trans('order.header.new_order') }}</b></h4>
			</div>
			<div class="box-body content">
				<div class="col-md-12 col-sm-12 order-form" >
					@include('site/message/index')
					<div class="basic-form">
						{!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}                        	  
						<table class="table table-responsive table-bordered tbl-common">
							<tr>
								<td>案件名称<span class="required"> *</span></td>
								<td>{!! Form::text('ProjectName', $order->ProjectName, ['class' => 'form-control']) !!}</td>
							</tr>
							<tr>
								<td>受注者<span class="required"> *</span></td>
								<td>{!! Form::select('Contractor', $gaia, null, ['class' => 'form-control']) !!}
									<!-- {!! Form::text('Contractor', $order->Contractor, ['class' => 'form-control']) !!} -->
								</td>		          
							</tr>
							<tr>
								<td>受注日<span class="required"> *</span></td>
								<td>
									<div class="form-group" style="margin-left:0;margin-right:0">
										<div class='input-group date' id='datetimepicker' >
											{!! Form::text('OrderDate', $order->OrderDate, ['class' => 'form-control']) !!}
											<span class="input-group-addon">
												<span class="glyphicon glyphicon-calendar"></span>
											</span>
										</div>
									</div>	 
								</td>		          
							</tr>
							<tr>
								<td>職種<span class="required"> *</span></td>
								<td>
									{!! Form::select('CategoryJob', array(''=>'-- 選択してください --','携帯販売' => '携帯販売', '家電販売' => '家電販売', '化粧品販売' => '化粧品販売','アパレル販売'=>'アパレル販売','雑貨販売'=>'雑貨販売','食品販売'=>'食品販売','試飲・試食販売'=>'試飲・試食販売','営業'=>'営業','ラウンダ'=>'ラウンダ','カフェスタッフ'=>'カフェスタッフ','百貨店レジ'=>'百貨店レジ','事務'=>'事務','データ入力'=>'データ入力','コンパニオン'=>'コンパニオン','ディレクター'=>'ディレクター','軽作業'=>'軽作業','その他'=>'その他'
									),$order->CategoryJob,['class' => 'form-control']) !!}
								</td>		          
							</tr>
							<tr>
								<td>受注区分<span class="required"> *</span></td>
								<td>
									{!! Form::select('OrderDivision', array(''=>'-- 選択してください --','001' => '派遣', '002' => '請負', '003' => '紹介予定派遣'),$order->OrderDivision,['class' => 'form-control']) !!}		     
								</td>		          
							</tr>
							<tr>
								<td>ブランド<span class="required"> *</span></td>
								<td>{!! Form::select('Brand', $brands, null, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>期間区分<span class="required"> *</span></td>
								<td>
									{!! Form::select('PeriodDivision', array(''=>'-- 選択してください --','単発' => '単発', '短期' => '短期', '長期' => '長期'),$order->PeriodDivision,['class' => 'form-control']) !!}
								</td>		          
							</tr>
							<tr>
								<td>契約開始<span class="required"> *</span></td>
								<td>
									<!-- {!! Form::text('BeginContract', $order->BeginContract, ['class' => 'form-control']) !!}  -->
									<div class="form-group" style="margin-left:0;margin-right:0">
										<div class='input-group date' id='datetimepicker1' >
											{!! Form::text('BeginContract', $order->BeginContract, ['class' => 'form-control' , 'id'=>'BeginContract']) !!}
											<span class="input-group-addon">
												<span class="glyphicon glyphicon-calendar"></span>
											</span>
										</div>
									</div>
								</td>		          
							</tr>
							<tr>
								<td>契約終了<span class="required"> *</span></td>
								<td>
									<!-- {!! Form::text('EndContract', $order->EndContract, ['class' => 'form-control']) !!} -->
									<div class="form-group" style="margin-left:0;margin-right:0">
										<div class='input-group date' id='datetimepicker2' >
											{!! Form::text('EndContract', $order->EndContract, ['class' => 'form-control' , 'id' =>'EndContract']) !!}
											<span class="input-group-addon">
												<span class="glyphicon glyphicon-calendar"></span>
											</span>
										</div>
									</div>
								</td>		          
							</tr>
							<tr>
								<td>現場名<span class="required"> *</span></td>
								<td>{!! Form::text('AddressCompany', $order->AddressCompany, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>業務概要<span class="required"> *</span></td>
								<td>
									{!! Form::text('TaskOverview', $order->TaskOverview, ['class' => 'form-control']) !!}
									<!-- <input type="text" name="TaskOverview" class="form-control"> -->
								</td>		          
							</tr>
							<tr>
								<td>服装<span class="required"> *</span></td>
								<td>{!! Form::textarea('Clothes', $order->Clothes, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>持ち物<span class="required"> *</span></td>
								<td>{!! Form::text('Belongings', $order->Belogings, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>最寄駅<span class="required"> *</span></td>
								<td>{!! Form::text('NeasestStation1', $order->NearestStation1, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td></td>
								<td>{!! Form::text('NeasestStation2',$order->NeasestStation2, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td></td>
								<td>{!! Form::text('NeasestStation3',$order->NeasestStation3, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td></td>
								<td>{!! Form::text('NeasestStation4',$order->NeasestStation4, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td></td>
								<td>{!! Form::text('NeasestStation5',$order->NearestStation5, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>集合時間</td>
								<td>{!! Form::text('MeetingTime', $order->MeetingTime, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>集合場所</td>
								<td>{!! Form::text('MeetingPlace', $order->MeetingPlace, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>担当営業<span class="required"> *</span></td>
								<td>{!! Form::text('SalesRepresentative',$order->SalesRepresentative, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>個別契約有無<span class="required"> *</span></td>
								<td>
									<input type="radio" name="ContractExistence" value="有" checked="checked"> 有
									<input type="radio" name="ContractExistence" value="無">無
								</td>		          
							</tr>
							<tr>
								<td>その他注意事項</td>
								<td>{!! Form::textarea('OtherNotes', $order->OtherNotes, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>就業先：派遣先名 <span class="required"> *</span></td>
								<td>{!! Form::select('EmploymentDestinationId', $companys, null, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>契約書送付先</td>
								<td>{!! Form::select('AgreementDestinationID', $companyName, null, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>請求書送付先</td>
								<td>{!! Form::select('OrderAddressId', $companyName, null, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>派遣先責任者名<span class="required"> *</span></td>
								<td>{!! Form::text('DispatchResponsibleName', $order->DispatchResponsibleName, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>派遣先責任者所属部署</td>
								<td>{!! Form::text('DispatchResponsibleDepartment', $order->DispatchResponsibleDepartment, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>派遣先責任者役職</td>
								<td>{!! Form::text('DispatchResponsibleTitle', $order->DispatchResponsibleTitle, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>派遣先責任者連絡先<span class="required"> *</span></td>
								<td>{!! Form::text('ResponsiblePersonContact', $order->ResponsiblePersonContact, ['class' => 'form-control phone-number']) !!}</td>		          
							</tr>
							<tr>
								<td>指揮命令者名<span class="required"> *</span></td>
								<td>{!! Form::text('ChainCommandName', $order->ChainCommandName, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>指揮命令者所属部署</td>
								<td>{!! Form::text('ChainCommandDepartment', $order->ChainCommandDepartment, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>指揮命令者役職</td>
								<td>{!! Form::text('ChainCommandTitle', $order->ChainCommandTitle, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>指揮命令者連絡先<span class="required"> *</span></td>
								<td>{!! Form::text('ChainCommandContact', $order->ChainCommandContact, ['class' => 'form-control phone-number']) !!}</td>		          
							</tr>
							<tr>
								<td>苦情処理担当者名<span class="required"> *</span></td>
								<td>{!! Form::text('ComplaintPersonCharge', $order->ComplaintPersonCharge, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>苦情処理担当者所属部署</td>
								<td>{!! Form::text('ComplaintPersonnelDepartment', $order->ComplaintPersonnelDepartment, ['class' => 'form-control']) !!}</td>
							</tr>
							<tr>
								<td>苦情処理担当者役職</td>
								<td>{!! Form::text('ComplaintPersonnelOfficers', $order->ComplaintPersonnelOfficers, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>苦情処理担当者連絡先<span class="required"> *</span></td>
								<td>{!! Form::text('ComplaintPersonnelContacts', $order->ComplaintPersonnelContacts, ['class' => 'form-control phone-number']) !!}</td>		    
							</tr>
							<tr>
								<td>請求単位<span class="required"> *</span></td>
								<td>
									<input type="radio" name="OrdersUnits" value="時間" checked="checked"> 時間
									<input type="radio" name="OrdersUnits" value="日別">  日別
								</td>		          
							</tr>
							<tr>
								<td>事前研修<span class="required"> *</span></td>
								<td>
									<input type="radio" name="OrderUnitsPreTraining" value="有" checked="checked"> 有
									<input type="radio" name="OrderUnitsPreTraining" value="無"> 無
								</td>		          
							</tr>
							<tr>
								<td>交通費支払<span class="required"> *</span></td>
								<td>
									<input type="radio" name="TransportationExpensePayment" value="有" checked="checked"> 有
									<input type="radio" name="TransportationExpensePayment" value="無"> 無
								</td>		          
							</tr>
							<tr>
								<td>交通費支払備考</td>
								<td>{!! Form::text('TransportationExpensesRemarks', $order->TransportationExpensesRemarks, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>交通費請求<span class="required"> *</span></td>
								<td>
									<input type="radio" name="ConstructionRemoval" value="有" checked="checked"> 有
									<input type="radio" name="ConstructionRemoval" value="無"> 無
								</td>		          
							</tr>
							<tr>
								<td>交通費請求備考</td>
								<td>{!! Form::text('ConstructionRemovalRemarks', $order->ConstructionRemovalRemarks, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>設営・撤去<span class="required"> *</span></td>
								<td>
									<input type="radio" name="Allowance" value="有" checked="checked"> 有
									<input type="radio" name="Allowance" value="無"> 無
								</td>		          
							</tr>
							<tr>
								<td>設営・撤去備考</td>
								<td>{!! Form::text('AllowanceRemarks', $order->AllowanceRemarks, ['class' => 'form-control']) !!}</td>		          
							</tr>
							<tr>
								<td>手当<span class="required"> *</span></td>
								<td>
									<input type="radio" name="ConstructionRemoval1" value="有" checked="checked"> 有
									<input type="radio" name="ConstructionRemoval1" value="無"> 無
								</td>		          
							</tr>
							<tr>
								<td>手当備考</td>
								<td>{!! Form::text('ConstructionRemovalRemarks1', $order->ConstructionRemovalRemarks1, ['class' => 'form-control']) !!}</td>		          
							</tr>
						</table>

						<h3>就業時間/支払・請求<span class="required" aria-required="true"> *</span></h3>
						<table class="table table-responsive table-bordered table-box-2" id="generate-data-table">
							<tr class="table-box-2-title">
								<td>NO</td>
								<td>始業</td>
								<td>終業</td>
								<td>休憩</td>
								<td>支払</td>
								<td>請求</td>
								<td>基本勤務時間</td>
								<td>備考</td>
							</tr>
							@for($i=1;$i<=6;$i++)

							<tr class="table-box-money table-get-money" data-row="{!! $i !!}">
								<td>{{$i}}</td>
								<td>
									{!! Form::text('OrdersTime['.$i.'][TimeStart]',null, ['class' => 'form-control TimeStart hour-minute','id'=>'TimeStart'.$i]) !!}
								</td>
								<td>
									{!! Form::text('OrdersTime['.$i.'][TimeEnd]',null, ['class' => 'form-control TimeEnd hour-minute','id'=>'TimeEnd'.$i ]) !!}
								</td>
								<td>
									{!! Form::text('OrdersTime['.$i.'][TimeBreak]',null, ['class' => 'form-control TimeBreak','id'=>'TimeBreak'.$i]) !!}
								</td> 
								<td>
									{!! Form::text('OrdersTime['.$i.'][Payment]',null, ['class' => 'form-control Payment number-comma','id'=>'Payment'.$i]) !!}
								</td>
								<td>
									{!! Form::text('OrdersTime['.$i.'][Claim]',null, ['class' => 'form-control Claim number-comma','id'=>'Claim'.$i]) !!}
								</td>
								<td>
									{!! Form::select('OrdersTime['.$i.'][TimeWorkings]', array('5' => '5時間', '5.3' => '5時間30分
									', '6' => '6時間','6.3'=>'6時間30分','7' => '7時間','7.3'=>'7時間30分','8' => '8時間','8.3'=>'8時間30分','9' => '9時間','9.3'=>'9時間30分','10' => '10時間'),'8',['class' => 'form-control']) !!}
								</td>
								<td>
									{!! Form::text('OrdersTime['.$i.'][Note]',null, ['class' => 'form-control Note','id'=>'Note'.$i]) !!}
									<input type="hidden" value="{{$i}}" name="OrdersTime[{{$i}}][Name]"  >
								</td>

							</tr>
							@endfor
						</table>

						<div class="working-registration">
							<button type="button" class="btn btn-primary button-submit" id="generate-btn" style="float:right;margin-bottom:15px;">勤務日登録</button>
						</div>

						<div id="generate-content">
						</div>

						<table class="table table-responsive table-bordered table-box-3" >
							<tr class="table-box-3-title">
								<td>請求総額</td>
								<td>支払総額</td>
								<td>特別広告</td>
								<td>粗利</td>
								<td></td>	
							</tr>
							<tr>
								<td><input type="text" class="form-control sum-money-2" name="TotalClaims" value="<?php echo $order->TotalClaims; ?>" ></td>
								<td><input type="text" class="form-control sum-money-1" name="TotalPay" value="<?php echo $order->TotalPay; ?>"  ></td>
								<td><input type="text" class="form-control sum-money-3" name="TotalServices" value="<?php echo $order->TotalPay; ?>"  ></td>
								<td><input type="text" class="form-control sum-money-total" name="SumTotal" value="<?php echo $order->SumTotal; ?>"  ></td>
								<td><button class="btn btn-default button-money" type="button">計算する</button></td>	
							</tr>
							<tr>
								<td><button class="btn btn-primary update-status">登録</button></td>
								<td colspan="4">
									<div class="box-1-people-time" style="margin-bottom:50px">
										<div class="col-md-3">最終更新</div>
										<?php $datenow = date("Y/m/d H:i:s")?>
										<div class="col-md-9">
											<input type="text" name="LastUpdateTime" class="form-control" disabled>
											<input type="hidden" name="LastUpdateTime" class="form-control">
										</div>

									</div>
									<div class="box-1-people-person">
										<div class="col-md-3">最終更新者</div>
										<div class="col-md-9">
											<input type="text" name="LastUpdatePerson" class="form-control" disabled>
											<input type="hidden" name="LastUpdatePerson" class="form-control">
										</div>
									</div>
								</td>
								<tr>
									<td>担当上長</td>
									<td colspan="4">
										<select name="PeppleApproal" class="form-control" disabled>
											<option value=''>-- 選択してください --</option>
											<?php 
											foreach ($roles as $role) {
												?>
												<option value="<?php echo $role->id ;?>"><?php echo $role->Firstname . ' ' . $role->Lastname ; ?></option>

												<?php 
											}
											?>
										</select>
										<input name="PeppleApproal" type="hidden">
									</td>
								</tr>
							</tr>
							<tr>
								<td>
									<button class="btn btn-default update-request" type="button" disabled>承認依頼</button>
								</td>
								<td colspan="4">
									<div class="box-2-people-time" style="margin-bottom:50px">
										<div class="col-md-3">承認依頼</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalRequestTime" class="form-control" disabled>
											<input type="hidden" name="ApprovalRequestTime" class="form-control" >
										</div>

									</div>
									<div class="box-2-people-person" style="margin-bottom:15px;overflow:hidden">
										<div class="col-md-3">承認依頼者</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalRequester" class="form-control" disabled>
											<input type="hidden" name="ApprovalRequester" class="form-control" >
										</div>
									</div>
									<div class="box-2-people-commet">
										<div class="col-md-3">コメント</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalRequestComment" class="form-control" disabled>
											<input type="hidden" name="ApprovalRequestComment" class="form-control">
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td>
									<div class="col-md-3 nonePaddingLeft">
										<button class="btn btn-default" type="button" disabled >承認</button>
									</div>
									<div class="col-md-3">
										<button class="btn btn-default change-status" type="button" disabled>否認</button>
									</div>
								</td>
								<td colspan="4">
									<div class="box-2-people-time" style="margin-bottom:50px">
										<div class="col-md-3">承認状態</div>
										<div class="col-md-9 approval-status-add">
											<input type="text" name="Status" class="form-control remove-status" disabled>
											<input type="hidden" name="Status" class="form-control remove-status" >
										</div>

									</div>
									<div class="box-2-people-person" style="margin-bottom:15px;overflow:hidden">
										<div class="col-md-3">担当者</div>
										<div class="col-md-9">
											<input type="text" name="PersonCharge" class="form-control" disabled>
											<input type="hidden" name="PersonCharge" class="form-control" >
										</div>
									</div>
									<div class="box-2-people-commet">
										<div class="col-md-3">コメント</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalComment" class="form-control" disabled>
											<input type="hidden" name="ApprovalComment" class="form-control" >
										</div>
									</div>
								</td>
							</tr>
						</table>

						<table class="table table-responsive table-bordered" >
							<tr>
								<td>受注者(営業) コメント</td>
								<td colspan="4">
									{!! Form::text('ContractorComments',$demandRegard->ContractorComments, ['class' => 'form-control']) !!}
								</td>
							</tr>
							<tr>
								<td>対象年齢</td>
								<td colspan="3">
									<div class="col-md-5 nonePaddingLeft">
										{!! Form::select('AgeStart', $ageStart ,$demandRegard->SexNam,['class' => 'form-control']) !!}
									</div>
									<div class="col-md-1">〜</div>
									<div class="col-md-5 nonePaddingLeft">
										{!! Form::select('AgeEnd', $ageEnd ,$demandRegard->SexNu,['class' => 'form-control']) !!}
									</div>

								</td>
							</tr>
							<tr>
								<td>性別</td>
								<td colspan="4">
									<!--  {!! Form::text('Sex', $demandRegard->Sex, ['class' => 'form-control']) !!} -->
									<!-- <input type="text" name="Sex" class="form-control" value="<?php $demandRegard->Sex;?>"> -->
									<input type="checkbox" name="SexNam"  value="0" checked="checked">男性
									<input type="checkbox" name="SexNu"   value="1" checked="checked">女性
								</td>
							</tr>
							<tr>
								<td rowspan="3">条件</td>
								<td>必須</td>
								<td>
									{!! Form::textarea('Required', $demandRegard->Required, ['class' => 'form-control']) !!}
									<!-- <input type="text" name="Required" class="form-control" value="<?php $demandRegard->Required;?>"> -->
								</td>
							</tr>
							<tr>
								<td>優先</td>
								<td>
									{!! Form::textarea('Priority', $demandRegard->Priority, ['class' => 'form-control']) !!}
									<!-- <input type="text" name="Priority" class="form-control" value="<?php $demandRegard->Priority;?>"> -->
								</td>
							</tr>
							<tr>
								<td>レジ</td>
								<td>
									<input type="radio" name="CashRegister" value="0" checked="checked"> 有
									<input type="radio" name="CashRegister" value="1"> 無
								</td>
							</tr>
						</table>

						<div class="button-group btn-button">
							<button class="btn btn-primary button-submit" type="button">{{ trans('title.order.submit') }}</button> 
						</div>

						{!! Form::close() !!}

					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection
@section('page_js')
<script src="{{ asset('plugins/bootstrap/js/moment.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') }}"></script>
<script type="text/javascript">
	$(function () {
		$('#datetimepicker').datetimepicker({
			format: 'YYYY/MM/DD'
		});
		$('#datetimepicker1').datetimepicker({
			format: 'YYYY/MM/DD'
		});
		$('#datetimepicker2').datetimepicker({
			format: 'YYYY/MM/DD'
		});
	});
</script>
<!-- <script src="{{ asset('js/site/user/order.js') }}"></script> -->
<!-- <script src="{{ asset('plugins/jquery/jquery.cookie.js') }}"></script> -->	
<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
<!-- <script type="text/javascript" src="{!! asset('js/site/user/order_validate.js') !!}"></script> -->
<script src="{{ asset('js/site/user/order.create.js') }}"></script>
@endsection