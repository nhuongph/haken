@extends('site/layouts/main')
@section('title')
{{ trans('title.order.update') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/gaia/order.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
	<h1><small></small></h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="{{route('order/list')}}">{{ trans('title.order.pageList') }}</a></li>
		<li class="active">{{ trans('title.order.update') }}</li>
	</ol>
</section>
@endsection
@section('content')
<div class="row text-setting order">
	<div class="col-lg-12 col-md-12">
		<div class="box box-info box-solid add">
			<div class="box-header with-border">
				<h4 class="text-title"><b>案件基本情報</b></h4>
			</div>
			<div class="box-body">
				<div class="col-md-12 col-sm-12 order-form" >
					@include('site/message/index')
					<div class="basic-form">
						{!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}                        	  
						<table class="table table-responsive table-bordered">
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">案件名称<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ProjectName', $order->ProjectName, ['class' => 'form-control']) !!}            	
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">受注者<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('Contractor',$gaia, $order->Contractor, ['class' => 'form-control']) !!}	
									</div>  
								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">受注日<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<div class="form-group" style="margin-left:0;margin-right:0">
											<div class='input-group date' id='datetimepicker' >
												{!! Form::text('OrderDate', $order->OrderDate, ['class' => 'form-control']) !!}
												<span class="input-group-addon">
													<span class="glyphicon glyphicon-calendar"></span>
												</span>
											</div>
										</div>	 
									</div>  
								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">職種<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('CategoryJob', array(''=>'-- 選択してください --','携帯販売' => '携帯販売', '家電販売' => '家電販売', '化粧品販売' => '化粧品販売','アパレル販売'=>'アパレル販売','雑貨販売'=>'雑貨販売','食品販売'=>'食品販売','試飲・試食販売'=>'試飲・試食販売','営業'=>'営業','ラウンダ'=>'ラウンダ','カフェスタッフ'=>'カフェスタッフ','百貨店レジ'=>'百貨店レジ','事務'=>'事務','データ入力'=>'データ入力','コンパニオン'=>'コンパニオン','ディレクター'=>'ディレクター','軽作業'=>'軽作業','その他'=>'その他'
										),$order->CategoryJob,['class' => 'form-control']) !!}

									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">受注区分<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('OrderDivision', array(''=>'-- 選択してください --','001' => '派遣', '002' => '請負', '003' => '紹介予定派遣'),$order->OrderDivision,['class' => 'form-control']) !!}		     
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">ブランド<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('Brand', $brands, $order->Brand, ['class' => 'form-control']) !!}	
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">期間区分<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('PeriodDivision', array(''=>'-- 選択してください --','単発' => '単発', '短期' => '短期', '長期' => '長期'),$order->PeriodDivision,['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">契約開始<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<div class="form-group" style="margin-left:0;margin-right:0">
											<div class='input-group date' id='datetimepicker1' >
												<input type='text' class="form-control" name="BeginContract" id="BeginContract" value="<?php echo $order->BeginContract?>"/>
												<span class="input-group-addon">
													<span class="glyphicon glyphicon-calendar"></span>
												</span>
											</div>
										</div>
									</div> 

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">契約終了<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<div class="form-group" style="margin-left:0;margin-right:0">
											<div class='input-group date' id='datetimepicker2' >
												<input type='text' class="form-control" name="EndContract" value="<?php echo $order->EndContract ?>"/>
												<span class="input-group-addon">
													<span class="glyphicon glyphicon-calendar"></span>
												</span>
											</div>
										</div>
									</div> 

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">現場名<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('AddressCompany', $order->AddressCompany, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">業務概要<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('TaskOverview', $order->TaskOverview, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">服装<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::textarea('Clothes', $order->Clothes, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">持ち物<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('Belongings', $order->Belogings, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">最寄駅<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('NeasestStation1', $order->NearestStation1, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft"></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('NeasestStation2', $order->NeasestStation2, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft"></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('NeasestStation3', $order->NeasestStation3, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft"></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('NeasestStation4', $order->NeasestStation4, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft"></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('NeasestStation5', $order->NearestStation5, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">集合時間</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('MeetingTime', $order->MeetingTime, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">集合場所</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('MeetingPlace', $order->MeetingPlace, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">担当営業<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('SalesRepresentative', $order->SalesRepresentative, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">個別契約有無<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<input type="radio" name="ContractExistence" value="有" checked="checked"> 有
										<input type="radio" name="ContractExistence" value="無">無
									</div> 
								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">その他注意事項</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::textarea('OtherNotes', $order->Othernotes, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">就業先：派遣先名 <span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('EmploymentDestinationId', $companys, $order->EmploymentDestinationId, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">契約書送付先</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('AgreementDestinationID', $companyName, $order->AgreementDestinationID, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">請求書送付先</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::select('OrderAddressId', $companyName, $order->OrderAddressId, ['class' => 'form-control']) !!}      
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">派遣先責任者名<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('DispatchResponsibleName', $order->DispatchResponsibleName, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">派遣先責任者所属部署</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('DispatchResponsibleDepartment', $order->DispatchResponsibleDepartment, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">派遣先責任者役職</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('DispatchResponsibleTitle', $order->DispatchResponsibleTitle, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">派遣先責任者連絡先<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ResponsiblePersonContact', $order->ResponsiblePersonContact, ['class' => 'form-control phone-number']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">指揮命令者名<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ChainCommandName', $order->ChainCommandName, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">指揮命令者所属部署</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ChainCommandDepartment', $order->ChainCommandDepartment, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">指揮命令者役職</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ChainCommandTitle', $order->ChainCommandTitle, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">指揮命令者連絡先<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ChainCommandContact', $order->ChainCommandContact, ['class' => 'form-control phone-number']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">苦情処理担当者名<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ComplaintPersonCharge', $order->ComplaintPersonCharge, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>


							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">苦情処理担当者所属部署</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ComplaintPersonnelDepartment', $order->ComplaintPersonnelDepartment, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">苦情処理担当者役職</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ComplaintPersonnelOfficers', $order->ComplaintPersonnelOfficers, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>

							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">苦情処理担当者連絡先<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ComplaintPersonnelContacts', $order->ComplaintPersonnelContacts, ['class' => 'form-control phone-number']) !!}
									</div>

								</td>		          
							</tr>


							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">請求単位<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">		                	
										<input type="radio" name="OrdersUnits" value="時間" 
										<?php if($order->OrdersUnits=='時間'){
											echo 'checked="checked"' ;
										}
										?> > 時間
										<input type="radio" name="OrdersUnits" value="日別"
										<?php if($order->OrdersUnits=='日別'){
											echo 'checked="checked"' ;
										}
										?>
										>
										日別
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">事前研修<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">		                	
										<input type="radio" name="OrderUnitsPreTraining" value="有" 
										<?php if($order->OrderUnitsPreTraining=='有'){
											echo 'checked="checked"' ;
										}
										?> > 有
										<input type="radio" name="OrderUnitsPreTraining" value="無"
										<?php if($order->OrderUnitsPreTraining=='無'){
											echo 'checked="checked"' ;
										}
										?>
										>
										無

									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">交通費支払<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<input type="radio" name="TransportationExpensePayment" value="有" 
										<?php if($order->TransportationExpensePayment=='有'){
											echo 'checked="checked"' ;
										}
										?> > 有
										<input type="radio" name="TransportationExpensePayment" value="無"
										<?php if($order->TransportationExpensePayment=='無'){
											echo 'checked="checked"' ;
										}
										?>
										>
										無
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">交通費支払備考</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('TransportationExpensesRemarks', $order->TransportationExpensesRemarks, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">交通費請求<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">		                	 
										<input type="radio" name="ConstructionRemoval" value="有" 
										<?php if($order->ConstructionRemoval=='有'){
											echo 'checked="checked"' ;
										}
										?> > 有
										<input type="radio" name="ConstructionRemoval" value="無"
										<?php if($order->ConstructionRemoval=='無'){
											echo 'checked="checked"' ;
										}
										?>
										>
										無

									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">交通費請求備考</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ConstructionRemovalRemarks', $order->ConstructionRemovalRemarks, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">設営・撤去<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<input type="radio" name="Allowance" value="有" 
										<?php if($order->Allowance=='有'){
											echo 'checked="checked"' ;
										}
										?> > 有
										<input type="radio" name="Allowance" value="無"
										<?php if($order->Allowance=='無'){
											echo 'checked="checked"' ;
										}
										?>
										>
										無
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">設営・撤去備考</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('AllowanceRemarks', $order->AllowanceRemarks, ['class' => 'form-control']) !!}	
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">手当<span class="required"> *</span></div>
									<div class="col-md-9 nonePaddingLeft">
										<input type="radio" name="ConstructionRemoval1" value="有" 
										<?php if($order->ConstructionRemoval1=='有'){
											echo 'checked="checked"' ;
										}
										?> > 有
										<input type="radio" name="ConstructionRemoval1" value="無"
										<?php if($order->ConstructionRemoval1=='無'){
											echo 'checked="checked"' ;
										}
										?>
										>
										無
									</div>

								</td>		          
							</tr>
							<tr>
								<td colspan="2">
									<div class="col-md-3 nonePaddingLeft">手当備考</div>
									<div class="col-md-9 nonePaddingLeft">
										{!! Form::text('ConstructionRemovalRemarks1', $order->ConstructionRemovalRemarks1, ['class' => 'form-control']) !!}
									</div>

								</td>		          
							</tr>
						</table>


						<table class="table table-responsive table-bordered table-box-2" id="generate-data-table">
							<tr class="table-box-2-title">
								<td>NO</td>
								<td>始業</td>
								<td>終業</td>
								<td>休憩</td>
								<td>支払</td>
								<td>請求</td>
								<td>基本勤務時間</td>
								<td>備考</td>
							</tr>

							@for($i=1;$i<=6;$i++)
							<tr class="table-box-money table-get-money" data-row="{!! $i !!}">
								<td>{{$i}}</td>
								<td>
									<input type="hidden"  name="OrdersTime[{{$i}}][OrderTimeid]" value="<?php echo isset($orderstime[$i-1]) ? $orderstime[$i-1]->OrderTimeid : ''; ?>" id="OrderTimeid{{$i}}" >
									{!! Form::text('OrdersTime['.$i.'][TimeStart]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeStart : '', ['class' => 'form-control TimeStart hour-minute','id'=>'TimeStart'.$i]) !!}
								</td>

								<td>
									{!! Form::text('OrdersTime['.$i.'][TimeEnd]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeEnd : '', ['class' => 'form-control TimeEnd hour-minute','id'=>'TimeEnd'.$i]) !!}
								</td>

								<td>
									{!! Form::text('OrdersTime['.$i.'][TimeBreak]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeBreak : '', ['class' => 'form-control TimeBreak hour-minute','id'=>'TimeBreak'.$i]) !!}
								</td>

								<td>
									{!! Form::text('OrdersTime['.$i.'][Payment]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->Payment : '', ['class' => 'form-control Payment number-comma','id'=>'Payment'.$i]) !!}
								</td>

								<td>
									{!! Form::text('OrdersTime['.$i.'][Claim]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->Claim : '', ['class' => 'form-control Claim number-comma','id'=>'Claim'.$i]) !!}
								</td>
								<td>
									{!! Form::select('OrdersTime['.$i.'][TimeWorkings]', array('5' => '5時間', '5.3' => '5時間30分
									', '6' => '6時間','6.3'=>'6時間30分','7' => '7時間','7.3'=>'7時間30分','8' => '8時間','8.3'=>'8時間30分','9' => '9時間','9.3'=>'9時間30分','10' => '10時間'),isset($orderstime[$i-1]) ? $orderstime[$i-1]->TimeWorkings : '8',['class' => 'form-control']) !!}
								</td>

								<td>
									{!! Form::text('OrdersTime['.$i.'][Note]',isset($orderstime[$i-1]) ? $orderstime[$i-1]->Note : '', ['class' => 'form-control Note ','id'=>'Note'.$i]) !!}
									<input type="hidden" value="{{$i}}" name="OrdersTime[{{$i}}][Name]">
								</td>

							</tr>
							@endfor
						</table>

						<div class="working-registration">
							<button type="button" class="btn btn-default btn-lg button-submit" id="generate-btn" style="float:right;margin-bottom:15px;">勤務日登録</button>
						</div>

						<div id="generate-content">
							@foreach( $orderDates as $key => $value )
							<h3>勤務日の登録</h3>
							<table class="table table-responsive table-bordered table-box-2 date-table generate-table">
								<tr>
									<th>日付</th>
									<th>勤務要否</th>
									<th>人数</th>
									<th>特記事項</th>
								</tr>
								@foreach( $value as $dkey => $orderDate )
								<tr>
									<td>
										<input type="hidden" name="OrdersDate[{{$key}}][{{$dkey}}][DateOrderId]" value="{{$orderDate->DateOrderId}}"/>
										<input type="hidden" name="OrdersDate[{{$key}}][{{$dkey}}][Date]" value="{{$orderDate->Date}}"/>
										{{date('m/d', strtotime($orderDate->Date))}}
									</td>
									<td><input type="checkbox"  name="OrdersDate[{{$key}}][{{$dkey}}][WorkNecessity]" value="{{$orderDate->WorkNecessity}}" {{$orderDate->WorkNecessity == 1 ? 'checked="checked"' : ''}}" /></td>
									<td><input type="text" value="{{$orderDate->NumberPeople}}" class="form-control NumberPeople number-people" name="OrdersDate[{{$key}}][{{$dkey}}][NumberPeople]"  /></td>
									<td><input type="text" class="form-control" value="{{$orderDate->Notices}}" name="OrdersDate[{{$key}}][{{$dkey}}][Notices]"/></td>
								</tr>
								@endforeach
							</table>
							@endforeach
						</div>

						<table class="table table-responsive table-bordered table-box-3" >

							<tr>
								<td>請求総額</td>
								<td>支払総額</td>
								<td>特別広告</td>
								<td>粗利</td>
								<td></td>	
							</tr>
							<tr>
								<td><input type="text" class="form-control sum-money-2" name="TotalClaims" value="<?php echo $order->TotalClaims; ?>" ></td>
								<td><input type="text" class="form-control sum-money-1" name="TotalPay" value="<?php echo $order->TotalPay; ?>"  ></td>
								<td><input type="text" class="form-control sum-money-3" name="TotalServices" value="<?php echo $order->TotalServices; ?>"  ></td>
								<td><input type="text" class="form-control sum-money-total" name="SumTotal" value="<?php echo $order->SumTotal; ?>"  ></td>
								<td><button class="btn btn-default btn-lg button-money" type="button">計算する</button></td>	
							</tr>

							<tr>
								<td>
									<?php if($order->Status=="下書き"){?>
									<button class="btn btn-default btn-lg update-status">更新</button>
									<?php }elseif($order->Status=="承認待"){?>
									<button class="btn btn-default btn-lg update-status" disabled>更新</button>
									<?php }else{?>
									<button class="btn btn-default btn-lg update-status" disabled>更新</button>
									<?php }?>

								</td>
								<td colspan="3">
									<div class="box-1-people-time" style="margin-bottom:50px">
										<div class="col-md-3">最終更新</div>
										<?php $datenow = date("Y/m/d H:i:s")?>
										<div class="col-md-9">
										  <input type="text" name="LastUpdateTime" class="form-control" value="<?php echo $datenow ?>" disabled ></div>
										<input type="hidden" name="LastUpdateTime" class="form-control" value="<?php echo $datenow ?>">
										</div>

									</div>
									<div class="box-1-people-person">
										<div class="col-md-3">最終更新者</div>
										<div class="col-md-9">
										  <input type="text" name="LastUpdatePerson" class="form-control LastUpdatePerson" value="<?php echo  $order->Contractor; ?>" disabled>
										 </div>
										<input type="hidden" name="LastUpdatePerson" class="form-control LastUpdatePerson" value="<?php echo $order->Contractor; ?>"></div>
									</div>
								</td>
								<tr>
									<td>担当上長</td>
									<td colspan="3">
										<select name="PeppleApproal" class="form-control">
											<option value=''>-- 選択してください --</option>
											<?php 
											foreach ($roles as $role) {
												?>
												<option value="<?php echo $role->id ;?>"><?php echo $role->Firstname . ' ' . $role->Lastname ; ?></option>

												<?php 
											}
											?>
										</select>
									</td>
								</tr>
							</tr>

							<tr>
								<td>		
									<?php if($order->Status=="下書き"){?>
									<button type="button" class="btn btn-default btn-lg update-request" data-toggle="modal" data-target="#myModal">承認依頼</button>
									<?php }else{ ?>
									<button type="button" class="btn btn-default btn-lg update-request" data-toggle="modal" data-target="#myModal" disabled>承認依頼</button>
									<?php } ?>
								</td>
								<td colspan="3">
									<div class="box-2-people-time" style="margin-bottom:50px">
										<div class="col-md-3">承認依頼</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalRequestTime" class="form-control" value="<?php echo $datenow ?>" disabled>
											<input type="hidden" name="ApprovalRequestTime" class="form-control" value="<?php echo $datenow ?>" >
										</div>

									</div>
									<div class="box-2-people-person" style="margin-bottom:15px;overflow:hidden">
										<div class="col-md-3">承認依頼者</div>
										<div class="col-md-9">

											<input type="text" name="ApprovalRequester" class="form-control ApprovalRequester" value="<?php echo auth()->guard('admin')->user()->name; ?>" disabled>
											<input type="hidden" name="ApprovalRequester" class="form-control ApprovalRequester" value="<?php echo auth()->guard('admin')->user()->name; ?>">
										</div>
									</div>
									<div class="box-2-people-commet">
										<div class="col-md-3">コメント</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalRequestComment" class="form-control" value="<?php echo $order->ApprovalRequestComment; ?>" disabled>
										</div>
									</div>
								</td>
							</tr>

							<tr>
								<td>
									<div class="col-md-4 nonePaddingLeft">
										<?php if($order->Status=='承認待'){?>
										<button class="btn btn-default btn-lg change-status" data-toggle="modal" type="button" data-target="#myModalChangeStatus">承認</button>
										<?php } else {?>
										<button class="btn btn-default btn-lg change-status" disabled data-toggle="modal" type="button" data-target="#myModalChangeStatus" disabled >承認</button>
										<?php } ?>
									</div>

									<div class="col-md-4 nonePaddingLeft">
										<?php if($order->Status=='下書き'){?>
										<button class="btn btn-default btn-lg update-status-return" >否認</button>
										<?php } elseif ($order->Status=='承認待'){?>
										<button class="btn btn-default btn-lg  update-status-return">否認</button>
										<?php } ?>
									</div>
								</td>
								<td colspan="3">
									<div class="box-2-people-time" style="margin-bottom:50px">
										<div class="col-md-3">承認状態</div>
										<div class="col-md-9 approval-status-add">
											<?php $datenow = date("Y/m/d H:i:s")?>
											<input type="text" name="Status" class="form-control remove-status" value="<?php echo $order->Status;  ?>" disabled>
											<input type="hidden" name="Status" class="form-control remove-status" value="<?php echo $order->Status;  ?>" >
										</div>

									</div>
									<div class="box-2-people-person" style="margin-bottom:15px;overflow:hidden">
										<div class="col-md-3">担当者</div>
										<div class="col-md-9">
											<input type="text" name="PersonCharge" class="form-control" value="<?php echo auth()->guard('admin')->user()->name; ?>" disabled>
											<input type="hidden" name="PersonCharge" class="form-control" value="<?php echo auth()->guard('admin')->user()->name; ?>">
										</div>
									</div>
									<div class="box-2-people-commet">
										<div class="col-md-3">コメント</div>
										<div class="col-md-9">
											<input type="text" name="ApprovalComment" class="form-control" value="<?php echo $order->ApprovalComment; ?>" disabled>
											<input type="hidden" name="ApprovalComment" class="form-control" value="<?php echo $order->ApprovalComment; ?>">
										</div>
									</div>
								</td>
							</tr>

						</table>

						<table class="table table-responsive table-bordered" >
							<tr>
								<td>受注者(営業) コメント<span class="required"> *</span></td>
								<td colspan="3">
									{!! Form::text('ContractorComments',$demandRegard->ContractorComments, ['class' => 'form-control']) !!}
								</td>
							</tr>
							<tr>
								<td>対象年齢</td>
								<td colspan="3">
									<div class="col-md-5 nonePaddingLeft">
										{!! Form::select('AgeStart',$ageStart ,$demandRegard->AgeStart,['class' => 'form-control']) !!}
									</div>
									<div class="col-md-1">〜</div>
									<div class="col-md-5 nonePaddingLeft">
										{!! Form::select('AgeEnd',$ageEnd ,$demandRegard->AgeEnd,['class' => 'form-control']) !!}
									</div>

								</td>
							</tr>
							<tr>
								<td>性別</td>
								<td colspan="3">
									<input type="checkbox" name="SexNam"  value="0" <?php if($demandRegard->SexNam=='0'){
										echo 'checked="checked"'; }?>
										> 男性
										<input type="checkbox" name="SexNu"  value="1" <?php if($demandRegard->SexNu=='1'){
											echo 'checked="checked"'; }?>
											> 女性
										</td>
									</tr>
									<tr>
										<td rowspan="3">条件</td>
										<td>必須</td>
										<td>
											{!! Form::textarea('Required', $demandRegard->Required, ['class' => 'form-control']) !!}
										</td>
									</tr>
									<tr>
										<td>優先</td>
										<td>
											{!! Form::textarea('Priority', $demandRegard->Priority, ['class' => 'form-control']) !!}
										</td>

									</tr>
									<tr>
										<td>レジ</td>
										<td>

											<input type="radio" name="CashRegister" value="0" 
											<?php if($demandRegard->CashRegister=='0'){
												echo 'checked="checked"' ;
											}
											?> > 有
											<input type="radio" name="CashRegister" value="1"
											<?php if($demandRegard->CashRegister=='1'){
												echo 'checked="checked"' ;
											}
											?>
											>
											無
										</td>

									</tr>

								</table>


								<div class="button-group btn-button">
									<button class="btn btn-default btn-lg button-submit" type="button">{{ trans('title.order.submit') }}</button> 
								</div>



								<div id="myModal" class="modal fade" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content update-request-order">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">承認依頼</h4>
											</div>
											<div class="modal-body">
												<td colspan="3">
													<div class="box-2-people-commet">
														<div class="col-md-3">コメント</div>
														<div class="col-md-9">
															<input type="text" name="ApprovalRequestComment" class="form-control" value="<?php echo $order->ApprovalRequestComment; ?>">
														</div>
													</div>
												</td>
											</div>
											<div class="modal-footer">
												<button class="btn btn-default btn-lg update-request">承認依頼</button>
												<button type="button" class="btn btn-default btn-lg" data-dismiss="modal">キャンセル</button>
											</div>
										</div>

									</div>
								</div>

								<div id="myModalChangeStatus" class="modal fade" role="dialog">
									<div class="modal-dialog">

										<!-- Modal content-->
										<div class="modal-content update-request-order">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
												<h4 class="modal-title">承認</h4>
											</div>
											<div class="modal-body">
												<td colspan="3">
													<div class="box-2-people-commet">
														<div class="col-md-3">コメント</div>
														<div class="col-md-9">
															<input type="text" name="ApprovalComment" class="form-control" value="<?php echo $order->ApprovalComment; ?>">
														</div>
													</div>
												</td>
											</div>
											<div class="modal-footer">
												<button class="btn btn-default btn-lg change-status">承認</button>
												<button type="button" class="btn btn-default btn-lg" data-dismiss="modal">キャンセル</button>
											</div>
										</div>

									</div>
								</div>




								{!! Form::close() !!}

								<div class="col-md-12" style="margin-top:30px">
									<div class="col-md-2">コメント</div>
									<div class="col-md-8"><input name="CommentId" class="form-control"/></div>
									<div class="col-md-2">
										<button class="btn btn-default btn-lg button-submit comment-submit-btn" type="button">コメント追加</button>
									</div>
								</div>

								<div class="comment-list col-md-12">
										<div class="col-md-12">
											<div class="col-md-2"></div>
											<div class="col-md-8">
												<?php
												foreach ($orderComments as $orderComment) {
												?>
												<div class="comment-contents col-md-4"><?php echo $orderComment->CommentContent?></div>
												<div class="people-comment col-md-4"><?php echo auth()->guard('admin')->user()->name; ?></div>
												<div class="people-comment col-md-4"><?php echo $orderComment->created_at;?></div>	
												<?php }?>
											</div>
										</div>
								</div>


							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		@endsection
		@section('page_js')
		<script src="{{ asset('plugins/bootstrap/js/moment.js') }}"></script>
		<script src="{{ asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') }}"></script>
		<script type="text/javascript">
			$(function () {
				$('#datetimepicker').datetimepicker({
					format: 'YYYY/MM/DD',
				});
				$('#datetimepicker1').datetimepicker({
					format: 'YYYY/MM/DD',
				});
				$('#datetimepicker2').datetimepicker({
					format: 'YYYY/MM/DD',
				});
			});
		</script>
		<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
		<script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
		<script src="{{ asset('js/site/user/order.create.js') }}"></script>
		@endsection