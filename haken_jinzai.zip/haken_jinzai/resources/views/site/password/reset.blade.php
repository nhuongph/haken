<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>{!! trans('title.pwd.reset_pwd.title') !!}</title>

        <!-- Bootstrap Core CSS -->
        <link href="{{ asset('plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="{{ asset('plugins/sb-admin/css/sb-admin-2.css') }}" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="{{ asset('plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
        <!-- jQuery -->
        <script type="text/javascript" src="{{ asset('plugins/jquery/jquery-2.1.4.min.js') }}"></script>
        <script src="{{ asset('js/site/password.js') }}" type="text/javascript"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                        <div class="panel-heading">
                        </div>
                        <div class="panel-body">
                            {!! Form::open(array('url' => 'password/reset','class'=>'form-signin','onsubmit'=>'return checkForm(this)')) !!}
                            <div class="form-group">
                                {!! Form::label('passwordOld',Lang::get('title.pwd.reset_pwd.label.mes_3')) !!}
                                {!! Form::hidden('email',$email) !!}
                            </div>
                            @include('site/message/index')
                            <div class="form-group">
                                {!! Form::label('passwordOld',Lang::get('title.pwd.reset_pwd.label.lb_pass')) !!}                                
                                {!! Form::password('passwordOld', ['class' => 'form-control','required'=>'','minlength'=>'6']) !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('passwordNew',Lang::get('title.pwd.reset_pwd.label.lb_pass_new')) !!}
                                {!! Form::password('passwordNew',  ['class' => 'form-control','required'=>'','id'=>'password','minlength'=>'6']) !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('passwordNew_confirmation',Lang::get('title.pwd.reset_pwd.label.lb_pass_new_re')) !!}
                                {!! Form::password('passwordNew_confirmation', ['class' => 'form-control','required'=>'','id'=>'confirm_password','minlength'=>'6']) !!}
                            </div>
                            <div class="form-group">
                                <div class="button-group">
                                    {!! Form::submit(Lang::get('title.pwd.reset_pwd.button.reset'),['class' => 'btn btn-lg btn-success btn-block','id'=>'submit']) !!}
                                </div>
                            </div>
                            {!! Form::close() !!}<!-- /form -->
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Bootstrap Core JavaScript -->
        <script type="text/javascript" src="{{ asset('plugins/bootstrap/js/bootstrap.min.js') }}"></script>

    </body>
</html>