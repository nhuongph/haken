@extends('site/layouts/main')

@section('title')
{{ trans('title.payment.list') }}
@endsection



@section('content')
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    {{ trans('title.payment.list') }}
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        @include('site/message/index')
                         <div class="basic-form">
                            <div class="brand-list-title-button ">
                                
                            {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal', 'method' => 'GET']) !!}
														<div class="payment-search-wapper">
	                            <div class="col-md-12 payment-search">
	                            	<div class="payment-search-box-1 col-md-3">
	                            		<h3>公開範囲</h3>
	                            		<select class="form-control" name="projectName">
                                            <option value="-1">すべて</option>
	                            			 <?php foreach($projectBasicInfos as $projectBasicInfo){?>
                                            <option value="<?php echo $projectBasicInfo->DisplayStatus ?>">
                                                <?php if($projectBasicInfo->DisplayStatus==1){
                                                    echo "短期";
                                                }else{
                                                    echo "単発";
                                                }
                                                    ?></option>
                                                
                                            <?php }?>
	                            		</select>
	                            	</div>
	                            	<div class="payment-search-box-1 col-md-3">
	                            		<h3>期間</h3>
	                            		<select class="form-control" name="AddressCompany">
                                            <option value="-1">すべて</option>
                                            <?php foreach($payments as $payment){?>
	                            			<option value="<?php echo $payment->PeriodDivision?>"><?php echo $payment->PeriodDivision?></option>
                                            <?php }?>
	                            		</select>
	                            	</div>
	                            	<div class="payment-search-box-1 col-md-3">
	                            		<h3>ブランド</h3>
	                            		<select class="form-control" name="Brand">
                                            <option value="-1">すべて</option>
	                            			<?php foreach($payments as $payment){?>
                                            <option value="<?php echo $payment->Brand?>"><?php echo $payment->Brand?></option>
                                            <?php }?>
	                            		</select>
	                            	</div>
	                            	<div class="col-md-3">
	                            		<button  class="btn btn-default btn-lg col-md-12">検索</button>
	                            	</div>
	                            </div>
                           
                            
                            <?php foreach ($paymentLists as $paymentList){?>
                            <div class="box-list-search col-md-12">
                            	<div class="col-md-4">
                            			<div class="electrical-appliances"><?php echo $paymentList->CategoryJob; ?></div>
                            			<h3><?php echo $paymentList->ProjectName; ?></h3>
                            			<div><?php echo $paymentList->EmploymentDestinationId; ?></div>
                            			<div>契約期間</div>
                            			<div class="date-orders">
                                            <?php $datestart = date_create($paymentList->BeginContract) ; 
                                                  $dateend   = date_create($paymentList->EndContract) ; 
                                            ?>
                                            <?php echo date_format($datestart,"m/d").'〜'; echo date_format($dateend,"m/d");?>
                                        </div>
                            	</div>

                            	<div class="col-md-6">
                            		<table class="table table-responsive table-bordered">
                            			<tr>
                            				<td>公開範囲</td>
                            				<td>公開範囲</td>
                            			</tr>
                            			<tr>
                            				<td>期間</td>
                            				<td><?php echo $paymentList->PeriodDivision; ?></td>
                            			</tr>
                            			<tr>
                            				<td>ブランド</td>
                            				<td><?php echo $paymentList->Brand; ?></td>
                            			</tr>
                            		</table>
                            		
                            	</div>

                            	<div class="col-md-2">
                            		<button class="col-md-12 btn btn-default payment-list-button-submit">スタッフ別</button>
                            		<button class="col-md-12 btn btn-default payment-list-button-submit">総合</button>
                            	</div>
                            </div>

                            <?php } ?>

                             </div>
                            
                           

                           {!! Form::close() !!}

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

