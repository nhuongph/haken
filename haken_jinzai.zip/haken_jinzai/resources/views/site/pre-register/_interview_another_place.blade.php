<div class="col-md-12 nonePaddingRight nonePaddingLeft">
    @foreach($anotherTimes as $anotherTime)
        <table class="table table-bordered">
          <tr class="row">
                <td  class="text-center col-md-2">
                    {{ $anotherTime->RegionName }} <br>
                    
                    {{ '('.$anotherTime->InterviewPeople.'名)' }} <br>
                    <!--{{ $anotherTime->ResponsibleName }}-->
                </td>
                <td id="anotherInterview_{{$anotherTime->AnotherInterviewTimeID}}" class="col-md-10">
                    @foreach($anotherTime->AnotherInterview as $anotherInterview)
                        <?php $staff = $staffBusiness->getStaffById($anotherInterview->StaffId) ?>
                        @if(count($staff) > 0)
                        <div class="text-center col-md-3 col-sm-3 schedule_list">
                            {{ $staff->Name }} <br>
                            {{ $staff->Email }} <br>
                            {{ $staff->Mobile }} <br>
                            希望時間:{{$anotherInterview->Hour}}
                            <i onclick="return removeAnotherSchedule({{$anotherInterview->AnotherInterviewId}})" class="fa fa-times remove_schedule" style="display:none" aria-hidden="true"></i>
                        </div>
                        @endif
                    @endforeach
                    
                    <div class="text-center col-md-2 col-sm-3 add_schedule" style="display: none">
                        <button onclick="return changeAnotherInterviewTimeId({{$anotherTime->AnotherInterviewTimeID}})" class="btn btn-default" role="button" data-toggle="modal" data-target="#another_search_staff">{{ trans('title.action.add') }}</button>
                    </div>
                </td>
            </tr>
        </table>
    @endforeach
</div>

<div class="modal fade" id="another_search_staff" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">{{ trans('title.interview-schedule.label.AddSchedule') }}</h4>
            </div>
            <div class="modal-body">
                {!! Form::open() !!}
                <div class="input-group marginBottom5">
                    {!! Form::text('another_staff_info',null,['id'=>'another_staff_info','class'=>'form-control']) !!}
                    <span class="input-group-btn">
                        <button onclick="return anotherSearchStaff()" id="search_staff" class="btn btn-secondary" type="button">{{ trans('title.action.search') }}</button>
                    </span>
                    {!! Form::hidden('anotherInterviewTimeId',null,['id'=>'anotherInterviewTimeId']) !!}
                </div>
                {!! Form::close() !!}
                <div id="another_search_result">
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="return addAnotherStaff()" type="button" class="btn btn-default" data-dismiss="modal">{{ trans('title.action.add') }}</button>
            </div>
        </div>
    </div>
</div>