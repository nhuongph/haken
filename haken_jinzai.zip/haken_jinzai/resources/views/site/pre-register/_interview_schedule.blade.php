<div class="col-md-12 nonePaddingRight nonePaddingLeft">
    @foreach($times as $time)
        <table class="table table-bordered">
            <tr>
                <td width="10%" class="text-center">
                    {{ date('H:i', strtotime($time->InterviewTime)) }}<br>
                    ({{ $time->InterviewPeople .'名' }})
                </td>
                <td id="interview_{{$time->InterviewTimeId}}">              
                    @foreach($time->Interview as $interview)
                        <?php $staff = $staffBusiness->getStaffById($interview->StaffId) ?>                   
                        @if(count($staff) > 0)
                        <div class="text-center col-md-2 col-sm-3 schedule_list">
                            {{ $staff->Name }} <br>
                            {{ $staff->Email }} <br>
                            {{ $staff->Mobile }}
                            <i onclick="return removeSchedule({{$interview->InterviewID}})" class="fa fa-times remove_schedule" style="display:none" aria-hidden="true"></i>
                        </div>
                        @endif
                    @endforeach
                    <div class="text-center col-md-2 col-sm-3 add_schedule" style="display: none">
                        <button onclick="return changeInterviewTimeId({{$time->InterviewTimeId}})" class="btn btn-default" role="button" data-toggle="modal" data-target="#search_staff">{{ trans('title.action.add') }}</button>
                    </div>
                </td>
            </tr>
        </table>
    @endforeach
</div>

<div class="modal fade" id="search_staff" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">{{ trans('title.interview-schedule.label.AddSchedule') }}</h4>
            </div>
            <div class="modal-body">
                {!! Form::open() !!}
                <div class="input-group marginBottom5">
                    {!! Form::text('staff_info',null,['id'=>'staff_info','class'=>'form-control']) !!}
                    <span class="input-group-btn">
                        <button onclick="return searchStaff()" id="search_staff" class="btn btn-secondary" type="button">{{ trans('title.action.search') }}</button>
                    </span>
                    {!! Form::hidden('interviewTimeId',null,['id'=>'interviewTimeId']) !!}
                </div>
                {!! Form::close() !!}
                <div id="search_result">
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="return addStaff()" type="button" class="btn btn-default" data-dismiss="modal">{{ trans('title.action.add') }}</button>
            </div>
        </div>
    </div>
</div>