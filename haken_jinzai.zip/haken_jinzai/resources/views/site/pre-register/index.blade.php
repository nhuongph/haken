@extends('site/layouts/main')
@section('title')
{{ trans('title.pre-register.management') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">{{trans('breadcrumb.pre-register.manage-menu')}}</li>
</ol>
</section>
@endsection
@section('content')
<div class="row text-setting pre-reg-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box box-info box-solid manage">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{!! trans('pre-register.manage.title-menu') !!}</b></h4>
            </div>            
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    @include('site.message.index')
                    <p class="text-right"><button class="btn btn-primary btn-lg pre-reg-manage-back-btn">
                        <i class="fa fa-step-backward"></i>
                        <span>{{ trans('common.button.back') }}</span>
                    </button></p>
                    <fieldset>
                        <div class="form-group">
                            <div class="button-group text-center">
                                <div class="">
                                    <a href="{{ route('pre-register/manage/interview/schedule') }}" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn">{{ trans('title.pre-register.interview_schedule') }}</a>
                                </div>
                                <div>
                                    <a href="{{ route('pre-register/manage/list') }}" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn">{{ trans('title.pre-register.pre-register_list') }}</a>
                                </div>
                                <div>
                                    <a href="{!! route('tokyokanagawa_list') !!}" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn">{{ trans('title.pre-register.interview_place') }}</a>
                                </div>
                                <div>
                                    <a href="{!! route('another_list') !!}" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn">{{ trans('title.pre-register.interview_other_place') }}</a>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
@endsection