<table id="scheduleNoPlace" class="table table-responsive" width="100%">
    <thead>
    <tr>
        <th width="10%" class="text-center">{{ trans('title.interview-schedule.label.Date') }}</th>
        <th class="text-center">{{ trans('title.interview-schedule.label.Schedule') }}</th>
    </tr>
    </thead>
</table>