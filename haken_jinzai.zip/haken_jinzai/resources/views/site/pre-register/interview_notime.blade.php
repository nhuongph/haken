<table id="scheduleNoTime" class="table table-responsive" width="100%">
    <thead>
        <tr>
            <th width="5%" class="text-center">No</th>
            <th class="text-center">面接希望者</th>
            <th class="text-center">コメント</th>
        </tr>
    </thead>
</table>

