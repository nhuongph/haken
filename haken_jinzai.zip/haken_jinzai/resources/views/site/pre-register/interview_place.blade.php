<table id="interviewSchedule" class="table table-responsive">
    <thead>
        <tr>
            <th width="10%" class="text-center">{{ trans('title.interview-schedule.label.Date') }}</th>
            <th class="text-center">{{ trans('title.interview-schedule.label.Schedule') }}</th>
        </tr>
    </thead>
</table>