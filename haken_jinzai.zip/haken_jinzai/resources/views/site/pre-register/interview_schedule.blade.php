@extends('site/layouts/main')
@section('title')
{{ trans('title.pre-register.interview_schedule') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="{{route('pre-register/manage')}}">{{trans('breadcrumb.pre-register.manage-menu')}}</a></li>
    <li class="active">{{trans('title.pre-register.interview_schedule')}}</li>
</ol>
</section>
@endsection
@section('content')
<div class="row text-setting pre-reg-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 list-interview-schedule">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{!! trans('title.pre-register.interview_schedule') !!}</b></h4>
            </div>
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    @include('site.message.index')
                    <div class="button-group text-right marginBottom10">
                        <button class="btn btn-primary btn-lg" id="edit_schedule">
                            <i class="fa fa-edit"></i>
                            <span>{{ trans('title.pre-register.edit') }}</span>
                        </button>
                        <button class="btn btn-primary btn-lg" id="cancel_schedule" style="display: none">{{ trans('common.button.confirm') }}</button>
                        <a href="{{ route('pre-register/manage') }}" class="btn btn-primary btn-lg btn-md" id="back_schedule">
                            <i class="fa fa-step-backward"></i>
                            {{ trans('title.pre-register.return') }}
                        </a>
                        <!--<button class="btn btn-primary btn-lg" id="cancel_schedule">{{ trans('title.pre-register.return') }}</button>-->
                    </div>

                    <div class="btn-group" role="group">
                      <button onclick="return interviewTable('東京')" type="button" class="btn btn-primary btn-lg btn-md">{{ trans('title.pre-register.tokyo') }}</button>
                      <button onclick="return interviewTable('神奈川')" type="button" class="btn btn-primary btn-lg btn-md">{{ trans('title.pre-register.kanagawa') }}</button>
                      <button onclick="return interviewTable('その他')" type="button" class="btn btn-primary btn-lg btn-md">{{ trans('title.pre-register.other') }}</button>
                      <button onclick="return interviewTable('時間外希望')" type="button" class="btn btn-primary btn-lg btn-md">{{ trans('title.pre-register.time_out_hope') }}</button>
                  </div>
                  {!! Form::hidden('region','東京',['id'=>'region']) !!}
                  <div class="layout-child-panel">
                    <div id="schedule_section">
                        @include('site/pre-register/interview_place')
                    </div>
                    <div id="schedule_other_place_section" style="display:none">
                        @include('site.pre-register.interview_another_place')
                    </div>
                    <div id="schedule_no_time_section" style="display:none">
                        @include('site/pre-register/interview_notime')
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
@section('page_js')
<script src="{{ asset('js/site/pre-register/interview_schedule.js') }}"></script>
@stop