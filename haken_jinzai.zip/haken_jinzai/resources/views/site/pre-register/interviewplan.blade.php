@extends('site.layouts.main')
@section('title')
Interview Plan
@endsection
@section('content')
<div class="row">
	<div class="col-md-6 top-buffer">面接予定</div>
	<div class="col-md-3 top-buffer">
		<button class="btn btn-default btn-block" type="button">編集</button>
	</div>
	<div class="col-md-3 top-buffer">
		<button class="btn btn-default btn-block" type="button">戻る</button>
	</div>
</div>
<div class="row top-buffer">	
	<div class="col-md-2">
		<button class="btn btn-default pull-right" type="button" id="Tokyo">東京</button>
	</div>
	<div class="col-md-2">
		<button class="btn btn-default pull-right" type="button" id="Kanagawa">神奈川</button>
	</div>
	<div class="col-md-2">
		<button class="btn btn-default pull-right" type="button" id="Another">その他</button>
	</div>
</div>
<div class="panel-body">

	<table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table">
		<thead>
			<tr>
				<th>InterviewID</th>
				<th>StaffID</th>
				<th>InterviewPlace</th>
				<th>AnotherPlace</th>
			</tr>
		</thead>
	</table>

</div>
@stop
@section('page_js')
	<script type="text/javascript" src="{{ asset('js/site/user/list.js') }}"></script>
@endsection