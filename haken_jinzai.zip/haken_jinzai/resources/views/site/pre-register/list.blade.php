@extends('site/layouts/main')
@section('title')
{{ trans('title.pre-register.list') }}
@endsection
@section('page_css')
<link href="{!! asset('css/common/text.css') !!}" rel="stylesheet">
<link href="{!! asset('css/common/layout_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="{{route('pre-register/manage')}}">{{trans('breadcrumb.pre-register.manage-menu')}}</a></li>
    <li class="active">{{ trans('title.pre-register.list') }}</li>
</ol>
</section>
@endsection
@section('content')
<div class="row text-setting pre-reg-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 list">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b>{{ trans('title.pre-register.list') }}</b></h4>
            </div>
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    @include('site.message.index')
                    <div class="row">
                        <div class="col-md-12 text-right marginBottom10">
                            <a href="{{route('pre-register/manage')}}" class="btn btn-primary btn-lg">
                                <i class="fa fa-step-backward"></i>
                                <span>{{ trans('common.button.back') }}</span>
                            </a>
                        </div>
                    </div>
                    <div class="layout-child-panel">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 marginBottom5">
                                <div class="text-title lbl-search">{{ trans('pre-register.list.lbl-title-search-interview-date') }}</div>
                                {!! Form::select('interviewDate',[''=>trans('pre-register.list.dll-select-interview-date')] + $selectDate,null,['class'=>'form-control']) !!}
                            </div>
                            <div class="col-md-4 col-sm-4 marginBottom5">
                                <div class="text-title lbl-search">{{ trans('pre-register.list.lbl-title-search-status') }}</div>
                                {!! Form::select('status',[''=>trans('pre-register.list.dll-select-status')] + $selectStatus,null,['class'=>'form-control']) !!}
                            </div>
                        </div>
                        <div class="row marginBottom5">
                            <div class="col-md-7 col-sm-7">
                                <div class="text-title lbl-search">{{ trans('pre-register.list.lbl-title-search-name') }}</div>
                                <div class="input-group marginBottom5">
                                    {!! Form::text('nameKey',null,['id'=>'nameKey','class'=>'form-control']) !!}
                                    <span class="input-group-btn">
                                        <button onclick="" id="search_staff" class="btn btn-secondary" type="button">
                                            <i class="fa fa-search"></i>
                                            <span>{{ trans('common.button.search') }}</span>
                                        </button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <table id="preRegisterList" class="table table-bordered table-responsive datatables_scroll">
                            <thead>
                                <tr>
                                    <th class="text-center" width="10%">{{ trans('pre-register.list.lbl-tb-title-name') }}</th>
                                    <th class="text-center" width="15%">{{ trans('pre-register.list.lbl-tb-title-image') }}</th>
                                    <th class="text-center">{{ trans('pre-register.list.lbl-tb-title-interview-day') }}</th>
                                    <th class="text-center">{{ trans('pre-register.list.lbl-tb-title-gender') }}</th>
                                    <th class="text-center">{{ trans('pre-register.list.lbl-tb-title-age') }}</th>
                                    <th class="text-center">{{ trans('pre-register.list.lbl-tb-title-status') }}</th>
                                    <th class="text-center"></th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('page_js')
<script src="{{ asset('js/site/pre-register/list.js') }}"></script>
@endsection