@extends('site.layouts.main')
@section('title')
User Management
@endsection
@section('content')
<div class="row">
	<div class="col-md-12 top-buffer">事前登録</div>
</div>
<hr/>
<div class="row top-buffer">	
	<div class="col-md-12"><button class="btn btn-default pull-right" type="submit">戻る</button></div>
</div>
<div class="row top-buffer">
	<div class="col-md-12">
		<button class="btn btn-default btn-block" type="submit">面接予定</button>
		<a href="{!! URL::route('interviewplan')!!}" class="btn btn-info" role="button">Link Button</a>
	</div>
</div>
<div class="row top-buffer">
	<div class="col-md-12"><button class="btn btn-default btn-block" type="submit">事前登録者一覧</button></div>
</div>
<div class="row top-buffer">
	<div class="col-md-12"><button class="btn btn-default btn-block" type="submit">東京・神奈川　面接枠管理</button></div>
</div>
<div class="row top-buffer">
	<div class="col-md-12"><button class="btn btn-default btn-block" type="submit">「その他」面接日登録</button></div>
</div>
@stop
@section('page_js')
	<script type="text/javascript" src="{{ asset('js/site/user/list.js') }}"></script>
@endsection