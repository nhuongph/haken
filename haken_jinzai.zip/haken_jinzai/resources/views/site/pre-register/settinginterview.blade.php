@extends('site.layouts.main')
@section('title')
{!! trans('pre-register.manage.interview.tokyo-register-title') !!}
@endsection
@section('page_css')
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
@endsection
@section('breadcrumb')
<section class="content-header">
	<h1><small></small></h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
		<li><a href="{{route('pre-register/manage')}}">{{trans('breadcrumb.pre-register.manage-menu')}}</a></li>
		<li><a href="{{route('tokyokanagawa_list')}}">{!! trans('pre-register.manage.interview.tokyo-register-title') !!}</a></li>
		<li class="active">{!! trans('pre-register.manage.interview.tokyo-register-title') !!}</li>
	</ol>
</section>
@endsection
@section('content')
<div class="row text-setting pre-reg-manage">
	<div class="col-lg-12 col-md-12 setting-interview">
		<div class="box box-info box-solid">
			<div class="box-header with-border">
				<h4 class="text-title"><b>{{ trans('title.pre-register.tokyo_kanagawa_list') }}</b></h4>
			</div>
			<div class="box-body">
				<div class="col-lg-12 col-md-12 col-sm-12 layout-child-panel">
					@include('site.message.index')
					{!! Form::open() !!}
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-3 si-col-title">{!! trans('title.pre-register.tokyo_kanagawa_labels.region_name') !!}</div>
						<div class="col-lg-9 col-md-9 col-sm-9">
							<select name="region" class="form-control">
								@foreach($regions as $region)
								@if($region->RegionId != 3)
								<option value="{!! $region->RegionId !!}">{!! $region->Name !!}</option>
								@endif
								@endforeach
							</select>
						</div>
					</div>				
					<div class="row si-top-buffer">
						<div class="col-lg-3 col-md-3 col-sm-3 si-col-title">{!! trans('title.pre-register.tokyo_kanagawa_labels.date') !!}</div>
						<div class="col-lg-9 col-md-9 col-sm-9">
							<div class="form-group">
								<div class='input-group date' id='datetimepicker_settinginterview'>
									<input type='text' class="form-control" name="interviewDate" value="{!! date("Y/m/d") !!}" />
									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>
							</div>

						</div>
					</div>
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-3 si-col-title">{!! trans('title.pre-register.tokyo_kanagawa_labels.interview_time') !!}</div>
						<div class="col-lg-9 col-md-9 col-sm-9">{!! Form::select('interviewHour', $interviewHour, "19:00", array('class'=>'form-control')) !!}</div>
					</div>
					<div class="row si-top-buffer">
						<div class="col-lg-3 col-md-3 col-sm-3 si-col-title">{!! trans('title.pre-register.tokyo_kanagawa_labels.interview_people') !!}</div>
						<div class="col-lg-9 col-md-9 col-sm-9">{!! Form::select('interviewPeople', $interviewPeople, 8, array('class'=>'form-control')) !!}</div>
					</div>
					<div class="row si-top-buffer">
						<div class="col-lg-3 col-md-3 col-sm-3 "></div>
						<div class="col-lg-9 col-md-9 col-sm-9 si-btn">
							<button type="submit" class="btn btn-primary">{!! trans('title.pre-register.register') !!}</button>
							<a href="{!!route('pre-register/manage')!!}" class="btn btn-primary">{!! trans('title.pre-register.cancel') !!}</a>
						</div>
					</div>
					{!! Form::close() !!}
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script type="text/javascript">
	$(function () {
		$('#datetimepicker_settinginterview').datetimepicker({
			format: 'YYYY/MM/DD',
			locale : 'ja'
		});
	});
</script>
{!! Form::close() !!}
@endsection