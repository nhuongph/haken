@extends('site/layouts/main')

@section('title')
{{ trans('title.report.index') }}
@endsection

@section('content')
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <div class="brand-list-page">
                            <a href="{{route('gaia/brand/list')}}" class="btn btn-default btn-lg return-brand-list">{{ trans('title.report.return') }}</a>
                        </div>
                        <div class="brand-list-page">
                        @include('site/message/index')
                         <div class="basic-form">
                            {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                            <table class="table table-responsive table-bordered">
                                <tr>
                                    <td>コメント欄に表示するタイトルを設定してください。</td>
                                </tr>
                                <tr>
                                    <td><input type="text" name="CommentContent" class="form-control"/></td>   
                                </tr>   
                            </table>
                            <div class="setting-report-center">
                                <button class="btn btn-default btn-lg">登録完了</button>
                            </div>
                           {!! Form::close() !!}

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

