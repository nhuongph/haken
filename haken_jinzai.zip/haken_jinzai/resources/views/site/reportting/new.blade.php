@extends('site/layouts/main')

@section('title')
{{ trans('title.report.index') }}
@endsection



@section('content')
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                </div>
                
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <div class="brand-list-page">
                          <a href="{{route('gaia/brand/list')}}" class="btn btn-default btn-lg return-brand-list">{{ trans('title.report.return') }}</a>
                        </div>
                         @include('site/message/index')
                         <div class="basic-form">
                            {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                            <table class="table table-responsive table-bordered">
                                <tr>
                                    <td>カテゴリー</td>
                                    <td>商品名</td>
                                    <td>単価</td> 

                                </tr>
                                <?php 
                                    for($i=1;$i<=50;$i++){
                                ?>
                                <tr>
                                    <td><input type="text" name="Report[{{$i}}][Category]" class="form-control"/></td>
                                    <td><input type="text" name="Report[{{$i}}][ProductName]" class="form-control"/></td>
                                    <td><input type="text" name="Report[{{$i}}][Price]" class="form-control"/></td>
                                </tr>
                                <?php       
                                    }
                                ?>


                            </table>
                            <div class="setting-report-center">
                                <button class="btn btn-default btn-lg">登録完了</button>
                            </div>
                           {!! Form::close() !!}

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

