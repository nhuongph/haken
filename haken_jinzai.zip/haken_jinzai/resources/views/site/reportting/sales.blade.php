@extends('site/layouts/main')

@section('title')
{{ trans('title.report.index') }}
@endsection

@section('content')
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        @include('site/message/index')
                         <div class="basic-form">
                            {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                                <?php foreach($salesLists as $salesList){?>
                                    <table class="table table-responsive table-bordered">
                                        <tr>
                                            <td>カテゴリー</td>
                                            <td>商品名</td>
                                            <td>単価</td>
                                        </tr>
                                        <tr>
                                            <td><?php echo $salesList->Category;?></td>
                                            <td><?php echo $salesList->Category;?></td>
                                            <td><?php echo $salesList->ProductName;?></td>   
                                        </tr>
                                        <tr>
                                            <td>販売数</td>
                                            <td><input type="text" class="form-control"/></td>
                                             <td>在庫数</td>
                                            <td><input type="text" class="form-control"/></td>   
                                        </tr>
                                    </table> 
                                <?php }?>  
                            
                            <button class="btn btn-default btn-lg">登録完了</button>
                           
                            {!! Form::close() !!}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

