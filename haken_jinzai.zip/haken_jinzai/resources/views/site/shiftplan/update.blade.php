@extends('site/layouts/main')
@section('title')
{{trans('title.shiftplan.business_detail')}}
@endsection

@section('page_css')

<link href="{!! asset('css/site/shift-plan/shift_plan.css') !!}" rel="stylesheet">

@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">{{trans('breadcrumb.project.business_management')}}</a></li>
    <li class="active">{{trans('breadcrumb.project.business_detail')}}</li>
</ol>
</section>
@endsection
@section('content')
<?php

use App\Business\ShiftPlanBusiness;
?>

<div class="row text-setting pre-reg-manage">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="box box-info box-solid manage">
                <div class="box-header with-border">
                    <h4 class="text-title"><b>{!! trans('title.user.basic_register.task_name.project_info_management') !!}</b></h4>
                </div>            
                <div class="box-body">
        <!-- List -->
        @include('site.menu.pre-register')
        @include('site/message/index')
        
         <button data-target="#search_staff" data-toggle="modal" role="button" class="btn btn-default col-md-2 col-xs-12  search-tab" onclick="" >{{ trans('title.shiftplan.addregister')}}</button>
         <div id='search-register' class="col-md-10 col-xs-12  well well-lg search-tab">

        </div>
        
        {!! Form::open(array( 'method' => 'POST')) !!}
        {!! Form::hidden('type',\Illuminate\Support\Facades\Input::get('type')) !!}
        <div id="table-submit-reponse" class="table-responsive  col-sm-12">


          <h2>{{ trans('title.shiftplan.shifttable')}} </h2>
          <table id="table-submit" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">

            @foreach ($dataTable as $row)
            <tr>
              @foreach ($row as $col)

              @if( strpos($col, '@') !== false ) 
              {{--*/ $dateWanted = explode('@', $col)[0] /*--}}
              {{--*/ $jobWanted = explode('@', $col)[1] /*--}}
              <th class="dragTo" data-cell="{{$col}}" data-maxpeople ="{{ShiftPlanBusiness::getMaxPeople($jobWanted ,$dateWanted)}}"> 
                
              <div class="cell-summary"></div>
            {!! ShiftPlanBusiness::renderWantedJob($dateWanted,$jobWanted,2) !!}
            </th>
            @else 
            <th  data-cell="{{$col}}" > 
              {{ $col}}
            </th>
            @endif

            @endforeach
            </tr>
            @endforeach              
          </table>
        </div>

        <div id="table-wanted-reponse" class="table-responsive  col-sm-12">
          <h2>{{ trans('title.shiftplan.application_situation')}} </h2>
          <table id="table-wanted" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">

            @foreach ($dataTable as $row)
            <tr>
              @foreach ($row as $col)

              <th class="{{$col}}" >  
                @if( strpos($col, '@') !== false ) 

                {{--*/ $dateWanted = explode('@', $col)[0] /*--}}
                {{--*/ $jobWanted = explode('@', $col)[1] /*--}}
                {!! ShiftPlanBusiness::renderWantedJob($dateWanted,$jobWanted) !!}

                @else 
                {{ $col}}
                @endif
              </th>
              @endforeach
            </tr>
            @endforeach              
          </table>
        </div>
        <a href="{{ route('shift-plan/update',['orderId'=>$orderId]) }}" id="btn-submit" class="btn btn-default btn-lg col-xs-6">{{ trans('title.shiftplan.confirm') }}</a>
        <a href="" id="btn-clear" class="btn btn-default btn-lg col-xs-6">{{ trans('title.shiftplan.clear') }}</a>
        {{ Form::close() }}

      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="search_staff" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">{{ trans('title.shiftplan.staff_search')}}</h4>
      </div>
      <div class="modal-body">
        {!! Form::open() !!}
        <div class="input-group marginBottom5">
          {!! Form::text('staff_info',null,['id'=>'staff_info','class'=>'form-control']) !!}
          <span class="input-group-btn">
            <button onclick="return searchStaff()" id="search_staff" class="btn btn-secondary" type="button">{{ trans('title.staff.search')}}</button>
          </span>
          {!! Form::hidden('interviewTimeId',null,['id'=>'interviewTimeId']) !!}
        </div>
        {!! Form::close() !!}
        <div id="search_result">
        </div>
      </div>
      <div class="modal-footer">
        <button onclick="return addStaff()" type="button" class="btn btn-default" data-dismiss="modal">{{ trans('title.shiftplan.regular_registration')}}</button>
      </div>
    </div>
  </div>
</div>

@section('page_js')

<script type="text/javascript" src="{{ asset('js/common/jquery-ui.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('js/site/shift-plan/shift-plan-update.js') }}"></script>
 
@endsection
@stop