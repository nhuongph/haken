@extends('site/layouts/main')
@section('title')
    {{trans('title.shiftplan.business_detail')}}
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="#">{{trans('breadcrumb.project.business_management')}}</a></li>
    <li class="active">{{trans('breadcrumb.project.business_detail')}}</li>
</ol>
</section>
@endsection
@section('content')
<?php
use App\Business\ShiftPlanBusiness;
?>

    <div class="row text-setting pre-reg-manage">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="box box-info box-solid manage">
                <div class="box-header with-border">
                    <h4 class="text-title"><b>{!! trans('title.user.basic_register.task_name.project_info_management') !!}</b></h4>
                </div>            
                <div class="box-body">
                    <!-- List -->
                    @include('site.menu.pre-register')
                    @include('site/message/index')
                    
                    
                    {!! Form::open(array( 'method' => 'POST')) !!}
                    {!! Form::hidden('type',\Illuminate\Support\Facades\Input::get('type')) !!}
                    <div class="table-responsive  col-sm-12">
                    <a href="{{ route('shift-plan/update',['orderId'=>$orderId]) }}" class="btn btn-default btn-lg">{{ trans('title.shiftplan.shifttable')}}</a>
                    <table  class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">
                        
                        @foreach ($dataTable as $row)
                            <tr>
                                @foreach ($row as $col)
                                    
                                    <th>  
                                      @if( strpos($col, '@') !== false ) 
                                      
                                      {{--*/ $dateWanted = explode('@', $col)[0] /*--}}
                                      {{--*/ $jobWanted = explode('@', $col)[1] /*--}}
                                      {!! ShiftPlanBusiness::renderWantedJob($dateWanted,$jobWanted) !!}
                                      
                                      @else 
                                      {{ $col}}
                                    @endif
                                    </th>
                                @endforeach
                            </tr>
                        @endforeach              
                    </table>
                    </div>
                    <div class="form-group">

                 
                    </div>
                    {{ Form::close() }}
                    
                </div>
            </div>
        </div>
    </div>
    
@stop