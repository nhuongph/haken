@extends('site/layouts/main')
@section('title')
{{ trans('title.pre-register.information_detail') }}
@endsection
@section('page_css')
<link href="{{ asset('plugins/simple_loop_jquery_slider/css/simple-slider.css') }}" rel="stylesheet">
<link href="{{ asset('plugins/simple_loop_jquery_slider/css/simple-slider-volume.css') }}" rel="stylesheet">
@endsection
@section('content')
<br>
<div class="row">
  <div class="col-lg-12 col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4>{{ trans('title.pre-register.information_detail') }}</h4>
      </div>
      <div class="panel-body">
        <div class="col-lg-12 col-md-12 col-sm-12">
          @include('site.message.index')
          <table class="table table-responsive table-bordered">
            <tr>
              <td colspan="4" width="80%">
                <div class="form-group">
                  <div class="col-md-9">
                    <span class="help-block">{{ trans('title.pre-register.upload_resume') }}</span>
                  </div>
                  <div class="col-md-3 text-center">
                    {!! Form::open(['url' => URL::to('/staff/download/skill-sheet')]) !!}
                    {!! Form::hidden('staffName', $staff->Name) !!}
                    {!! Form::hidden('staffId', $staffId) !!}
                    <button class="btn btn-default">スキルシートダウンロード</button>
                    {!! Form::close() !!}
                  </div>
                </div>
              </td>
              <td class="text-center">
                <button type="button" class="btn btn-default edit">{{ trans('title.pre-register.edit') }}</button>
                <a href="{{ route('pre-register/manage/list') }}" type="button" class="btn btn-default">{{ trans('title.pre-register.return') }}</a>
              </td>
            </tr>
            {!! Form::open(['files'=>true]) !!}
            <tr>
              <td width="20%"  rowspan="2">
                @if($staff->SubStaff->Image > 0)
                <img src="{{ asset($staff->SubStaff->Resource->Path) }}" class="detail-thumbnail img-responsive">
                @endif
              </td>
              <td class="text-center" width="20%"  rowspan="2">
                {{ $staff->Name }}<br>
                {{ $staff->NameFurigana }}
              </td>
              <td class="text-center">
                {{ trans('title.pre-register.gender') }}
              </td>
              <td class="text-center">
                {{ trans('title.pre-register.age') }}
              </td>
              <td class="text-center">
                {{ trans('title.pre-register.update_by') }}
              </td>
            </tr>
            <tr>
              <td class="text-center">{{ $staff->Sex == 1 ? trans('title.pre-register.male') : trans('title.pre-register.female') }}</td>
              <td class="text-center">
                {{ $age }}
              </td>
              <td class="text-center">
                {{ $staff->ContactName }}
              </td>
            </tr>
            <tr>
              <td class="text-center">{{ trans('title.pre-register.interviewer') }}</td>
              <td class="text-center">{{ trans('title.pre-register.interview_day') }}</td>
            </tr>
            <tr>
              <td class="text-center">
                {!! Form::select('interviewer',[''=>'-- Select Interviewer--']+$interviewers,$staff->Interviewer,['class'=>'form-control']) !!}
              </td>
              <td class="text-center">
                <div class="input-group date marginBottom5">
                  {!! Form::text('interviewDate', $staff->InterviewDate ? $staff->InterviewDate : $interviewDate , ['id'=>'interviewDate','class'=>'form-control']) !!}
                  <span class="input-group-addon">
                    <span class="glyphicon glyphicon-calendar"></span>
                  </span>
                </div>
              </td>
            </tr>
          </table>
          <div class="row">
            <h4>タグ</h4>
            <div class="tag_section col-md-12">
              <ul class="tag_list nonePaddingLeft">

                @foreach($staff->SubStaff->TagArray as $key => $value)
                <li>
                  {!! Form::checkbox($key, 1, $staff->SubStaff->$key ) !!} {{$value}}
                </li>
                @endforeach

              </ul>
            </div>
          </div>
          <div class="row registration_division">
            <div class="form-group">
              <h4>{{ trans('title.pre-register.registration_division') }}</h4>
              <div class="col-md-4">
                {!! Form::select('selectRank', [''=>trans('title.selectbox.please_select')]+$selectRank, $staff->SubStaff->RankType,['class'=>'form-control']) !!}
              </div>
            </div>
          </div>
          <div class="row">
            <div class="evaluation_section col-md-12" style="display: none;">
              <table class="table table-bordered table-bordered">
                <thead>
                  <tr>
                    <th width="30%">{{ trans('title.pre-register.evaluation') }}</th>
                    <th width="15%">{{ trans('title.pre-register.total_score') }}</th>
                    <th class="text-center score">27点</th>
                    <th width="20%">{{ trans('title.pre-register.rank') }}</th>
                    <th class="text-center rank">
                    </th>
                    @if($staff->SubStaff->Rank == null || $staff->SubStaff->RankType != 1)
                    {!! Form::hidden('rank',null) !!}
                    @else
                    {!! Form::hidden('rank',$staff->SubStaff->Rank) !!}
                    @endif
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{{ trans('title.pre-register.appearance') }}</td>
                    <td>{!! Form::number('appearance',$staff->SubStaff->Appearance ? $staff->SubStaff->Appearance : 3,['class'=>'form-control evaluation','id'=>'appearance','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('appearance_volume',null,['id'=>'appearance_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.attitude') }}</td>
                    <td>{!! Form::number('attitude',$staff->SubStaff->Attitude ? $staff->SubStaff->Attitude : 3,['class'=>'form-control evaluation','id'=>'attitude','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('attitude_volume',null,['id'=>'attitude_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.expression') }}</td>
                    <td>{!! Form::number('expression',$staff->SubStaff->Expression ? $staff->SubStaff->Expression : 3,['class'=>'form-control evaluation','id'=>'expression','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('expression_volume',null,['id'=>'expression_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.personality') }}</td>
                    <td>{!! Form::number('personality',$staff->SubStaff->Personality ? $staff->SubStaff->Personality : 3,['class'=>'form-control evaluation','id'=>'personality','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('personality_volume',null,['id'=>'personality_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.admin_sale_experience') }}</td>
                    <td>{!! Form::number('admin_sale_experience',$staff->SubStaff->AdminExperience ? $staff->SubStaff->AdminExperience : 3,['class'=>'form-control evaluation','id'=>'admin_sale_experience','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('admin_sale_experience_volume',null,['id'=>'admin_sale_experience_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.sale_experience') }}</td>
                    <td>{!! Form::number('sale_experience',$staff->SubStaff->SaleExperience ? $staff->SubStaff->SaleExperience : 3,['class'=>'form-control evaluation','id'=>'sale_experience','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('sale_experience_volume',null,['id'=>'sale_experience_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.being_late') }}</td>
                    <td>{!! Form::number('being_late',$staff->SubStaff->BeingLate ? $staff->SubStaff->BeingLate : 3,['class'=>'form-control evaluation','id'=>'being_late','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('being_late_volume',null,['id'=>'being_late_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.willing') }}</td>
                    <td>{!! Form::number('willing',$staff->SubStaff->Willing ? $staff->SubStaff->Willing : 3,['class'=>'form-control evaluation','id'=>'willing','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('willing_volume',null,['id'=>'willing_volume']) !!}</td>
                  </tr>
                  <tr>
                    <td>{{ trans('title.pre-register.corresponding') }}</td>
                    <td>{!! Form::number('corresponding',$staff->Corresponding ? $staff->Corresponding : 3,['class'=>'form-control evaluation','id'=>'corresponding','max'=> 5]) !!}</td>
                    <td colspan="3">{!! Form::text('corresponding_volume',null,['id'=>'corresponding_volume']) !!}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div class="row">
            <div class="comment_section col-md-12">
              <div class="form-group">
                <label>{{ trans('title.pre-register.first_impression') }}</label>
                {!! Form::text('first_impression',$staff->SubStaff->FirstImpression,['class'=>'form-control']) !!}
              </div>
              <div class="form-group">
                <label>{{ trans('title.pre-register.comment') }}</label>
                {!! Form::textarea('comment',$staff->SubStaff->Comment,['class'=>'form-control','rows'=>4]) !!}
              </div>
            </div>
          </div>
          <!--Add Detail form update-->
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.phone') }}
            </td>
            <td>
              {!! Form::text('phone', $staff->Phone, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.fax') }}
            </td>
            <td>
              {!! Form::text('fax', $staff->Fax, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.mobile') }}
            </td>
            <td>
              {!! Form::text('mobile', $staff->Mobile, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.postal_code') }}<span class="required">*</span>
            </td>
            <td>
              <input type="text" name="postal_code" maxlength="8" value="{{ $staff->PostalCode ? $staff->PostalCode : null}}" class="form-control" onKeyUp="AjaxZip3.zip2addr(this, '', 'prefectural_name', 'commune');">
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.district_name') }}<span class="required">*</span>
            </td>
            <td>
              <input type="text" name="prefectural_name" value="{{ $staff->PrefecturalName ? $staff->PrefecturalName : null }}" class="form-control">
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.commune') }}<span class="required">*</span>
            </td>
            <td>
              <input type="text" name="commune" value="{{ $staff->MunicipalName ? $staff->MunicipalName : null }}" class="form-control">
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.address_detail') }}<span class="required">*</span>
            </td>
            <td>
              {!! Form::text('address_detail', $staff->AddressDetail, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.current_employment_status') }}
            </td>
            <td>
              {!! Form::select('current_employment_status', $employmentStatus, $staff->CurrentEmploymentStatus, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.station') }}
            </td>
            <td>
              {!! Form::text('nearest_station', $subStaff->NearestStation, ['class'=>'form-control']) !!}
            </td>
          </tr>
          <tr>
            <td class="text-right">
              {{ trans('title.pre-register.registration_history') }}
            </td>
            <td>
              {{--{!! Form::select('registration_history',[''=> '-- 選択してください --'] + $selectRegistrationHistory, $subStaff->RegistrationHistory, ['class'=>'form-control']) !!}--}}
            </td>
          </tr>

          </table>
          <table class="table table-responsive table-bordered">
            <tr>
              <td width="20%" class="text-right">
                {{ trans('title.pre-register.desire_period') }}
              </td>
              <td>
                {!! Form::select('desire_period',[''=> '-- 選択してください --'] + $selectDesirePeriod ,$staff->DesiredPeriod, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.employment_workday') }}
              </td>
              <td>
                <div class="form-group">
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('monday',1, $subStaff->Monday == 1 ? true : false) !!} 月</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('tuesday',1,$subStaff->Tuesday == 1 ? true : false) !!} 火</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('wednesday',1,$subStaff->Wednesday == 1 ? true : false) !!} 水</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('thursday',1,$subStaff->Thursday == 1 ? true : false) !!} 木</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('friday',1,$subStaff->Friday == 1 ? true : false) !!} 金</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('saturday',1,$subStaff->Saturday == 1 ? true : false) !!} 土</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('sunday',1,$subStaff->Sunday == 1 ? true : false) !!} 日</div>
                  <div class="col-md-3 col-xs-6">{!! Form::checkbox('public_holiday',1,$subStaff->PublicHoliday == 1 ? true : false) !!} 祝日</div>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.job_objective') }}
              </td>
              <td>
                {!! Form::checkbox('mobile_sale',1, $subStaff->MobileSale == 1 ? true : false) !!} 携帯販売 <br>
                {!! Form::checkbox('home_sale',1, $subStaff->HomeSale == 1 ? true : false) !!} 家電販売 <br>
                {!! Form::checkbox('cosmetic_sale',1, $subStaff->CosmeticSale == 1 ? true : false) !!} 化粧品販売<br>
                {!! Form::checkbox('apparel_sale',1, $subStaff->ApparelSale == 1 ? true : false) !!} アパレル販売<br>
                {!! Form::checkbox('goods_sale',1, $subStaff->GoodsSale == 1 ? true : false) !!} 雑貨販売<br>
                {!! Form::checkbox('food_sale',1, $subStaff->FoodSale == 1 ? true : false) !!} 食品販売<br>
                {!! Form::checkbox('tasting_sale',1, $subStaff->TastingSale == 1 ? true : false) !!} 試飲・試食販売<br>
                {!! Form::checkbox('business',1, $subStaff->Business == 1 ? true : false) !!} 営業<br>
                {!! Form::checkbox('rounder',1, $subStaff->Rounder == 1 ? true : false) !!} ラウンダ<br>
                {!! Form::checkbox('coffee_staff',1, $subStaff->CoffeeStaff == 1 ? true : false) !!} カフェスタッフ<br>
                {!! Form::checkbox('department_store_cash',1, $subStaff->DepartmentStoreCashRegister == 1 ? true : false) !!} 百貨店レジ<br>
                {!! Form::checkbox('secretary',1, $subStaff->Secretary == 1 ? true : false) !!} 事務<br>
                {!! Form::checkbox('data_entry',1, $subStaff->DataEntry == 1 ? true : false) !!} データ入力<br>
                {!! Form::checkbox('companion',1, $subStaff->Companion == 1 ? true : false) !!} コンパニオン<br>
                {!! Form::checkbox('director',1, $subStaff->Director == 1 ? true : false) !!} ディレクター<br>
                {!! Form::checkbox('light_work',1, $subStaff->Lightwork == 1 ? true : false) !!} 軽作業<br>
                {!! Form::checkbox('other',1, $subStaff->Other == 1 ? true : false) !!} その他<br>
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.employment_deadline') }} <br>
                {{ trans('title.pre-register.expiration_date') }}
              </td>
              <td>
                <div class="input-group date marginBottom5">
                  {!! Form::text('employment_deadline',$subStaff->EmploymentDeadline, ['class'=>'form-control','id'=>'employment_deadline']) !!}
                  <span class="input-group-addon">
                    <span class="glyphicon glyphicon-calendar"></span>
                  </span>
                </div>
              </td>
            </tr>
          </table>
          <table class="table table-responsive table-bordered">
            <tr>
              <td width="20%" class="text-right">
                {{ trans('title.pre-register.entitlement') }}
              </td>
              <td>
                {!! Form::checkbox('ordinary_license',1, $subStaff->OrdinaryLicense == 1 ? true : false ) !!} 普通免許 <br>
                {!! Form::checkbox('sales_officer',1, $subStaff->SalesOfficer == 1 ? true : false) !!} 販売士<br>
                {!! Form::checkbox('home_appliance_advisor',1, $subStaff->HomeApplianceAdvisor == 1 ? true : false) !!} 家電製品アドバイザー<br>
                {!! Form::checkbox('other_language_test',1, $subStaff->OtherLanguageTest == 1 ? true : false) !!} 他言語検定 <br>
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.entitlement') }} <br>
                {{ trans('title.pre-register.english') }}
              </td>
              <td>
                <div class="input-group marginBottom5">
                  <span class="input-group-btn">
                    <button class="btn btn-secondary widthBtnGroup70" type="button">TOEIC</button>
                  </span>
                  {!! Form::text("TOEIC",$subStaff->TOEIC ? $subStaff->TOEIC : 0,['class' => 'form-control']) !!}
                  <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button">点</button>
                  </span>
                </div>
                <div class="input-group marginBottom5">
                  <span class="input-group-btn">
                    <button class="btn btn-secondary widthBtnGroup70" type="button">TOEFL</button>
                  </span>
                  {!! Form::text("TOEFL",$subStaff->TOEFL ? $subStaff->TOEFL : 0,['class' => 'form-control']) !!}
                  <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button">点</button>
                  </span>
                </div>
              </td>
            </tr>
            <tr>
              <td width="20%" class="text-right">
                {{ trans('title.pre-register.entitlement') }} <br>
                {{ trans('title.pre-register.other') }}
              </td>
              <td>
                {!! Form::textarea('entitlement',$subStaff->Entitlement,['class'=>'form-control','rows'=>4]) !!}
              </td>
            </tr>
            <tr>
              <td colspan="4">
                卒業校について、新しいものから2つ、情報の登録を行ってください。
              </td>
            </tr>
            <tr>
              <td width="20%" class="text-right">
                {{ trans('title.pre-register.education') }}1 <span class="required">*</span>
              </td>
              <td>
                {!! Form::select('education',[''=>'-- 学歴区分 --'] + $educationDivision ,$staff->EducationDivision, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.education_school') }}1 <span class="required">*</span>
              </td>
              <td>
                {!! Form::text('education_school', $staff->EducationDivisionSchool, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.education_department') }}1
              </td>
              <td>
                {!! Form::text('education_department', $staff->EducationDivisionDepartment, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.education') }}2 <span class="required">*</span>
              </td>
              <td>
                {!! Form::select('education_2',[''=>'-- 学歴区分 --'] + $educationDivision ,$staff->EducationDivision_2, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.education_school') }}2 <span class="required">*</span>
              </td>
              <td>
                {!! Form::text('education_school_2', $staff->EducationDivisionSchool_2, ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.education_department') }}2
              </td>
              <td>
                {!! Form::text('education_department_2', $staff->EducationDivisionDepartment_2, ['class'=>'form-control']) !!}
              </td>
            </tr>
          </table>
          <h4>{{ trans('title.pre-register.part_time') }}</h4>
          <table class="table table-bordered table-responsive">
            <thead>
              <tr>
                <th class="text-center">{{ trans('title.pre-register.company_name') }}</th>
                <th class="text-center">{{ trans('title.pre-register.work_content') }}</th>
                <th class="text-center">{{ trans('title.pre-register.work_code') }}</th>
                <th class="text-center">{{ trans('title.pre-register.start_work') }} & {{ trans('title.pre-register.end_work') }}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td width="20%">
                  {!! Form::text('CompanyName1',$staff->CompanyName1,['class'=>'form-control']) !!}
                </td>
                <td>
                  {!! Form::textarea('WorkContent1',$staff->WorkContent1,['class'=>'form-control','rows' => 3]) !!}
                </td>
                <td width="20%">
                  {!! Form::select('WorkCode1',[''=>'-- 選択ワークコード --'] + $workCode, $staff->WorkCode1,['class'=>'form-control']) !!}
                </td>
                <td width="20%">
                  <div class="input-group date marginBottom5">
                    {!! Form::text('StartWork1',$staff->StartWork1,['id'=>'start_work1','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('EndWork1',$staff->EndWork1,['id'=>'end_work1','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  {!! Form::text('CompanyName2',$staff->CompanyName2,['class'=>'form-control']) !!}
                </td>
                <td>
                  {!! Form::textarea('WorkContent2',$staff->WorkContent2,['class'=>'form-control','rows' => 3]) !!}
                </td>
                <td>
                  {!! Form::select('WorkCode2',[''=>'-- 選択ワークコード --'] + $workCode, $staff->WorkCode2,['class'=>'form-control']) !!}
                </td>
                <td>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('StartWork2',$staff->StartWork2,['id'=>'start_work2','class'=>'form-control marginBottom5']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('EndWork2',$staff->EndWork2,['id'=>'end_work2','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  {!! Form::text('CompanyName3',$staff->CompanyName3,['class'=>'form-control']) !!}
                </td>
                <td>
                  {!! Form::textarea('WorkContent3',$staff->WorkContent3,['class'=>'form-control','rows' => 3]) !!}
                </td>
                <td>
                  {!! Form::select('WorkCode3',[''=>'-- 選択ワークコード --'] + $workCode, $staff->WorkCode3,['class'=>'form-control']) !!}
                </td>
                <td>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('StartWork3',$staff->StartWork3,['id'=>'start_work3','class'=>'form-control marginBottom5']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('EndWork3',$staff->EndWork3,['id'=>'end_work3','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  {!! Form::text('CompanyName4',$staff->CompanyName4,['class'=>'form-control']) !!}
                </td>
                <td>
                  {!! Form::textarea('WorkContent4',$staff->WorkContent4,['class'=>'form-control','rows' => 3]) !!}
                </td>
                <td>
                  {!! Form::select('WorkCode4',[''=>'-- 選択ワークコード --'] + $workCode, $staff->WorkCode4,['class'=>'form-control']) !!}
                </td>
                <td>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('StartWork4',$staff->StartWork4,['id'=>'start_work4','class'=>'form-control marginBottom5']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('EndWork4',$staff->EndWork4,['id'=>'end_work4','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </td>
              </tr>
              <tr>
                <td>
                  {!! Form::text('CompanyName5',$staff->CompanyName5,['class'=>'form-control']) !!}
                </td>
                <td>
                  {!! Form::textarea('WorkContent5',$staff->WorkContent5,['class'=>'form-control','rows' => 3]) !!}
                </td>
                <td>
                  {!! Form::select('WorkCode5',[''=>'-- 選択ワークコード --'] + $workCode, $staff->WorkCode5,['class'=>'form-control']) !!}
                </td>
                <td>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('StartWork5',$staff->StartWork5,['id'=>'start_work5','class'=>'form-control marginBottom5']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                  <div class="input-group date marginBottom5">
                    {!! Form::text('EndWork5',$staff->EndWork5,['id'=>'end_work5','class'=>'form-control']) !!}
                    <span class="input-group-addon">
                      <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <table class="table table-responsive table-bordered">
            <tr>
              <td width="20%" class="text-right">
                {{ trans('title.pre-register.transfer_method') }}<span class="required">*</span>
              </td>
              <td>
                {!! Form::radio('transfer_method','月払', $staff->TransferMethod != null && $staff->TransferMethod == '月払' ? true : false ) !!} {{ trans('title.pre-register.month') }}
                {!! Form::radio('transfer_method','週払', $staff->TransferMethod != null && $staff->TransferMethod == '週払' ? true : false) !!} {{ trans('title.pre-register.week') }}
              </td>
            </tr>
            <tr>
              <td width="15%" class="text-right">
                {{ trans('title.pre-register.height') }}
              </td>
              <td>
                <div class="input-group marginBottom5">
                  {!! Form::number('height',$staff->Height,['class'=>'form-control','min'=>'0']) !!}
                  <span class="input-group-btn">
                    <button class="btn btn-secondary" type="button">Cm</button>
                  </span>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.uniform_size') }}
              </td>
              <td colspan="3">
                <div class="col-md-2 uniformSize marginBottom5 nonePaddingLeft">
                  @foreach($selectUniformSize as $size)
                  {!! Form::radio('uniform_type',$size, $staff->UniformType != null && $staff->UniformType == $size ? true : false) !!} {{ $size }}
                  @endforeach
                </div>
                <div class="col-md-4">
                  <div class="input-group marginBottom5 nonePaddingLeft">
                    {!! Form::select('clothes_size',$selectClotheSize, $subStaff->ClothesSize ? $subStaff->ClothesSize : 9,['class'=>'form-control']) !!}
                    <span class="input-group-btn">
                      <button class="btn btn-secondary" type="button">号</button>
                    </span>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.shoes_size') }}
              </td>
              <td>

                {!! Form::select('shoes_size',$selectShoesSize, $staff->ShoesSize ? $staff->ShoesSize : 24.5,['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.suit_preparation') }}
              </td>
              <td>
                {!! Form::radio('suit_preparation',1, $staff->SuitPreparation != null && $staff->SuitPreparation == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('suit_preparation',0, $staff->SuitPreparation != null && $staff->SuitPreparation == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.white_shirt_preparation') }}
              </td>
              <td>
                {!! Form::radio('white_shirt_preparation',1, $staff->WhiteShirtPreparation != null && $staff->WhiteShirtPreparation == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('white_shirt_preparation',0, $staff->WhiteShirtPreparation != null && $staff->WhiteShirtPreparation == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.black_pump_preparation') }}
              </td>
              <td>
                {!! Form::radio('black_pump_preparation',1, $staff->BlackPumpPreparation != null && $staff->BlackPumpPreparation == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('black_pump_preparation',0, $staff->BlackPumpPreparation != null && $staff->BlackPumpPreparation == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.apron_sling') }}
              </td>
              <td>
                {!! Form::radio('apron_sling',1, $staff->ApronSling != null && $staff->ApronSling == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('apron_sling',0, $staff->ApronSling != null && $staff->ApronSling == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.black_hair_modification') }}
              </td>
              <td>
                {!! Form::radio('black_hair_modification',1, $staff->BlackHairModification != null && $staff->BlackHairModification == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('black_hair_modification',0, $staff->BlackHairModification != null && $staff->BlackHairModification == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.voice') }}
              </td>
              <td>
                {!! Form::radio('voice',1, $staff->Voice != null && $staff->Voice == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('voice',0, $staff->Voice != null && $staff->Voice == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.department_store_experience') }}
              </td>
              <td>
                {!! Form::radio('department_store_experience',1, $staff->DepartmentStoreExperience != null && $staff->DepartmentStoreExperience == 1 ? true : false ) !!} {{ trans('title.pre-register.ok') }}
                {!! Form::radio('department_store_experience',0, $staff->DepartmentStoreExperience != null && $staff->DepartmentStoreExperience == 0 ? true : false ) !!} {{ trans('title.pre-register.nothing') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.pos_cash_register_experience') }}
              </td>
              <td>
                {!! Form::radio('pos_cash_register_experience',1, $staff->POSCashRegisterExperience != null && $staff->POSCashRegisterExperience == 1 ? true : false ) !!} {{ trans('title.pre-register.ok') }}
                {!! Form::radio('pos_cash_register_experience',0, $staff->POSCashRegisterExperience != null && $staff->POSCashRegisterExperience == 0 ? true : false ) !!} {{ trans('title.pre-register.nothing') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.cat_experience') }}
              </td>
              <td>
                {!! Form::radio('cat_experience',1, $staff->CATExperience != null && $staff->CATExperience == 1 ? true : false ) !!} {{ trans('title.pre-register.ok') }}
                {!! Form::radio('cat_experience',0, $staff->CATExperience != null && $staff->CATExperience == 0 ? true : false ) !!} {{ trans('title.pre-register.nothing') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.nail_modification') }}
              </td>
              <td>
                {!! Form::radio('nail_modification',1, $staff->NailModification != null && $staff->NailModification == 1 ? true : false ) !!} {{ trans('title.pre-register.yes') }}
                {!! Form::radio('nail_modification',0, $staff->NailModification != null && $staff->NailModification == 0 ? true : false ) !!} {{ trans('title.pre-register.improper') }}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.bank_code') }}
              </td>
              <td>
                <?php $bankCode = null;
                  $branchCode = null;
                ?>
                @if($staff->BankCode != null)
                <?php
                  $bankCode = mb_substr($staff->BankCode, 0, 4);
                  $branchCode = mb_substr($staff->BankCode, -3);
                ?>
                @endif
                {!! Form::select('bank_code',[''=>'-- 選択銀行 --'] + $selectBank, $bankCode,['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.branch_code') }}
              </td>
              <td>
                {!! Form::hidden('branch',$branchCode) !!}
                {!! Form::select('branch_code', [''=>'-- 選択支店 --'], $branchCode,['class'=>'form-control','disabled'=>'disabled']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.account_saving_number') }}
              </td>
              <td>
                {!! Form::number('account_saving_number', $staff->AccountNumber,['class'=>'form-control','min' => 0 ]) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.nationality_code') }} :
              </td>
              <td>
                {!! Form::select('nationality_code',[''=>'-- 選択銀行 --'] + $nationCode, $staff->NationalCode,['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.verify') }} :
              </td>
              <td>
                {!! Form::checkbox('verify',1,$subStaff->Verify) !!}
              </td>
            </tr>

            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.contact_name') }} :
              </td>
              <td>
                {!! Form::text('contact_name',$staff->ContactName,  ['class'=>'form-control']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.contact_phone') }} :
              </td>
              <td>
                {!! Form::text('contact_phone',$staff->ContactPhoneNumber,  ['class'=>'form-control phone-number']) !!}
              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.work_start') }} :
              </td>
              <td>
                <div class="input-group date marginBottom5">
                  {!! Form::text('work_start', $staff->WorkStartDate , ['id'=>'work_start','class'=>'form-control']) !!}
                  <span class="input-group-addon">
                    <span class="glyphicon glyphicon-calendar"></span>
                  </span>
                </div>

              </td>
            </tr>
            <tr>
              <td class="text-right">
                {{ trans('title.pre-register.tax_classification') }} :
              </td>
              <td>
                {!! Form::text('tax_classification',$staff->TaxClassification,  ['class'=>'form-control']) !!}
              </td>
            </tr>
          </table>

          <!-- <div class="row">
              <div class="button-group text-center">
                  <button class="btn btn-default updateButton" disabled style="display: none;">{{ trans('title.action.update') }}</button>
                  <button type="button" class="btn btn-default cancelButton" disabled style="display: none;">{{ trans('title.action.cancel') }}</button>
                  <button type="button" onclick="return changeRole('{{$staff->Email}}')" class="btn btn-default register">{{ trans('title.action.registration') }}</button>
              </div>
          </div> -->



          <div class="row">
            <div class="form-group">
              <div class="col-md-12"><h4>参加案件履歴</h4></div>
              @foreach($wantedJobs as $key => $value)
              <div class="col-md-12">
                <div class="thumbnail">
                  <div class="row">
                    <div class="col-md-8">
                      <div class="desc">
                        <h4><b>{!! $value->AddressCompany !!}</b></h4>
                        <p>{!! $value->ProjectName !!}</p>
                        <p>就業機間</p>
                        <p>{!! date('Y 年 m 月 d 日', strtotime($value->StartDate)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($value->EndDate)) !!}</p>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div><button class="btn btn-default btn-sm" style="width: 100%">販売</button></div>

                      <div><a class="btn btn-default btn-lg" style="width: 100%" href="{!! URL::to('/wanted-job/view/'.$value->OrderId) !!}">詳細</a></div>
                    </div>
                  </div>
                </div>
              </div>
              @endforeach
            </div>
          </div>

          {!! Form::close() !!}
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
@section('page_js')
<script src="{{ asset('plugins/simple_loop_jquery_slider/js/simple-slider.min.js') }}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
<script src="{{ asset('js/site/pre-register/detail.js') }}"></script>
@endsection
