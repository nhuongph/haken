<div class="text-header">{!! trans('pre-register.new.interview-time') !!}</div>
<div class="pre-reg-new-step2-layout ">
<table class="table  table-bordered">
@if(count($times) > 0 && $region->Type == 1)
    @if($region->Type == 1)
        {!! Form::hidden('regionType',$region->Type) !!}
        <?php $i = 0 ?>
        @foreach($times as $key => $time)
            <tr >
                <td colspan="3" class="text-center col-md-2">{{ date('m/d', strtotime($key)) }} <br> ({{ $date[date('w', strtotime($key))] }})</td>
                <td>
                    {!! Form::hidden("interviewDate[]",$key) !!}
                    @foreach($time as $hour)
                        <p class="text-center">{!! Form::checkbox("interviewTime[".$i."][]",$hour,false,['class'=>'interview']) !!} {{ $hour }}</p>
                    @endforeach
                </td>
            </tr>
        <?php $i++ ?>
        @endforeach
    @endif
@endif
@if(count($times) > 0 && $region->Type == 0)
    <?php $i = 0 ?>
    {!! Form::hidden('regionType',$region->Type) !!}
    @foreach($times as $key => $time)
        <?php $places = $AnotherInterviewTimeBusiness->getAnotherInterviewTimeByDate($time->Date) ?>
    <tr class="row">
            <td colspan="3" class="text-center col-md-2">{{ date('m/d', strtotime($time->Date)) }} <br> ({{ $date[date('w', strtotime($time->Date))] }})</td>
            <td>
                {!! Form::hidden("interviewDate[]",$time->Date) !!}
                @if(count($places) > 0)
                    @foreach($places as $place)
                    <div class="col-md-3">
                        {!! Form::radio("anotherInterviewTime",$place->AnotherInterviewTimeID,false,['class'=>'anotherInterview']) !!} {{ $place->RegionName.' '.$place->ResponsibleName }}
                    </div>
                    @endforeach
                @endif
            </td>
        </tr>
        <?php $i++ ?>
    @endforeach
@endif
</table>
</div>
<script>
    $('.interview').on('change',function(){
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });
    $('.anotherInterview').on('change',function() {
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });
</script>
