@extends('site/layouts/main')
@section('title')
    {!! trans('title.staff.title') !!}
@endsection
@section('breadcrumb')
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="{{route('pre-register/manage')}}">{{trans('breadcrumb.pre-register.manage-menu')}}</a></li>
    <li class="active">{{ trans('title.pre-register.list') }}</li>
</ol>
</section>
@endsection
@section('content')
    <div class="row text-setting pre-reg-manage">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="box box-info box-solid manage">
                <div class="box-header with-border">
                    <h4 class="text-title"><b>{!! trans('title.staff.management_staff') !!}</b></h4>
                </div>            
                <div class="box-body">
                    @include('site.message.index')
                    <style type="text/css">
                        .row [class*="column-cus"] .main-panel-staff{
                            height: 370px !important;
                            overflow-y: auto;
                            overflow-x: hidden;
                            padding: 10px;
                        }

                    </style>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 column-cus">
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">{!! trans('title.staff.management_staff') !!}</h3>
                                </div>
                                <div class="box-body main-panel-staff">
                                    {{ Form::open(['method' => 'GET']) }}
                                    <div class="row margin-top-10">
                                        <div class="col-md-2"><b>{!! trans('title.staff.gender') !!}</b></div>
                                        <div class="col-md-10">
                                            {!! Form::checkbox('male', true, isset($search['male']) ? $search['male'] : '') !!} {!! trans('title.staff.male') !!}
                                            {!! Form::checkbox('female',  true , isset($search['female']) ? $search['female'] : '') !!} {!! trans('title.staff.female') !!}
                                        </div>
                                    </div>

                                    <div class="row margin-top-10">
                                        <div class="col-md-2"><b>{!! trans('title.staff.age') !!}</b></div>
                                        <div class="col-md-10 row">
                                            <div class="col-md-4">
                                                {!! Form::text('startAge', isset($search['startAge']) ? $search['startAge'] : '', ['class' => 'form-control']) !!}
                                            </div>
                                            <div class="col-md-8 row">
                                                <div class="col-md-5">
                                                    {!! trans('title.staff.to_age') !!}
                                                </div>
                                                <div class="col-md-7">
                                                    {!! Form::text('endAge', isset($search['endAge']) ? $search['endAge'] : '', ['class' => 'form-control']) !!}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row margin-top-10">
                                        <div class="col-md-2"><b>{!! trans('title.staff.tag') !!}</b></div>
                                        <div class="col-md-10">
                                            <ul class="tag_list nonePaddingLeft">

                                              @foreach($tags as $key => $value)
                                                  <li>
                                                      {!! Form::checkbox("tags[{$key}]", 1, isset($search['tags'][$key]) ? $search['tags'][$key] : '' ) !!} {{$value}}
                                                  </li>
                                              @endforeach
                                                
                                            </ul>
                                        </div>
                                    </div>

                                    <div class="row margin-top-10">
                                        <div class="col-md-2"><b>登録経緯</b></div>
                                        <div class="col-md-10">
                                            <div class="input-group">
                                              <select class="form-control" name="registrationHistory">
                                                  <option value="-1">すべて</option>
                                                  @foreach ($history as $key => $value)
                                                      <option value="{!! $key !!}" @if( isset($search['registrationHistory']) && $value == $search['registrationHistory'] ) 'selected' @endif>{!! $value !!}</option>
                                                  @endforeach
                                              </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row margin-top-10">
                                        <div class="col-md-2"><b>{!! trans('title.staff.nearest_station') !!}</b></div>
                                        <div class="col-md-10">
                                            <div class="input-group">
                                              {!! Form::text('nearestStation', isset($search['nearestStation']) ? $search['nearestStation'] : '', ['class' => 'form-control']) !!}
                                              <span class="input-group-btn">
                                                <button class="btn btn-default" type="button"><i class="glyphicon glyphicon-search"></i></button>
                                              </span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row margin-top-10">
                                        <div class="col-md-2"></div>
                                        <div class="col-md-10">
                                            <button class="btn btn-success search-btn" type="submit">{!! trans('title.staff.search') !!}</button>
                                        </div>
                                    </div>
                                    {{ Form::close() }}
                                </div>
                                <!-- <div class="box-footer text-center">
                                    <a href="javascript:void(0)" class="uppercase">View All Products</a>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 column-cus">
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <h3 class="box-title">{!! trans('title.staff.last_comments') !!}</h3>
                                </div>
                                <div class="box-body main-panel-staff">
                                    <ul class="products-list product-list-in-box">
                                        
                                        @foreach($comments as $key => $comment)

                                            @if( $comment->Comment != '' )
                                            <li class="item">
                                                <p class="margin-all-none"><b>{!! $comment->InterviewDate !!}</b></p>
                                                <a href="javascript:void(0)" class="product-title">{tên GaiA}が{!! $comment->Name !!}にコメントしました。</a>
                                                <span class="product-description">
                                                    {!! $comment->Comment !!}
                                                </span>
                                            </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                </div>
                                <!-- <div class="box-footer text-center">
                                    <a href="javascript:void(0)" class="uppercase">View All Products</a>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr class="active">
                                    <th>{!! trans('title.staff.labels.name') !!}</th>
                                    <th>{!! trans('title.staff.labels.photo') !!}</th>
                                    <th>{!! trans('title.staff.labels.sex') !!}</th>
                                    <th>{!! trans('title.staff.labels.age') !!}</th>
                                    <th>{!! trans('title.staff.labels.tag') !!}</th>
                                    <th>{!! trans('title.staff.labels.nearest_station') !!}</th>
                                    <th>{!! trans('title.staff.labels.first_impression') !!}</th>
                                    <th>{!! trans('title.staff.labels.registration_history') !!}</th>
                                    <th style="max-width: 15%"></th>
                                </tr>
                                @foreach($staffs as $key => $staff)
                                <tr>
                                    <td>{!! $staff->Name !!}</td>
                                    <td><img src="{!! URL::to($staff->Path) !!}" style="width: 100px; height: 100px" onerror="this.src='{{ URL::to('/img/no_image.jpg') }}'"></td>
                                    
                                    <td>{!! $staff->Sex == 1 ? '男' : '女' !!}</td>
                                    <td>{!! $staff->Age !!}</td>
                                    <td>{!! $staff->Tag !!}</td>
                                    <td>{!! $staff->StationName !!}</td>
                                    <td>{!! $staff->FirstImpression !!}</td>
                                    <td>{!! $staff->RegistrationHistory !!}</td>
                                    <td><a href="{!! URL::to('/staff/detail/'.$staff->StaffRegisterId) !!}" class="btn btn-default btn-lg">詳細</a></td>
                                </tr>
                                @endforeach
                            </thead>
                        </table>
                    </div>
                    @if( count($staffs) == 0 )
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h4>{{ trans('common.labels.no_record') }}</h4>
                        </div>
                    </div>
                    @endif
                    <div class="lst-company-paging">{!! $staffs->appends(\Illuminate\Support\Facades\Input::except('page'))->render() !!}</div>
                </div>
            </div>
        </div>
    </div>
@endsection