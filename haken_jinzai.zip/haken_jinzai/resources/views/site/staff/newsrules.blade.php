@extends('site/layouts/main')

@section('title')
{{ trans('title.bankaccount.title-new') }}
@endsection
@section('page_css')
<link href="{!! asset('css/site/staff/staff.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/staff/staff_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
<br>
<div class="container col-lg-12 col-md-12 col-sm-12 text-setting register-staff">
    <div class="panel panel-default account-bank-info">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12'>
                    <h4 class="text-title"><b>{{ trans('title.bankaccount.header-new') }}</b></h4>
                </div>
            </div>
        </div>        
        <div class="panel-body layout-border">
            @include('site/message/index')
            <div class="col-lg-12 col-md-12 col-sm-12 layout-child-panel">
                <div class="basic-form">
                    {!! Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']) !!}
                    <table class="table table-responsive table-bordered">
                        <tr>
                            <td width="25%">振込先銀行 <span class="required">*</span></td>
                            <td>
                                {!! Form::select('NameBank',$banks,null, ['class' => 'form-control','id'=>'accountbank']) !!}                                    
                            </td>
                        </tr>
                        <tr>
                            <td>支店名<span class="required">*</span></td>
                            <td>
                                @if (Session::has('NameBranch'))
                                {!! Form::hidden('previousBranch',Session::get('NameBranch'))!!}
                                @endif
                                <select class="form-control"  name="NameBranch" id="namebranch">

                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>支店番号</td>
                           
                            <td id="numberbankbranch">
                                <!-- <input type="hidden" name="NumberBankBranch"> -->
                                 {!! Form::hidden('NumberBankBranch',null,array('class'=>'form-control')) !!}
                                 {!! Form::text('NumberBankBranchDisabled',null,array('class'=>'form-control','disabled'=>'disabled')) !!}
                                <!-- <input type="text"  class="form-control" name="NumberBankBranchDisabled" disabled /> -->
                                <input type="hidden" id="branchChange">
                            </td>
                        </tr>
                        <tr>
                            <td>口座名義 カタカナ <span class="required">*</span></td>
                            <td>
                                {!! Form::text('AccountName',$rules->AccountName,array('class'=>'form-control')) !!} 
                            </td>
                        </tr>
                        <tr>
                            <td>振込方法</td>
                            <td>
                                <div class="sex_section newsrules" >
                                  <input type="radio" name="TransferMethod" value="1" class="gender-section" > 週払い<br>
                                  <input type="radio" name="TransferMethod" value="2" class="gender-section" checked="checked"> 月払い<br>
                              </div>
                          </td>
                      </tr>

                      <tr>
                        <td>口座番号<span class="required">*</span></td>
                        <td>
                            {!! Form::text('TransferNumber',$rules->TransferNumbers,array('class'=>'form-control')) !!} 
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <button class="btn btn-primary btn-lg btn-button-rules">登録</button>
                            <a href="{{ url('pre-register/reg-staff/oath') }}">
                                <button class="btn btn-primary btn-lg btn-button-rules" type="button">
                                    キャンセル
                                </button>
                            </a>                                
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
@section('page_js')

<script type="text/javascript">
    $(document).ready(function(){
        if($('#accountbank').val() != null) {
           id = $('#accountbank').val();
           $.post(SITE_ROOT+"/staff/bankbranch",{id:id},function (data) {  
            data = $.parseJSON(data);
            previousBranch = $('[name=previousBranch]').val();                
            $('#namebranch').children('option').remove();
            $.each(data,function(i, item) {                    
                $('#namebranch').append('<option value="'+item.MasterBankId+'">'+item.FullName+'</option>');
            });  
            $('#namebranch').val(previousBranch);
        });
       }

        $('#accountbank').change(function(){
        var id =$(this).val();
            $.post(SITE_ROOT+"/staff/bankbranch",{id:id},function (data) { 
                data = $.parseJSON(data);
                $('#namebranch').children('option').remove();
                $.each(data,function(i, item) {
                    $('#namebranch').append('<option value="'+item.MasterBankId+'" data-code="'+item.BranchCode+'">'+item.FullName+'</option>');
                    var code = $('#namebranch').find('option:selected').attr('data-code');
                    $('input[name="NumberBankBranchDisabled"]').val(code);
                    $('input[name="NumberBankBranch"]').val(code);
                });          
            });
       
        });

        $('#namebranch').change(function(){
            var code = $(this).find('option:selected').attr('data-code');
            $('input[name="NumberBankBranchDisabled"]').val(code);
            $('input[name="NumberBankBranch"]').val(code);
        });

        $('input[name="NumberBankBranchDisabled"]').val($('input[name="NumberBankBranch"]').val());
   });
</script>
<script src="{{ asset('plugins/bootstrap/js/moment.js') }}"></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') }}"></script>
<script type="text/javascript" src="{!! asset('plugins/validate/jquery.validate.min.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/jquery/jquery.session.js') !!}"></script>
<script type="text/javascript" src="{!! asset('js/site/user/order_validate.js') !!}"></script>
@endsection


