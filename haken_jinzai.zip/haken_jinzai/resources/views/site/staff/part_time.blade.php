<tr id="parttime_{{$currentPosition}}">
    <td>
        {!! Form::select("workPlace[]", $selectWorkPlace, null,['class' => 'form-control']) !!}
    </td>
    <td>
        {!! Form::select("jobPosition[]", $selectJobPosition, null,['class' => 'form-control']) !!}
    </td>
    <td>
        {!! Form::select("contractType[]", $selectContractType, null,['class' => 'form-control']) !!}
    </td>
    <td>
        <div class="col-md-9">
            <p>{!! Form::text("startDate[]",null,['class'=>'start_date','data-format' => 'YYYY-MM-DD', 'data-template' => 'YYYY 年 MMM 月 D 日']) !!}</p>
            <p>{!! Form::text("endDate[]",null,['class'=>'end_date','data-format' => 'YYYY-MM-DD', 'data-template' => 'YYYY 年 MMM 月 D 日']) !!}</p>
        </div>
        <div class="class-md-3">
            <i class="fa fa-times fa-2x" aria-hidden="true" onclick="removeParttime('parttime_{{$currentPosition}}')"></i>
        </div>

    </td>

</tr>
<script>
    year = new Date().getFullYear();
    $('.start_date').combodate({
        minYear: year-80,
        maxYear: year
    });
    $('.end_date').combodate({
        minYear: year-80,
        maxYear: year
    });
</script>