@extends('site/layouts/main')

@section('title')
{!! trans('pre-register.register-staff.title') !!}
@endsection
@section('page_css')
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
@endsection
@section('content')
<br>
<div class="row text-setting pre-reg">
    <div class="panel panel-default reg-staff">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12'>
                    <h4 class="text-title"><b>{!! trans('pre-register.register-staff.title') !!}</b></h4>
                </div>
            </div>
        </div>    
        <div class="panel-body layout-border">  
            <div class="col-lg-12 col-md-12 col-sm-12">
                @include('site/message/index')
                <div class="basic-form">
                    <div class="content-rules">
                        <div class="content-rules-1">
                            1. 会社及び就業先の秩序を乱すような以下の行為はいたしません。
                            <p>①無断欠勤・遅刻・早退　</p>
                            <p>②暴行・脅迫等の行為、暴言・噂・宗教やネットワークビジネスの勧誘等の秩序を乱す言動
                            尚、注意を受けても一向に改善できない場合は、会社からの就業・業務紹介が頂けない場合があることを理解いたします。（一般常識上やむを得ない場合を除く）
                        </div>
                        <div class="content-rules-2">
                            2. 就業中、依頼先の顧客と業務が円滑に進むよう心がけ、会社・就業先の名誉・信用を失墜させるような行為はいたしません。又、業務途中での職場放棄もいたしません。就業中に生じる諸問題に関しては、直ちに会社へ連絡いたします。
                        </div>
                        <div class="content-rules-3">
                            3. 会社の内部情報や雇用に関する内容について就業先や第三者に開示、又は漏洩をいたしません。就業中、私が知り得た公知の事実以外の機密事項ならびに個人情報に関しては、第三者にこれを漏洩いたしませんし、業務以外の目的で使用・加工・修正いたしません。また当項目は、就業期間中はもちろん、就業期間終了後においても有効であることを理解いたします。故意または過失により当項目に違反し、会社・就業先及び第三者に損害を与えた場合は、損害に対して賠償の責を負います。（上記は、携帯・スマートフォン・ＰＣ等を利用し「Twitter」「ブログ」「Facebook」等SNSへの情報の掲載・投稿などを含みます。）
                        </div>
                        <div class="content-rules-4">
                            4. 就業先が決定した後に、会社が私の氏名及び勤務予定日時等の個人情報を確認のため就業先に提出すること、また就業先へ提出する請求書に私の氏名や勤務実績が記載されることを了承します。また、業務内容により機密情報の取り扱いに関する契約・覚書を就業先と直接締結する場合があることにも了承いたします。
                        </div>
                        <div class="content-rules-5">
                            5. 会社から指示があった際、就業先への出発時・到着時・終了時は必ず会社に連絡致します。又、不測の事態の時は、直ちに会社へ連絡・報告いたします。
                        </div>
                    </div>
                    <div class="button-group btn-button text-center">
                        <input name="step" type="hidden" value="step_2">
                        <a href="{{ route('pre-register/reg-staff/bankaccount') }}" class="btn btn-primary btn-lg">{{ trans('pre-register.register-staff.oath') }}</a>
                        <a href="{{ route('home') }}" class="btn btn-primary btn-lg">{{ trans('pre-register.register-staff.not-oath') }}</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('page_js')
@endsection
