{!! Form::open(['class' => 'form-horizontal']) !!}
    <div class="form-group">
        <div class="col-md-2">
            <label>Name</label>
        </div>
        <div class="col-md-8">
            {!! Form::text('name',$user->name,array('class'=>'form-control')) !!}
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-2">
            <label>Email</label>
        </div>
        <div class="col-md-8">
            {!! Form::text('email',$user->email,array('class'=>'form-control')) !!}
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-2">
            <label>Password</label>
        </div>
        <div class="col-md-8">
            {!! Form::password('password',array('class'=>'form-control')) !!}
        </div>
    </div>
    <div class="form-group">
        <div class="col-md-2">
            <label>Confirm Password</label>
        </div>
        <div class="col-md-8">
            {!! Form::password('password_confirmation',array('class'=>'form-control')) !!}
        </div>
    </div>
    <div class="form-group">
        <div class="button-group text-center">
            <button class="btn btn-primary btn-lg">Submit</button>
        </div>
    </div>
{!! Form::close() !!}