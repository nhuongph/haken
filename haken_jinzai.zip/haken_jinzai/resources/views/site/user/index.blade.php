@extends('site/layouts/main')
@section('title')
    User Management
@endsection

@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Article List</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default">

                        </div>
                    </div>
                    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Type</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @section('page_js')
        <script type="text/javascript" src="{{ asset('js/site/user/list.js') }}"></script>
    @endsection
@stop