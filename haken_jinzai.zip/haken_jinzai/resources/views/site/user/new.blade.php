@extends('site/layouts/main')
@section('title')
    New User
@endsection
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Add New User</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-10">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <div class="col-md-10 col-md-offset-2">
                        @include('site/message/index')
                        @include('site/user/_form')
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop