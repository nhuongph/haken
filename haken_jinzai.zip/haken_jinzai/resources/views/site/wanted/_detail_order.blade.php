<div class="row">
  
  <img class="img-responsive col-xs-4 col-md-3" alt=""  src="{!! count($data->ProJectBasicInfo->Resource) >0 ? URL::to($data->ProJectBasicInfo->Resource->Path) : URL::to('/img/no_image.jpg') !!}" onerror="this.src='{{ URL::to('/img/no_image.jpg') }}'">

  <div class="col-xs-5 col-md-6">
    <strong>
    {{ $data->ProjectName}}
    </strong>
  </div>

  <div class="col-xs-3 col-md-2">

    <a href="{{ route('wanted-job/listOrder',['type' =>\Illuminate\Support\Facades\Input::get('type')]) }}" class=" col-xs-12 col-md-12 btn btn-default btn-lg">{{ trans('title.action.return') }}</a>
  </div>
</div>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong> {{ trans('title.wanted-job.work_location')}} </strong> </h4>
    {{ $data->AddressCompany }}
  </div>

</div>
<br>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong>{{ trans('title.wanted-job.period')}} </strong></h4>
    {{ Helper::fullDateFormatString( $data->BeginContract ) . ' - '. Helper::fullDateFormatString($data->EndContract) }}

  </div>

</div>
<br>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong> {{ trans('title.wanted-job.over_view')}} </strong></h4>
    {{ $data->TaskOverview}}
    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">

      <tr>
        <th> {{'勤務時間'}}</th>
        <th> {{'給与'}}</th>
      </tr>
      @foreach ($orderTime as $item)
      <tr>
        <th> {{   $item->TimeStart.'-'.$item->TimeEnd}}</th>
        <th> {{$item->Payment}}</th>
      </tr>
      @endforeach              
    </table>
  </div>

</div>
<br>
<div class="row">
  <div class="col-md-12">
    @if($data->ProJectBasicInfo->IsNoExperience) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.OK_inperienced') !!}</span> @endif
    @if($data->ProJectBasicInfo->IsTransportation) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.transportation_paid') !!}</span> @endif
    @if($data->ProJectBasicInfo->IsLongTime) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.long_term') !!}</span> @endif
    @if($data->ProJectBasicInfo->IsInAMonth) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.in_a_month') !!}</span> @endif
    @if($data->ProJectBasicInfo->IsTenDays) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.in_10_days') !!}</span> @endif
    @if($data->ProJectBasicInfo->IsOnlyOneDay) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.only_1_day') !!}</span> @endif
  </div>
</div>
<br>
<div class="col-xs-12"> 
  @if(Route::is('wanted-job/view'))
  <h4>  {!! nl2br(trans('title.wanted-job.helpview')) !!}</h4>
  @else
  <h4>  {{ trans('title.wanted-job.helpregister')}}</h4>
  @endif

</div>
<br>