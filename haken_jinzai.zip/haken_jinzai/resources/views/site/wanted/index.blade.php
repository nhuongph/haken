@extends('site/layouts/main')
@section('title')
    {{trans('title.wanted-job.worklist')}}
@endsection

@section('content')

<style>

    table tbody tr th:first-child{
        width: 30%;
    }
</style>    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    @include('site/message/index')
                    <a href="{{ route('wanted-job/listOrder',array('type'=>'1')) }}">
                    <div class="well well-lg"> {{ trans('title.wanted-job.apply_for_job') }}</div>
                    </a>
                    <a href="{{ route('wanted-job/listOrder',array('type'=>'2')) }}">
                    <div class="well well-lg">{{ trans('title.wanted-job.recommend') }} 
                      <div class="badge" >({{$countRecomment}}) </div>
                    </div>
                    </a>
                    <a href="{{ route('wanted-job/listOrder',array('type'=>'3')) }}">
                    <div class="well well-lg">{{ trans('title.wanted-job.registed') }}</div>
                    </a>
                    
                </div>
            </div>
        </div>
    </div>
    @section('page_js')
        
    @endsection
@stop