@extends('site/layouts/main')
@section('title')
{{trans('title.wanted-job.worklist')}}
@endsection
@section('content')
<link href="{!! asset('css/site/wanted/search.css') !!}" rel="stylesheet">
<style>
  .item-order{
    background: #eee;
    margin: 20px 0px;
    padding: 2%;
  }
  img{
    width: 20%;
  }
</style>
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
        @if (\Illuminate\Support\Facades\Input::get('type') == 1 )
        {{ trans('title.wanted-job.recruitment_list') }}
        @else
        
        {{ trans('title.wanted-job.introduced_work') }}
        @endif
    </h1>
  </div>
  <!-- /.col-lg-12 -->
</div>

<div class="row">
  <div class="col-lg-10">
    <div class="panel panel-default">
      <div class="panel-heading">
        
      </div>
      <div class="panel-body">
        <div class="col-md-12 ">
          @include('site/message/index' )
          <div class="row ">
            <div class="col-xs-12 col-md-12">
              <a href="{{ route('wanted-job/index',['type' =>\Illuminate\Support\Facades\Input::get('type')]) }}" class="pull-right  btn btn-default btn-lg">{{ trans('title.action.return') }}</a>
              <a href="{{ route('project_search',['type' =>\Illuminate\Support\Facades\Input::get('type')]) }}" class="pull-right  btn btn-default btn-lg">{{ trans('title.wanted-job.search.filter_search') }}</a>
            </div>
          </div>         

          @if(count($datas) > 0 )
          @foreach($datas as $data)
          <div class="item-order">
            <div class="row">
              <div class="col-md-3">
                
                <img class="img-responsive thumbnail" alt="" src="{!! count($data->Resource) >0 ? URL::to($data->Resource->Path) : URL::to('/img/no_image.jpg')  !!}" onerror="this.src='{{ URL::to('/img/no_image.jpg') }}'">     
              </div>
              <div class="col-md-7">
                <div><h3>{{ isset($data->Orders) ? $data->Orders->ProjectName:'' }}</h3></div>
                <div class="text-right"><p><b>{{ isset($data->Orders) ? $data->Orders->AddressCompany:'' }}</b></p></div>
              </div>
              <div class="col-md-2 text-right">
                <p><span class="label label-warning label-cate">{{ $data->Orders->CategoryJob }}</span></p>
                <p><span class="label label-success label-cate">{{ $data->Orders->AddressCompany }}</span></p>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                @if($data->IsNoExperience) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.OK_inperienced') !!}</span> @endif
                @if($data->IsTransportation) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.transportation_paid') !!}</span> @endif
                @if($data->IsLongTime) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.long_term') !!}</span> @endif
                @if($data->IsInAMonth) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.in_a_month') !!}</span> @endif
                @if($data->IsTenDays) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.in_10_days') !!}</span> @endif
                @if($data->IsOnlyOneDay) <span class="label label-info label-tag">{!! trans('title.wanted-job.search.only_1_day') !!}</span> @endif
              </div>
            </div>

            <div class="row">
              <div class="col-md-10">
                <p class="taskoverview">{!! $data->Orders->TaskOverview !!}</p>
              </div>
              <div class="col-md-2">
                <div class="text-right">
                  @if(\Illuminate\Support\Facades\Input::get('type') != 3)
                  <a href="{{ route('wanted-job/register',['orderId'=>$data->OrderId,'type' =>\Illuminate\Support\Facades\Input::get('type')]) }}" class=" col-xs-12 col-md-12 btn btn-default ">{{ trans('title.action.detail') }}</a>
                  @else
                  <a href="{{ route('wanted-job/view',['orderId'=>$data->OrderId,'type' =>\Illuminate\Support\Facades\Input::get('type')]) }}" class=" col-xs-12 col-md-12 btn btn-default ">{{ trans('title.action.detail') }}</a>
                  @endif 
                </div>
              </div>
            </div>
          </div>
          @endforeach
          @endif

          <div class="pull-right">
            {!! $datas->appends(\Illuminate\Support\Facades\Input::except('page'))->render() !!}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@stop