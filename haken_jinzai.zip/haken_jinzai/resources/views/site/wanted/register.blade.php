@extends('site/layouts/main')
@section('title')
    {{trans('title.wanted-job.worklist')}}
@endsection

@section('content')

<style>

    table tbody tr th:first-child{
        width: 30%;
    }
</style>    
    

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    @include('site/message/index')
                    @include('site/wanted/_detail_order',['data'=>$data])
                    
                    {!! Form::open(array( 'method' => 'POST')) !!}
                    {!! Form::hidden('type',\Illuminate\Support\Facades\Input::get('type')) !!}
                    @foreach ($dateTable as $dateRange)
                    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">
                        
                        @foreach ($dateRange as $row)
                            <tr class="row-result">
                                @foreach ($row as $col)
                                    <?php $isSelect = in_array($col, $userSelected) ?>
                                    <th>{{   strpos($col, '@') !== false ? Form::checkbox('wanted_job[]', $col,$isSelect): $col }}</th>
                                @endforeach
                            </tr>
                        @endforeach              
                    </table>
                    @endforeach
                    <div class="form-group">

                    
                    {!! Form::submit(trans('title.action.apply'), ['class' => 'col-xs-offset-3 col-xs-6 btn btn-default btn-lg']) !!}
                    
                    </div>
                    {{ Form::close() }}
                    
                </div>
            </div>
        </div>
    </div>
    @section('page_js')
       <script>
     $(function(){
         $('.row-result').each(function (i, e) {
            var $e = $(e);

            if ($e.text().indexOf('土') >= 0 || $e.text().indexOf('日') >= 0) {
                $e.addClass("danger");
            }
        });
       
     })
    </script> 
    @endsection
@stop
