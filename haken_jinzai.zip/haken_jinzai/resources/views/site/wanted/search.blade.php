<!--
    Creator: ToiTL
    Date: 2016/05/25
-->
@extends('site.layouts.main')
@section('title')
Setting Interview
@endsection
@section('page_css')
<link href="{!! asset('css/site/pre-register/pre-register.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/pre-register/pre-register_responsive.css') !!}" rel="stylesheet">
<link href="{!! asset('css/site/wanted/search.css') !!}" rel="stylesheet">
@endsection
@section('content')
	<br/>
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					{!! trans('title.wanted-job.search.filter_search') !!}
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-6">
							{!! Form::open(['url' => URL::to('/wanted-job/search-result'), 'method' => 'GET']) !!}
							{!! Form::hidden('type', $type) !!}
							<div class="row">
								<div class="col-md-12"><h3>{!! trans('title.wanted-job.search.according_to_job') !!}</h3></div>
								<div class="col-md-12">
									<ul class="tag_list nonePaddingLeft">
									@foreach($tags as $value)
										<li>{!! Form::checkbox('CategoryJob[]', $value, false) !!} {!! $value !!}</li>
									@endforeach                               
                                    </ul>
								</div>
							</div>

							<div class="row">
								<div class="col-md-12"><h3>{!! trans('title.wanted-job.search.according_to_project_feature') !!}</h3></div>
								<div class="col-md-12">
									<div class="row">
										<div class="col-md-6">{!! Form::checkbox('IsNoExperience', 'ok', false) !!} {!! trans('title.wanted-job.search.OK_inperienced') !!}</div>
										<div class="col-md-6">{!! Form::checkbox('IsTransportation', 'ok', false) !!} {!! trans('title.wanted-job.search.transportation_paid') !!}</div>
										<div class="col-md-6">{!! Form::checkbox('IsLongTime', 'ok', false) !!} {!! trans('title.wanted-job.search.long_term') !!}</div>
										<div class="col-md-6">{!! Form::checkbox('IsInAMonth', 'ok', false) !!} {!! trans('title.wanted-job.search.in_a_month') !!}</div>
										<div class="col-md-6">{!! Form::checkbox('IsTenDays', 'ok', false) !!} {!! trans('title.wanted-job.search.in_10_days') !!}</div>
										<div class="col-md-6">{!! Form::checkbox('IsOnlyOneDay', 'ok', false) !!} {!! trans('title.wanted-job.search.only_1_day') !!}</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="col-md-12"><h3>{!! trans('title.wanted-job.search.according_to_brand') !!}</h3></div>
								<div class="col-md-12 form-group">
									<select class="form-control" id="brand-select" name="Brand">
	                                    <option value="-1">{!! trans('title.wanted-job.search.all') !!}</option>
	                                    @foreach($brands as $key => $value)
	                                    <option value="{!! $value->Brand !!}">{!! $value->Brand !!}</option>
	                                    @endforeach
	                                </select>
								</div>
							</div>
							<div class="text-center"><button class="btn btn-default">{!! trans('title.wanted-job.search.search') !!}</button></div>
							{!! Form::close() !!}
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
@endsection
@section('page_js')
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/moment.js') !!}"></script>
<script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>
{!! Form::close() !!}
@endsection