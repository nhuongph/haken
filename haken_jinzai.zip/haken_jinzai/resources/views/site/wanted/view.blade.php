@extends('site/layouts/main')
@section('title')
    {{trans('title.wanted-job.worklist')}}
@endsection

@section('content')

<style>

    table tbody tr th:first-child{
        width: 30%;
    }
    .red {
        background:  red;
        color: red;
    }
</style>    
    
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
        
        {{ trans('title.wanted-job.committed_work_list') }}
        
    </h1>
  </div>
  <!-- /.col-lg-12 -->
</div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    @include('site/message/index')
                    @include('site/wanted/_detail_order',['data'=>$data])
                    
                    {!! Form::open(array( 'method' => 'POST')) !!}
                    {!! Form::hidden('type',\Illuminate\Support\Facades\Input::get('type')) !!}
                    @foreach ($dateTable as $dateRange)
                    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">
                        
                        @foreach ($dateRange as $row)
                            <tr class="row-result">
                                @foreach ($row as $col)
                                    <?php $isSelect = in_array($col, $userSelected) ?>
                                    <th class="">
                                      @if(strpos($col, '@') !== false)
                                        @if($isSelect)
                                          <i class="fa fa-check" aria-hidden="true"></i>
                                        @else  
                                          
                                        @endif  
                                      @else
                                        {{$col}}
                                      @endif
                                    </th>
                                @endforeach
                            </tr>
                            
                        @endforeach              
                    </table>
                   
                    @endforeach
                    <br>
                    <div class="form-group">
                      
                        @if(count($projectCheckPoint) > 0 )
                       
                        <div class="row" >
                            @foreach ($projectCheckPoint as $timeSubmit)
                            <div class="col-md-6">
                                {{ trans('title.wanted-job.timewanted')}} 
                                {!! Form::label($timeSubmit['name']); !!}
                                
                                {!! Form::text('timewanted_'.$timeSubmit['orderTimeId'],$timeSubmit['time'],['class'=>'form-control date-hour']) !!}
                            </div>    
                            @endforeach
                           
                            <div class="col-md-12">
                               <br>
                            {!! nl2br(trans('title.wanted-job.wanningwakeup')) !!}
                            </div>
                            <div class="col-md-12">
                            {!! Form::submit(trans('title.wanted-job.accepttime'), ['class' => 'col-xs-offset-3 col-xs-6 btn btn-default btn-lg']) !!}
                            </div>
                        @endif
                        
                      </div>
                    </div>
                    
                    {{ Form::close() }}
                    
                </div>
            </div>
        </div>
    </div>
    @section('page_js')
     <script type="text/javascript" src="{!! asset('plugins/bootstrap/js/bootstrap-datetimepicker.js') !!}"></script>   
    <script>
     $(function(){
         $('.row-result').each(function (i, e) {
            var $e = $(e);

            if ($e.text().indexOf('土') >= 0 || $e.text().indexOf('日') >= 0) {
                $e.addClass("danger");
            }
        });
        $('.date-hour').datetimepicker({
    
        format: 'HH:mm',
        locale: 'ja'
});
       
     })
    </script>
    @endsection
@stop