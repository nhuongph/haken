<meta charset="utf-8">
<table>
	<tr>
		<tr>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
		<td style="width: 10px"></td>
	</tr>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td>{!! $date !!}</td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td style="font-weight: bold; font-size: 20px; height: 30px">Skill sheet</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td>株式会社ガイアコミュニケーションズ</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td style="font-weight: bold;">{!! $staffName !!}</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td>フィールドプロモーションサービス</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td>TEL:03-6862-6811</td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td>【職務内容】</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td colspan="2" style="color: #fff; background: #09c;border: 1px solid #000">期間</td>
		<td colspan="2" style="color: #fff; background: #09c;border: 1px solid #000">勤務先</td>
		<td colspan="6" style="color: #fff; background: #09c;border: 1px solid #000; border-right: 1px solid #000">業務内容</td>
	</tr>

	@if( $staff->WorkContent1 != '' )
	<tr>
		<td></td>
		<td colspan="2">{!! date('Y 年 m 月 d 日', strtotime($staff->StartWork1)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($staff->EndWork1)) !!}</td>
		<td colspan="2">{!! $staff->Company1 !!}</td>
		<td colspan="6">{!! $staff->WorkContent1 !!}</td>
	</tr>
	@endif

	@if( $staff->WorkContent2 != '' )
	<tr>
		<td></td>
		<td colspan="2">{!! date('Y 年 m 月 d 日', strtotime($staff->StartWork2)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($staff->EndWork2)) !!}</td>
		<td colspan="2">{!! $staff->Company2 !!}</td>
		<td colspan="6">{!! $staff->WorkContent2 !!}</td>
	</tr>
	@endif

	@if( $staff->WorkContent3 != '' )
	<tr>
		<td></td>
		<td colspan="2">{!! date('Y 年 m 月 d 日', strtotime($staff->StartWork3)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($staff->EndWork3)) !!}</td>
		<td colspan="2">{!! $staff->Company3 !!}</td>
		<td colspan="6">{!! $staff->WorkContent3 !!}</td>
	</tr>
	@endif

	@if( $staff->WorkContent4 != '' )
	<tr>
		<td></td>
		<td colspan="2">{!! date('Y 年 m 月 d 日', strtotime($staff->StartWork4)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($staff->EndWork4)) !!}</td>
		<td colspan="2">{!! $staff->Company4 !!}</td>
		<td colspan="6">{!! $staff->WorkContent4 !!}</td>
	</tr>
	@endif

	@if( $staff->WorkContent5 != '' )
	<tr>
		<td></td>
		<td colspan="2">{!! date('Y 年 m 月 d 日', strtotime($staff->StartWork5)) !!} 〜 {!! date('Y 年 m 月 d 日', strtotime($staff->EndWork5)) !!}</td>
		<td colspan="2">{!! $staff->Company5 !!}</td>
		<td colspan="6">{!! $staff->WorkContent5 !!}</td>
	</tr>
	@endif

	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>


	<tr>
		<td></td>
		<td>【資格】</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td colspan="2" style="color: #fff; background: #09c; border: 1px solid #000">取得資格</td>
		<td colspan="8" style="color: #fff; background: #09c; border: 1px solid #000">備考</td>
	</tr>

	<tr>
		<td></td>
		<td colspan="2">普通免許</td>
		<td colspan="8"></td>
	</tr>
	<tr>
		<td></td>
		<td colspan="2">TOEIC {!! $staff->SubStaff->TOIC !!}点</td>
		<td colspan="8"></td>
	</tr>
	<tr>
		<td></td>
		<td colspan="2">{!! $staff->SubStaff->Entitlement !!}</td>
		<td colspan="8"</td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td>【その他】</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td colspan="10"></td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>

	<tr>
		<td></td>
		<td colspan="10" style="word-wrap: break-word;">労働者派遣法第24条の3、第35条、労働者派遣施行規則第28条および派遣スタッフの個人情報保護に配慮し、職歴等に一部実名を伏せる等に表現を使っておりますことをご了承ください。
本スキルシートは複写・転用・加工禁止、使用済後は破棄処分をお願いいたします。
</td>
	</tr>
</table>