{!! Form::open(['files'=>'true']) !!}
    {!! Form::file('bank') !!}
    <button>Submit</button>
{!! Form::close() !!}