<?php echo e($name); ?>様<br>
<br>
この度は弊社の<?php echo e($service_name); ?>にご登録いただきまして、誠にありがとうございます。<br>
<br>
案件紹介システムの利用が可能となりましたので、お知らせいたします。<br>
<br>
◼︎ログイン情報<br>
メールアドレス：<?php echo e($staffAddress); ?><br>
スタッフコード：<?php echo e($staffCode); ?><br>
<!--パスワード：xlkqigr43h8<br>-->
<br>
下記のアドレスより、ログインを行ってください。<br>
<?php echo e(url('login')); ?><br>