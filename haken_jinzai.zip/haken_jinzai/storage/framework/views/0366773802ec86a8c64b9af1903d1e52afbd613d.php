<?php $__env->startSection('title'); ?>
<?php echo e(trans('gaia.register.title-update')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row text-setting gaia-manage">
	<div class="panel panel-default register">
		<div class="panel-heading layout-bg-title">
			<div class="row">
				<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
					<h4 class="text-title"><b></b></h4>
				</div>
			</div>
		</div> 
		<div class="panel-body layout-border">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="basic-form">
					<?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>                        	  
					<span class="reg-title"><?php echo trans('gaia.register.title1'); ?></span>
					<div class="layout-child-panel reg-content">
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.first-name'); ?></div>
							<div class="col-md-3"><?php echo Form::text('firstname',$gaia->Firstname, ['class'=>'form-control']); ?></div>
							<div class="col-md-2"><?php echo trans('common.title.last-name'); ?></div>
							<div class="col-md-3"><?php echo Form::text('lastname', $gaia->Lastname, ['class'=>'form-control']); ?></div>
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.first-name-kana'); ?></div>
							<div class="col-md-3"><?php echo Form::text('firstname_kana', $gaia->Firstname_Kana, ['class'=>'form-control']); ?></div>
							<div class="col-md-2"><?php echo trans('common.title.last-name-kana'); ?></div>
							<div class="col-md-3"><?php echo Form::text('lastname_kana', $gaia->Lastname_Kana, ['class'=>'form-control']); ?></div>
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.email'); ?></div>
							<div class="col-md-8" ><?php echo Form::text('email', $user->email, ['class'=>'form-control']); ?></div>							
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.password'); ?></div>
							<div class="col-md-8" >
								<?php echo Form::password('password',['class'=>'form-control']); ?>		
							</div>						
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.department-name'); ?></div>
							<div class="col-md-8" >
								<?php echo Form::text('part', $gaia->Part, ['class'=>'form-control']); ?>		
							</div>
						</div>
					</div>
					<div class="reg-title"><?php echo trans('gaia.register.title2'); ?></div>
					<div class="layout-child-panel reg-chk">
						<?php foreach($role as $roles): ?>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-10">
										<?php if(count($role_user) > 0): ?>	                	
										<input type="checkbox" name="roleid[]"  value="<?php echo e($roles->id); ?>" <?php if(in_array($roles->id,$role_user)): ?> 
										<?php echo e('checked'); ?>

										<?php endif; ?>/>
										<?php else: ?>
										<?php echo Form::checkbox('roleid[]', $roles->id); ?>		
										<?php endif; ?>
										<?php echo e($roles->display_name); ?>								
							</div>
						</div>
						<?php endforeach; ?>						
					</div>
					<div class="button-group btn-button text-center">
						<button class="btn btn-primary btn-lg"><?php echo trans('common.button.update'); ?></button> 
						<a href="<?php echo e(route('employee/detail', ['userId'=>$user->id])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('common.button.cancel')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<!-- <script src="<?php echo e(asset('js/site/staff.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>