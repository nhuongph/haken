<?php $__env->startSection('title'); ?>
<?php echo e(trans('brand.title.add')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/brand.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/brand_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row text-setting brand">
    <div class="panel panel-default add">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                    <h4 class="text-title"><b><?php echo e(trans('brand.header.add')); ?></b></h4>
                </div>
            </div>
        </div>     
        <div class="panel-body layout-border content">
            <div class="col-md-12 col-sm-12 col-sx-12">
                <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="layout-child-panel">
                    <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>

                    <table class="table table-responsive">
                        <tr>
                            <td><?php echo e(trans('brand.header-table.manage-name')); ?></td>
                            <td><?php echo Form::text('ManagementName', $brand->ManagementName, ['class' => 'form-control']); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('brand.header-table.display-name')); ?></td>
                            <td><?php echo Form::text('DisplayName', $brand->DisplayName, ['class' => 'form-control']); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('brand.header-table.note')); ?></td>
                            <td><?php echo Form::text('Remarks', $brand->Remarks, ['class' => 'form-control']); ?></td>
                        </tr>
                    </table>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                        <div class="button-group btn-button">
                        <button class="btn btn-primary button-submit"><?php echo e(trans('common.button.register')); ?></button> 
                            <a href="<?php echo e(route('gaia/brand/list')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.cancel')); ?></a>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>