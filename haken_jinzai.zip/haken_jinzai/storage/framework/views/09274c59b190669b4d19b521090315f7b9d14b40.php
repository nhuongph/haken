<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo e($title); ?></title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('plugins/sb-admin/css/sb-admin-2.css')); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo e(asset('plugins/jquery/jquery-2.1.4.min.js')); ?>"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo Form::open(['role'=>'form']); ?>

                    <fieldset>
                        <div class="form-group">
                            <div class="username-satff-login"><?php echo e(trans('title.login.labels.email_address_id')); ?></div>
                            <input class="form-control" placeholder="Username" name="email" type="email" autofocus>
                        </div>
                        <div class="form-group">
                            <div class="password-satff-login"><?php echo e(trans('title.login.labels.password')); ?></div>
                            <input class="form-control" placeholder="Password" name="password" type="password" value="">
                        </div>
                        <div class="form-group">
                            <div class="button-group">
                                <button class="btn btn-lg btn-success btn-block"><?php echo e(trans('title.action.login')); ?></button>
                            </div>
                        </div>
                        <!-- Change this to a button or input when using this as a form -->
                        <p class="text-right"><a href="<?php echo e(url('password/email')); ?>"><?php echo e(trans('title.login.labels.fogot_pwd')); ?></a></p>
                    </fieldset>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>


<!-- Bootstrap Core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

</body>
</html>