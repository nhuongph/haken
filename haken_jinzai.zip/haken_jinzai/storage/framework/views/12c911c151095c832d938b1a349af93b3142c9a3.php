<?php $__env->startSection('title'); ?>
<?php echo e(trans('brand.title.list')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/brand.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/brand_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row text-setting brand">
    <div class="panel panel-default list">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                    <h4 class="text-title"><b><?php echo e(trans('brand.header.list')); ?></b></h4>
                </div>
            </div>
        </div>        
        <div class="panel-body layout-border content">
            <div class="col-md-12 col-sm-12">
                <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <p class="text-right">
                    <a href="<?php echo e(route('gaia/brand/add')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.add-new')); ?></a>
                </p>
                <div class="layout-child-panel table-container">
                    <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>

                    <table class="table table-responsive table-bordered brand-list">
                        <thead>
                            <tr>
                                <th><?php echo e(trans('brand.header-table.list-registration-date')); ?></th>
                                <th><?php echo e(trans('brand.header-table.list-management-name')); ?></th>
                                <th><?php echo e(trans('brand.header-table.list-display-name')); ?></th>
                                <th><?php echo e(trans('brand.header-table.note')); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <?php foreach($brandLists as $brandList){?>
                        <tr>
                         <td>
                            <?php 
                            $date=date_create($brandList->created_at);
                            echo date_format($date,"Y/m/d");
                            ?>   
                        </td>
                        <td><?php echo $brandList->ManagementName;?></td>
                        <td><?php echo $brandList->DisplayName;?></td>
                        <td><?php echo $brandList->Remarks;?></td>
                        <td class="action" style="width:300px;">
                            <div class="row text-center">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('gaia/brand/update', ['brandId'=>$brandList->id])); ?>" class="btn btn-primary btn-detail"><?php echo e(trans('common.button.edit')); ?></a>
                                    <a href="<?php echo e(route('gaia/brand/delete', ['brandId'=>$brandList->id])); ?>" class="btn btn-primary btn-delete"><?php echo e(trans('common.button.delete')); ?></a>                                    
                                </div>
                            </div>
                            <div class="row text-center">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('report/index', ['brandId'=>$brandList->id])); ?>" class="btn btn-primary btn-setting-shop"><?php echo e(trans('brand.button.list-setting-info-shop')); ?></a>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php  } ?>

                </table>


                <?php echo Form::close(); ?>


            </div>

        </div>
    </div>
</div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>