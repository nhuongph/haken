<?php foreach( $projectList as $key => $value ): ?>
	<div class="row thumbnail">
		<div class="col-lg-4 col-md-4">
			<span class="label label-default" style="font-size: 15px;"><?php echo trans('title.user.basic_register.action.sale'); ?></span>
			<span class="label label-default" style="font-size: 15px;"><?php echo $value->RecruitmentTime; ?></span>
			<h3><?php echo $value->ProjectName; ?></h3>
			<b><?php echo $value->CompanyName; ?></b>
			<p><?php echo trans('title.user.basic_register.labels.recruitment_period'); ?></p>
			<span><?php echo date('Y 年 m 月 d 日', strtotime($value->StartDate)); ?> 〜 <?php echo date('Y 年 m 月 d 日', strtotime($value->EndDate)); ?></span>
		</div>
		<div class="col-lg-6 col-md-6">
			<table class="table">
				<tr>
					<td style="width: 50%"><?php echo trans('title.user.basic_register.labels.status'); ?></td>
					<td><?php echo $value->StatusName; ?></td>
				</tr>
				<tr>
					<td><?php echo trans('title.user.basic_register.labels.open_range'); ?></td>
					<td><?php echo $value->DisplayStatusName; ?></td>
				</tr>
				<tr>
					<td><?php echo trans('title.user.basic_register.labels.period'); ?></td>
					<td><?php echo $value->PeriodDivision; ?></td>
				</tr>
				<tr>
					<td><?php echo trans('title.user.basic_register.labels.brand'); ?></td>
					<td><?php echo $value->ManagementName; ?></td>
				</tr>
			</table>
		</div>
		<div class="col-lg-2 col-md-2">
			<a href="<?php echo URL::to('/user/project/update/'.$value->BasicInfoID); ?>" class="btn btn-default btn-lg" style="width: 100%"><?php echo trans('title.user.basic_register.action.detail'); ?></a>
		</div>
	</div>
<?php endforeach; ?>
<div class="lst-company-paging"><?php echo $projectList->appends(\Illuminate\Support\Facades\Input::except('page'))->render(); ?></div>