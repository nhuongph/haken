<?php $__env->startSection('title'); ?>
<?php echo e(trans('company.header-detail')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<form id="registercompany" method="POST"> 
	<div class="row text-setting company">
		<div class="panel panel-default get">
			<div class="panel-heading layout-bg-title">
				<div class="row">
					<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
						<h4 class="text-title"><b><?php echo e(trans('company.title')); ?></b></h4>
					</div>
				</div>
			</div>
			<div class="panel-body layout-border content">	
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-right">
						<a href="<?php echo e(route('listcompany')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.back-list-item')); ?></a>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 text-title">
						<?php echo e($company->CompanyName); ?><?php echo e(trans('company.title-company')); ?>

					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-right">
						<a href="<?php echo e(route('editcompany', $company->CompanyId)); ?>" class="btn btn-primary"><?php echo e(trans('common.button.edit')); ?></a>
						<a href="<?php echo e(route('getdeletecompany', $company->CompanyId)); ?>" class="btn btn-primary"><?php echo e(trans('common.button.delete')); ?></a>
					</div>
				</div>				
				<?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="layout-child-panel">
					<div class="row row-eq-height">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 col-sm-8 col-xs-8"><?php echo $company->CompanyName; ?></div>    
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.furigana-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->FuriganaName; ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.postal-code')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo $company->PostalCode; ?>

						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.prefectural-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->PrefecturalName; ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.municipal-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->MunicipalName; ?></div>			
					</div>				
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.detail-address')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->DetailAddress; ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.tel')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->PhoneNumber; ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.fax')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->FaxNumber; ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.head-office')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->HeadOffice; ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.capital-stock')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->CapitalStock; ?></div>				
					</div>			
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.employee-number')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->EmployeeNumber; ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.ceo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->PepresentativeName; ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-name-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ResponsiblePersonNameHaken; ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-position-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ResponsiblePersonPositionHaken; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 "><?php echo e(trans('company.title-content.responsible-person-phone-number-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ResponsiblePersonPhoneNumberHaken; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ChainCommandName; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-position')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ChainCommandPosition; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-contact')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->ChainCommandPhoneNumber; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.establishment-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo $subcompany->EstablishmentDate == "0000-00-00" ? " " : date('Y 年 m 月 d 日', strtotime($subcompany->EstablishmentDate)); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer-bank')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->MainCustomerBank; ?><?php echo trans('company.content.main-bank'); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.lastyear-suppliers')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->LastYearSuppliers; ?><?php echo e(trans('company.content.money')); ?></div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $subcompany->MainCustomer; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 "><?php echo e(trans('company.title-content.basic-contract-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo $company->ContractDate == "0000-00-00" ? " " : date('Y 年 m 月 d 日', strtotime($company->ContractDate)); ?>

						</div>
					</div>
					<div class="row">

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-memo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 white-space-setting"><?php echo e($subcompany->CompanyMemo); ?></div>	
					</div>				
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.person-charge')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->PersonCharge; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.department-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo $company->DepartmentName; ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.offical-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo e($subcompany->OfficialName == 1 ? trans('company.radio.regular'): trans('company.radio.deputy')); ?>

						</div>	
					</div>
				</div>		
			</div>
		</div>
	</div>
	<input type="hidden" name="sections" id="sections" value="1">
	<input type="hidden" name="lstPaymentUpdate" id="lstPaymentUpdate" value="1,">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/moment.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/gaia/company.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/ajax_zip3/ajax_zip3.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>