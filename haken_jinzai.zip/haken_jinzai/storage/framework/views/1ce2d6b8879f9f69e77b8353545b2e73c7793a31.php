<div class="row">
  
  <img class="img-responsive col-xs-4 col-md-3" alt=""  src="<?php echo count($data->ProJectBasicInfo->Resource) >0 ? URL::to($data->ProJectBasicInfo->Resource->Path) : URL::to('/img/no_image.jpg'); ?>" onerror="this.src='<?php echo e(URL::to('/img/no_image.jpg')); ?>'">

  <div class="col-xs-5 col-md-6">
    <strong>
    <?php echo e($data->ProjectName); ?>

    </strong>
  </div>

  <div class="col-xs-3 col-md-2">

    <a href="<?php echo e(route('wanted-job/listOrder',['type' =>\Illuminate\Support\Facades\Input::get('type')])); ?>" class=" col-xs-12 col-md-12 btn btn-default btn-lg"><?php echo e(trans('title.action.return')); ?></a>
  </div>
</div>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong> <?php echo e(trans('title.wanted-job.work_location')); ?> </strong> </h4>
    <?php echo e($data->AddressCompany); ?>

  </div>

</div>
<br>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong><?php echo e(trans('title.wanted-job.period')); ?> </strong></h4>
    <?php echo e(Helper::fullDateFormatString( $data->BeginContract ) . ' - '. Helper::fullDateFormatString($data->EndContract)); ?>


  </div>

</div>
<br>
<div class="row">
  <div class="col-xs-12"> 
    <h4> <strong> <?php echo e(trans('title.wanted-job.over_view')); ?> </strong></h4>
    <?php echo e($data->TaskOverview); ?>

    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">

      <tr>
        <th> <?php echo e('勤務時間'); ?></th>
        <th> <?php echo e('給与'); ?></th>
      </tr>
      <?php foreach($orderTime as $item): ?>
      <tr>
        <th> <?php echo e($item->TimeStart.'-'.$item->TimeEnd); ?></th>
        <th> <?php echo e($item->Payment); ?></th>
      </tr>
      <?php endforeach; ?>              
    </table>
  </div>

</div>
<br>
<div class="row">
  <div class="col-md-12">
    <?php if($data->ProJectBasicInfo->IsNoExperience): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.OK_inperienced'); ?></span> <?php endif; ?>
    <?php if($data->ProJectBasicInfo->IsTransportation): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.transportation_paid'); ?></span> <?php endif; ?>
    <?php if($data->ProJectBasicInfo->IsLongTime): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.long_term'); ?></span> <?php endif; ?>
    <?php if($data->ProJectBasicInfo->IsInAMonth): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.in_a_month'); ?></span> <?php endif; ?>
    <?php if($data->ProJectBasicInfo->IsTenDays): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.in_10_days'); ?></span> <?php endif; ?>
    <?php if($data->ProJectBasicInfo->IsOnlyOneDay): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.only_1_day'); ?></span> <?php endif; ?>
  </div>
</div>
<br>
<div class="col-xs-12"> 
  <?php if(Route::is('wanted-job/view')): ?>
  <h4>  <?php echo nl2br(trans('title.wanted-job.helpview')); ?></h4>
  <?php else: ?>
  <h4>  <?php echo e(trans('title.wanted-job.helpregister')); ?></h4>
  <?php endif; ?>

</div>
<br>