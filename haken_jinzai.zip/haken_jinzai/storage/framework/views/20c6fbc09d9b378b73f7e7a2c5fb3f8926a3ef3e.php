<a href="#" class="logo">
	<!-- mini logo for sidebar mini 50x50 pixels -->
	<span class="logo-mini"><b>Jin</b>zai</span>
	<!-- logo for regular state and mobile devices -->
	<span class="logo-lg"><?php echo e(trans('menu.icon-hakenjinzai')); ?></span>
</a>
<nav class="navbar navbar-static-top">
	<!-- Sidebar toggle button-->
	<a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
		<span class="sr-only">Toggle navigation</span>
	</a>

	<div class="navbar-custom-menu">
		<ul class="nav navbar-nav">
			<!-- Messages: style can be found in dropdown.less-->
			<li class="dropdown messages-menu">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<i class="fa fa-envelope-o"></i>
					<!-- <span class="label label-success">0</span> -->
				</a>
			</li>
			<!-- Notifications: style can be found in dropdown.less -->
			<li class="dropdown notifications-menu">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<i class="fa fa-bell-o"></i>
					<!-- <span class="label label-warning">10</span> -->
				</a>
			</li>
			<!-- Tasks: style can be found in dropdown.less -->
			<li class="dropdown tasks-menu">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<i class="fa fa-flag-o"></i>
					<!-- <span class="label label-danger">9</span> -->
				</a>
			</li>
			<!-- User Account: style can be found in dropdown.less -->
			<li class="dropdown user user-menu">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<img src="" class="user-image" alt="User Image" onerror="this.src='<?php echo e(URL::to('/img/no_image.jpg')); ?>'">
					<span class="hidden-xs"><?php echo e(trans('menu.staff')); ?></span>
				</a>
				<ul class="dropdown-menu">
					<!-- User image -->
					<li class="user-header">
						<img src="" class="img-circle" alt="User Image" onerror="this.src='<?php echo e(URL::to('/img/no_image.jpg')); ?>'">
						<p>
							Staff
							<!-- <small>Member since Nov. 2012</small> -->
						</p>
					</li>
					<!-- Menu Body -->
					<!-- Menu Footer-->
					<li class="user-footer">
						<div class="pull-right">
							<a href="#" class="btn btn-default btn-flat"><?php echo e(trans('menu.sign-out')); ?></a>
						</div>
					</li>
				</ul>
			</li>
			<!-- Control Sidebar Toggle Button -->
			<li class="dropdown tasks-menu user user-menu">
            	<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><i class="fa fa-gears"></i></a>
            	<ul class="dropdown-menu">
              		<li class="header">Setting</li>
              		<li><a href="<?php echo e(URL::to('/logout')); ?>"><i class="glyphicon glyphicon-log-out text-aqua"></i> <?php echo e(trans('menu.sign-out')); ?></a></li>
              		<li class="footer"></li>
            	</ul>
          	</li>
		</ul>
	</div>
</nav>