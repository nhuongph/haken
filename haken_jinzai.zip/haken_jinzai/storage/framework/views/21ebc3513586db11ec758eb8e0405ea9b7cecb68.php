<?php $__env->startSection('title'); ?>
New Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/customerstyle.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/customerstyle_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open(); ?>

<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">
			<row>取引先管理</row>
		</div>
		<div class="panel-body">
			<div class="row lst-company-row">
				<div class="lst-company lst-company-right-align">
					<div class="input-group">
						<?php echo Form::text('searchCompany', null, ['class'=>'form-control', 'required' => 'required']); ?>

						<span class="input-group-btn">
							<?php echo Form::button('', ['id'=>'btSearch', 'class'=>'btn btn-default glyphicon glyphicon-search']); ?>

						</span>
					</div><!-- /input-group -->
					<div class="lst-company-right-align lst-company-button">
						<a href="<?php echo route('newcompany'); ?>" value="新規登録" class="btn btn-primary">新規登録</a>
					</div>
				</div>
			</div>			
			<div class="content">
				<?php foreach($listcompany as $company): ?>
				<div class="row lst-company-row">
					<div class="col-md-12">
						<div class="col-md-3">
							<div><?php echo link_to_route('editcompany', $company->CompanyName, ['id'=>$company->CompanyId]); ?></div>
							<div><?php echo $company->PostalCode; ?></div>
						</div>
						<div class="col-md-2">
							<?php echo $company->OfficialName == 1 ? trans('company.radio.regular') :  trans('company.radio.deputy'); ?>

						</div>
						<div class="col-md-5">
							<div>住所:<?php echo $company->DetailAddress; ?></div>
							<div>代表者:<?php echo $company->PepresentativeName; ?></div>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
				<div class="pagination lst-company-paging"> <?php echo e($listcompany->links()); ?> </div>
			</div>
		</div>
	</div>
</div>
<?php echo Form::close(); ?>

<?php $__env->startSection('page_js'); ?>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/user/company.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>