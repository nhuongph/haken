<div class="navbar-default sidebar layout-left-menu" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="left-menu-user">
                <div class="pull-left image">
                    <img src="" class="img-circle" alt="">
                </div>
                <div class="pull-left info">
                    <p>Officer</p>
                </div>
            </li>
            <li class="header-gaia-menu">MENU</li>
            <?php foreach(Menu::getSidebarMenus() as $key => $value): ?>
            <li>
                <a href="<?php echo URL::to($value->link); ?>"><i class="fa fa-edit fa-fw"></i>&#32;<?php echo trans($value->text); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>