<?php echo e($staff_name); ?>より登録情報の変更申請がありました。<br>
<br>
<br>
○変更箇所<br>
<?php echo e($title_change); ?><br>
<br>
○変更内容<br>
<pre><?php echo e($content_change); ?></pre>
<br>
○申請者<br>
<?php echo e($staff_name); ?><br>
<?php echo e($staff_mail); ?><br>
<br>
-------------------<br>
このメールはシステムより自動配信されています。<br>
返信は受付できませんので、ご了承ください。<br>
