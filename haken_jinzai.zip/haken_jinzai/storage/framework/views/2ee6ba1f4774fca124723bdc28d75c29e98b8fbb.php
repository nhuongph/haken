<?php echo e($project_name); ?><br>
<?php echo e($staff_name); ?>からメッセージが届きました。<br>
<br>
<pre><?php echo e($message_detail); ?></pre>
<br>
<br>
メッセージに返信する<br>
<?php echo e(url('staff/manage/check-point/message/')); ?>/<?php echo e($message_id); ?><br>
<br>
案件詳細<br>
<?php echo e(url('user/project/detail/')); ?>/<?php echo e($project_id); ?><br>
<br>
-------------------<br>
このメールはシステムより自動配信されています。<br>
返信は受付できませんので、ご了承ください。<br>