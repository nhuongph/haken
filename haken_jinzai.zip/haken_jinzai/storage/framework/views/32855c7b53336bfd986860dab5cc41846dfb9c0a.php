<?php $__env->startSection('title'); ?>
    <?php echo e(trans('title.wanted-job.worklist')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>

    table tbody tr th:first-child{
        width: 30%;
    }
</style>    
    

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('site/wanted/_detail_order',['data'=>$data], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                    <?php echo Form::open(array( 'method' => 'POST')); ?>

                    <?php echo Form::hidden('type',\Illuminate\Support\Facades\Input::get('type')); ?>

                    <?php foreach($dateTable as $dateRange): ?>
                    <table width="100%" class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" id="user-table" style="margin-top: 50px">
                        
                        <?php foreach($dateRange as $row): ?>
                            <tr class="row-result">
                                <?php foreach($row as $col): ?>
                                    <?php $isSelect = in_array($col, $userSelected) ?>
                                    <th><?php echo e(strpos($col, '@') !== false ? Form::checkbox('wanted_job[]', $col,$isSelect): $col); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>              
                    </table>
                    <?php endforeach; ?>
                    <div class="form-group">

                    
                    <?php echo Form::submit(trans('title.action.apply'), ['class' => 'col-xs-offset-3 col-xs-6 btn btn-default btn-lg']); ?>

                    
                    </div>
                    <?php echo e(Form::close()); ?>

                    
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('page_js'); ?>
       <script>
     $(function(){
         $('.row-result').each(function (i, e) {
            var $e = $(e);

            if ($e.text().indexOf('土') >= 0 || $e.text().indexOf('日') >= 0) {
                $e.addClass("danger");
            }
        });
       
     })
    </script> 
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>