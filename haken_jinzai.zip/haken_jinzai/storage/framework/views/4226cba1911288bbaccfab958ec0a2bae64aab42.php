<table class="table schedule-week">
	<?php foreach($dateList as $date): ?>
		<?php if( isset($scheduleList[$date]) ): ?>
			<?php foreach($scheduleList[$date] as $key => $chedule): ?>
			<tr>
				<?php if($key == 0): ?>
				<th rowspan="<?php echo e(count($scheduleList[$date])); ?>" style="width: 10%" class="<?php echo e($date == $currentDate ? 'info' : 'bg-primary'); ?>"><?php echo e(date('m-d', strtotime($date)).' '.trans( 'common.days.'.date('D', strtotime($date)) )); ?></th>				
				<?php endif; ?>
				<td><?php echo e($chedule->AddressCompany); ?> <?php echo e($chedule->Brand); ?><br/><?php echo e($chedule->AddressCompany); ?></td>
				<td><?php echo e($chedule->TimeStart); ?> 〜 <?php echo e($chedule->TimeEnd); ?></td>
			</tr>
			<?php endforeach; ?>
		<?php elseif( date('D', strtotime($date)) == 'Sat' ||  date('D', strtotime($date)) == 'Sun' ): ?>
		<tr class="danger">
			<th style="width: 10%"><?php echo e(date('m-d', strtotime($date)).' '.trans( 'common.days.'.date('D', strtotime($date)) )); ?></th>
			<td></td>
			<td></td>
		</tr>
		<?php else: ?>
		<tr>
			<th style="width: 10%" class="bg-primary"><?php echo e(date('m-d', strtotime($date)).' '.trans( 'common.days.'.date('D', strtotime($date)) )); ?></th>
			<td></td>
			<td></td>
		</tr>
		<?php endif; ?>
	<?php endforeach; ?>
</table>