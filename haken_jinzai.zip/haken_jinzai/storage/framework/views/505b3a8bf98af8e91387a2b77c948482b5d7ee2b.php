<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.wanted-job.worklist')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<link href="<?php echo asset('css/site/wanted/search.css'); ?>" rel="stylesheet">
<style>
  .item-order{
    background: #eee;
    margin: 20px 0px;
    padding: 2%;
  }
  img{
    width: 20%;
  }
</style>
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
        <?php if(\Illuminate\Support\Facades\Input::get('type') == 1 ): ?>
        <?php echo e(trans('title.wanted-job.recruitment_list')); ?>

        <?php else: ?>
        
        <?php echo e(trans('title.wanted-job.introduced_work')); ?>

        <?php endif; ?>
    </h1>
  </div>
  <!-- /.col-lg-12 -->
</div>

<div class="row">
  <div class="col-lg-10">
    <div class="panel panel-default">
      <div class="panel-heading">
        
      </div>
      <div class="panel-body">
        <div class="col-md-12 ">
          <?php echo $__env->make('site/message/index' , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="row ">
            <div class="col-xs-12 col-md-12">
              <a href="<?php echo e(route('wanted-job/index',['type' =>\Illuminate\Support\Facades\Input::get('type')])); ?>" class="pull-right  btn btn-default btn-lg"><?php echo e(trans('title.action.return')); ?></a>
              <a href="<?php echo e(route('project_search',['type' =>\Illuminate\Support\Facades\Input::get('type')])); ?>" class="pull-right  btn btn-default btn-lg"><?php echo e(trans('title.wanted-job.search.filter_search')); ?></a>
            </div>
          </div>         

          <?php if(count($datas) > 0 ): ?>
          <?php foreach($datas as $data): ?>
          <div class="item-order">
            <div class="row">
              <div class="col-md-3">
                
                <img class="img-responsive thumbnail" alt="" src="<?php echo count($data->Resource) >0 ? URL::to($data->Resource->Path) : ''; ?>">     
              </div>
              <div class="col-md-7">
                <div><h3><?php echo e(isset($data->Orders) ? $data->Orders->ProjectName:''); ?></h3></div>
                <div class="text-right"><p><b><?php echo e(isset($data->Orders) ? $data->Orders->AddressCompany:''); ?></b></p></div>
              </div>
              <div class="col-md-2 text-right">
                <p><span class="label label-warning label-cate"><?php echo e($data->Orders->CategoryJob); ?></span></p>
                <p><span class="label label-success label-cate"><?php echo e($data->Orders->AddressCompany); ?></span></p>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <?php if($data->IsNoExperience): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.OK_inperienced'); ?></span> <?php endif; ?>
                <?php if($data->IsTransportation): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.transportation_paid'); ?></span> <?php endif; ?>
                <?php if($data->IsLongTime): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.long_term'); ?></span> <?php endif; ?>
                <?php if($data->IsInAMonth): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.in_a_month'); ?></span> <?php endif; ?>
                <?php if($data->IsTenDays): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.in_10_days'); ?></span> <?php endif; ?>
                <?php if($data->IsOnlyOneDay): ?> <span class="label label-info label-tag"><?php echo trans('title.wanted-job.search.only_1_day'); ?></span> <?php endif; ?>
              </div>
            </div>

            <div class="row">
              <div class="col-md-10">
                <p class="taskoverview"><?php echo $data->Orders->TaskOverview; ?></p>
              </div>
              <div class="col-md-2">
                <div class="text-right">
                  <?php if(\Illuminate\Support\Facades\Input::get('type') != 3): ?>
                  <a href="<?php echo e(route('wanted-job/register',['orderId'=>$data->OrderId,'type' =>\Illuminate\Support\Facades\Input::get('type')])); ?>" class=" col-xs-12 col-md-12 btn btn-default "><?php echo e(trans('title.action.detail')); ?></a>
                  <?php else: ?>
                  <a href="<?php echo e(route('wanted-job/view',['orderId'=>$data->OrderId,'type' =>\Illuminate\Support\Facades\Input::get('type')])); ?>" class=" col-xs-12 col-md-12 btn btn-default "><?php echo e(trans('title.action.detail')); ?></a>
                  <?php endif; ?> 
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>

          <div class="pull-right">
            <?php echo $datas->appends(\Illuminate\Support\Facades\Input::except('page'))->render(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>