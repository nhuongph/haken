承認依頼が届いています。<br>
ご確認をお願いいたします。<br>
<br>
案件名：<?php echo e($order_name); ?><br>
派遣先名称：<?php echo e($company_name); ?><br>
受注者：<?php echo e($created_name); ?><br>
業務概要：<?php echo e($overview_content); ?><br>
<br>
承認URL<br>
https://aaa.test.jp/123/details/final<br>
<br>
<br>
-------------------<br>
このメールはシステムより自動配信されています。<br>
返信は受付できませんので、ご了承ください。<br>