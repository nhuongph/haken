<div>
    <span class="required">※</span>は入力必須項目です。<br>
    それ以外の項目は、必須ではありませんが、ご入力いただけますと、面接がスムーズです。<br>
    可能な限り、入力いただけますと幸いです。
</div>
<br>
<div id="basic_form">
    <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal', 'files' => true]); ?>

    <table class="table table-responsive table-bordered">
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.first_name')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('first_name', $staff->FirstName, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td width="15%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.last_name')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('last_name', $staff->LastName, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.first_name_furigana')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('first_name_furigana', $staff->FirstNameFurigana, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.last_name_furigana')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('last_name_furigana', $staff->LastNameFurigana, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.birthdate')); ?><span class="required">*</span> :
            </td>
            <td>
                <div id='birthdate' class="input-group date marginBottom5 col-md-6">
                    <?php echo Form::text('birthdate', isset($staff->Birthdate) ? $staff->Birthdate :'1980-01-01', ['id'=>'','class'=>'form-control']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.sex')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::radio('sex',1 , $staff->Sex && $staff->Sex == 1 ? true : false); ?> <?php echo e(trans('title.pre-register.male')); ?>

                <?php echo Form::radio('sex',0 , $staff->Sex && $staff->Sex == 0 ? true : false); ?> <?php echo e(trans('title.pre-register.female')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.phone')); ?> <span class="required">*</span>  :
            </td>
            <td>
                <?php echo Form::text('phone', $staff->Phone, ['class'=>'form-control phone-number']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.fax')); ?> :
            </td>
            <td>
                <?php echo Form::text('fax', $staff->Fax, ['class'=>'form-control','maxlength'=>'15']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.mobile')); ?> :
            </td>
            <td>
                <?php echo Form::text('mobile', $staff->Mobile, ['class'=>'form-control phone-number']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.email')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('email', $staff->Email, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.password')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::password('password', ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.postal_code')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('postal_code', $staff->PostalCode, ['class'=>'form-control zip-code','onKeyUp'=>"AjaxZip3.zip2addr(this, '', 'prefectural_name', 'commune');",'maxlength'=>'8']); ?>

                <!--<input type="text" name="postal_code" maxlength="8" value="<?php echo e($staff->PostalCode ? $staff->PostalCode : null); ?>" class="form-control" onKeyUp="AjaxZip3.zip2addr(this, '', 'prefectural_name', 'commune');">-->
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.district_name')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('prefectural_name', $staff->PrefecturalName, ['class'=>'form-control']); ?>

                <!--<input type="text" name="prefectural_name" value="<?php echo e($staff->PrefecturalName ? $staff->PrefecturalName : null); ?>" class="form-control">-->
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.commune')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('commune', $staff->MunicipalName, ['class'=>'form-control']); ?>

                <!--<input type="text" name="commune" value="<?php echo e($staff->MunicipalName ? $staff->MunicipalName : null); ?>" class="form-control">-->
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.address_detail')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('address_detail', $staff->AddressDetail, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.current_employment_status')); ?> :
            </td>
            <td>
                <?php echo Form::select('current_employment_status', $employmentStatus, isset ($staff->CurrentEmploymentStatus) ? $staff->CurrentEmploymentStatus : '在職中', ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.station')); ?> <span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::text('nearest_station', $subStaff->NearestStation, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.registration_history')); ?> :
            </td>
            <td>
                <?php echo Form::select('registration_history',[''=> '-- 選択してください --'] + $selectRegistrationHistory, $subStaff->RegistrationHistory, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.image_step1')); ?> :
            </td>
            <td>
                <div class="form-group">
                    <div class="col-md-6">
                        <?php echo Form::file('image',['class'=>'form-control']); ?>

                        <span>パスポートや免許証に設定しているのと同じような、バストアップの画像が最善です。</span>
                        <div id="profileImage" class="categoryThumbnail">

                            <?php if($subStaff->Image): ?>
                            <?php $image = \App\Model\Resource::find($subStaff->Image); ?>

                            <img src="<?php echo e(route('home')); ?>/<?php echo e($image->Path); ?>" alt="" class="img-responsive img-circle">
                            <?php endif; ?>
                            <!-- Thumbnail here -->
                        </div>
                        
                    </div>
                </div>
            </td>
        </tr>
    </table>
    <table class="table table-responsive table-bordered">
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.desire_period')); ?> <span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::select('desire_period',$selectDesirePeriod ,$staff->DesiredPeriod, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.employment_workday')); ?> <span class="required">*</span> :
            </td>
            <td>
                <div class="form-group">
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('monday',1,$subStaff->Monday); ?> 月</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('tuesday',1,$subStaff->Tuesday); ?> 火</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('wednesday',1,$subStaff->Wednesday); ?> 水</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('thursday',1,$subStaff->Thursday); ?> 木</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('friday',1,$subStaff->Friday); ?> 金</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('saturday',1,$subStaff->Saturday); ?> 土</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('sunday',1,$subStaff->Sunday); ?> 日</div>
                    <div class="col-md-3 col-xs-6"><?php echo Form::checkbox('public_holiday',1,$subStaff->PublicHoliday); ?>祝日</div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.job_objective')); ?> :
            </td>
            <td>

                <?php echo Form::checkbox('mobile_sale',1,$subStaff->MobileSale); ?> 携帯販売 <br>
                <?php echo Form::checkbox('home_sale',1,$subStaff->HomeSale); ?> 家電販売 <br>
                <?php echo Form::checkbox('cosmetic_sale',1,$subStaff->CosmeticSale); ?> 化粧品販売<br>
                <?php echo Form::checkbox('apparel_sale',1,$subStaff->ApparelSale); ?> アパレル販売<br>
                <?php echo Form::checkbox('goods_sale',1,$subStaff->GoodsSale); ?> 雑貨販売<br>
                <?php echo Form::checkbox('food_sale',1,$subStaff->FoodSale); ?> 食品販売<br>
                <?php echo Form::checkbox('tasting_sale',1,$subStaff->TastingSale); ?> 試飲・試食販売<br>
                <?php echo Form::checkbox('business',1,$subStaff->Business); ?> 営業<br>
                <?php echo Form::checkbox('rounder',1,$subStaff->Rounder); ?> ラウンダ<br>
                <?php echo Form::checkbox('coffee_staff',1,$subStaff->CoffeeStaff); ?> カフェスタッフ<br>
                <?php echo Form::checkbox('department_store_cash',1,$subStaff->DeparmentStoreCashRegister); ?> 百貨店レジ<br>
                <?php echo Form::checkbox('secretary',1,$subStaff->Secretary); ?> 事務<br>
                <?php echo Form::checkbox('data_entry',1,$subStaff->DataEntry); ?> データ入力<br>
                <?php echo Form::checkbox('companion',1,$subStaff->Companion); ?> コンパニオン<br>
                <?php echo Form::checkbox('director',1,$subStaff->Director); ?> ディレクター<br>
                <?php echo Form::checkbox('light_work',1,$subStaff->Lightwork); ?> 軽作業<br>
                <?php echo Form::checkbox('other',1,$subStaff->Other  ); ?> その他<br>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.employment_deadline')); ?> : <br>
                <?php echo e(trans('title.pre-register.expiration_date')); ?>

            </td>
            <td>
                <div id='employment_deadline' class="input-group date marginBottom5 col-md-6">
                    <?php echo Form::text('employment_deadline',$subStaff->EmploymentDeadline, ['class'=>'form-control']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </td>
        </tr>
    </table>
    <table class="table table-responsive table-bordered">
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.entitlement')); ?> :
            </td>
            <td>
                <?php echo Form::checkbox('ordinary_license',1,$subStaff->OrdinaryLicense); ?> 普通免許 <br>
                <?php echo Form::checkbox('sales_officer',1,$subStaff->SalesOfficer); ?> 販売士<br>
                <?php echo Form::checkbox('home_appliance_advisor',1,$subStaff->HomeApplianceAdvisor); ?> 家電製品アドバイザー<br>
                <?php echo Form::checkbox('other_language_test',1,$subStaff->OtherLanguageTest); ?> 他言語検定 <br>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.entitlement')); ?> <br>
                <?php echo e(trans('title.pre-register.english')); ?>

            </td>
            <td>
                <div class="input-group marginBottom5 col-md-6">
                    <span class="input-group-btn">
                        <button class="btn btn-secondary widthBtnGroup70" type="button">TOEIC</button>
                    </span>
                    <?php echo Form::text("TOEIC",$subStaff->TOEIC ? $subStaff->TOEIC : 0,['class' => 'form-control']); ?>

                    <span class="input-group-btn">
                        <button class="btn btn-secondary" type="button">点</button>
                    </span>
                </div>
                <div class="input-group marginBottom5 col-md-6">
                    <span class="input-group-btn">
                        <button class="btn btn-secondary widthBtnGroup70" type="button">TOEFL</button>
                    </span>
                    <?php echo Form::text("TOEFL",$subStaff->TOEFL ? $subStaff->TOEFL : 0,['class' => 'form-control']); ?>

                    <span class="input-group-btn">
                        <button class="btn btn-secondary" type="button">点</button>
                    </span>
                </div>
            </td>
        </tr>
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.entitlement')); ?> <br>
                <?php echo e(trans('title.pre-register.other')); ?>

            </td>
            <td>
                <?php echo Form::textarea('entitlement',$subStaff->Entitlement,['class'=>'form-control','rows'=>4]); ?>

            </td>
        </tr>
        <tr>
            <td colspan="4">
                卒業校について、新しいものから2つ、情報の登録を行ってください。
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education_school')); ?> <span class="required">*</span>:
            </td>
            <td>
                <?php echo Form::text('education_school', $staff->EducationDivisionSchool, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education')); ?> <span class="required">*</span>:
            </td>
            <td>
                <?php echo Form::select('education', $educationDivision ,$staff->EducationDivision, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education_department')); ?> :
            </td>
            <td>
                <?php echo Form::text('education_department', $staff->EducationDivisionDepartment, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education_school')); ?> <span class="required">*</span>:
            </td>
            <td>
                <?php echo Form::text('education_school_2', $staff->EducationDivisionSchool_2, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education')); ?> <span class="required">*</span>:
            </td>
            <td>
                <?php echo Form::select('education_2', $educationDivision ,$staff->EducationDivision_2, ['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.education_department')); ?> :
            </td>
            <td>
                <?php echo Form::text('education_department_2', $staff->EducationDivisionDepartment_2, ['class'=>'form-control']); ?>

            </td>
        </tr>
    </table>
    <h4 class="text-header-content"><?php echo e(trans('title.pre-register.part_time')); ?></h4>
    <legend class="pre-reg-new-legend"><?php echo trans('pre-register.new.1'); ?><?php echo e(trans('title.pre-register.part_time')); ?></legend>
    <div class="row pre-reg-new-row-title pre-reg-new-h-header row-eq-height">
        <div class="col-md-2"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-4"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-3"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3"><?php echo trans('title.pre-register.work_period'); ?></div>        
    </div>
    <div class="row pre-reg-new-row-content">
        <div class="col-md-2 pre-reg-new-v-header"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-2 pre-reg-new-cell-height">
            <div class="pre-reg-new-cell">
                <?php echo Form::text('CompanyName1',$staff->CompanyName1,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-8 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-4 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::textarea('WorkContent1',$staff->WorkContent1,['class'=>'form-control full-width','rows' => 3]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::select('WorkCode1', $workCode, $staff->WorkCode1,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_period'); ?></div>                
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('StartWork1',$staff->StartWork1,['id'=>'start_work1','class'=>'form-control full-width']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('EndWork1',$staff->EndWork1,['id'=>'end_work1','class'=>'form-control full-width']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>            
            </div>
        </div>  
    </div>
    <legend class="pre-reg-new-legend"><?php echo trans('pre-register.new.2'); ?><?php echo e(trans('title.pre-register.part_time')); ?></legend>
    <div class="row pre-reg-new-row-content">
        <div class="col-md-2 pre-reg-new-v-header"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-2 pre-reg-new-cell-height">
            <div class="pre-reg-new-cell">
                <?php echo Form::text('CompanyName2',$staff->CompanyName2,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-8 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-4 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::textarea('WorkContent2',$staff->WorkContent2,['class'=>'form-control full-width','rows' => 3]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::select('WorkCode2', $workCode, $staff->WorkCode2,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_period'); ?></div>                
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('StartWork2',$staff->StartWork2,['id'=>'start_work2','class'=>'form-control full-width marginBottom5']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('EndWork2',$staff->EndWork2,['id'=>'end_work2','class'=>'form-control full-width']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>            
            </div>
        </div>  
    </div>    
    <legend class="pre-reg-new-legend"><?php echo trans('pre-register.new.3'); ?><?php echo e(trans('title.pre-register.part_time')); ?></legend>
    <div class="row pre-reg-new-row-content">
        <div class="col-md-2 pre-reg-new-v-header"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-2 pre-reg-new-cell-height">
            <div class="pre-reg-new-cell">
                <?php echo Form::text('CompanyName3',$staff->CompanyName3,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-8 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-4 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::textarea('WorkContent3',$staff->WorkContent3,['class'=>'form-control full-width','rows' => 3]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::select('WorkCode3', $workCode, $staff->WorkCode3,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_period'); ?></div>                
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('StartWork3',$staff->StartWork3,['id'=>'start_work3','class'=>'form-control marginBottom5']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('EndWork3',$staff->EndWork3,['id'=>'end_work3','class'=>'form-control']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>            
            </div>
        </div>  
    </div>       
    <legend class="pre-reg-new-legend"><?php echo trans('pre-register.new.4'); ?><?php echo e(trans('title.pre-register.part_time')); ?></legend>
    <div class="row pre-reg-new-row-content">
        <div class="col-md-2 pre-reg-new-v-header"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-2 pre-reg-new-cell-height">
            <div class="pre-reg-new-cell">
                <?php echo Form::text('CompanyName4',$staff->CompanyName4,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-8 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-4 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::textarea('WorkContent4',$staff->WorkContent4,['class'=>'form-control full-width','rows' => 3]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::select('WorkCode4', $workCode, $staff->WorkCode4,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_period'); ?></div>                
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('StartWork4',$staff->StartWork4,['id'=>'start_work4','class'=>'form-control marginBottom5']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('EndWork4',$staff->EndWork4,['id'=>'end_work4','class'=>'form-control']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>            
            </div>
        </div>  
    </div> 
    <legend class="pre-reg-new-legend"><?php echo trans('pre-register.new.5'); ?><?php echo e(trans('title.pre-register.part_time')); ?></legend>
    <div class="row pre-reg-new-row-content">
        <div class="col-md-2 pre-reg-new-v-header"><?php echo trans('title.pre-register.company_name'); ?></div>
        <div class="col-md-2 pre-reg-new-cell-height">
            <div class="pre-reg-new-cell">
                <?php echo Form::text('CompanyName5',$staff->CompanyName5,['class'=>'form-control full-width']); ?>

            </div>
        </div>
        <div class="col-md-8 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_content'); ?></div>
        <div class="col-md-4 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::textarea('WorkContent5',$staff->WorkContent5,['class'=>'form-control full-width','rows' => 3]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_code'); ?></div>
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <?php echo Form::select('WorkCode5', $workCode, $staff->WorkCode5,['class'=>'form-control full-width' ]); ?>

            </div>
        </div>
        <div class="col-md-3 pre-reg-new-v-header"><?php echo trans('title.pre-register.work_period'); ?></div>                
        <div class="col-md-3 pre-reg-new-cell-height pre-reg-new-pt-border">
            <div class="pre-reg-new-cell">
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('StartWork5',$staff->StartWork5,['id'=>'start_work5','class'=>'form-control marginBottom5']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                <div class="input-group date marginBottom5">
                    <?php echo Form::text('EndWork5',$staff->EndWork5,['id'=>'end_work5','class'=>'form-control']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>            
            </div>
        </div>  
    </div> 
    <br>
    <table class="table table-responsive table-bordered">
        <tr>
            <td width="20%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.transfer_method')); ?><span class="required">*</span> :
            </td>
            <td>
                <?php echo Form::radio('transfer_method','月払', $staff->TransferMethod != null && $staff->TransferMethod == '月払' ? true : false ); ?> <?php echo e(trans('title.pre-register.month')); ?>

                <?php echo Form::radio('transfer_method','週払', $staff->TransferMethod != null && $staff->TransferMethod == '週払' ? true : false); ?> <?php echo e(trans('title.pre-register.week')); ?>

            </td>
        </tr>
        <tr>
            <td width="15%" class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.height')); ?> :
            </td>
            <td>
                <div class="input-group marginBottom5 col-md-6">
                    <?php echo Form::number('height',$staff->Height,['class'=>'form-control','min'=>'0']); ?>

                    <span class="input-group-btn">
                        <button class="btn btn-secondary" type="button">Cm</button>
                    </span>
                </div>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.uniform_size')); ?> :
            </td>
            <td colspan="3">
                <div class="col-md-2 uniformSize marginBottom5 nonePaddingLeft">
                    <?php foreach($selectUniformSize as $size): ?>
                    <?php echo Form::radio('uniform_type',$size, ($staff->UniformType != null && $staff->UniformType == $size) || ($staff->UniformType ==null && $size =='M') ? true : false); ?> <?php echo e($size); ?>

                    <?php endforeach; ?>
                </div>
                <div class="col-md-4">
                    <div class="input-group marginBottom5 nonePaddingLeft">
                        <?php echo Form::select('clothes_size',$selectClotheSize, $subStaff->ClothesSize ? $subStaff->ClothesSize : 9,['class'=>'form-control']); ?>

                        <span class="input-group-btn">
                            <button class="btn btn-secondary" type="button">号</button>
                        </span>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.shoes_size')); ?> :
            </td>
            <td>
                <?php echo Form::select('shoes_size',$selectShoesSize, $staff->ShoesSize ? $staff->ShoesSize : '24.5',['class'=>'form-control']); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.suit_preparation')); ?> :
            </td>
            <td>
                <?php echo Form::radio('suit_preparation',1, $staff->SuitPreparation != null && $staff->SuitPreparation == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('suit_preparation',0, $staff->SuitPreparation == null || $staff->SuitPreparation == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.white_shirt_preparation')); ?> :
            </td>
            <td>
                <?php echo Form::radio('white_shirt_preparation',1, $staff->WhiteShirtPreparation != null && $staff->WhiteShirtPreparation == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('white_shirt_preparation',0, $staff->WhiteShirtPreparation == null || $staff->WhiteShirtPreparation == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.black_pump_preparation')); ?> :
            </td>
            <td>
                <?php echo Form::radio('black_pump_preparation',1, $staff->BlackPumpPreparation != null && $staff->BlackPumpPreparation == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('black_pump_preparation',0, $staff->BlackPumpPreparation == null || $staff->BlackPumpPreparation == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.apron_sling')); ?> :
            </td>
            <td>
                <?php echo Form::radio('apron_sling',1, $staff->ApronSling != null && $staff->ApronSling == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('apron_sling',0, $staff->ApronSling == null || $staff->ApronSling == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.black_hair_modification')); ?> :
            </td>
            <td>
                <?php echo Form::radio('black_hair_modification',1, $staff->BlackHairModification != null && $staff->BlackHairModification == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('black_hair_modification',0, $staff->BlackHairModification == null || $staff->BlackHairModification == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.voice')); ?> :
            </td>
            <td>
                <?php echo Form::radio('voice',1, $staff->Voice != null && $staff->Voice == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('voice',0, $staff->Voice == null || $staff->Voice == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.department_store_experience')); ?> :
            </td>
            <td>
                <?php echo Form::radio('department_store_experience',1, $staff->DepartmentStoreExperience != null && $staff->DepartmentStoreExperience == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.ok')); ?>

                <?php echo Form::radio('department_store_experience',0, $staff->DepartmentStoreExperience == null || $staff->DepartmentStoreExperience == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.nothing')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.pos_cash_register_experience')); ?> :
            </td>
            <td>
                <?php echo Form::radio('pos_cash_register_experience',1, $staff->POSCashRegisterExperience != null && $staff->POSCashRegisterExperience == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.ok')); ?>

                <?php echo Form::radio('pos_cash_register_experience',0, $staff->POSCashRegisterExperience == null || $staff->POSCashRegisterExperience == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.nothing')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.cat_experience')); ?> :
            </td>
            <td>
                <?php echo Form::radio('cat_experience',1, $staff->CATExperience != null && $staff->CATExperience == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.ok')); ?>

                <?php echo Form::radio('cat_experience',0, $staff->CATExperience == null || $staff->CATExperience == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.nothing')); ?>

            </td>
        </tr>
        <tr>
            <td class="text-right pre-reg-new-header">
                <?php echo e(trans('title.pre-register.nail_modification')); ?> :
            </td>
            <td>
                <?php echo Form::radio('nail_modification',1, $staff->NailModification != null && $staff->NailModification == 1 ? true : false ); ?> <?php echo e(trans('title.pre-register.yes')); ?>

                <?php echo Form::radio('nail_modification',0, $staff->NailModification == null || $staff->NailModification == 0 ? true : false ); ?> <?php echo e(trans('title.pre-register.improper')); ?>

            </td>
        </tr>
    </table>
    <div class="form-group">
        <div class="button-group text-center">
            <?php echo Form::hidden('step','step_2'); ?>

            <button class="btn widthBtnGroup70 btn-primary btn-lg"><?php echo e(trans('title.staff.next')); ?></button>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>