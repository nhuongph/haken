  <?php use Illuminate\Support\Facades\Auth; ?>
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('img/avatar.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(empty(auth()->guard('admin')->user()) ? '' : auth()->guard('admin')->user()->name); ?></p>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header"><?php echo e(trans('menu.header-main-sidebar')); ?></li>
        <?php foreach(Menu::getSidebarMenus() as $key => $value): ?>
        <li class="treeview">
          <a href="<?php echo URL::to($value->link); ?>">
            <i class="<?php echo $value->icon; ?> "></i>&#32;
            <span><?php echo trans($value->text); ?></span>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>