  <?php use Illuminate\Support\Facades\Auth; ?>
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('img/avatar.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(auth()->guard('admin')->user()->name); ?></p>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header"><?php echo e(trans('menu.header-main-sidebar')); ?></li>
        <?php 
            $icons = array("fa fa-tasks", 
            "fa fa-pencil-square-o", 
            "fa fa-user-secret", 
            "fa fa-registered", 
            "fa fa-table", 
            "fa fa-briefcase", 
            "fa fa-credit-card", 
            "fa fa-envelope-o", 
            "fa fa-user", 
            "glyphicon glyphicon-export",
            "fa fa-unlock-alt");
            $i=0;
        ?>
        <?php foreach(Menu::getSidebarMenus() as $key => $value): ?>
        <li class="treeview">
          <a href="<?php echo URL::to($value->link); ?>">
            <i class="<?php echo $icons[$i]; ?> "></i>&#32;
            <span><?php echo trans($value->text); ?></span>
          </a>
        </li>
        <?php $i+=1; ?>
        <?php endforeach; ?>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>