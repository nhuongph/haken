<div class="text-header"><?php echo trans('pre-register.new.interview-time'); ?></div>
<div class="pre-reg-new-step2-layout ">
<table class="table  table-bordered">
<?php if(count($times) > 0 && $region->Type == 1): ?>
    <?php if($region->Type == 1): ?>
        <?php echo Form::hidden('regionType',$region->Type); ?>

        <?php $i = 0 ?>
        <?php foreach($times as $key => $time): ?>
            <tr >
                <td colspan="3" class="text-center col-md-2"><?php echo e(date('m/d', strtotime($key))); ?> <br> (<?php echo e($date[date('w', strtotime($key))]); ?>)</td>
                <td>
                    <?php echo Form::hidden("interviewDate[]",$key); ?>

                    <?php foreach($time as $hour): ?>
                        <p class="text-center"><?php echo Form::checkbox("interviewTime[".$i."][]",$hour,false,['class'=>'interview']); ?> <?php echo e($hour); ?></p>
                    <?php endforeach; ?>
                </td>
            </tr>
        <?php $i++ ?>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>
<?php if(count($times) > 0 && $region->Type == 0): ?>
    <?php $i = 0 ?>
    <?php echo Form::hidden('regionType',$region->Type); ?>

    <?php foreach($times as $key => $time): ?>
        <?php $places = $AnotherInterviewTimeBusiness->getAnotherInterviewTimeByDate($time->Date) ?>
    <tr class="row">
            <td colspan="3" class="text-center col-md-2"><?php echo e(date('m/d', strtotime($time->Date))); ?> <br> (<?php echo e($date[date('w', strtotime($time->Date))]); ?>)</td>
            <td>
                <?php echo Form::hidden("interviewDate[]",$time->Date); ?>

                <?php if(count($places) > 0): ?>
                    <?php foreach($places as $place): ?>
                    <div class="col-md-3">
                        <?php echo Form::radio("anotherInterviewTime",$place->AnotherInterviewTimeID,false,['class'=>'anotherInterview']); ?> <?php echo e($place->RegionName.' '.$place->ResponsibleName); ?>

                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php $i++ ?>
    <?php endforeach; ?>
<?php endif; ?>
</table>
</div>
<script>
    $('.interview').on('change',function(){
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });
    $('.anotherInterview').on('change',function() {
        if($(this).is(':checked')){
            $('[name=noPossibleTime]').prop('checked', false);
        }
    });
</script>
