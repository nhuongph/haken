<!--
    Creator: ToiTL
    Date: 2016/05/18
-->

<?php $__env->startSection('title'); ?>
    <?php echo trans('title.pre-register.management'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/pre-register/pre-register.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="alert alert-sm alert-danger error_message" style="opacity: 0; display: none;"></div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo trans('title.staff.management_staff'); ?>

                </div>
                <div class="panel-body">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <style type="text/css">
                            /*.table-cus {
                                display: table;
                            }

                            .row [class*="column-cus"]{
                                float: none;
                                display: table-cell;
                                vertical-align: top;
                            }*/

                            .row [class*="column-cus"] .main-panel{
                                height: 500px !important;
                                overflow-y: auto;
                                overflow-x: hidden;
                                padding: 10px;
                            }

                        </style>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 column-cus">
                                <form action="" method="post" id="searchDataForm">
                                    <h4><?php echo trans('title.staff.management_staff'); ?></h4>
                                    <div class="panel panel-default main-panel">
                                        <div class="row top-buffer">
                                            <div class="col-md-2"><?php echo trans('title.staff.gender'); ?></div>
                                            <div class="col-md-10">
                                                <?php echo Form::checkbox('male', null, false); ?> <?php echo trans('title.staff.male'); ?>

                                                <?php echo Form::checkbox('female', null, false); ?> <?php echo trans('title.staff.female'); ?>

                                            </div>
                                        </div>

                                        <div class="row top-buffer">
                                            <div class="col-md-2"><?php echo trans('title.staff.age'); ?></div>
                                            <div class="col-md-10 row">
                                                <div class="col-md-4">
                                                    <?php echo Form::text('startAge', '', ['class' => 'form-control']); ?>

                                                </div>
                                                <div class="col-md-8 row">
                                                    <div class="col-md-5">
                                                        <?php echo trans('title.staff.to_age'); ?>

                                                    </div>
                                                    <div class="col-md-7">
                                                        <?php echo Form::text('endAge', '', ['class' => 'form-control']); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row top-buffer">
                                            <div class="col-md-2"><?php echo trans('title.staff.tag'); ?></div>
                                            <div class="col-md-10">
                                                <ul class="tag_list nonePaddingLeft">

                                                  <?php foreach($tags as $key => $value): ?>
                                                      <li>
                                                          <?php echo Form::checkbox("tags[{$key}]", 1, false ); ?> <?php echo e($value); ?>

                                                      </li>
                                                  <?php endforeach; ?>
                                                    
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="row top-buffer">
                                            <div class="col-md-2">登録経緯</div>
                                            <div class="col-md-10">
                                                <div class="input-group">
                                                  <select class="form-control" name="registrationHistory">
                                                      <option value="-1">すべて</option>
                                                      <?php foreach($history as $key => $value): ?>
                                                          <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                                      <?php endforeach; ?>
                                                  </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row top-buffer">
                                            <div class="col-md-2"><?php echo trans('title.staff.nearest_station'); ?></div>
                                            <div class="col-md-10">
                                                <div class="input-group">
                                                  <?php echo Form::text('nearestStation', '', ['class' => 'form-control']); ?>

                                                  <span class="input-group-btn">
                                                    <button class="btn btn-default" type="button"><i class="glyphicon glyphicon-search"></i></button>
                                                  </span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row top-buffer">
                                            <div class="col-md-2"></div>
                                            <div class="col-md-10">
                                                <button class="btn btn-success search-btn" type="submit"><?php echo trans('title.staff.search'); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 column-cus">
                                <h4><?php echo trans('title.staff.last_comments'); ?></h4>
                                <div class="panel panel-default main-panel">
                                    <ul class="media-list">
                                        <?php foreach($comments as $key => $comment): ?>
                                        <li>
                                            <div class="panel panel-danger">
                                                <div class="panel-body">
                                                    <b><?php echo $comment->Name; ?></b>
                                                    <span><?php echo $comment->InterviewDate; ?></span>
                                                    <hr>
                                                    <div>
                                                        <?php echo $comment->Comment; ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div id="ajax-content">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('page_js'); ?>
        <script type="text/javascript" src="<?php echo e(asset('js/common/func/base.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/site/staff/management_staff_list.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>