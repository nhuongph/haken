<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.GaiA.GaiA_member_detail')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(route('gaia/management/member/menu')); ?>"><?php echo e(trans('gaiamanagement.title-menu')); ?></a></li>
        <li class="active"><?php echo e(trans('gaiamanagement.title-view')); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row text-setting gaia-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box box-info box-solid add">
            <div class="box-header with-border">
                <h4 class="text-title"><b><?php echo e(trans('gaiamanagement.title-view')); ?></b></h4>
            </div>
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="basic-form">
                        <div class="col-md-12 col-xs-12 text-right">
                            <?php if(!empty($user)): ?>
                            <a href="<?php echo e(route('registerpersonnel/getupdateregisterpersonal', ['userId'=>$user->id])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.user.basic_register.action.edit')); ?></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('listGaiAMember')); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.action.return')); ?></a>
                        </div>
                        <div class="col-md-12 col-xs-12">
                            &nbsp;
                        </div>
                        <div class="col-md-12 col-xs-12">
                            <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <?php if(!empty($user)): ?>
                        <?php echo Form::open(['id'=> 'registercompany', 'class' => 'form-horizontal']); ?>                        	  
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="col-md-1"></div>                            
                            <div class="col-md-11">
                                <h4><?php echo e(Form::label('title',\Lang::get('gaia.register.title1'),['class'=>'reg-title'])); ?></h4>
                            </div>
                        </div>
                        <div class="layout-child-panel reg-content col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.first-name'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Firstname; ?></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.last-name'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Lastname; ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.first-name-kana'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Firstname_Kana; ?></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.last-name-kana'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Lastname_Kana; ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.email'); ?></b></div>
                                <div class="col-md-8 email-validation" ><?php echo $user->email; ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.phone'); ?></b></div>
                                <div class="col-md-8 email-validation" ><?php echo $user->phone; ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.department-name'); ?></b></div>
                                <div class="col-md-8" >
                                    <?php echo $user->Part; ?>		
                                </div>
                            </div>
                            <div class="form-group"> 
                                <div class="col-md-2"></div>
                                <div class="col-md-2"><b><?php echo trans('gaia.register.title2'); ?></b></div>
                                <div class="col-md-8" >
                                    <?php echo $user->display_name; ?>

                                </div>
                            </div>            
                            <div class="form-group text-center">
                                &nbsp;
                            </div>  
                        </div>
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="col-md-1"></div>
                            <div class="col-md-11">
                                <h4><?php echo e(Form::label('title',\Lang::get('title.gaia_1.title'),['class'=>'reg-title'])); ?></h4>
                            </div>
                        </div>
                        <div class="col-md-10 col-xs-10 col-md-offset-1 col-xs-offset-1">
                            <table class="table table-bordered">
                                <?php foreach($role as $key=>$value): ?>
                                <tr>
                                    <td class="col-md-1 ">
                                        <?php echo Form::checkbox('roleid[]', $value->id,in_array($value->id, $role_user),['class'=>'roleid', 'disabled'=>'']); ?>

                                    </td>
                                    <td class="col-md-5 ">
                                        <?php echo e($value->display_name); ?>							
                                    </td>
                                    <td class="col-md-5 ">
                                        <?php $tit = 'title.gaia_1.role_' . (string) $key ?>
                                        <?php echo trans($tit); ?>

                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>         
                        <div class="form-group text-center">
                            &nbsp;
                        </div> 
                        <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>