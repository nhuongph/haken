<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.GaiA.GaiA_member_detail')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row text-setting gaia">
    <div class="col-lg-12 col-md-12 gaia-manage">
        <div class="panel panel-default register">
            <div class="panel-body layout-border">
                <div class="col-md-12 col-sm-12 col-sm-12 col-xs-12">
                    <div class="basic-form">
                        <div class="col-md-12 col-xs-12 text-right">
                            <a href="<?php echo e(route('registerpersonnel/getupdateregisterpersonal', ['userId'=>$user->id])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.user.basic_register.action.edit')); ?></a>

                            <a href="<?php echo e(route('listGaiAMember')); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.action.return')); ?></a>
                        </div>
                        <?php echo Form::open(['id'=> 'registercompany', 'class' => 'form-horizontal']); ?>                        	  
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <?php echo e(Form::label('title',\Lang::get('gaia.register.title1'),['class'=>'reg-title'])); ?>

                        </div>
                        <div class="layout-child-panel reg-content col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <div class="form-group">
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('common.title.first-name'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Firstname; ?></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.last-name'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Lastname; ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('common.title.first-name-kana'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Firstname_Kana; ?></div>
                                <div class="col-md-2"><b><?php echo trans('common.title.last-name-kana'); ?></b></div>
                                <div class="col-md-3"><?php echo $user->Lastname_Kana; ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('common.title.email'); ?></b></div>
                                <div class="col-md-8 email-validation" ><?php echo $user->email; ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('common.title.phone'); ?></b></div>
                                <div class="col-md-8 email-validation" ><?php echo $user->phone; ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('common.title.department-name'); ?></b></div>
                                <div class="col-md-8" >
                                    <?php echo $user->Part; ?>		
                                </div>
                            </div>
                            <div class="form-group"> 
                                <div class="col-md-1"></div>
                                <div class="col-md-3"><b><?php echo trans('gaia.register.title2'); ?></b></div>
                                <div class="col-md-8" >
                                    <?php echo $user->display_name; ?>

                                </div>
                            </div>            
                            <div class="form-group text-center">
                                &nbsp;
                            </div>  
                        </div>
                        <div class="form-group col-md-11 col-xs-11 col-md-offset-0 col-xs-offset-0">
                            <?php echo e(Form::label('title',\Lang::get('title.gaia_1.title'),['class'=>'reg-title'])); ?>

                        </div>
                        <div class="col-md-10 col-xs-10 col-md-offset-1 col-xs-offset-1">
                            <table class="table table-bordered table-responsive">
                                <?php foreach($role as $key=>$value): ?>
                                <tr>
                                    <td class="col-md-1 ">
                                        <?php echo Form::checkbox('roleid[]', $value->id,in_array($value->id, $role_user),['class'=>'roleid', 'disabled'=>'']); ?>

                                    </td>
                                    <td class="col-md-5 ">
                                        <?php echo e($value->display_name); ?>							
                                    </td>
                                    <td class="col-md-5 ">
                                        <?php $tit = 'title.gaia_1.role_' . (string) $key ?>
                                        <?php echo trans($tit); ?>

                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>         
                        <div class="form-group text-center">
                            &nbsp;
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>