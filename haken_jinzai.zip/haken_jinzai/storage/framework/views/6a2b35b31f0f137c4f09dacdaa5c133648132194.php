<?php $__env->startSection('title'); ?>
<?php echo e(trans('gaiamanagement.title-menu')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo e(trans('gaiamanagement.title-menu')); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row text-setting gaia">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 menu">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b><?php echo e(trans('gaiamanagement.title-menu')); ?></b></h4>
            </div>
            <div class="box-body menu-item">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="form-group">
                        <div class="button-group text-center">
                            <div>
                                <a href="<?php echo e(route('registerpersonnel/getnewregisterpersonal')); ?>" class="btn btn-lg btn-primary btn-management"><?php echo e(trans('title.gaia.new')); ?></a>
                            </div>
                            <div>
                            <a href="<?php echo e(route('listGaiAMember')); ?>" class="btn btn-lg btn-primary btn-management"><?php echo e(trans('title.gaia.list')); ?></a>
                            </div>
                            <div>
                                <a href="/gaia/management/history/list" class="btn btn-lg btn-primary btn-management"><?php echo e(trans('title.gaia.operationhistory')); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>