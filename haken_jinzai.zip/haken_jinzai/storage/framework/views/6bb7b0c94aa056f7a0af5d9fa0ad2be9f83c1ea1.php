<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.pre-register.management')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-lg-12 col-md-12 col-sm-12 col-xs-12 text-setting">
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading layout-bg-title">
                    <div class="row">
                        <div class='col-lg-8 col-md-8 col-sm-8 col-xs-8'>
                            <h4 class="text-title"><b><?php echo trans('pre-register.manage.title-menu'); ?></b></h4>
                        </div>
                    </div>
                </div>  
                <div class="panel-body layout-border">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <p class="text-right"><button class="btn btn-primary btn-lg pre-reg-manage-back-btn"><?php echo e(trans('title.action.return')); ?></button></p>
                        <fieldset>
                            <div class="form-group">
                                <div class="button-group text-center">
                                    <div class="">
                                    <a href="<?php echo e(route('pre-register/manage/interview/schedule')); ?>" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn"><?php echo e(trans('title.pre-register.interview_schedule')); ?></a>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('pre-register/manage/list')); ?>" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn"><?php echo e(trans('title.pre-register.pre-register_list')); ?></a>
                                    </div>
                                    <div>
                                        <a href="<?php echo route('tokyokanagawa_list'); ?>" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn"><?php echo e(trans('title.pre-register.interview_place')); ?></a>
                                    </div>
                                    <div>
                                        <a href="<?php echo route('another_list'); ?>" class="btn btn-default btn-lg pre-register-menu-button btn-primary pre-reg-manage-btn"><?php echo e(trans('title.pre-register.interview_other_place')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>