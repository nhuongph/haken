<?php $__env->startSection('title'); ?>
List Notice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/notice.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/notice_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/staffmanager/introducejob.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url'=> 'staffmanager/introducejobstaff', 'id'=>'introducejob', 'class'=>'form-horizontal']); ?>

<div class="container text-setting">
    <div class="panel panel-default">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-md-8 col-xs-8'>
                    <h4 class="text-title"><b><?php echo trans('staffmanager.introducejob.title'); ?></b></h4>
                </div>
            </div>
        </div>
        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="panel-body layout-border">  
            <div class="row margin-top-10 margin-bottom-10">
                <div class="staff-manager-child-panel p-up">
                    <div class="p-up-title"><?php echo trans('title.introducejob.title.introduce_job'); ?></div>                  
                    <div class="form-group text-center">
                        &nbsp;
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 category-search"><b><?php echo trans('title.introducejob.label.introduce_job_1'); ?></b></div>
                        <div class="col-md-9 nonePaddingLeft">
                            <?php echo e(Form::checkbox('sex[]', '1', false)); ?>&nbsp;男 &nbsp;&nbsp;
                            <?php echo e(Form::checkbox('sex[]', '0', false)); ?>&nbsp;女
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 category-search"><b><?php echo trans('title.introducejob.label.introduce_job_2'); ?></b></div>
                        <div class="col-md-9 nonePaddingLeft"> 
                            <?php echo e(Form::checkbox('rank[]', 'A', false)); ?>&nbsp;A &nbsp;&nbsp;
                            <?php echo e(Form::checkbox('rank[]', 'B', false)); ?>&nbsp;B &nbsp;&nbsp;
                            <?php echo e(Form::checkbox('rank[]', 'C', false)); ?>&nbsp;C &nbsp;&nbsp;
                            <?php echo e(Form::checkbox('rank[]', 'D', false)); ?>&nbsp;D
                        </div>
                    </div>                                    
                    <div class="form-group">
                        <div class="col-md-3 category-search"><b><?php echo trans('title.introducejob.label.introduce_job_3'); ?></b></div>
                        <div class="col-md-9 nonePaddingLeft">
                            <div class="col-md-3 nonePaddingLeft">
                                <?php echo Form::number('oldstart', null,['class'=>'form-control','min'=>0,'max'=>200,'id'=>'oldstart']); ?>

                            </div>
                            <div class="col-md-2 text-left float-left nonePaddingLeft"> 歳から </div>
                            <div class="col-md-3 nonePaddingLeft">
                                <?php echo Form::number('oldend', null,['class'=>'form-control','min'=>0,'max'=>200,'id'=>'oldend']); ?>

                            </div>
                            <div class="col-md-2 text-left float-left nonePaddingLeft"> 歳まで </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 category-search"><b><?php echo trans('title.introducejob.label.introduce_job_4'); ?></b></div>
                        <div class="col-md-9 nonePaddingLeft">
                            <?php foreach($tags as $tag): ?>
                            <?php $name = "Tag[$tag->TagId]";
                            ?>
                            <?php echo e(Form::checkbox($name, $tag->TagId, false)); ?>&nbsp;<?php echo $tag->Content; ?> &nbsp;&nbsp;
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-3 category-search"><b><?php echo trans('title.introducejob.label.introduce_job_5'); ?></b></div>
                        <div class="col-md-9 nonePaddingLeft">
                            <div class="col-md-5 nonePaddingLeft">
                                <?php echo Form::text('name', null,['class'=>'form-control']); ?>

                            </div>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <?php echo e(Form::submit(\Lang::get('title.introducejob.button.introduce_job_submit'),['class'=>'btn btn-default btn-lg button-submit','id'=>'submit_introducejob'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script src="<?php echo e(asset('js/site/staff/introducejob.js')); ?>"></script>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>