<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo csrf_token(); ?>">

    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('img/icons/favicon.ico')); ?>" type="image/x-icon">

    <!-- Web Fonts-->
    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet" type="text/css"> -->

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('plugins/sb-admin/css/sb-admin-2.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('plugins/admin-lte/css/AdminLTE.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/admin-lte/css/skins/_all-skins.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/sb-admin/css/timeline.css')); ?>" rel="stylesheet">

    <!-- Custom Css -->
    <link href="<?php echo e(asset('css/site/style.css')); ?>" rel="stylesheet">
    <!-- Font-awesome -->
    <link href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/metisMenu/dist/metisMenu.min.css')); ?>" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('css/site/menu/menu.css')); ?>" rel="stylesheet"> -->

    <!-- DataTable Css -->
    <link href="<?php echo e(asset('plugins/datatables/media/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Calendar Css -->
    <link href="<?php echo e(asset('css/site/bootstrap-datetimepicker.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Common Css -->
    <link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/common/layout.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/common/layout_responsive.css')); ?>" rel="stylesheet" type="text/css"/>    
    <!-- Include Css -->
    <?php echo $__env->yieldContent('page_css'); ?>

    <script type="text/javascript" src="<?php echo e(asset('plugins/jquery/jQuery-2.2.0.min.js')); ?>"></script>    
    <script type="text/javascript" src="<?php echo e(asset('js/site/main.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common/msg.jp.js')); ?>"></script>
    <!-- Inlcude common func js -->
    <script type="text/javascript" src="<?php echo e(asset('js/common/func/URLCommon.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common/func/StringCommon.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common/func/DateCommon.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common/func/EventCommon.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common/func/LoadingEventCommon.js')); ?>"></script>
    <script>
        var SITE_ROOT = "<?php echo e(route('home')); ?>"
    </script>
            <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!-- WARNING: Respond.js doesn't work if you view the page via file://-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')
    script(src='https://oss.maxcdn.com/respond/1.4.2/respond.min.js')
    -->
</head>
<body class="skin-blue sidebar-mini wysihtml5-supported">
<div class="wrapper">
    <header class="main-header">
        <?php echo $__env->make('site/layouts/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <aside class="main-sidebar">
        <?php echo $__env->make('site/layouts/main-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>
    
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('breadcrumb'); ?>
        <section class="content">
        <?php echo $__env->yieldContent('content'); ?>
        </section>
    </div>

</div>

<!-- Vendor jQuery-->

<!-- Metis Menu Plugin JavaScript -->
<!-- <script src="<?php echo e(asset('plugins/metisMenu/dist/metisMenu.min.js')); ?>"></script> -->

<!-- Main JS -->
<!-- <script src="<?php echo e(asset('plugins/sb-admin/js/sb-admin-2.js')); ?>"></script> -->
<script src="<?php echo e(asset('plugins/datatables/media/js/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootbox/bootbox.min.js')); ?>"></script>


<script type="text/javascript" src="<?php echo e(asset('plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<script type="text/javascript" src="<?php echo e(asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script type="text/javascript" src="<?php echo e(asset('plugins/admin-lte/js/app.min.js')); ?>"></script>

<!-- Custom Theme JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!-- Include JS -->
<script type="text/javascript" src="<?php echo e(asset('js/common/func/moment-with-locales.js')); ?>"></script>
<?php echo $__env->yieldContent('page_js'); ?>
</body>

