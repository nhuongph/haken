<!--
    Creator: ToiTL
    Date: 2016/05/25
-->

<?php $__env->startSection('title'); ?>
    <?php echo trans('project.title.list'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo trans('title.user.basic_register.task_name.project_info_management'); ?>

                </div>
                <div class="panel-body">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::open(['method' => 'GET']); ?>

                        <div class="search-tab row">
                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p class="text-center"><?php echo trans('title.user.basic_register.labels.time'); ?></p>
                                <?php echo Form::select('time',$recruitments, isset($search['time']) ? $search['time'] : null, ['class' => 'form-control', 'id' => 'time-select'] ); ?>

                            </div>
                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p class="text-center"><?php echo trans('title.user.basic_register.labels.status'); ?></p>
                                <?php echo Form::select('status',$status, isset($search['status']) ? $search['status'] : null, ['class' => 'form-control', 'id' => 'status-select'] ); ?>

                            </div>
                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p class="text-center"><?php echo trans('title.user.basic_register.labels.open_range'); ?></p>
                                <?php echo Form::select('displayStatus',$scopes, isset($search['displayStatus']) ? $search['displayStatus'] : null, ['class' => 'form-control', 'id' => 'displayStatus-select'] ); ?>

                            </div>
                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p class="text-center"><?php echo trans('title.user.basic_register.labels.period'); ?></p>
                                <?php echo Form::select('period',$periods, isset($search['period']) ? $search['period'] : null, ['class' => 'form-control', 'id' => 'period-select'] ); ?>

                            </div>
                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p class="text-center"><?php echo trans('title.user.basic_register.labels.brand'); ?></p>
                                <?php echo Form::select('brand',$brands, isset($search['brand']) ? $search['brand'] : null, ['class' => 'form-control', 'id' => 'brand-select'] ); ?>

                            </div>

                            <div class="col-lg-2 col-md-2 top-buffer">
                                <p></p><br/>
                                <button href="<?php echo URL::to('/user/project/create'); ?>" class="btn btn-default" id="search-btn"><i class="glyphicon glyphicon-search"></i> <?php echo trans('title.user.basic_register.action.search'); ?></button>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                        <hr/>
                        <!-- <p class="text-left">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="javascript: void(0);" data-tab="-1"><?php echo trans('title.user.basic_register.action.all'); ?></a></li>
                                <li><a href="javascript: void(0);" data-tab="0"><?php echo trans('title.user.basic_register.action.sale'); ?></a></li>
                                <li><a href="javascript: void(0);" data-tab="1"><?php echo trans('title.user.basic_register.action.business'); ?></a></li>
                                <li><a href="javascript: void(0);" data-tab="2"><?php echo trans('title.user.basic_register.action.special_events'); ?></a></li>
                            </ul>
                        </p> -->
                        <div id="list-content">
                            <?php echo $__env->make('site.user.project.ajax_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('page_js'); ?>
        <script type="text/javascript" src="<?php echo e(asset('js/site/user/basic_register.list.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>