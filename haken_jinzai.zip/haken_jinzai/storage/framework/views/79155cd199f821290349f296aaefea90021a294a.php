<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.report.index')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                         <div class="basic-form">
                            <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>

                            <table class="table table-responsive table-bordered">
                                <tr>
                                    <td>Id</td>
                                    <td>カテゴリー</td>
                                    <td>商品名</td>
                                    <td>単価</td> 

                                </tr>
                                <?php 
                                    for($i=1;$i<=50;$i++){
                                ?>
                                <tr>
                                    <td><?php echo $i;?></td>
                                    <td><input type="text" name="Category[]" class="form-control"/></td>
                                    <td><input type="text" name="ProductName[]" class="form-control"/></td>
                                    <td><input type="text" name="Price[]" class="form-control"/></td>
                                </tr>
                                <?php       
                                    }
                                ?>


                            </table>
                            <button class="btn btn-default btn-lg">登録完了</button>
                           <?php echo Form::close(); ?>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>