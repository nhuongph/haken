<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.order.pageList')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/order.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row text-setting order">
    <div class="panel panel-default list">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
                    <h4 class="text-title"><b><?php echo e(trans('order.header.list')); ?></b></h4>
                </div>
            </div>
        </div>  
        <div class="panel-body layout-border content">
            <div class="col-md-12 text-right">
                <a href="<?php echo e(route('gaia/order/new')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.add-new')); ?></a>
            </div>
            <div class="col-md-12 col-sm-12">
                <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="basic-form box-list-order">
                    <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal', 'method' => 'GET']); ?>

                    <div class="box-search-order col-md-12" style="margin-bottom:30px;">
                        <div class="payment-search-box-1 col-md-3">
                            <h3>受注者</h3>
                            <?php echo Form::select('Contractor',$contractors,Session::get('Contractor'),['class' => 'form-control']); ?>

                        </div>
                        <div class="payment-search-box-1 col-md-3">
                            <h3>受注区分</h3>
                            <?php echo Form::select('OrderDivision', array('-1'=>'すべて','001' => '派遣', '002' => '請負', '003' => '紹介予定派遣'),Session::get('OrderDivision'),['class' => 'form-control']); ?>

                        </div>
                        <div class="payment-search-box-1 col-md-3">
                            <h3>職種</h3>
                            <?php echo Form::select('CategoryJob', array('-1'=>'すべて','携帯販売' => '携帯販売', '家電販売' => '家電販売', '化粧品販売' => '化粧品販売','アパレル販売'=>'アパレル販売','雑貨販売'=>'雑貨販売','食品販売'=>'食品販売','試飲・試食販売'=>'試飲・試食販売','営業'=>'営業','ラウンダ'=>'ラウンダ','カフェスタッフ'=>'カフェスタッフ','百貨店レジ'=>'百貨店レジ','事務'=>'事務','データ入力'=>'データ入力','コンパニオン'=>'コンパニオン','ディレクター'=>'ディレクター','軽作業'=>'軽作業','その他'=>'その他'
                            ),Session::get('CategoryJob'),['class' => 'form-control']); ?>

                        </div>
                        <div class="payment-search-box-1 col-md-3">
                            <h3>受注月</h3>
                            <select class="form-control" name="OrderDate">
                                <!-- <option value="-1">すべて</option> -->
                                <?php 
                                foreach ($dates as $key => $date) {
                                 ?>
                                 <option value="<?php echo $key ;?>" <?php if(date('Y-m') == $key): ?> selected  <?php endif; ?>><?php  echo $date ; ?></option>
                                 <?php }
                                 ?>

                             </select>
                         </div>
                         <div class="payment-search-box-1 col-md-3">
                            <h3>期間区分</h3>
                            <?php echo Form::select('PeriodDivision', array('-1'=>'すべて','単発' => '単発', '短期' => '短期', '長期' => '長期'),Session::get('PeriodDivision'),['class' => 'form-control']); ?>


                        </div>
                        <div class="payment-search-box-1 col-md-3">
                            <h3>ステータス</h3>
                            <?php echo Form::select('Status',$status,Session::get('Status'),['class' => 'form-control']); ?>


                        </div>

                        <div class="payment-search-box-1 col-md-3">
                            <h3>&nbsp;</h3>
                            <h3>粗利計：<span id="sum-total"></span></h3>
                        </div>

                        <div class="order-list-submit col-md-3" style="margin-top:30px">
                            <button class="btn btn-primary btn-lg">絞込む</button>
                        </div>
                    </div>
                    <?php 
                    $sumValue = 0;
                    foreach ($orderLists as $orderList) {
                        $sumValue += $orderList->SumTotal;
                        ?>      
                        <div class="col-md-12">
                            <table class="table table-responsive table-bordered list-order-box-1">
                                <tr>
                                    <td>案件名称</td>
                                    <td><?php echo $orderList->ProjectName?></td>
                                    <td>職種</td>
                                    <td><?php echo $orderList->CategoryJob ?></td>
                                    <td rowspan="4"></td>
                                    <td rowspan="4">
                                        <div class="status">
                                            <div class="list-order-box-2">
                                                <div class="action-order-list-status"><?php echo $orderList->Status?></div>
                                                <div class="action">
                                                 <a href="<?php echo e(route('order/delete', ['orderId'=>$orderList->OrderId])); ?>" class="btn btn-default btn-lg button-action">削除</a>
                                             </div>
                                             <div class="action">
                                                <a href="<?php echo e(route('order/update', ['orderId'=>$orderList->OrderId])); ?>" class="btn btn-default btn-lg button-action">詳細</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>取引先名</td>
                                    <td><?php echo $orderList->EmploymentDestinationId ;?></td>
                                    <td>受注区分</td>
                                    <td>
                                        <?php if($orderList->OrderDivision=='001'){
                                            echo '派遣';

                                        }elseif($orderList->OrderDivision=='002'){
                                            echo '請負';
                                        }else{
                                            echo '紹介予定派遣';
                                        }
                                        ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td>受注者</td>
                                    <td><?php echo $orderList->Contractor ;?></td>
                                    <td>期間区分</td>
                                    <td><?php echo $orderList->PeriodDivision ;?></td>
                                </tr>
                                <tr>
                                    <td>受注日</td>
                                    <td><?php echo $orderList->OrderDate?></td>
                                    <td>粗利</td>
                                    <td><?php echo $orderList->SumTotal ;?></td>
                                </tr>
                            </table>
                            <div class="cls" style="clear:both;"></div>
                        </div>
                        <?php } ?>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name="sumTotal" value="<?php echo e($sumValue); ?>">
    <script>
        $(document).ready(function(){
            StringCommon.convertToNumberWithComma( $('input[name="sumTotal"]').get(0), $('input[name="sumTotal"]').val() );
            $('#sum-total').text($('input[name="sumTotal"]').val());
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>