<!--
    Creator: ToiTL
    Date: 2016/05/25
-->

<?php $__env->startSection('title'); ?>
    <?php echo trans('staff.check-point.title.schedule_check-point'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<!-- <link href="<?php echo asset('css/common/layout.css'); ?>" rel="stylesheet"> -->
<!-- <link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet"> -->
<link href="<?php echo asset('css/site/staff/check-point.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <br>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div>
                <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="panel panel-info new-panel">
                    <div class="panel-heading"><h4>
                    <span><?php echo trans('staff.check-point.header.notice_list'); ?> <?php if( $isNew ): ?></span>
                    <span class="new">New</span>
                    <?php endif; ?> <span class="toggle-notice" data-icon="show"><i class="glyphicon glyphicon-triangle-bottom"></i></span>
                    </h4></div>
                    <div class="panel-body">
                        <div class="thumbnail" data-toggle="notice">
                            <div class="row">
                                <?php foreach($notices as $key => $value): ?>
                                <div class="col-md-12 col-sm-12 col-sx-12">
                                    <b><?php echo e($key); ?></b>
                                    <ul>
                                    <?php foreach($value as $nkey => $notice): ?>
                                        <li>
                                            <a href="<?php echo URL::to('/comments/'.$notice->NoticeId); ?>" class="notice-title" data-target="<?php echo e($notice->NoticeId); ?>"><?php echo e($notice->Title); ?></a>
                                            <div data-notice="<?php echo e($notice->NoticeId); ?>" class="notice-content">
                                                <?php echo e($notice->Content); ?>

                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="text-right"><a href="<?php echo URL::to('/notice/listnotice'); ?>"><?php echo e(trans('staff.check-point.labels.all_notice')); ?></a></div>
                    </div>
                    <!-- <div class="panel-footer"></div> -->
                </div>

                <div class="panel panel-default task-panel">
                    <div class="panel-heading"><h4><?php echo $currentDate; ?> <?php echo e(trans('staff.check-point.header.task_list')); ?></h4></div>
                    <div class="panel-body">
                        <?php foreach($taskList as $key => $value): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <th><?php echo e(trans('staff.check-point.labels.basic_information')); ?></th>
                                    <td><?php echo e($value->CompanyName); ?>　<?php echo e($value->ManagementName); ?><br/><?php echo e($value->ProjectName); ?></td>
                                    <td><!-- <a href="" class="btn btn-success">報告完了</a> --></td>
                                </tr>

                                <tr>
                                    <th><?php echo e(trans('staff.check-point.labels.work_breaking_hours')); ?></th>
                                    <td><?php echo e($value->TimeStart); ?> 〜 <?php echo e($value->TimeEnd); ?><br/><?php echo e($value->TimeBreak); ?> 分</td>
                                    <td class="cbtn-container">
                                        <a href="#" class="btn btn-success full-width check-point-btn disabled" data-cbtn='<?php echo e($value->ShiftTableId); ?>_1' data-report="<?php echo e($value->ShiftTableId); ?>" data-step="0">Loading...</a>
                                        <a href="#" class="btn btn-success full-width check-point-btn disabled hidden" data-cbtn='<?php echo e($value->ShiftTableId); ?>_2' data-report="<?php echo e($value->ShiftTableId); ?>" data-step="0">Loading...</a>
                                    </td>
                                </tr>

                                <tr>
                                    <th><?php echo e(trans('staff.check-point.labels.work_location')); ?></th>
                                    <td><?php echo e($value->AddressCompany); ?></td>
                                    <td></td>
                                </tr>

                                <tr>
                                    <th><?php echo e(trans('staff.check-point.labels.notices')); ?></th>
                                    <td><?php echo e($value->Notices); ?></td>
                                    <td>
                                        <a href="#" class="btn btn-warning check-point-btn full-width hidden" data-cbtn='<?php echo e($value->ShiftTableId); ?>_3' data-target=""><?php echo e(trans('staff.check-point.button.report_notify')); ?></a>
                                        <a href="#" class="btn btn-warning check-point-btn full-width hidden" data-cbtn='<?php echo e($value->ShiftTableId); ?>_4' data-target=""><?php echo e(trans('staff.check-point.button.report_notify')); ?></a>
                                    </td>
                                </tr>

                                <tr>
                                    <th><?php echo e(trans('staff.check-point.labels.emergency_contact')); ?></th>
                                    <td><?php echo e(trans('staff.check-point.labels.contact_person')); ?>：<?php echo e($value->MainChargeName); ?><br/>TEL: </td>
                                    <td><a href="" class="btn btn-warning full-width send-message-btn <?php if( $value->IsReceiptMail == 0 ): ?> <?php echo e('disabled'); ?> <?php endif; ?>" data-toggle="modal" data-target="#messageDialog" data-report="<?php echo e($value->ShiftTableId); ?>"><?php echo e(trans('staff.check-point.button.message_transmission')); ?></a></td>
                                </tr>
                            </table>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div><?php echo e(trans('staff.check-point.labels.task_note.line_1')); ?></div>
                                <div><?php echo e(trans('staff.check-point.labels.task_note.line_2')); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php if( count($taskList) < 1 ): ?>
                        <div class="text-center">
                            <h3><?php echo e(trans('staff.check-point.labels.have_no_task_today')); ?></h3>
                        </div>
                        <?php endif; ?>
                    </div>  
                </div>
                <div class="panel panel-warning week-schedule-panel">
                    <div class="panel-heading">
                        <div class="row">
                            <h4><div class="col-md-2 col-xs-2 col-sm-2 text-left goto-schedule" data-type="previous" data-current="0"><b><span class="glyphicon glyphicon-triangle-left"></span></b></div>
                            <div class="col-md-2 col-xs-8 col-sm-8 text-center"><b><?php echo e(trans('staff.check-point.labels.schedule_of_week')); ?></b></div>
                            <div class="col-md-2 col-xs-2 col-sm-2 text-right goto-schedule" data-type="next" data-current="0"><b><span class="glyphicon glyphicon-triangle-right"></span></b></div></h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <div id="ajax-schedule">
                                
                            </div>
                            <div class="text-center text-success" id="loading-ajax-schedule">
                                <span class="glyphicon glyphicon-refresh glyphicon-refresh-animate"></span>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dialog message -->
    <div class="modal fade" id="messageDialog" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" id="messageForm">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans('staff.check-point.header.send_message')); ?></h4>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="message-shiftTableId" value=""/>
                    <textarea class="form-control full-width" name="message-content" style="height: 300px"></textarea>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary submit-message-btn"><?php echo e(trans('staff.check-point.button.send')); ?></button>
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('staff.check-point.button.cancel')); ?></button>
                </div>
            </form>
        </div>
      </div>
    </div>

    <div class="modal fade" id="resultDialog" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" id="messageForm">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?php echo e(trans('staff.check-point.header.send_message')); ?></h4>
                </div>

                <div class="modal-body" id="message-content">
                    
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('staff.check-point.button.cancel')); ?></button>
                </div>
            </form>
        </div>
      </div>
    </div>

    <input class="openResultDialog" type="hidden" data-toggle="modal" data-target="#resultDialog"/>
    <!-- End dialog message -->
    <?php $__env->startSection('page_js'); ?>
        <script type="text/javascript" src="<?php echo e(asset('js/site/staff/manage/check-point.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>