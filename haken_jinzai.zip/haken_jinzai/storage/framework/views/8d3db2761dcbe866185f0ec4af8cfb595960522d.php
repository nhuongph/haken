<?php $__env->startSection('title'); ?>
List Notice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/notice.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/notice_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/staffmanager/introducejob.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url'=> 'staffmanager/introducejobproject', 'id'=>'introducejob', 'class'=>'form-horizontal']); ?>

<div class="container text-setting">
    <div class="panel panel-default">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-md-8 col-xs-8'>
                    <h4 class="text-title"><b><?php echo trans('staffmanager.introducejob.title'); ?></b></h4>
                </div>
            </div>
        </div>
        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="panel-body layout-border">
            <div class="row">
                <div class="staff-manager-child-panel p-up">
                    <div class="p-up-title"><?php echo trans('title.introducejob.title.introduce_staff1'); ?><?php echo e(count($staffInfo)); ?><?php echo trans('title.introducejob.title.introduce_staff2'); ?></div>
                    <div class="form-group text-center">
                        &nbsp;
                    </div>
                    <div class="col-md-12 tablecontent">
                        <table class="table border-control-timepicker table-responsive table-hover layout-table-curved">
                            <thead class="lst-notice-bg-head-table text-header">
                                <tr>
                                    <th></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_staff_1'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_staff_2'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_staff_3'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_staff_4'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($staffInfo as $staff): ?>
                                <tr class="content">
                                    <?php $val_staff = $staff->Email . ',' . $staff->Name . ',' . $staff->StaffRegisterId ?>
                                    <td><?php echo e(Form::checkbox('staffInfo[]', $val_staff, false,['class'=>'staffInfo'])); ?></td>
                                    <td><?php echo $staff->Name; ?></td>
                                    <td><?php echo $staff->Age; ?></td>
                                    <td><?php echo $staff->Rank; ?></td>
                                    <td><?php echo $staff->NearestStation; ?></td>
                                    <!-- <input type="hidden" name="name[]" value="<?php echo $staff->Email; ?>"> -->
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="form-group text-center">
                        &nbsp;
                    </div>
                    <div class="col-md-12 basic-form  text-center">
                        <?php echo e(Form::submit(\Lang::get('title.introducejob.button.introduce_staff_submit'),['class'=>'btn btn-default btn-lg button-submit','id'=>'submit_staff'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script src="<?php echo e(asset('js/site/staff/introducejob.js')); ?>"></script>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>