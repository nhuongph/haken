<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.report.index')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                    
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                         <div class="basic-form">
                            <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>

                            <table class="table table-responsive table-bordered">
                                <div class="col-md-12 menu-title">アカウント情報は以下の通り登録されています。変更を行いたい場合は、ページ下部の「変更申請」ボタンより操作を行ってください。</div>
                                
                                <?php foreach($staffLists as $staffList){?>
                                 <tr>
                                    <td>姓</td>
                                    <td><?php echo $staffList->Name; ?></td>
                                    <td>名</td>
                                    <td><?php echo $staffList->Name; ?></td>
                                </tr>   
                                <tr>
                                    <td>セイ</td>
                                    <td><?php echo $staffList->NameFurigana; ?></td>
                                     <td>メイ</td> 
                                    <td><?php echo $staffList->NameFurigana; ?></td> 
                                </tr>
                                
                                <tr>
                                		<td>生年月日</td>
                                		<td colspan="3"><?php echo $staffList->Birthdate; ?></td>
                                </tr>
                                <tr>
                                		<td>性別</td>
                                		<td colspan="3">
	                                		<?php 
	                                			if($staffList->Sex=='1'){
	                                				echo "男";
	                                			}else{
	                                				echo "女";
	                                			}
	                                		?>
                                			
                                		</td>
                                </tr>
                                <tr>
                                		<td>電話番号</td>
                                		<td colspan="3"><?php echo $staffList->PostalCode; ?></td>
                                </tr>
                                <tr>
                                		<td>FAX番号</td>
                                		<td colspan="3"><?php echo $staffList->Fax; ?></td>
                                </tr>
                                 <tr>
                                		<td>携帯電話番号</td>
                                		<td colspan="3"><?php echo $staffList->Mobile; ?></td>
                                </tr>
                                <tr>
                                		<td>email</td>
                                		<td colspan="3"><?php echo $staffList->email?></td>
                                </tr>
                                 <tr>
                                		<td>パスワード</td>
                                		<td colspan="3">
                                			<input type="password" class="form-control" value="<?php echo $staffList->password?>" />
                                		</td>
                                </tr>
                                <tr>
                                		<td>郵便番号</td>
                                		<td colspan="3"><?php echo $staffList->PostalCode; ?></td>
                                </tr>
                                 <tr>
                                		<td>都道府県</td>
                                		<td colspan="3"><?php echo $staffList->PrefecturalName; ?></td>
                                </tr>
                                <tr>
                                		<td>市区町村</td>
                                		<td colspan="3"><?php echo $staffList->MunicipalName; ?></td>
                                </tr>
                                 <tr>
                                		<td>パスワード</td>
                                		<td colspan="3"><?php echo $staffList->AddressDetail; ?></td>
                                </tr>
                                <?php }?>
                            </table>
                            
                            <button class="btn btn-default btn-lg menu-list-user-id" type="button"><a href="/staff/requestchange/<?php echo $staffList->StaffRegisterId?>">変更申請</a></button>
                           <?php echo Form::close(); ?>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>