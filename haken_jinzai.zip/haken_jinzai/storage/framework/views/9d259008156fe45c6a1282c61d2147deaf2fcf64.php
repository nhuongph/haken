<div class="layout-child-panel">
    <div id="basic_form">
        <?php echo Form::open(['id'=> 'interviewForm', 'class' => '', 'files' => true]); ?>


        <div class="form-group">
            <div class="text-header"><?php echo trans('pre-register.new.interview-location'); ?></div>
            <div class="pre-reg-new-step2-layout">
                <?php foreach($regions as $region): ?>
                <?php echo Form::radio('region', $region->RegionId,false); ?> <?php echo e($region->Name); ?>

                <?php endforeach; ?>
            </div>
        </div>
        <div id="interviewTime">

        </div>
        <div class="form-group hidden" id="noPossibleTime">
            <?php echo Form::checkbox('noPossibleTime','check',false); ?> 参加可能時間なし
            <br>
            時間外で面接をご希望の方は、参加可能時間なしを選択してください。<br>
                        後ほど、担当者からご連絡差し上げます。
        </div>
        <br>
        <div class="noPossibleTime_Hour" id="noPossibleTime_Hour" style="display: none;">
            <label class="col-md-2">希望面接時間</label>
            <div class="col-md-10">
              <div class="row form-group" > 

                <div class="col-md-4 " >
                <?php echo Form::text('appointment_time_from',null,['id'=>'appointment_time_from','class'=>'form-control input-block-level','style'=>'min-width:120px' ]); ?>

                </div>
                <label class="col-md-1 ">~</label>
                <div class="col-md-4 " >
                <?php echo Form::text('appointment_time_to',null,['id'=>'appointment_time_to','class'=>'form-control input-block-level','style'=>'min-width:120px']); ?>

                </div>
 
                <div class="col-md-2">
                    <!--<button class="btn btn-primary btn-lg"><?php echo e(trans('title.staff.register')); ?></button>-->
                </div>
              </div>  
            </div>
        </div>
        
        <div class="button-group text-center">
            <a href="<?php echo e(route('staff/pre-register',['step_1'])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.staff.back')); ?></a>
            <?php echo Form::hidden('step','finish'); ?>

            <button class="btn btn-primary btn-lg noPossibleTime_Hour"><?php echo e(trans('title.staff.register')); ?></button>
            <button type="button" onclick="return staffRegister()" class="btn btn-primary btn-lg staffRegister"><?php echo e(trans('title.staff.register')); ?></button>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>

