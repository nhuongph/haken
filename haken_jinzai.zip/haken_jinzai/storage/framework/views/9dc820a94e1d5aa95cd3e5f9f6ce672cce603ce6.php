<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.staff.register_title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="container col-md-12 col-sm-12 text-setting">
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-md-8 col-xs-8'>
                    <h4 class="text-title"><b>個人情報の取り扱いについて</b></h4>
                </div>
            </div>
            </div>
            <div class="panel-body layout-border">
                <div class="col-md-12 col-sm-12">
                    <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="well policy content-rules">
                        <div class="content-rules-inner"><strong class="text-header-content">【個人情報の利用目的】</strong></div>
                        <ul>
                            <li>人材派遣等における最適な仕事のご案内・仕事に関する連絡及び契約締結に関する業務</li>
                            <li>適正な雇用管理及び緊急事態が発生した際の連絡
                                <ul>
                                    <li>本人ならびに公衆の生命・身体・財産を脅かす恐れがある場合や、登録いただいた連絡先に連絡が付かず、当社が必要と判断した場合にはご提出いただいた緊急連絡先に連絡させていただくとともに、必要に応じて状況を説明させていただくことがあります。</li>
                                </ul>
                            </li>
                            <li>弊社からの情報提供</li>
                            <li>人材派遣等の当社事業目的に関するご意見・ご要望等の聴取</li>
                        </ul>
                        <div class="content-rules-inner"><strong class="text-header-content">【個人情報の提供】</strong></div>
                        ご提出いただいた個人情報はご本人の同意なく第三者へ個人情報を提供することはありません。但し、以下いずれかに該当する場合は提供をすることがあります。
                        <ul>
                            <li>あらかじめ、本人に必要事項を明示又は通知し、本人の同意を得ている場合</li>
                            <li>本人ならびに公衆の生命・身体・財産を脅かす可能性がある場合</li>
                            <li>公衆の衛生の向上又児童の健全な育成の推進のために特に必要がある場合であって、本人の同意を得ることが困難な場合</li>
                            <li>国の機関もしくは、地方公共団体又はその委託を受けたものが法令の定める事務を遂行することに対して協力する場合であって、本人の同意を得ることにより当該事務の遂行に支障をきたす場合</li>
                            <li>その他、第三者に損傷を生じさせた、又は損害を生じさせるおそれがある場合は、関係者ないし関係諸機関へ通報、通知します。</li>
                        </ul>
                        その他、第三者に損傷を生じさせた、又は損害を生じさせるおそれがある場合は、関係者ないし関係諸機関へ通報、通知します。<br><br>
                        <div class="content-rules-inner"><strong class="text-header-content">【本人の権利】</strong></div>
                        本人から個人情報の利用目的の通知、開示、内容の訂正、追加又は削除、利用停止、消去及び第三者への提供の停止（以下「開示」という）の要請があった場合には、当社で定める所定の手続くに則り速やかに対応いたします。ただし、当該個人情報の存否を明らかにすることが、以下のいずれかに該当する場合は開示対象個人情報とはなりません。
                        <ul>
                            <li>本人並びに公衆の生命・身体・財産、その他の権利利害を害するおそれがある場合</li>
                            <li>違法又は不当な行為を助長し、又は誘発するおそれがある場合</li>
                            <li>犯罪の予防、鎮圧又は捜査その他の公共の安全と秩序維持に支障がおよぶおそれがある場合</li>
                            <li>第三者との信頼関係にかかわり、業務の適正な実施に著しい支障を及ぼすおそれがある場合</li>
                        </ul>
                        <div class="content-rules-inner"><strong class="text-header-content">【開示等のお申し出先】</strong></div>
                        苦情・相談窓口<br>
                        株式会社ガイアコミュニケーションズ<br>
                        03-6862-6811<br><br>
                        <div class="content-rules-inner"><strong class="text-header-content">【開示等のお申し出方法】</strong></div>
                        お電話、電子メール、文書等にて承ります
                        <ul>
                            <li>本人または、代理人であることの確認方法</li>
                            <li>当社所定の方法により、本人または代理人であることを確認させていただきます。</li>
                        </ul>
                        個人情報の削除を要請された場合、お申し出時期によって削除完了後も当社から連絡・郵便物が届いてしまう場合がありますのであらかじめご了承下さい。<br><br>

                        <div class="content-rules-inner"><strong class="text-header-content">【個人情報等の返却】</strong></div>
                        ご提出いただいた個人情報は、いかなる媒体においても返却する義務を負いません。

                    </div>
                    <div class="form-group">
                        <div class="button-group text-center">
                            <a href="<?php echo e(route('staff/pre-register',['step_1'])); ?>" class="btn btn-primary btn-lg pre-reg-policy-btn-small"><?php echo e(trans('title.action.accept')); ?></a>
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-lg pre-reg-policy-btn-small"><?php echo e(trans('title.action.not_accept')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>