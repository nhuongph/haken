<?php $__env->startSection('title'); ?>
<?php echo e(trans('gaiamanagement.title-add')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="content-header">
    <h1><small></small></h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(route('gaia/management/member/menu')); ?>"><?php echo e(trans('gaiamanagement.title-menu')); ?></a></li>
        <li class="active"><?php echo e(trans('gaiamanagement.title-add')); ?></li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row text-setting gaia-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="box box-info box-solid add">
            <div class="box-header with-border">
                <h4 class="text-title"><b><?php echo e(trans('gaiamanagement.title-add')); ?></b></h4>
            </div> 
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="basic-form">
                        <?php echo Form::open(['id'=> 'registercompany', 'class' => 'form-horizontal']); ?>                        	  
                        <div class="form-group col-md-12 col-xs-12">
                            <?php echo e(Form::label('title',\Lang::get('gaia.register.title1'),['class'=>'reg-title'])); ?>

                        </div>
                        <div class="layout-child-panel reg-content col-md-10 col-xs-10 col-md-offset-1 col-xs-offset-1">
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.first-name'); ?></div>
                                <div class="col-md-3"><?php echo Form::text('firstname',$user->Firstname, ['class'=>'form-control']); ?></div>
                                <div class="col-md-2"><?php echo trans('common.title.last-name'); ?></div>
                                <div class="col-md-3"><?php echo Form::text('lastname', $user->Lastname, ['class'=>'form-control']); ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.first-name-kana'); ?></div>
                                <div class="col-md-3"><?php echo Form::text('firstname_kana', $user->Firstname_Kana, ['class'=>'form-control']); ?></div>
                                <div class="col-md-2"><?php echo trans('common.title.last-name-kana'); ?></div>
                                <div class="col-md-3"><?php echo Form::text('lastname_kana', $user->Lastname_Kana, ['class'=>'form-control']); ?></div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.email'); ?></div>
                                <div class="col-md-8 email-validation" ><?php echo Form::email('email', $user->email, ['class'=>'form-control email-gai-a','required' => 'required']); ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.phone'); ?></div>
                                <div class="col-md-8 email-validation" ><?php echo Form::text('phone', $user->Phone, ['class'=>'form-control','required' => '']); ?></div>							
                            </div>
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.password'); ?></div>
                                <div class="col-md-8" >
                                    <?php echo Form::password('password',['class'=>'form-control']); ?>		
                                </div>						
                            </div>
                            <div class="form-group">
                                <div class="col-md-3"><?php echo trans('common.title.department-name'); ?></div>
                                <div class="col-md-8" >
                                    <?php echo Form::text('part', $user->Part, ['class'=>'form-control furiganaName','required' => 'required']); ?>		
                                </div>
                            </div>
                            <div class="form-group">                                
                                <div class="col-md-3"><?php echo trans('gaia.register.title2'); ?></div>
                                <div class="col-md-8" >
                                    <?php echo Form::select('basicAuthority', $role_select, null ,['class'=>'form-control','required' => 'required','id' => 'basicAuthority']); ?>		
                                </div>
                            </div>
                            <div class="form-group">
                                <?php foreach($role as $roles): ?>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-8">
                                        <?php if(count($role_user) > 0): ?>	                	
                                        <input type="checkbox" class="roleid" name="roleid[]"  value="<?php echo e($roles->id); ?>" <?php if(in_array($roles->id,$role_user)): ?> 
                                               <?php echo e('checked'); ?>

                                               <?php endif; ?>/>
                                               <?php else: ?>
                                               <?php echo Form::checkbox('roleid[]', $roles->id,false,['class'=>'roleid']); ?>		
                                               <?php endif; ?>
                                               <?php echo e($roles->display_name); ?>								
                                    </div>
                                <?php endforeach; ?>						
                            </div>
                            <div class="form-group text-center">
                                &nbsp;
                            </div>    
                            <div class="form-group text-center">
                                <button class="btn btn-primary btn-lg gaia-new-submit"><?php echo trans('common.button.register'); ?></button> 
                                <a href="<?php echo e(route('gaia/management/member/menu')); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('common.button.cancel')); ?></a>
                            </div>                              
                            <div class="form-group text-center">
                                &nbsp;
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/moment.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/user/company_validate.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/user/company_section_payment.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/gaia/gaia.js'); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>