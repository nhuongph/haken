<?php $__env->startSection('title'); ?>
<?php echo e(trans('company.header-add')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<form id="registercompany" method="POST" action="<?php echo URL::route('addcompany'); ?>">
	<div class="row text-setting company">
		<div class="panel panel-default add">
			<div class="panel-heading layout-bg-title">
				<div class="row">
					<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
						<h4 class="text-title"><b><?php echo e(trans('company.title')); ?></b></h4>
					</div>
				</div>
			</div>  
			<div class="panel-body layout-border content">	
				<?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="layout-child-panel">
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('companyName', null, ['class'=>'form-control']); ?></div>    
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.furigana-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('furiganaName', null, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.postal-code')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo Form::text('postalCode', null, ['class'=>'form-control zip-code', 'onKeyUp'=>"AjaxZip3.zip2addr(this, '', 'prefecturalName', 'municipalName');"]); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.prefectural-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('prefecturalName', null, ['class'=>'form-control']); ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.municipal-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('municipalName', null, ['class'=>'form-control']); ?></div>			
					</div>				
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.detail-address')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('detailAddress', null, ['class'=>'form-control']); ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.tel')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('phoneNumber', null, ['class'=>'form-control phone-number']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.fax')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('faxNumber', null, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.head-office')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('headOffice', null, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.capital-stock')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('capitalStock', null, ['class'=>'form-control']); ?></div>				
					</div>			
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.employee-number')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('employeeNumber', null, ['class'=>'form-control']); ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.ceo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('pepresentativeName', null, ['class'=>'form-control']); ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-name-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsibleName', null, ['class'=>'form-control']); ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-position-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsiblePosition', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-phone-number-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsiblePhone', null, ['class'=>'form-control phone-number']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainName', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-position')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainPosition', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-contact')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainPhone', null, ['class'=>'form-control phone-number']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.establishment-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<div class="form-group">
								<div class='input-group date' id='datetimepicker_establishmentdate'>
									<input type='text' class="form-control" name="establishmentDate" />
									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>	
							</div>			
						</div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer-bank')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('mainCustomerBank', null, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.lastyear-suppliers')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('lastYearSuppliers', null, ['class'=>'form-control']); ?></div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('mainCustomer', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.basic-contract-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<div class="form-group">
								<div class='input-group date' id='datetimepicker_contractdate'>
									<input type='text' class="form-control" name="contractDate" />
									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>	
							</div>			
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-memo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::textarea('companyMemo', null, ['class'=>'form-control']); ?></div>
					</div>				
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.person-charge')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('personCharge', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.department-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('departmentName', null, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.offical-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo e(Form::radio('officialName', '1', true)); ?>

							<?php echo e(trans('company.radio.regular')); ?>

							<?php echo e(Form::radio('officialName', '0')); ?>

							<?php echo e(trans('company.radio.deputy')); ?>

						</div>	
					</div>
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
							<button type="submit" class="btn btn-primary" id="btnsubmit"><?php echo e(trans('common.button.register')); ?></button>
							<a href="<?php echo e(route('listcompany')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.cancel')); ?></a>
						</div>
					</div>
				</div>
			</div>		
		</div>
	</div>
	<input type="hidden" name="sections" id="sections" value="1">
	<input type="hidden" name="lstPaymentUpdate" id="lstPaymentUpdate" value="1,">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<!-- <script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/moment.js'); ?>"></script> -->
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/gaia/company_datetime.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/ajax_zip3/ajax_zip3.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>