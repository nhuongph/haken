<table class="table table-bordered table-responsive table-hover success" id="another-interview-table">
    <thead>
        <tr class="active">
            <th><?php echo trans('title.staff.labels.name'); ?></th>
            <th><?php echo trans('title.staff.labels.photo'); ?></th>
            <th><?php echo trans('title.staff.labels.sex'); ?></th>
            <th><?php echo trans('title.staff.labels.age'); ?></th>
            <th><?php echo trans('title.staff.labels.tag'); ?></th>
            <th><?php echo trans('title.staff.labels.nearest_station'); ?></th>
            <th><?php echo trans('title.staff.labels.first_impression'); ?></th>
            <th><?php echo trans('title.staff.labels.registration_history'); ?></th>
            <th style="max-width: 15%"></th>
        </tr>
        <?php foreach($staffs as $key => $staff): ?>
        <tr>
            <td><?php echo $staff->Name; ?></td>
            <?php if($staff->Path != ''): ?>
            <td><img src="<?php echo URL::to($staff->Path); ?>" style="width: 100px; height: 100px"></td>
            <?php else: ?>
            <td><img src="<?php echo e(URL::to('/')); ?>/img/no_image.jpg" style="width: 100px; height: 100px"></td>
            
            <?php endif; ?>
            
            <td><?php echo $staff->Sex == 1 ? '男' : '女'; ?></td>
            <td><?php echo $staff->Age; ?></td>
            <td><?php echo $staff->Tag; ?></td>
            <td><?php echo $staff->StationName; ?></td>
            <td><?php echo $staff->FirstImpression; ?></td>
            <td><?php echo $staff->RegistrationHistory; ?></td>
            <td><a href="<?php echo URL::to('/staff/detail/'.$staff->StaffRegisterId); ?>" class="btn btn-default btn-sm">詳細</a></td>
        </tr>
        <?php endforeach; ?>
    </thead>
</table>
<?php if( count($staffs) == 0 ): ?>
<div class="text-center">
    No result
</div>
<?php endif; ?>
<div class="lst-company-paging"><?php echo $staffs->links(); ?> </div>