<?php $__env->startSection('title'); ?>
    Administrator Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Site Summary</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="panel-group" id="accordion">
                        <div class="panel panel-default">

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->startSection('page_js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/admin/user/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>