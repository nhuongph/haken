<?php $__env->startSection('title'); ?>
    <?php echo e(trans('title.wanted-job.worklist')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>

    table tbody tr th:first-child{
        width: 30%;
    }
</style>    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <!-- List -->
                    <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <a href="<?php echo e(route('wanted-job/listOrder',array('type'=>'1'))); ?>">
                    <div class="well well-lg"> <?php echo e(trans('title.wanted-job.apply_for_job')); ?></div>
                    </a>
                    <a href="<?php echo e(route('wanted-job/listOrder',array('type'=>'2'))); ?>">
                    <div class="well well-lg"><?php echo e(trans('title.wanted-job.recommend')); ?> 
                      <div class="badge" >(<?php echo e($countRecomment); ?>) </div>
                    </div>
                    </a>
                    <a href="<?php echo e(route('wanted-job/listOrder',array('type'=>'3'))); ?>">
                    <div class="well well-lg"><?php echo e(trans('title.wanted-job.registed')); ?></div>
                    </a>
                    
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startSection('page_js'); ?>
        
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>