<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.pre-register.list')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<section class="content-header">
  <h1><small></small></h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(route('pre-register/manage')); ?>"><?php echo e(trans('breadcrumb.pre-register.manage-menu')); ?></a></li>
    <li class="active"><?php echo e(trans('title.pre-register.list')); ?></li>
</ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row text-setting pre-reg-manage">
    <div class="col-lg-12 col-md-12 col-sm-12 list">
        <div class="box box-info box-solid">
            <div class="box-header with-border">
                <h4 class="text-title"><b><?php echo e(trans('title.pre-register.list')); ?></b></h4>
            </div>
            <div class="box-body">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                        <div class="col-md-12 text-right marginBottom10">
                            <a href="<?php echo e(route('pre-register/manage')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.back')); ?></a>
                        </div>
                    </div>
                    <div class="layout-child-panel">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 marginBottom5">
                                <div class="text-title lbl-search"><?php echo e(trans('pre-register.list.lbl-title-search-interview-date')); ?></div>
                                <?php echo Form::select('interviewDate',[''=>trans('pre-register.list.dll-select-interview-date')] + $selectDate,null,['class'=>'form-control']); ?>

                            </div>
                            <div class="col-md-4 col-sm-4 marginBottom5">
                                <div class="text-title lbl-search"><?php echo e(trans('pre-register.list.lbl-title-search-status')); ?></div>
                                <?php echo Form::select('status',[''=>trans('pre-register.list.dll-select-status')] + $selectStatus,null,['class'=>'form-control']); ?>

                            </div>
                        </div>
                        <div class="row marginBottom5">
                            <div class="col-md-7 col-sm-7">
                                <div class="text-title lbl-search"><?php echo e(trans('pre-register.list.lbl-title-search-name')); ?></div>
                                <div class="input-group marginBottom5">
                                    <?php echo Form::text('nameKey',null,['id'=>'nameKey','class'=>'form-control']); ?>

                                    <span class="input-group-btn">
                                        <button onclick="" id="search_staff" class="btn btn-secondary" type="button"><?php echo e(trans('common.button.search')); ?></button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <table id="preRegisterList" class="table table-bordered table-responsive datatables_scroll">
                            <thead>
                                <tr>
                                    <th class="text-center" width="10%"><?php echo e(trans('pre-register.list.lbl-tb-title-name')); ?></th>
                                    <th class="text-center" width="15%"><?php echo e(trans('pre-register.list.lbl-tb-title-image')); ?></th>
                                    <th class="text-center"><?php echo e(trans('pre-register.list.lbl-tb-title-interview-day')); ?></th>
                                    <th class="text-center"><?php echo e(trans('pre-register.list.lbl-tb-title-gender')); ?></th>
                                    <th class="text-center"><?php echo e(trans('pre-register.list.lbl-tb-title-age')); ?></th>
                                    <th class="text-center"><?php echo e(trans('pre-register.list.lbl-tb-title-status')); ?></th>
                                    <th class="text-center"></th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script src="<?php echo e(asset('js/site/pre-register/list.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>