件名：【人材派遣システム】パスワード再設定用URL通知<br>
<br>
遠藤　学様<br>
<br>
人材派遣システム、アカウントのパスワード変更リクエストを受付ました。<br>
<br>
<span style="color: red;">下記のURLより、パスワードの変更を行ってください。<br>
    変更を行う際には、仮パスワードを使用してください。<br></span>
<br>
<?php echo e(url('password/reset/')); ?>/<?php echo e($email); ?><br>
<br>
<span style="color: red;">仮パスワード：<?php echo e($passwordOld); ?><br></span>
<br>
<br>
※このメールにお心当たりがない場合は、恐れ入りますがメールを破棄していただけますようお願いいたします。