<?php $__env->startSection('title'); ?>
List Notice
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/notice.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/notice_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/staffmanager/introducejob.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo Form::open(['url'=> 'staffmanager/introducejobfinish', 'id'=>'introducejob', 'class'=>'form-horizontal']); ?>

<div class="container text-setting">
    <div class="panel panel-default">
        <div class="panel-heading layout-bg-title">
            <div class="row">
                <div class='col-md-8 col-xs-8'>
                    <h4 class="text-title"><b><?php echo trans('staffmanager.introducejob.title'); ?></b></h4>
                </div>
            </div>
        </div>
        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="panel-body layout-border">  
            <div class="row">
                <div class="staff-manager-child-panel p-up">
                    <div class="p-up-title"><?php echo trans('title.introducejob.title.introduce_order1'); ?><?php echo e(count($projectInfo)); ?><?php echo trans('title.introducejob.title.introduce_order2'); ?></div>
                    <div class="form-group text-center">
                        &nbsp;
                    </div>
                    <div class="col-md-12 basic-form tablecontent">
                        <table class="table border-control-timepicker table-responsive table-hover layout-table-curved">
                            <thead class="lst-notice-bg-head-table text-header">
                                <tr>
                                    <th></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_order_1'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_order_2'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_order_3'); ?></th>
                                    <th class="category-search"><?php echo trans('title.introducejob.label.introduce_order_4'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($projectInfo as $project): ?>
                                <tr class="content">
                                    <?php $val_order = $project->OrderId.','.$project->ProjectName.','.$project->CategoryJob ?>
                                    <td><?php echo e(Form::checkbox('orderInfo[]', $val_order, false,['class'=>'orderInfo'])); ?></td>
                                    <td><?php echo $project->ProjectName; ?></td>
                                    <td><?php echo $project->CompanyName; ?></td>
                                    <td><?php echo $project->ProjectName; ?></td>
                                    <td><?php echo $project->ProjectName; ?></td>

                                </tr>
                                <?php endforeach; ?>
                            <input type="hidden" value="<?php echo htmlspecialchars($staffInfo); ?>" name="staffInfo">
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-10 basic-form col-md-offset-2">
                        <div class="form-group">
                            <b class="category-search"><?php echo trans('title.introducejob.title.title_mail'); ?></b>
                            <?php echo e(Form::text('title_mail',null, array('class' => 'form-control', 'required'=>''))); ?>

                        </div>
                    </div>
                    <div class="col-md-12 basic-form text-center">
                        <?php echo e(Form::submit(\Lang::get('title.introducejob.button.introduce_order_submit'),['class'=>'btn btn-default btn-lg button-submit','id'=>'submit_order'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script src="<?php echo e(asset('js/site/staff/introducejob.js')); ?>"></script>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>