<?php $__env->startSection('title'); ?>
<?php echo e(trans('gaia.register.title-new')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<div class="row text-setting gaia-manage">
	<div class="panel panel-default register">
		<div class="panel-heading layout-bg-title">
			<div class="row">
				<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
					<h4 class="text-title"><b></b></h4>
				</div>
			</div>
		</div> 
		<div class="panel-body layout-border">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="basic-form">
					<?php echo Form::open(['id'=> 'registercompany', 'class' => 'form-horizontal']); ?>                        	  
					<span class="reg-title"><?php echo trans('gaia.register.title1'); ?></span>
					<div class="layout-child-panel reg-content">
						<div class="row">

							<div class="col-md-2"><?php echo trans('common.title.first-name'); ?></div>
							<div class="col-md-3"><?php echo Form::text('firstname',$user->Firstname, ['class'=>'form-control']); ?></div>
							<div class="col-md-2"><?php echo trans('common.title.last-name'); ?></div>
							<div class="col-md-3"><?php echo Form::text('lastname', $user->Lastname, ['class'=>'form-control']); ?></div>
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.first-name-kana'); ?></div>
							<div class="col-md-3"><?php echo Form::text('firstname_kana', $user->Firstname_Kana, ['class'=>'form-control']); ?></div>
							<div class="col-md-2"><?php echo trans('common.title.last-name-kana'); ?></div>
							<div class="col-md-3"><?php echo Form::text('lastname_kana', $user->Lastname_Kana, ['class'=>'form-control']); ?></div>
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.email'); ?></div>
							<div class="col-md-8 email-validation" ><?php echo Form::text('email', $user->email, ['class'=>'form-control email-gai-a','required' => 'required']); ?></div>							
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.password'); ?></div>
							<div class="col-md-8" >
								<?php echo Form::password('password',['class'=>'form-control']); ?>		
							</div>						
						</div>
						<div class="row">
							<div class="col-md-2"><?php echo trans('common.title.department-name'); ?></div>
							<div class="col-md-8" >
								<?php echo Form::text('part', $user->Part, ['class'=>'form-control furiganaName','required' => 'required']); ?>		
							</div>
						</div>
					</div>
					<div class="reg-title"><?php echo trans('gaia.register.title2'); ?></div>
					<div class="layout-child-panel reg-chk">
						<?php foreach($role as $roles): ?>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-10">
										<?php if(count($role_user) > 0): ?>	                	
										<input type="checkbox" name="roleid[]"  value="<?php echo e($roles->id); ?>" <?php if(in_array($roles->id,$role_user)): ?> 
										<?php echo e('checked'); ?>

										<?php endif; ?>/>
										<?php else: ?>
										<?php echo Form::checkbox('roleid[]', $roles->id); ?>		
										<?php endif; ?>
										<?php echo e($roles->display_name); ?>								
							</div>
						</div>
						<?php endforeach; ?>						
					</div>
					<div class="button-group btn-button text-center">
						<button class="btn btn-primary btn-lg gaia-new-submit"><?php echo trans('common.button.register'); ?></button> 
						<a href="<?php echo e(route('gaia/menu')); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('common.button.cancel')); ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
 <script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/moment.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('js/site/user/company_validate.js'); ?>"></script>
	<script type="text/javascript" src="<?php echo asset('js/site/user/company_section_payment.js'); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>