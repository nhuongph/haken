<?php echo e($last_name); ?> <?php echo e($first_name); ?>様<br>
<br>
この度は、弊社のスタッフ登録面談にご応募いただき、ありがとうございました。<br>
<br>
下記の通り、面談予約を承りました。<br>
<br>
会場：<?php echo e($region_name); ?><br>
日時：<?php echo e($date); ?><br>
希望時間：<?php echo e($time_from); ?>時〜<?php echo e($time_to); ?>時<br>
<br>
詳しい会場の情報と時間につきましては、担当者から改めてご連絡差し上げます。<br>
<br>
面接会場へ到着後、給与のお支払いのための口座情報等の登録を行っていただきます。<br>
登録画面へのログインには、ご登録メールアドレスと、下記の登録パスワードをご利用ください。<br>
<br>
パスワード：<br>
<?php echo e($password); ?><br>
<br>
それでは、<?php echo e($last_name); ?>様と面接会場にてお会いできることを楽しみにしております。<br>