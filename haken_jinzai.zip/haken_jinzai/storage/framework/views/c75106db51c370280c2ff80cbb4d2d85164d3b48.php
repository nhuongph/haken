<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.confirmation.list')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                  <?php echo e(trans('title.confirmation.list')); ?>

                </div>
                <div class="panel-body">
                    <div class="col-md-12">
                        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="basic-form col-md-10 col-md-offset-1">
                            
                            <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal  padding-top-10 padding-bottom-10', 'method' => 'GET']); ?>

                                    
                                <div class="form-group">
                                    <div class="col-md-3">操作時刻で探す</div>
                                    <div class="col-md-9 nonePaddingLeft">
                                        <div class="col-md-5">
                                            <div class='input-group date' id='datetimepicker' >
                                                <?php echo Form::text('dateFrom', Session::get('dateFrom'), ['class' => 'form-control']); ?>

                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-2 text-center float-left"> 〜 </div>
                                        <div class="col-md-5">
                                            <div class='input-group date' id='datetimepicker1' >
                                                <?php echo Form::text('dateTo', Session::get('dateTo'), ['class' => 'form-control']); ?>

                                                <span class="input-group-addon">
                                                        <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-3">実行者で探す</div>
                                    <div class="col-md-9 nonePaddingLeft">  
                                        <div class="col-md-5">
                                            <?php echo Form::select('Operator', $operator, Session::get('operator'), ['class' => 'form-control']); ?>	
                                        </div>
                                    </div>
                                </div>                                    
                                <div class="form-group">
                                    <div class="col-md-3">対象で探す</div>
                                    <div class="col-md-9 nonePaddingLeft">
                                        <div class="col-md-5">
                                            <?php echo Form::select('Object', $object, Session::get('object'), ['class' => 'form-control']); ?>	
                                        </div>                                            
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-3">種別で探す</div>
                                    <div class="col-md-9 nonePaddingLeft">
                                        <div class="col-md-5">
                                            <?php echo Form::select('OpnType', $opnType, Session::get('opnType'), ['class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="form-group text-center">
                                    <button class="btn btn-default btn-lg button-submit" >検索実行</button>
                                </div>

                            <?php echo Form::close(); ?>                            
                        </div>
                        <div class="serach-lisst-confirmation-history">
                            <table class="table table-responsive table-bordered col-md-11">
                                <tr>
                                    <td>操作時刻</td>
                                    <td>実行者</td>
                                    <td>対象</td>
                                    <td>対象詳細</td>
                                    <td>種別</td>
                                    <td>項目名</td>
                                </tr>
                                <?php foreach ($confirmations as $confirmation) {
                                ?>
                                <tr>
                                    <td><?php echo $confirmation->OpnTime ;?></td>
                                    <td><?php echo $confirmation->Operator ;?></td>
                                    <td><?php echo $confirmation->Object ;?></td>
                                    <td><?php echo $confirmation->ObjectDetail ;?></td>
                                    <td><?php echo $confirmation->OpnType ;?></td>
                                    <td><?php echo $confirmation->ItemName ;?></td>
                                </tr>

                                <?php } ?>                                      
                            </table>
                            <?php echo $confirmations->appends(Request::only(['dateFrom','dateTo','Operator','Object','OpnType']))->render(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script src="<?php echo e(asset('plugins/bootstrap/js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap-datetimepicker.js')); ?>"></script>
<script type="text/javascript">
	$(function () {
		$('#datetimepicker').datetimepicker({
			format: 'YYYY/MM/DD'
		});
                $('#datetimepicker1').datetimepicker({
			format: 'YYYY/MM/DD'
		});
	});
</script>
<!--<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script src="<?php echo e(asset('js/site/user/order.create.js')); ?>"></script>-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>