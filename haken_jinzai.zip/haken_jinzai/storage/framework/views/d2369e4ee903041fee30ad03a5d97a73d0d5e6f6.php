<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.staff.register_title')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/site/pre-register/pre-register.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/pre-register/pre-register_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
    <div class="row text-setting pre-reg-new">
        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
            <div class="panel panel-default">
                <div class="panel-heading layout-bg-title">
                    <div class="row">
                        <div class='col-lg-8 col-md-8 col-xs-8 col-sm-8'>
                            <h4 class="text-title"><b></b></h4>
                        </div>
                    </div>
                </div>                
                <div class="panel-body layout-border">
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 pre-reg-child-panel">
                        <?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make("site.staff.pre-register.$step", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/ajax_zip3/ajax_zip3.min.js'); ?>"></script>
<script src="<?php echo e(asset('js/site/staff.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>