<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.GaiA.GaiA_member_detail')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/gaiamanage_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12 col-md-12 gaia-manage">
		<div class="panel panel-default register">
			<div class="panel-body layout-border">
				<div class="col-md-12 col-sm-12 col-sm-12 col-xs-12">
					<div class="basic-form">
						<div class="row">
							<!-- <div class="col-md-8"></div> -->
							<div class="col-md-9 pull-right">
								<a href="<?php echo e(route('registerpersonnel/getupdateregisterpersonal', ['userId'=>$user->id])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.user.basic_register.action.edit')); ?></a>

								<a href="<?php echo e(route('listGaiAMember')); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.action.return')); ?></a>
							</div>
						</div>   
						<br> 
						<div class="reg-title"><?php echo trans('title.GaiA.user_basic_info'); ?></div>        	  
						<div class="layout-child-panel reg-content">
							<div class="row">
								<div class="col-md-2"><?php echo e(trans('title.pre-register.first_name')); ?></div>
								<div class="col-md-3">
									<?php echo Form::label($user->Firstname, null, ['class'=>'control-label']); ?>

								</div>
								<div class="col-md-2"><?php echo e(trans('title.pre-register.last_name')); ?></div>
								<div class="col-md-3">
									<?php echo Form::label($user->Lastname, null, ['class'=>'control-label']); ?>

								</div>	          
							</div>
							<div class="row">
								<div class="col-md-2"><?php echo e(trans('title.pre-register.first_name_furigana')); ?></div>
								<div class="col-md-3">
									<?php echo Form::label($user->Firstname_Kana, null, ['class'=>'control-label']); ?>

								</div>
								<div class="col-md-2"><?php echo e(trans('title.pre-register.last_name_furigana')); ?></div>
								<div class="col-md-3">
									<?php echo Form::label($user->Lastname_Kana, null, ['class'=>'control-label']); ?>

								</div>
							</div>
							<div class="row">
								<div class="col-md-2"><?php echo e(trans('title.GaiA.email')); ?></div>
								<div class="col-md-8 col-sm-8 col-xs-8" >
								<?php echo $user->email; ?>

									<!-- <?php echo Form::label($user->email, null, ['class'=>'control-label']); ?> -->
								
								</div>
							</div>
							<div class="row">
								<div class="col-md-2"><?php echo e(trans('title.GaiA.department_name')); ?></div>
								<div class="col-md-8" >
									<?php echo Form::label($user->Part, null, ['class'=>'control-label']); ?>

								</div>
							</div>	
						</div>
						<div class="reg-title"><?php echo trans('title.GaiA.user_authority'); ?></div>
						<div class="layout-child-panel reg-content">
							<?php foreach($role as $roles): ?>
								<div class="row">
									<div class="col-md-2">
										<?php if(count($role_user) > 0): ?>	                	
											<?php if(in_array($roles->id,$role_user)): ?> 
												<?php echo e(Form::checkbox('roleid[]', $roles->id, true,array('disabled'))); ?>

											<?php else: ?>
												<?php echo e(Form::checkbox('roleid[]', $roles->id, false,array('disabled'))); ?>

											<?php endif; ?>
										<?php else: ?>
											<?php echo e(Form::checkbox('roleid[]', $roles->id, false,array('disabled'))); ?>		
										<?php endif; ?>

									</div>		        
									<div class="col-md-8">
										<?php echo e($roles->display_name); ?>

									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>