<?php $__env->startSection('title'); ?>
<?php echo e(trans('company.header-update')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
<link href="<?php echo asset('css/common/text.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/common/layout_responsive.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company.css'); ?>" rel="stylesheet">
<link href="<?php echo asset('css/site/gaia/company_responsive.css'); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<form id="editcompany" method="POST"> 
	<div class="row text-setting company">
		<div class="panel panel-default add">
			<div class="panel-heading layout-bg-title">
				<div class="row">
					<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
						<h4 class="text-title"><b><?php echo e(trans('company.title')); ?></b></h4>
					</div>
				</div>
			</div>  
			<div class="panel-body layout-border content">	
				<?php echo $__env->make('site.message.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="layout-child-panel">
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('companyName', $company->CompanyName, ['class'=>'form-control']); ?></div>    
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.furigana-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('furiganaName', $company->FuriganaName, ['class'=>'form-control']); ?></div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.postal-code')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo Form::text('postalCode', $company->PostalCode, ['class'=>'form-control zip-code','onKeyUp'=>"AjaxZip3.zip2addr(this, '', 'prefecturalName', 'municipalName');"]); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.prefectural-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('prefecturalName', $company->PrefecturalName, ['class'=>'form-control']); ?></div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.municipal-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('municipalName', $company->MunicipalName, ['class'=>'form-control']); ?></div>
					</div>				
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.detail-address')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('detailAddress', $company->DetailAddress, ['class'=>'form-control']); ?></div>		
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.tel')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('phoneNumber', $company->PhoneNumber, ['class'=>'form-control phone-number', 'required' => 'required']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.fax')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('faxNumber', $company->FaxNumber, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.head-office')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('headOffice', $subcompany->HeadOffice, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.capital-stock')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('capitalStock', $subcompany->CapitalStock, ['class'=>'form-control']); ?></div>				
					</div>			
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.employee-number')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('employeeNumber', $subcompany->EmployeeNumber, ['class'=>'form-control']); ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.ceo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('pepresentativeName', $company->PepresentativeName, ['class'=>'form-control', 'required' => 'required']); ?></div>
					</div>						
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-name-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsibleName', $company->ResponsiblePersonNameHaken, ['class'=>'form-control']); ?></div>			
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-position-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsiblePosition', $company->ResponsiblePersonPositionHaken, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.responsible-person-phone-number-haken')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('responsiblePhone', $company->ResponsiblePersonPhoneNumberHaken, ['class'=>'form-control phone-number']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainName', $company->ChainCommandName, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-position')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainPosition', $company->ChainCommandPosition, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.chain-command-contact')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('chainPhone', $company->ChainCommandPhoneNumber, ['class'=>'form-control phone-number']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.establishment-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<div class="form-group">
								<div class='input-group date' id='datetimepicker_establishmentdate'>
									<?php echo Form::text('establishmentDate', $subcompany->EstablishmentDate, ['class'=>'form-control']); ?>

									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>	
							</div>			
						</div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer-bank')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('mainCustomerBank', $subcompany->MainCustomerBank, ['class'=>'form-control']); ?></div>				
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.lastyear-suppliers')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('lastYearSuppliers', $subcompany->LastYearSuppliers, ['class'=>'form-control']); ?></div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.main-customer')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('mainCustomer', $subcompany->MainCustomer, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.basic-contract-date')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<div class="form-group">
								<div class='input-group date' id='datetimepicker_contractdate'>
									<?php echo Form::text('contractDate', $company->ContractDate, ['class'=>'form-control']); ?>

									<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
									</span>
								</div>	
							</div>			
						</div>
					</div>
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.company-memo')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::textarea('companyMemo', $subcompany->CompanyMemo, ['class'=>'form-control', 'required' => 'required']); ?></div>	
					</div>				
					<div class="row">
						<div class="col-lg-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 col-sm-4 col-xs-4 required-star"><?php echo e(trans('company.title-content.person-charge')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('personCharge', $company->PersonCharge, ['class'=>'form-control', 'required' => 'required']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.department-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8"><?php echo Form::text('departmentName', $company->DepartmentName, ['class'=>'form-control']); ?></div>	
					</div>
					<div class="row">
						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4"><?php echo e(trans('company.title-content.offical-name')); ?></div>
						<div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
							<?php echo e(Form::radio('officialName', '1', $subcompany->OfficialName == 1 ? true: false)); ?>

							<?php echo e(trans('company.radio.regular')); ?>

							<?php echo e(Form::radio('officialName', '0', $subcompany->OfficialName == 0 ? true: false)); ?>

							<?php echo e(trans('company.radio.deputy')); ?>

						</div>	
					</div>
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
							<button type="submit" class="btn btn-primary" id="btnsubmit"><?php echo e(trans('common.button.update')); ?></button>
							<a href="<?php echo e(route('listcompany')); ?>" class="btn btn-primary"><?php echo e(trans('common.button.cancel')); ?></a>
						</div>
					</div>
				</div>
			</div>		
		</div>
	</div>
	<input type="hidden" name="sections" id="sections" value="1">
	<input type="hidden" name="lstPaymentUpdate" id="lstPaymentUpdate" value="1,">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_js'); ?>
<!-- <script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/moment.js'); ?>"></script> -->
<script type="text/javascript" src="<?php echo asset('plugins/bootstrap/js/bootstrap-datetimepicker.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/validate/jquery.validate.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/jquery/jquery.session.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('js/site/gaia/company_datetime.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('plugins/ajax_zip3/ajax_zip3.min.js'); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>