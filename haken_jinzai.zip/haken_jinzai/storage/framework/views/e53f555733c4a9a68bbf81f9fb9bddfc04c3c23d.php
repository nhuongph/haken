<?php if(session()->has('errors')): ?>
    <div class="alert alert-danger" role="alert" >
        <?php foreach($errors as $error): ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert" >
        <?php foreach(session()->get('success') as $message): ?>
            <p><?php echo e($message); ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>