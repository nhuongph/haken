
<table id="GaiAUserList" class="table table-bordered table-responsive">
	<thead>
		<tr>
			<th width="20%" class="text-center"><?php echo e(trans('title.GaiA.name')); ?></th>
			<th width="30%" class="text-center"><?php echo e(trans('title.GaiA.authority')); ?></th>
			<th width="15%" class="text-center"><?php echo e(trans('title.GaiA.department')); ?></th>
			<th class="text-center"></th>
		</tr>
	</thead>
	<?php if($message ==""): ?>                               
		<?php foreach($listGaiaMember as $gaiaMember): ?>
		<tr>
			<td class="text-center"><?php echo e($gaiaMember->Firstname .' '. $gaiaMember->Lastname); ?></td>                                    
			<td class="text-center">
				<?php $roleName = $userBusiness->getRoleNameByUserId($gaiaMember->id); ?>     

				<?php if(count($roleName) > 0): ?>
				<?php foreach($roleName as $name): ?>
				<?php echo e($name); ?> <br>
				<?php endforeach; ?>
				<?php endif; ?>                                        
			</td>
			<td class="text-center"><?php echo e($gaiaMember->Part); ?></td>
			<td class="text-center">
				<div class="button-group text-center">
					<a href="<?php echo e(route('employee/detail', ['userId'=>$gaiaMember->id])); ?>" class="btn btn-primary btn-lg"><?php echo e(trans('title.action.detail')); ?></a>
					<a href="javascript: void(0)" class="btn btn-primary btn-lg delete-btn" data-id="<?php echo $gaiaMember->id; ?>"><?php echo e(trans('title.action.delete')); ?></a>
				</div>
			</td>
		</tr>
		<?php endforeach; ?>
	<?php else: ?>
		<tr>
			<td colspan="4" class="text-center"><?php echo e($message); ?></td>
		</tr>
	<?php endif; ?>
</table>
<?php echo e($listGaiaMember->links()); ?>