<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.report.index')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules">
                    ブランド登録
                    
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                         <div class="basic-form">
                            <?php echo Form::open(['id'=> 'basicForm', 'class' => 'form-horizontal']); ?>

                            	<div class="menu-update-user">
                                    <div class="update-pw-return col-md-2">
                                        <a href="/staff/info/<?php echo $user->id;?>">戻る</a></div>
                                    <div class="col-md-12 menu-update-user-bottom">
                                    	変更が必要な箇所を指定してください
                                    </div>
                                
                                    <div class="col-md-12 menu-update-user-bottom">
                                    	<select name="selectbox" class="form-control">
                                    		 <option class="form-control" value="郵便番号、住所、最寄駅">郵便番号、住所、最寄駅</option>
                                    		 <option class="form-control" value="姓">姓</option>
                                    		 <option class="form-control" value="電話番号、携帯電話番号、FAX番号">電話番号、携帯電話番号、FAX番号</option>
                                    		 <option class="form-control" value="email">email</option>
                                    		 <option class="form-control" value="パスワード">パスワード</option>
                                    	</select>
                                    </div>
                                    
                                   	<div class="col-md-12 menu-update-user-bottom">
                                   			変更する内容を記載してください。
                                   	</div>

                                   	<div class="col-md-12 menu-update-user-bottom">
                                   		<input type="text" name="password" class="form-control">
                                   	</div>
                                
                                
                                
		                            <div class="button-submit col-md-12">
		                            	<button class="btn btn-default btn-lg">変更申請</button>
		                            </div>
                                </div>
                           <?php echo Form::close(); ?>


                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>