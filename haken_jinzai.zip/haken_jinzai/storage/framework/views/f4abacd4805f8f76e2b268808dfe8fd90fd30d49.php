<?php $__env->startSection('title'); ?>
<?php echo e(trans('title.report.index')); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="row">
        
        <!-- /.col-lg-12 -->
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-default" style="margin-top:20px;">
                <div class="panel-heading panel-heading-rules" style="overflow:hidden">
                    <div class="col-md-10">入店報告設定</div>
                    <div class="col-md-2">戻る</div>
                </div>
                <div class="panel-body">
                    <div class="col-md-12 col-sm-12">
                        <?php echo $__env->make('site/message/index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                         <div class="basic-form">

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">時間帯別売上</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">年代別接客割合</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">販売数</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                    <a href="/report/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                            編集
                                        </button>
                                    </a>
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">販売数コメント</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                     <a href="/comment/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                           編集
                                        </button>
                                    </a>
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">サンプル配布</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                    <a href="/distribution/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                            編集
                                        </button>
                                    </a>
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">サンプル配布コメント</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                    <a href="/comment/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                            編集
                                        </button>
                                    </a>
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">接客内容</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                   
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">接客内容コメント</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                    <a href="/comment/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                            編集
                                        </button>
                                    </a>
                                </div>
                            </div>

                            <div class="box-1-report">
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-default btn-report">総合コメント</button>
                                </div>
                                <div class="col-md-4 report-inner">
                                    <input type="checkbox" name="demo">
                                    表示
                                </div>
                                <div class="col-md-2">
                                    <a href="/comment/new">
                                        <button type="button" class="btn btn-default btn-report-right">
                                            編集
                                        </button>
                                    </a>
                                </div>
                            </div>


                        </div>

                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site/layouts/main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>